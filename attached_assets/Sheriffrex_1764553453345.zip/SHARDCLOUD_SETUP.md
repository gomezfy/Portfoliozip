# Sheriff Rex Bot - ShardCloud Deployment Guide

## Quick Setup (5 minutos)

### 1. Prepare Your Discord Application
1. Go to https://discord.com/developers/applications
2. Create a new application (or use existing)
3. Go to "General Information" tab and copy:
   - **Application ID** → `DISCORD_CLIENT_ID`
   - **Client Secret** → `DISCORD_CLIENT_SECRET`
4. Go to "Bot" tab and copy:
   - **Token** → `DISCORD_TOKEN`

### 2. Setup Database
You need a PostgreSQL database. Options:
- **Neon** (recommended): https://neon.tech
  - Create account and new project
  - Copy connection string → `DATABASE_URL`
  - Format: `postgresql://user:password@host/database`

### 3. Configure ShardCloud
1. Login to https://shardcloud.app
2. Create new bot project
3. Connect your GitHub repository (this project)
4. In **Environment Variables**, add:

```
DISCORD_TOKEN=YOUR_BOT_TOKEN_HERE
DISCORD_CLIENT_ID=YOUR_APPLICATION_ID_HERE
DISCORD_CLIENT_SECRET=YOUR_CLIENT_SECRET_HERE
OWNER_ID=339772388566892546
DEV_GUILD_ID=YOUR_GUILD_ID_HERE
DATABASE_URL=YOUR_POSTGRESQL_URL_HERE
NODE_ENV=production
```

5. Click **Deploy** and wait for build to complete

### 4. Verify Deployment
- ✅ Bot should appear online in Discord
- ✅ Check ShardCloud logs for "All systems operational!"
- ✅ Try `/ping` command in your Discord server

## Environment Variables Explained

| Variable | Example | Description |
|----------|---------|-------------|
| `DISCORD_TOKEN` | `MTQzMjg4...` | Bot authentication token (KEEP SECRET!) |
| `DISCORD_CLIENT_ID` | `1432847343195263059` | Application ID from Discord Developer Portal |
| `DISCORD_CLIENT_SECRET` | `yS57oydWk1Wn...` | OAuth2 Secret (KEEP SECRET!) |
| `OWNER_ID` | `339772388566892546` | Your Discord user ID (admin access) |
| `DEV_GUILD_ID` | `1432849343995711581` | Your test server Guild ID |
| `DATABASE_URL` | `postgresql://...` | PostgreSQL connection string |
| `NODE_ENV` | `production` | Deployment environment |

## Troubleshooting

### Bot won't start
- ✓ Check all environment variables are filled
- ✓ Verify DATABASE_URL format (must start with `postgresql://`)
- ✓ Ensure bot token is valid and fresh

### Database connection error
- ✓ Copy entire DATABASE_URL without spaces
- ✓ Check firewall allows connections from ShardCloud
- ✓ Verify username/password are correct

### Commands not showing
- ✓ Bot is still loading (check logs for "Synced X commands")
- ✓ Wait 1-2 minutes for Discord cache to update
- ✓ Try `/` in Discord chat to refresh

## Auto-Restart Configuration
ShardCloud will automatically:
- ✅ Restart bot if it crashes
- ✅ Respawn shards if they disconnect
- ✅ Rebuild on GitHub push (if webhook enabled)
- ✅ Rotate logs after 7 days

## Scaling
The bot is configured to:
- Start with 1 shard (auto-scales if needed)
- Maximum 4 shards for large deployments
- Memory: 256MB per shard
- Auto-restart on crash with backoff strategy

## Need Help?
- Discord Developer Portal: https://discord.com/developers
- ShardCloud Docs: https://docs.shardcloud.app
- Bot Repository: https://github.com/gomezfy/Sheriffbot-
