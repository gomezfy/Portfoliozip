// Mock objects for testing Discord.js interactions
export const mockUser = () => ({
  id: 'test-user-id',
  tag: 'TestUser#0001',
  username: 'TestUser',
  bot: false,
} as any);

export const mockGuild = () => ({
  id: 'test-guild-id',
  name: 'Test Guild',
  memberCount: 100,
} as any);

export const mockMember = () => ({
  id: 'test-member-id',
  user: mockUser(),
  displayName: 'TestUser',
} as any);

export const mockInteraction = (overrides: any = {}) => ({
  id: 'test-interaction-id',
  commandName: 'test-command',
  user: mockUser(),
  guild: mockGuild(),
  member: mockMember(),
  reply: jest.fn().mockResolvedValue(undefined),
  deferReply: jest.fn().mockResolvedValue(undefined),
  editReply: jest.fn().mockResolvedValue(undefined),
  followUp: jest.fn().mockResolvedValue(undefined),
  ...overrides,
} as any);
