import {
  MAX_CURRENCY_AMOUNT,
  MAX_BET_AMOUNT,
  MAX_BOUNTY_AMOUNT,
} from '../../../src/utils/security';

describe('Security Constants', () => {
  it('should define reasonable currency limits', () => {
    expect(MAX_CURRENCY_AMOUNT).toBe(1_000_000_000);
    expect(MAX_BET_AMOUNT).toBe(10_000_000);
    expect(MAX_BOUNTY_AMOUNT).toBe(100_000_000);
  });

  it('should have bounty amount greater than bet amount', () => {
    expect(MAX_BOUNTY_AMOUNT).toBeGreaterThan(MAX_BET_AMOUNT);
  });

  it('should have bet amount less than currency limit', () => {
    expect(MAX_BET_AMOUNT).toBeLessThan(MAX_CURRENCY_AMOUNT);
  });
});
