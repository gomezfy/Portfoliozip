import { CooldownManager } from '../../../src/utils/cooldownManager';

describe('CooldownManager', () => {
  let manager: CooldownManager;

  beforeEach(() => {
    manager = new CooldownManager(1000);
  });

  it('should check cooldown status correctly', () => {
    const result = manager.check('daily', 'user123', 5000);
    expect(result.isOnCooldown).toBe(false);
  });

  it('should set and enforce cooldown', () => {
    manager.set('daily', 'user123', 5000);
    const result = manager.check('daily', 'user123', 5000);
    expect(result.isOnCooldown).toBe(true);
  });

  it('should return time left for active cooldown', () => {
    manager.set('daily', 'user123', 10000);
    const result = manager.check('daily', 'user123', 10000);
    expect(result.timeLeft).toBeGreaterThan(0);
  });
});
