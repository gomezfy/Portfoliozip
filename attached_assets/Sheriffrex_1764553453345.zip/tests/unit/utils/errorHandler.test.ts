import { BaseBotError, InsufficientFundsError, CooldownError, ValidationError } from '../../../src/utils/errors';

describe('Error Classes', () => {
  describe('BaseBotError', () => {
    it('should create error with message and code', () => {
      const error = new BaseBotError('Test error', 'TEST_CODE');
      expect(error.message).toBe('Test error');
      expect(error.code).toBe('TEST_CODE');
      expect(error.isOperational).toBe(true);
    });
  });

  describe('InsufficientFundsError', () => {
    it('should have correct code and message', () => {
      const error = new InsufficientFundsError('Not enough gold');
      expect(error.message).toBe('Not enough gold');
      expect(error.code).toBe('INSUFFICIENT_FUNDS');
    });
  });

  describe('CooldownError', () => {
    it('should store remaining time', () => {
      const error = new CooldownError('Command on cooldown', 30);
      expect(error.remainingTime).toBe(30);
      expect(error.code).toBe('COOLDOWN_ACTIVE');
    });
  });

  describe('ValidationError', () => {
    it('should be created with message', () => {
      const error = new ValidationError('Invalid input');
      expect(error.message).toBe('Invalid input');
      expect(error.code).toBe(undefined);
    });
  });
});
