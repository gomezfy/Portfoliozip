describe('Ping Command', () => {
  it('should respond to ping', () => {
    const response = 'Pong! 🏓';
    expect(response).toBeDefined();
  });

  it('should have valid ping time', () => {
    const ping = 45;
    expect(ping).toBeGreaterThan(0);
    expect(ping).toBeLessThan(200);
  });
});
