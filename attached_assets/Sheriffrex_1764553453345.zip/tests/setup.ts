/// <reference types="jest" />

// Mock environment variables for tests
process.env.DISCORD_TOKEN = 'test-token-123';
process.env.DISCORD_CLIENT_ID = 'test-client-id';
process.env.OWNER_ID = 'test-owner-id';
process.env.DATABASE_URL = 'postgresql://test:test@localhost/test';
process.env.NODE_ENV = 'test';
