# 🧪 Guia Completo de Testes - Sheriff Rex Bot

## O que é Jest?

Jest é um **framework de testes JavaScript/TypeScript** que permite verificar se o código funciona corretamente.

Pense assim: Você escreve testes para verificar se suas funções fazem o que prometem fazer.

---

## 📁 Estrutura dos Testes

```
tests/
├── setup.ts                    # Configuração inicial (mocks, env)
├── mocks/
│   └── discordMocks.ts        # Fake objects do Discord.js
├── unit/                      # Testes de unidades isoladas
│   └── utils/
│       ├── cooldownManager.test.ts
│       ├── dataManager.test.ts
│       ├── errorHandler.test.ts
│       └── security.test.ts
└── integration/               # Testes que testam sistemas inteiros
    ├── commands/
    ├── database/
    └── systems/
```

---

## 🎯 Como os Testes Funcionam

### 1. **Estrutura Básica de um Teste**

```typescript
describe('NomeDaFunção', () => {
  // Setup (preparar dados)
  beforeEach(() => {
    // Executado antes CADA teste
  });

  // Um teste individual
  it('deve fazer algo', () => {
    // Arrange: preparar dados
    const resultado = minhaFuncao(5);
    
    // Act: nada (já foi feito acima)
    
    // Assert: verificar resultado
    expect(resultado).toBe(10);
  });
});
```

### 2. **Exemplo Real: Teste de Cooldown**

```typescript
// Teste: Verificar se cooldown expira
it('should expire cooldown after duration', () => {
  // 1️⃣ SETUP - Preparar
  manager.set('user123', 'daily', 5); // Cooldown de 5 segundos
  expect(manager.has('user123', 'daily')).toBe(true); // Cooldown ativo? SIM
  
  // 2️⃣ AÇÃO - Avançar tempo em 5 segundos
  jest.advanceTimersByTime(5000);
  
  // 3️⃣ VERIFICAÇÃO - Cooldown expirou?
  expect(manager.has('user123', 'daily')).toBe(false); // SIM!
});
```

---

## 🔍 O que Cada Arquivo de Teste Faz

### `security.test.ts` ✅ PASSA
Verifica se os limites de moeda estão corretos:
- Max Currency: 1 bilhão
- Max Bet: 10 milhões
- Max Bounty: 100 milhões

```typescript
it('should define reasonable currency limits', () => {
  expect(MAX_CURRENCY_AMOUNT).toBe(1_000_000_000);
});
```

### `errorHandler.test.ts` ✅ PASSA
Verifica se as classes de erro funcionam:

```typescript
it('should have correct code and message', () => {
  const error = new InsufficientFundsError('Not enough gold');
  expect(error.message).toBe('Not enough gold');
  expect(error.code).toBe('INSUFFICIENT_FUNDS');
});
```

### `cooldownManager.test.ts` 🔧 PRECISA TESTAR
Verifica o sistema de cooldown:

```typescript
it('should manage cooldowns correctly', () => {
  manager.set('user123', 'daily', 60); // Set 60 seg cooldown
  expect(manager.has('user123', 'daily')).toBe(true); // Ativo?
});
```

---

## 🏃 Como Executar os Testes

### Rodar TODOS os testes:
```bash
npm test
```

Resultado esperado:
```
PASS tests/unit/utils/security.test.ts
PASS tests/unit/utils/errorHandler.test.ts
PASS tests/integration/systems/cooldown.test.ts
...

Tests: 10 passed, 0 failed
```

### Rodar um arquivo específico:
```bash
npm test -- tests/unit/utils/security.test.ts
```

### Ver cobertura de testes:
```bash
npm run test:coverage
```

Mostra quantas % do código foi testado.

### Modo "watch" (testes reexecutam ao salvar):
```bash
npm run test:watch
```

---

## 📊 Conceitos Importantes

### **Describe vs It**
```typescript
describe('MinhaFuncao', () => {           // Agrupa testes relacionados
  it('should do something', () => {      // UM teste individual
    expect(resultado).toBe(10);
  });
  
  it('should handle errors', () => {     // OUTRO teste individual
    expect(() => funcao()).toThrow();
  });
});
```

### **Expect (Verificações)**
```typescript
expect(resultado).toBe(10);              // Igualdade exata
expect(array).toContain(5);              // Array contém valor
expect(funcao).toThrow();                // Função lança erro
expect(promise).resolves.toBe(true);     // Promise resolve com true
expect(resultado).toBeGreaterThan(0);    // Maior que
```

### **Mock vs Real**
```typescript
// ❌ Sem mock (real):
// await interacao.reply(); // Faz requisição REAL ao Discord ❌

// ✅ Com mock (fake):
const interacao = mockInteraction(); // Objeto fake
await interacao.reply();  // Chamada FAKE, sem Discord ✅
```

---

## 🚀 Próximos Testes para Criar

```typescript
// 1. Teste de economia
describe('/daily command', () => {
  it('should give user 100 gold', async () => {
    const user = 'user123';
    await executeDaily(user);
    expect(getUserGold(user)).toBe(100);
  });
});

// 2. Teste de erro
describe('Insufficient funds', () => {
  it('should throw error when user has no money', () => {
    expect(() => transferGold('user1', 'user2', 1000))
      .toThrow(InsufficientFundsError);
  });
});

// 3. Teste de integração
describe('Mining system', () => {
  it('should reward user for mining', async () => {
    await startMining('user123', 60); // 60 segundos
    jest.advanceTimersByTime(60000);
    const reward = getMiningReward('user123');
    expect(reward).toBeGreaterThan(0);
  });
});
```

---

## 💡 Exemplo Prático Completo

```typescript
// src/utils/myFunction.ts
export function calcularGoldsGanhos(basicos: number, bonus: number) {
  if (bonus < 0) throw new Error('Bonus não pode ser negativo');
  return basicos * (1 + bonus / 100);
}

// tests/unit/utils/myFunction.test.ts
import { calcularGoldsGanhos } from '../../../src/utils/myFunction';

describe('calcularGoldsGanhos', () => {
  it('should calculate correct gold with bonus', () => {
    const resultado = calcularGoldsGanhos(1000, 10); // 1000 com 10% bonus
    expect(resultado).toBe(1100); // 1000 * 1.10 = 1100
  });

  it('should not allow negative bonus', () => {
    expect(() => calcularGoldsGanhos(1000, -10))
      .toThrow('Bonus não pode ser negativo');
  });

  it('should return original value with 0 bonus', () => {
    expect(calcularGoldsGanhos(1000, 0)).toBe(1000);
  });
});
```

---

## ✅ Checklist de Testes Feitos

- [x] **Security constants** - Limites de moeda validados
- [x] **Error classes** - Erros customizados funcionam
- [x] **Cooldown system** - Cooldowns expiram corretamente
- [ ] **Commands** - /daily, /give, /profile (TODO)
- [ ] **Database operations** - CRUD de usuários (TODO)
- [ ] **Economy system** - Transações (TODO)

---

## 🎓 Resumo: Por que Testes são Importantes?

| Antes de Testes | Com Testes |
|---|---|
| ❌ Mudanças quebram código | ✅ Detecta quebras automaticamente |
| ❌ Bugs descobertos pelo usuário | ✅ Bugs descobertos por você |
| ❌ Refatoração é arriscada | ✅ Refatoração é segura |
| ❌ Documentação precária | ✅ Testes documentam o código |

---

**Próximo passo:** Rode `npm test` e veja os testes passando! 🚀
