# Sheriff Rex Bot - Project Status

## 📋 Overview
Western-themed Discord bot with comprehensive economy system for Portuguese-speaking users. Built with Discord.js v14, TypeScript, and PostgreSQL via Neon.

**Status:** ✅ Production-Ready | **Deployment:** ShardCloud.app | **Version:** 1.0.0

---

## 🎯 Core Features (68 Commands)
- **Economy:** Daily rewards, bounties, leaderboards, transactions
- **Activities:** Hunting, fishing, mining (with loadingUX), gaming (dice/roulette/poker)
- **RPG:** Guilds, territories, health/stamina/hunger system, bleeding mechanics
- **Gangs:** ⭐ NEW - Gang system with hierarchical roles, treasury, leveling (1-15), donation XP
- **Gang Boosts:** Crime success +5-7%, Duel damage +3-5, Bank robbery rewards +5-10%
- **Admin:** Permission system (Admin/Mod/Staff/Moderador roles), event management
- **AI:** Google Generative AI integration for roleplay
- **Payment:** Stripe integration for premium features

---

## 🛠️ Recent Updates (Nov 30, 2025)

### ✅ Completed - Automatic Translation System (PT-BR / EN-US)
- **Translation Pattern:** `getLocale(interaction)` + `isPtBr ? "PT text" : "EN text"`
- **Translated Commands:** fish, hunterstore, saude, rexbucks, sell, team-capture
- **Features:**
  - Auto-detects user's Discord language setting
  - Falls back to EN-US if locale not recognized
  - Custom emoji IDs preserved in all translations
  - All user-facing strings translated (embeds, menus, buttons, errors)
- **Data Structures Updated:** Added `nameEn` / `rarityEn` fields to item interfaces
- **Build Status:** ✅ Compiles successfully, 61 commands synced with Discord

### ✅ Completed - Gang System (Dec Round)
- **Gang Database Schema:** 3 new tables (bot_gangues, bot_gangue_membros, bot_gangue_convites)
- **Gang Manager:** 400+ lines with full CRUD operations, XP/level system, boost calculations
- **Command `/gangue`:** 12 subcommands (criar, info, convidar, aceitar, convites, doar, promover, sair, expulsar, dissolver)
- **Gang Boosts Integration:** Crime (+%), Duel damage (+), Bank robbery (+%)
- **Hierarchical Roles:** Líder 1 (founder), Líder 2 (vice-leader), Veterano (veteran), Membro Regular (member)
- **Features:** Invite system (24h expiry), shared treasury, donation tracking, 30-member limit
- **Build Status:** ✅ TypeScript compilation successful, 0 LSP errors

### Previous Updates (Nov 28, 2025)
- Modernized logging system (`modernLogger.ts`) with ANSI colors, data masking, timestamps
- Unified environment variables (`DISCORD_CLIENT_ID` - removed redundant `CLIENT_ID`)
- Created ShardCloud deployment config (`.shardcloud.yml`, `Procfile`, guide)
- Fixed bleeding system error handling (graceful degradation on DB connection errors)

### 📊 Code Metrics
- **Total Lines:** ~32k lines TypeScript
- **Commands:** 68 command files (56+ synced with Discord)
- **New Files:** `src/utils/gangueManager.ts` (500 lines), `src/commands/guild/gangue.ts` (450 lines)
- **Modified Files:** `shared/schema.ts`, `crime.ts`, `duel.ts`, `bankrob.ts`
- **Build:** `npm run build` (tsc + tsc-alias) ✅ SUCCESS
- **Startup:** `npm run start` (node with 1800MB heap) ✅ RUNNING

---

## 🚀 Deployment Guide

### Option 1: ShardCloud.app (Recommended)
```
1. Push code to GitHub (includes Procfile & .shardcloud.yml)
2. Connect repo to ShardCloud
3. Set environment variables:
   - DISCORD_TOKEN (from Discord Dev Portal)
   - DISCORD_CLIENT_ID (Application ID)
   - DISCORD_CLIENT_SECRET
   - OWNER_ID=339772388566892546
   - DEV_GUILD_ID (your test server)
   - DATABASE_URL (PostgreSQL connection)
   - NODE_ENV=production
4. Deploy & monitor logs
```

### Option 2: Production Server
- Requires Node.js 18+
- `npm install && npm run build && npm run start`
- Set environment variables before startup
- Requires PostgreSQL database

---

## 📦 Dependencies
- **discord.js:** 14.24.2 (latest with slash commands)
- **drizzle-orm:** 0.44.7 (TypeScript ORM)
- **@neondatabase/serverless:** 1.0.2 (PostgreSQL Neon client)
- **TypeScript:** 5.9.3, Node 22.17.1
- **Other:** stripe, google-generative-ai, canvas, axios, ws, node-cron

---

## 🔧 Scripts
```bash
npm run start           # Production: run compiled bot
npm run dev            # Development: run with ts-node
npm run build          # Compile TypeScript → dist/
npm run build:prod     # Build + lint + deploy
npm run deploy         # Sync slash commands with Discord
npm run lint           # Check code quality (ESLint)
npm run format         # Format code (Prettier)
npm run db:push        # Migrate schema to database
```

---

## 🗂️ Project Structure
```
src/
├── index.ts               # Main bot entry point (modernLogger integrated)
├── shard.ts              # Sharding manager (for 10k+ users)
├── commands/
│   ├── guild/
│   │   ├── gangue.ts     # 🆕 Gang system command (12 subcommands)
│   │   └── [other guild commands]
│   ├── crime/
│   │   └── crime.ts      # Updated with gang boosts
│   ├── gambling/
│   │   ├── duel.ts       # Updated with gang damage boosts
│   │   └── bankrob.ts    # Updated with gang reward boosts
│   └── [68 total slash command files]
├── events/               # 9 Discord event handlers
├── utils/
│   ├── modernLogger.ts   # Professional logging system with ANSI colors
│   ├── gangueManager.ts  # 🆕 Gang system manager (500 lines)
│   ├── database.ts       # Drizzle ORM setup
│   ├── bleedingSystem.ts # Health/bleeding mechanics
│   ├── permissionManager.ts
│   ├── cooldownManager.ts
│   └── [40+ utility files]
├── server/
│   ├── db.ts            # Database connection
│   └── schema.ts         # Drizzle schema (includes 3 new gang tables)
└── features/            # Additional feature commands
```

---

## 🔐 Environment Variables Required
| Variable | Example | Required |
|----------|---------|----------|
| DISCORD_TOKEN | `MTQzMjg4...` | ✅ |
| DISCORD_CLIENT_ID | `1432847343195263059` | ✅ |
| DISCORD_CLIENT_SECRET | `yS57oydWk1Wn...` | ✅ |
| OWNER_ID | `339772388566892546` | ✅ |
| DEV_GUILD_ID | `1432849343995711581` | ✅ |
| DATABASE_URL | `postgresql://...` | ✅ |
| NODE_ENV | `production` | ✅ |
| GOOGLE_API_KEY | [optional] | AI features |

---

## 🎨 Modern Logger Features
```typescript
modernLogger.banner("Title")              // Large banner
modernLogger.section("Section Name")      // Section divider
modernLogger.info("Message")              // ℹ️ Info
modernLogger.success("Success message")   // ✅ Success
modernLogger.warn("Warning")              // ⚠️ Warning
modernLogger.error("Error", error)        // ❌ Error
modernLogger.debug("Debug info")          // Debug
modernLogger.table({key: value})          // Formatted table
modernLogger.divider()                    // Visual divider
```

**Features:**
- ✅ ANSI colors (green/red/cyan/yellow)
- ✅ Automatic sensitive data masking (tokens, DATABASE_URL)
- ✅ ISO timestamps [HH:MM:SS]
- ✅ Context tags (database, auth, commands)
- ✅ Structured output for production

---

## 🐛 Known Issues & Solutions
| Issue | Cause | Solution |
|-------|-------|----------|
| DATABASE_URL Invalid | Malformed PostgreSQL string | Verify URL format: `postgresql://user:pass@host/db` |
| Bot won't start | Missing env variables | Ensure all 7 required vars are set |
| Commands not syncing | Discord rate limit | Wait 1-2 minutes & try `/ping` |
| Memory warnings | Large cache in low-memory env | Use `npm run start:low-memory` |

---

## 📝 User Preferences
- 🇵🇹 **Language:** Portuguese (all interactions in PT-BR)
- 🎯 **Deployment:** Prioritize ShardCloud.app setup
- 🔒 **Security:** Automatic token masking in logs, environment-based config

---

## 🏴 Gang System Details

### Database Schema
```typescript
// bot_gangues: Main gang data
- id: UUID
- serverId: Text
- nome: Text (unique per server)
- level: 1-15 (based on xpTotal)
- xpTotal: Integer (progression counter)
- tesouroPrata/Ouro: Treasury balances
- maxMembros: Default 30 limit

// bot_gangue_membros: Gang membership
- cargo: lider_1 | lider_2 | veterano | membro_regular
- doadoPrata/Ouro: Individual donation tracking
- ultimoConvite: Rate limit for Veterano invites

// bot_gangue_convites: Pending invitations
- status: pendente | aceito | recusado
- expiraEm: 24-hour expiry
```

### Gang Boosts Formula (Level-based)
```
Level 1-5:   Crime +1-3%, Duel +0-1 dmg, Bankrob +0-2%
Level 6-10:  Crime +4-5%, Duel +2-3 dmg, Bankrob +3-5%
Level 11-15: Crime +6-7%, Duel +4-5 dmg, Bankrob +7-10%
```

### Command Permissions
- **Líder 1:** Create/dissolve gang, promote/demote, expel members
- **Líder 2:** Invite members, promote to Veterano, expel lower ranks
- **Veterano:** Invite members (1x/24h), donate to treasury
- **Membro Regular:** Donate to treasury, view gang info

---

## ✨ Next Improvements (Future)
- [ ] Gang wars/territory control (tie-in with existing territory system)
- [ ] Gang shop (purchase items with shared treasury)
- [ ] Gang history/activity log
- [ ] Gang statistics (crimes completed, total donations)
- [ ] Redis caching layer for gang operations
- [ ] Web dashboard for gang management
- [ ] Seasonal gang competitions/leaderboards

---

**Last Updated:** November 30, 2025 @ 22:45 UTC
**Maintainer:** Sheriff Bot Development Team
