<:Skull_outlaw:1444366422238298162> **Bem-vindo ao Sistema de Gangues!**

Cansado de vagar sozinho pelo Velho Oeste? Una-se com outros vaqueiros e forme sua **gangue lendária**!

---

## <:scroll_west:1440185935852605564> O QUE SÃO GANGUES?

Organizações de jogadores que conquistam o Velho Oeste juntos. Quanto mais forte sua gangue, maiores os benefícios!

---

## <:dart_west:1440185961081212978> COMO COMEÇAR

**1️⃣ Criar:** `/gangue criar [nome]` - Você será o **Líder Supremo** <:trophy_west:1440185971210453023>

**2️⃣ Convidar:** `/gangue convidar [usuário]` - Traga seus amigos!

**3️⃣ Info:** `/gangue info` - Veja nível, tesouro e benefícios

---

## <:trophy_west:1440185971210453023> NÍVEIS (1-15)

Sua gangue ganha **XP** com doações. Cada nível traz mais poder!

| Nível | Crime | Duelo | Assalto | Cooldown |
|-------|-------|-------|---------|----------|
| 1-5 | +1-3% | +0-1 dmg | +0-2% | 0-2% |
| 6-10 | +4-5% | +2-3 dmg | +3-5% | 3-5% |
| 11-15 | +6-7% | +4-5 dmg | +7-10% | 7-10% |

---

## <:gem_west:1440185978118737960> 4 BENEFÍCIOS ATIVOS

<:el_sombra:1444363376636461209> **Crime Boost** - +7% sucesso (nv15)
<:showds_rex:1441099823016181881> **Duel Damage** - +5 dano (nv15)
<:bank_west:1440185974507175947> **Bankrob Boost** - +10% prata (nv15)
<:timer:1440185990328356955> **Cooldown Reduction** - -10% espera (nv15)

---

## <:cowboys:1440185993792716910> HIERARQUIA

| Cargo | Permissões |
|-------|-----------|
| <:trophy_west:1440185971210453023> **Líder Supremo** | Criar/dissolver, promover, expulsar |
| <:star_west:1440185917645262928> **Líder** | Convidar, promover Veteranos |
| <:silver_medal:1440185928533672039> **Veterano** | Convidar 1x/dia, doar |
| <:cowboy:1440185964684378163> **Membro** | Doar, aproveitar benefícios |

---

## <:moneybag_west:1440185945478398072> TESOURO

Doe prata <:silver_coin:1440185957675438080> e ouro <:gold_bar:1440185933722030162>:
```
/gangue doar prata:[valor] ouro:[valor]
```

---

## <:lightning:1440185979599065179> COMANDOS

```
/gangue criar [nome]      → Crie sua gangue
/gangue info              → Ver informações
/gangue convidar [user]   → Convidar membro
/gangue aceitar [nome]    → Aceitar convite
/gangue doar [p] [o]      → Doar recursos
/gangue promover [user]   → Mudar cargo
/gangue expulsar [user]   → Expulsar
/gangue sair              → Sair da gangue
/gangue dissolver         → Dissolver (Líder)
```

---

<:info:1440185969537191978> Monte sua gangue e domine o Velho Oeste! <:revolver:1440185930311798967>
