import { pgTable, text, varchar, integer, boolean, timestamp, jsonb, real, unique } from 'drizzle-orm/pg-core';
import { relations } from 'drizzle-orm';

export const userSessions = pgTable("user_sessions", {
  sid: varchar("sid").primaryKey(),
  sess: jsonb("sess").notNull(),
  expire: timestamp("expire").notNull(),
});

export const users = pgTable('bot_users', {
  userId: text('user_id').primaryKey(),
  username: text('username').notNull(),
  
  gold: integer('gold').notNull().default(0),
  silver: integer('silver').notNull().default(0),
  saloonTokens: integer('saloon_tokens').notNull().default(0),
  bank: integer('bank').notNull().default(0),
  rexBucks: integer('rex_bucks').notNull().default(0),
  
  level: integer('level').notNull().default(1),
  xp: integer('xp').notNull().default(0),
  lastMessage: timestamp('last_message'),
  
  lastClaimDaily: timestamp('last_claim_daily'),
  dailyStreak: integer('daily_streak').notNull().default(0),
  
  customBackground: text('custom_background'),
  isVip: boolean('is_vip').notNull().default(false),
  badges: jsonb('badges').notNull().default([]),
  
  gamesPlayed: integer('games_played').notNull().default(0),
  bountiesCaptured: integer('bounties_captured').notNull().default(0),
  miningSessions: integer('mining_sessions').notNull().default(0),
  totalEarnings: integer('total_earnings').notNull().default(0),
  totalSpent: integer('total_spent').notNull().default(0),
  
  language: text('language').notNull().default('pt-BR'),
  showStats: boolean('show_stats').notNull().default(true),
  privateProfile: boolean('private_profile').notNull().default(false),
  
  backpackCapacity: integer('backpack_capacity').notNull().default(100),
  lastMiningTime: timestamp('last_mining_time'),
  totalMined: integer('total_mined').notNull().default(0),
  
  health: integer('health').notNull().default(100),
  maxHealth: integer('max_health').notNull().default(100),
  stamina: integer('stamina').notNull().default(100),
  maxStamina: integer('max_stamina').notNull().default(100),
  thirst: integer('thirst').notNull().default(100),
  maxThirst: integer('max_thirst').notNull().default(100),
  hunger: integer('hunger').notNull().default(100),
  maxHunger: integer('max_hunger').notNull().default(100),
  blood: integer('blood').notNull().default(100),
  maxBlood: integer('max_blood').notNull().default(100),
  temperature: integer('temperature').notNull().default(37),
  
  isBleeding: boolean('is_bleeding').notNull().default(false),
  bleedingAmount: integer('bleeding_amount').notNull().default(0),
  
  createdAt: timestamp('created_at').notNull().defaultNow(),
  updatedAt: timestamp('updated_at').notNull().defaultNow(),
});

export const inventoryItems = pgTable('bot_inventory_items', {
  id: text('id').primaryKey(),
  userId: text('user_id').notNull().references(() => users.userId, { onDelete: 'cascade' }),
  itemId: text('item_id').notNull(),
  name: text('name').notNull(),
  quantity: real('quantity').notNull().default(1),
  weight: real('weight').notNull(),
  value: integer('value').notNull(),
  type: text('type').notNull(),
  createdAt: timestamp('created_at').notNull().defaultNow(),
}, (table) => ({
  userItemUnique: unique().on(table.userId, table.itemId),
}));

export const bounties = pgTable('bot_bounties', {
  id: text('id').primaryKey(),
  targetId: text('target_id').notNull().references(() => users.userId, { onDelete: 'cascade' }),
  issuerId: text('issuer_id').references(() => users.userId, { onDelete: 'cascade' }),
  amount: integer('amount').notNull(),
  reason: text('reason').notNull(),
  timestamp: timestamp('timestamp').notNull().defaultNow(),
  active: boolean('active').notNull().default(true),
});

export const activeMining = pgTable('bot_active_mining', {
  id: text('id').primaryKey(),
  userId: text('user_id').notNull().references(() => users.userId, { onDelete: 'cascade' }),
  startTime: timestamp('start_time').notNull(),
  duration: integer('duration').notNull(),
  type: text('type').notNull(),
  participants: jsonb('participants'),
  expectedRewards: integer('expected_rewards').notNull(),
});

export const territories = pgTable('bot_territories', {
  id: text('id').primaryKey(),
  name: text('name').notNull(),
  ownerId: text('owner_id').references(() => users.userId, { onDelete: 'set null' }),
  controlledGuildId: text('controlled_guild_id'),
  income: integer('income').notNull().default(0),
  defenseLevel: integer('defense_level').notNull().default(1),
  lastIncomeTime: timestamp('last_income_time').notNull().defaultNow(),
});

export const punishments = pgTable('bot_punishments', {
  id: text('id').primaryKey(),
  userId: text('user_id').notNull().references(() => users.userId, { onDelete: 'cascade' }),
  reason: text('reason').notNull(),
  startTime: timestamp('start_time').notNull(),
  duration: integer('duration').notNull(),
  active: boolean('active').notNull().default(true),
});

export const playerGuilds = pgTable('bot_player_guilds', {
  id: text('id').primaryKey(),
  name: text('name').notNull().unique(),
  description: text('description').notNull(),
  leaderId: text('leader_id').notNull().references(() => users.userId, { onDelete: 'cascade' }),
  createdAt: timestamp('created_at').notNull().defaultNow(),
  level: integer('level').notNull().default(1),
  xp: integer('xp').notNull().default(0),
  maxMembers: integer('max_members').notNull().default(10),
  isPublic: boolean('is_public').notNull().default(true),
  requireApproval: boolean('require_approval').notNull().default(false),
});

export const guildMembers = pgTable('bot_guild_members', {
  id: text('id').primaryKey(),
  guildId: text('guild_id').notNull().references(() => playerGuilds.id, { onDelete: 'cascade' }),
  userId: text('user_id').notNull().references(() => users.userId, { onDelete: 'cascade' }),
  joinedAt: timestamp('joined_at').notNull().defaultNow(),
  role: text('role').notNull().default('member'),
});

export const guildJoinRequests = pgTable('bot_guild_join_requests', {
  id: text('id').primaryKey(),
  userId: text('user_id').notNull().references(() => users.userId, { onDelete: 'cascade' }),
  guildId: text('guild_id').notNull().references(() => playerGuilds.id, { onDelete: 'cascade' }),
  requestedAt: timestamp('requested_at').notNull().defaultNow(),
  status: text('status').notNull().default('pending'),
});

export const logs = pgTable('bot_logs', {
  id: text('id').primaryKey(),
  timestamp: timestamp('timestamp').notNull().defaultNow(),
  type: text('type').notNull(),
  guildId: text('guild_id').notNull(),
  userId: text('user_id'),
  details: jsonb('details').notNull(),
});

export const rexBuckTransactions = pgTable('bot_rex_buck_transactions', {
  id: text('id').primaryKey(),
  userId: text('user_id').notNull().references(() => users.userId, { onDelete: 'cascade' }),
  amount: integer('amount').notNull(),
  type: text('type').notNull(),
  redemptionCode: text('redemption_code'),
  balanceBefore: integer('balance_before').notNull(),
  balanceAfter: integer('balance_after').notNull(),
  metadata: jsonb('metadata'),
  timestamp: timestamp('timestamp').notNull().defaultNow(),
});

export const welcomeSettings = pgTable('bot_welcome_settings', {
  guildId: text('guild_id').primaryKey(),
  channelId: text('channel_id'),
  message: text('message'),
  enabled: boolean('enabled').notNull().default(false),
});

export const redemptionCodes = pgTable('bot_redemption_codes', {
  code: text('code').primaryKey(),
  productId: text('product_id').notNull(),
  productName: text('product_name').notNull(),
  tokens: integer('tokens').notNull().default(0),
  coins: integer('coins').notNull().default(0),
  rexBucks: integer('rex_bucks').notNull().default(0),
  vip: boolean('vip').notNull().default(false),
  background: boolean('background').notNull().default(false),
  backpack: integer('backpack'),
  createdAt: timestamp('created_at').notNull().defaultNow(),
  createdBy: text('created_by').notNull(),
  redeemed: boolean('redeemed').notNull().default(false),
  redeemedBy: text('redeemed_by'),
  redeemedAt: timestamp('redeemed_at'),
});

export const rexBuckPackages = pgTable('bot_rex_buck_packages', {
  id: text('id').primaryKey(),
  name: text('name').notNull(),
  description: text('description').notNull(),
  amountRexBucks: integer('amount_rexbucks').notNull(),
  bonusRexBucks: integer('bonus_rexbucks').notNull().default(0),
  priceCents: integer('price_cents').notNull(),
  currency: text('currency').notNull().default('BRL'),
  active: boolean('active').notNull().default(true),
  displayOrder: integer('display_order').notNull().default(0),
  createdAt: timestamp('created_at').notNull().defaultNow(),
  updatedAt: timestamp('updated_at').notNull().defaultNow(),
});

export const mercadoPagoPayments = pgTable('bot_mercadopago_payments', {
  id: text('id').primaryKey(),
  userId: text('user_id').notNull().references(() => users.userId, { onDelete: 'cascade' }),
  packageId: text('package_id').notNull().references(() => rexBuckPackages.id),
  externalReference: text('external_reference').notNull().unique(),
  preferenceId: text('preference_id'),
  mpPaymentId: text('mp_payment_id').unique(),
  status: text('status').notNull().default('pending'),
  amount: integer('amount').notNull(),
  currency: text('currency').notNull().default('BRL'),
  paidAt: timestamp('paid_at'),
  rawPayload: jsonb('raw_payload'),
  processed: boolean('processed').notNull().default(false),
  rexBuckTransactionId: text('rex_buck_transaction_id'),
  createdAt: timestamp('created_at').notNull().defaultNow(),
  updatedAt: timestamp('updated_at').notNull().defaultNow(),
});

export const usersRelations = relations(users, ({ many }) => ({
  inventoryItems: many(inventoryItems),
  issuedBounties: many(bounties, { relationName: 'issuer' }),
  targetedBounties: many(bounties, { relationName: 'target' }),
  activeMining: many(activeMining),
  territories: many(territories),
  punishments: many(punishments),
  guildMemberships: many(guildMembers),
  guildJoinRequests: many(guildJoinRequests),
  rexBuckTransactions: many(rexBuckTransactions),
}));

export const inventoryItemsRelations = relations(inventoryItems, ({ one }) => ({
  user: one(users, {
    fields: [inventoryItems.userId],
    references: [users.userId],
  }),
}));

export const bountiesRelations = relations(bounties, ({ one }) => ({
  target: one(users, {
    fields: [bounties.targetId],
    references: [users.userId],
    relationName: 'target',
  }),
  issuer: one(users, {
    fields: [bounties.issuerId],
    references: [users.userId],
    relationName: 'issuer',
  }),
}));

export const activeMiningRelations = relations(activeMining, ({ one }) => ({
  user: one(users, {
    fields: [activeMining.userId],
    references: [users.userId],
  }),
}));

export const territoriesRelations = relations(territories, ({ one }) => ({
  owner: one(users, {
    fields: [territories.ownerId],
    references: [users.userId],
  }),
}));

export const punishmentsRelations = relations(punishments, ({ one }) => ({
  user: one(users, {
    fields: [punishments.userId],
    references: [users.userId],
  }),
}));

export const playerGuildsRelations = relations(playerGuilds, ({ one, many }) => ({
  leader: one(users, {
    fields: [playerGuilds.leaderId],
    references: [users.userId],
  }),
  members: many(guildMembers),
  joinRequests: many(guildJoinRequests),
}));

export const guildMembersRelations = relations(guildMembers, ({ one }) => ({
  guild: one(playerGuilds, {
    fields: [guildMembers.guildId],
    references: [playerGuilds.id],
  }),
  user: one(users, {
    fields: [guildMembers.userId],
    references: [users.userId],
  }),
}));

export const guildJoinRequestsRelations = relations(guildJoinRequests, ({ one }) => ({
  user: one(users, {
    fields: [guildJoinRequests.userId],
    references: [users.userId],
  }),
  guild: one(playerGuilds, {
    fields: [guildJoinRequests.guildId],
    references: [playerGuilds.id],
  }),
}));

export const rexBuckTransactionsRelations = relations(rexBuckTransactions, ({ one }) => ({
  user: one(users, {
    fields: [rexBuckTransactions.userId],
    references: [users.userId],
  }),
}));

export const redemptionCodesRelations = relations(redemptionCodes, ({ one }) => ({
  redeemedByUser: one(users, {
    fields: [redemptionCodes.redeemedBy],
    references: [users.userId],
  }),
}));

export const characterSheets = pgTable('bot_character_sheets', {
  id: text('id').primaryKey(),
  userId: text('user_id').notNull().references(() => users.userId, { onDelete: 'cascade' }),
  name: text('name').notNull(),
  description: text('description'),
  backstory: text('backstory'),
  personality: text('personality'),
  appearance: text('appearance'),
  skills: jsonb('skills').notNull().default([]),
  traits: jsonb('traits').notNull().default([]),
  equipment: jsonb('equipment').notNull().default([]),
  isActive: boolean('is_active').notNull().default(true),
  createdAt: timestamp('created_at').notNull().defaultNow(),
  updatedAt: timestamp('updated_at').notNull().defaultNow(),
});

export const rpSessions = pgTable('bot_rp_sessions', {
  id: text('id').primaryKey(),
  guildId: text('guild_id').notNull(),
  channelId: text('channel_id').notNull(),
  name: text('name').notNull(),
  description: text('description'),
  narratorId: text('narrator_id').references(() => users.userId),
  status: text('status').notNull().default('active'),
  currentScene: text('current_scene'),
  weather: text('weather').notNull().default('clear'),
  timeOfDay: text('time_of_day').notNull().default('day'),
  temperature: integer('temperature').notNull().default(25),
  location: text('location'),
  participants: jsonb('participants').notNull().default([]),
  eventLog: jsonb('event_log').notNull().default([]),
  startedAt: timestamp('started_at').notNull().defaultNow(),
  endedAt: timestamp('ended_at'),
});

export const rpLocations = pgTable('bot_rp_locations', {
  id: text('id').primaryKey(),
  guildId: text('guild_id').notNull(),
  name: text('name').notNull(),
  description: text('description').notNull(),
  type: text('type').notNull(),
  defaultWeather: text('default_weather').notNull().default('clear'),
  dangerLevel: integer('danger_level').notNull().default(1),
  resources: jsonb('resources').notNull().default([]),
  npcs: jsonb('npcs').notNull().default([]),
  createdBy: text('created_by').references(() => users.userId),
  createdAt: timestamp('created_at').notNull().defaultNow(),
});

export const rpReputation = pgTable('bot_rp_reputation', {
  id: text('id').primaryKey(),
  userId: text('user_id').notNull().references(() => users.userId, { onDelete: 'cascade' }),
  npcType: text('npc_type').notNull(),
  reputation: integer('reputation').notNull().default(0),
  interactionCount: integer('interaction_count').notNull().default(0),
  lastInteraction: timestamp('last_interaction'),
  notes: jsonb('notes').notNull().default([]),
}, (table) => ({
  userNpcUnique: unique().on(table.userId, table.npcType),
}));

export const rpActionHistory = pgTable('bot_rp_action_history', {
  id: text('id').primaryKey(),
  userId: text('user_id').notNull().references(() => users.userId, { onDelete: 'cascade' }),
  sessionId: text('session_id').references(() => rpSessions.id, { onDelete: 'set null' }),
  actionType: text('action_type').notNull(),
  action: text('action').notNull(),
  narration: text('narration'),
  healthEffects: jsonb('health_effects'),
  timestamp: timestamp('timestamp').notNull().defaultNow(),
});

export const characterSheetsRelations = relations(characterSheets, ({ one }) => ({
  user: one(users, {
    fields: [characterSheets.userId],
    references: [users.userId],
  }),
}));

export const rpSessionsRelations = relations(rpSessions, ({ one, many }) => ({
  narrator: one(users, {
    fields: [rpSessions.narratorId],
    references: [users.userId],
  }),
  actionHistory: many(rpActionHistory),
}));

export const rpLocationsRelations = relations(rpLocations, ({ one }) => ({
  creator: one(users, {
    fields: [rpLocations.createdBy],
    references: [users.userId],
  }),
}));

export const rpReputationRelations = relations(rpReputation, ({ one }) => ({
  user: one(users, {
    fields: [rpReputation.userId],
    references: [users.userId],
  }),
}));

export const rpActionHistoryRelations = relations(rpActionHistory, ({ one }) => ({
  user: one(users, {
    fields: [rpActionHistory.userId],
    references: [users.userId],
  }),
  session: one(rpSessions, {
    fields: [rpActionHistory.sessionId],
    references: [rpSessions.id],
  }),
}));

export const rpNpcMemory = pgTable('bot_rp_npc_memory', {
  id: text('id').primaryKey(),
  npcType: text('npc_type').notNull(),
  userId: text('user_id').notNull().references(() => users.userId, { onDelete: 'cascade' }),
  channelId: text('channel_id').notNull(),
  memory: text('memory').notNull(),
  importance: integer('importance').notNull().default(1),
  emotionalTone: text('emotional_tone').notNull().default('neutral'),
  createdAt: timestamp('created_at').notNull().defaultNow(),
}, (table) => ({
  userNpcChannelIdx: unique().on(table.userId, table.npcType, table.channelId, table.id),
}));

export const rpEvents = pgTable('bot_rp_events', {
  id: text('id').primaryKey(),
  eventType: text('event_type').notNull(),
  name: text('name').notNull(),
  description: text('description').notNull(),
  triggeredBy: text('triggered_by').references(() => users.userId, { onDelete: 'set null' }),
  channelId: text('channel_id'),
  guildId: text('guild_id'),
  participants: jsonb('participants').notNull().default([]),
  outcome: text('outcome'),
  rewards: jsonb('rewards'),
  penalties: jsonb('penalties'),
  status: text('status').notNull().default('active'),
  createdAt: timestamp('created_at').notNull().defaultNow(),
  resolvedAt: timestamp('resolved_at'),
});

export const rpNpcMemoryRelations = relations(rpNpcMemory, ({ one }) => ({
  user: one(users, {
    fields: [rpNpcMemory.userId],
    references: [users.userId],
  }),
}));

export const rpEventsRelations = relations(rpEvents, ({ one }) => ({
  triggeredByUser: one(users, {
    fields: [rpEvents.triggeredBy],
    references: [users.userId],
  }),
}));

export const farms = pgTable('bot_farms', {
  id: text('id').primaryKey(),
  userId: text('user_id').notNull().references(() => users.userId, { onDelete: 'cascade' }).unique(),
  name: text('name').notNull().default('Rancho Sem Nome'),
  level: integer('level').notNull().default(1),
  xp: integer('xp').notNull().default(0),
  
  storageLevel: integer('storage_level').notNull().default(1),
  storageCapacity: integer('storage_capacity').notNull().default(100),
  houseLevel: integer('house_level').notNull().default(1),
  barnLevel: integer('barn_level').notNull().default(1),
  siloLevel: integer('silo_level').notNull().default(1),
  
  resources: jsonb('resources').notNull().default({
    wheat: 0,
    corn: 0,
    carrot: 0,
    tomato: 0,
    cotton: 0,
    milk: 0,
    egg: 0,
    wool: 0,
    meat: 0,
    leather: 0,
  }),
  
  lastHarvest: timestamp('last_harvest'),
  lastAnimalCollection: timestamp('last_animal_collection'),
  totalEarnings: integer('total_earnings').notNull().default(0),
  
  hasManager: boolean('has_manager').notNull().default(false),
  managerBonus: real('manager_bonus').notNull().default(1.0),
  
  createdAt: timestamp('created_at').notNull().defaultNow(),
  updatedAt: timestamp('updated_at').notNull().defaultNow(),
});

export const farmBuildings = pgTable('bot_farm_buildings', {
  id: text('id').primaryKey(),
  farmId: text('farm_id').notNull().references(() => farms.id, { onDelete: 'cascade' }),
  type: text('type').notNull(),
  name: text('name').notNull(),
  level: integer('level').notNull().default(1),
  
  isBuilding: boolean('is_building').notNull().default(false),
  buildStartTime: timestamp('build_start_time'),
  buildEndTime: timestamp('build_end_time'),
  
  productionRate: real('production_rate').notNull().default(1.0),
  lastCollection: timestamp('last_collection'),
  
  createdAt: timestamp('created_at').notNull().defaultNow(),
});

export const farmWorkers = pgTable('bot_farm_workers', {
  id: text('id').primaryKey(),
  farmId: text('farm_id').notNull().references(() => farms.id, { onDelete: 'cascade' }),
  name: text('name').notNull(),
  role: text('role').notNull(),
  
  happiness: integer('happiness').notNull().default(100),
  skill: real('skill').notNull().default(1.0),
  salary: integer('salary').notNull().default(50),
  
  assignedTo: text('assigned_to'),
  isOnStrike: boolean('is_on_strike').notNull().default(false),
  
  hiredAt: timestamp('hired_at').notNull().defaultNow(),
  lastPaid: timestamp('last_paid'),
});

export const farmCrops = pgTable('bot_farm_crops', {
  id: text('id').primaryKey(),
  farmId: text('farm_id').notNull().references(() => farms.id, { onDelete: 'cascade' }),
  type: text('type').notNull(),
  name: text('name').notNull(),
  
  quantity: integer('quantity').notNull().default(1),
  plantedAt: timestamp('planted_at').notNull().defaultNow(),
  harvestTime: timestamp('harvest_time').notNull(),
  
  isReady: boolean('is_ready').notNull().default(false),
  yieldAmount: integer('yield_amount').notNull().default(1),
  yieldMultiplier: real('yield_multiplier').notNull().default(1.0),
});

export const farmAnimals = pgTable('bot_farm_animals', {
  id: text('id').primaryKey(),
  farmId: text('farm_id').notNull().references(() => farms.id, { onDelete: 'cascade' }),
  type: text('type').notNull(),
  name: text('name').notNull(),
  
  quantity: integer('quantity').notNull().default(1),
  productionType: text('production_type').notNull(),
  productionRate: real('production_rate').notNull().default(1.0),
  lastCollection: timestamp('last_collection'),
  
  health: integer('health').notNull().default(100),
  happiness: integer('happiness').notNull().default(100),
  
  purchasedAt: timestamp('purchased_at').notNull().defaultNow(),
});

export const farmsRelations = relations(farms, ({ one, many }) => ({
  user: one(users, {
    fields: [farms.userId],
    references: [users.userId],
  }),
  buildings: many(farmBuildings),
  workers: many(farmWorkers),
  crops: many(farmCrops),
  animals: many(farmAnimals),
}));

export const farmBuildingsRelations = relations(farmBuildings, ({ one }) => ({
  farm: one(farms, {
    fields: [farmBuildings.farmId],
    references: [farms.id],
  }),
}));

export const farmWorkersRelations = relations(farmWorkers, ({ one }) => ({
  farm: one(farms, {
    fields: [farmWorkers.farmId],
    references: [farms.id],
  }),
}));

export const farmCropsRelations = relations(farmCrops, ({ one }) => ({
  farm: one(farms, {
    fields: [farmCrops.farmId],
    references: [farms.id],
  }),
}));

export const farmAnimalsRelations = relations(farmAnimals, ({ one }) => ({
  farm: one(farms, {
    fields: [farmAnimals.farmId],
    references: [farms.id],
  }),
}));

export const gangues = pgTable('bot_gangues', {
  id: text('id').primaryKey(),
  serverId: text('server_id').notNull(),
  nome: text('nome').notNull(),
  level: integer('level').notNull().default(1),
  xpTotal: integer('xp_total').notNull().default(0),
  tesouroPrata: integer('tesouro_prata').notNull().default(0),
  tesouroOuro: integer('tesouro_ouro').notNull().default(0),
  maxMembros: integer('max_membros').notNull().default(30),
  criadoEm: timestamp('criado_em').notNull().defaultNow(),
  atualizadoEm: timestamp('atualizado_em').notNull().defaultNow(),
}, (table) => ({
  serverNameUnique: unique().on(table.serverId, table.nome),
}));

export const gangueMembros = pgTable('bot_gangue_membros', {
  id: text('id').primaryKey(),
  gangueId: text('gangue_id').notNull().references(() => gangues.id, { onDelete: 'cascade' }),
  userId: text('user_id').notNull().references(() => users.userId, { onDelete: 'cascade' }),
  cargo: text('cargo').notNull().default('membro_regular'),
  doadoPrata: integer('doado_prata').notNull().default(0),
  doadoOuro: integer('doado_ouro').notNull().default(0),
  entradaEm: timestamp('entrada_em').notNull().defaultNow(),
  ultimoConvite: timestamp('ultimo_convite'),
}, (table) => ({
  gangueUserUnique: unique().on(table.gangueId, table.userId),
}));

export const gangueConvites = pgTable('bot_gangue_convites', {
  id: text('id').primaryKey(),
  gangueId: text('gangue_id').notNull().references(() => gangues.id, { onDelete: 'cascade' }),
  convidadoId: text('convidado_id').notNull().references(() => users.userId, { onDelete: 'cascade' }),
  convidadorId: text('convidador_id').notNull().references(() => users.userId, { onDelete: 'cascade' }),
  criadoEm: timestamp('criado_em').notNull().defaultNow(),
  expiraEm: timestamp('expira_em').notNull(),
  status: text('status').notNull().default('pendente'),
});

export const ganguesRelations = relations(gangues, ({ many }) => ({
  membros: many(gangueMembros),
  convites: many(gangueConvites),
}));

export const gangueMembrosRelations = relations(gangueMembros, ({ one }) => ({
  gangue: one(gangues, {
    fields: [gangueMembros.gangueId],
    references: [gangues.id],
  }),
  user: one(users, {
    fields: [gangueMembros.userId],
    references: [users.userId],
  }),
}));

export const gangueConvitesRelations = relations(gangueConvites, ({ one }) => ({
  gangue: one(gangues, {
    fields: [gangueConvites.gangueId],
    references: [gangues.id],
  }),
  convidado: one(users, {
    fields: [gangueConvites.convidadoId],
    references: [users.userId],
  }),
  convidador: one(users, {
    fields: [gangueConvites.convidadorId],
    references: [users.userId],
  }),
}));

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
export type InventoryItem = typeof inventoryItems.$inferSelect;
export type InsertInventoryItem = typeof inventoryItems.$inferInsert;
export type Bounty = typeof bounties.$inferSelect;
export type InsertBounty = typeof bounties.$inferInsert;
export type Territory = typeof territories.$inferSelect;
export type InsertTerritory = typeof territories.$inferInsert;
export type Punishment = typeof punishments.$inferSelect;
export type InsertPunishment = typeof punishments.$inferInsert;
export type PlayerGuild = typeof playerGuilds.$inferSelect;
export type InsertPlayerGuild = typeof playerGuilds.$inferInsert;
export type GuildMember = typeof guildMembers.$inferSelect;
export type InsertGuildMember = typeof guildMembers.$inferInsert;
export type WelcomeSetting = typeof welcomeSettings.$inferSelect;
export type InsertWelcomeSetting = typeof welcomeSettings.$inferInsert;
export type RexBuckTransaction = typeof rexBuckTransactions.$inferSelect;
export type InsertRexBuckTransaction = typeof rexBuckTransactions.$inferInsert;
export type RedemptionCode = typeof redemptionCodes.$inferSelect;
export type InsertRedemptionCode = typeof redemptionCodes.$inferInsert;
export type CharacterSheet = typeof characterSheets.$inferSelect;
export type InsertCharacterSheet = typeof characterSheets.$inferInsert;
export type RpSession = typeof rpSessions.$inferSelect;
export type InsertRpSession = typeof rpSessions.$inferInsert;
export type RpLocation = typeof rpLocations.$inferSelect;
export type InsertRpLocation = typeof rpLocations.$inferInsert;
export type RpReputation = typeof rpReputation.$inferSelect;
export type InsertRpReputation = typeof rpReputation.$inferInsert;
export type RpActionHistory = typeof rpActionHistory.$inferSelect;
export type InsertRpActionHistory = typeof rpActionHistory.$inferInsert;
export type RpNpcMemory = typeof rpNpcMemory.$inferSelect;
export type InsertRpNpcMemory = typeof rpNpcMemory.$inferInsert;
export type RpEvent = typeof rpEvents.$inferSelect;
export type InsertRpEvent = typeof rpEvents.$inferInsert;
export type Farm = typeof farms.$inferSelect;
export type InsertFarm = typeof farms.$inferInsert;
export type FarmBuilding = typeof farmBuildings.$inferSelect;
export type InsertFarmBuilding = typeof farmBuildings.$inferInsert;
export type FarmWorker = typeof farmWorkers.$inferSelect;
export type InsertFarmWorker = typeof farmWorkers.$inferInsert;
export type FarmCrop = typeof farmCrops.$inferSelect;
export type InsertFarmCrop = typeof farmCrops.$inferInsert;
export type FarmAnimal = typeof farmAnimals.$inferSelect;
export type InsertFarmAnimal = typeof farmAnimals.$inferInsert;
export type Gangue = typeof gangues.$inferSelect;
export type InsertGangue = typeof gangues.$inferInsert;
export type GangueMembro = typeof gangueMembros.$inferSelect;
export type InsertGangueMembro = typeof gangueMembros.$inferInsert;
export type GangueConvite = typeof gangueConvites.$inferSelect;
export type InsertGangueConvite = typeof gangueConvites.$inferInsert;
