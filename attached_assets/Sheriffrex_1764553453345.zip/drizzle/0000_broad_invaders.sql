CREATE TABLE "bot_active_mining" (
	"id" text PRIMARY KEY NOT NULL,
	"user_id" text NOT NULL,
	"start_time" timestamp NOT NULL,
	"duration" integer NOT NULL,
	"type" text NOT NULL,
	"participants" jsonb,
	"expected_rewards" integer NOT NULL
);
--> statement-breakpoint
CREATE TABLE "bot_bounties" (
	"id" text PRIMARY KEY NOT NULL,
	"target_id" text NOT NULL,
	"issuer_id" text,
	"amount" integer NOT NULL,
	"reason" text NOT NULL,
	"timestamp" timestamp DEFAULT now() NOT NULL,
	"active" boolean DEFAULT true NOT NULL
);
--> statement-breakpoint
CREATE TABLE "bot_character_sheets" (
	"id" text PRIMARY KEY NOT NULL,
	"user_id" text NOT NULL,
	"name" text NOT NULL,
	"description" text,
	"backstory" text,
	"personality" text,
	"appearance" text,
	"skills" jsonb DEFAULT '[]'::jsonb NOT NULL,
	"traits" jsonb DEFAULT '[]'::jsonb NOT NULL,
	"equipment" jsonb DEFAULT '[]'::jsonb NOT NULL,
	"is_active" boolean DEFAULT true NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL,
	"updated_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "bot_farm_animals" (
	"id" text PRIMARY KEY NOT NULL,
	"farm_id" text NOT NULL,
	"type" text NOT NULL,
	"name" text NOT NULL,
	"quantity" integer DEFAULT 1 NOT NULL,
	"production_type" text NOT NULL,
	"production_rate" real DEFAULT 1 NOT NULL,
	"last_collection" timestamp,
	"health" integer DEFAULT 100 NOT NULL,
	"happiness" integer DEFAULT 100 NOT NULL,
	"purchased_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "bot_farm_buildings" (
	"id" text PRIMARY KEY NOT NULL,
	"farm_id" text NOT NULL,
	"type" text NOT NULL,
	"name" text NOT NULL,
	"level" integer DEFAULT 1 NOT NULL,
	"is_building" boolean DEFAULT false NOT NULL,
	"build_start_time" timestamp,
	"build_end_time" timestamp,
	"production_rate" real DEFAULT 1 NOT NULL,
	"last_collection" timestamp,
	"created_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "bot_farm_crops" (
	"id" text PRIMARY KEY NOT NULL,
	"farm_id" text NOT NULL,
	"type" text NOT NULL,
	"name" text NOT NULL,
	"quantity" integer DEFAULT 1 NOT NULL,
	"planted_at" timestamp DEFAULT now() NOT NULL,
	"harvest_time" timestamp NOT NULL,
	"is_ready" boolean DEFAULT false NOT NULL,
	"yield_amount" integer DEFAULT 1 NOT NULL,
	"yield_multiplier" real DEFAULT 1 NOT NULL
);
--> statement-breakpoint
CREATE TABLE "bot_farm_workers" (
	"id" text PRIMARY KEY NOT NULL,
	"farm_id" text NOT NULL,
	"name" text NOT NULL,
	"role" text NOT NULL,
	"happiness" integer DEFAULT 100 NOT NULL,
	"skill" real DEFAULT 1 NOT NULL,
	"salary" integer DEFAULT 50 NOT NULL,
	"assigned_to" text,
	"is_on_strike" boolean DEFAULT false NOT NULL,
	"hired_at" timestamp DEFAULT now() NOT NULL,
	"last_paid" timestamp
);
--> statement-breakpoint
CREATE TABLE "bot_farms" (
	"id" text PRIMARY KEY NOT NULL,
	"user_id" text NOT NULL,
	"name" text DEFAULT 'Rancho Sem Nome' NOT NULL,
	"level" integer DEFAULT 1 NOT NULL,
	"xp" integer DEFAULT 0 NOT NULL,
	"storage_level" integer DEFAULT 1 NOT NULL,
	"storage_capacity" integer DEFAULT 100 NOT NULL,
	"house_level" integer DEFAULT 1 NOT NULL,
	"barn_level" integer DEFAULT 1 NOT NULL,
	"silo_level" integer DEFAULT 1 NOT NULL,
	"resources" jsonb DEFAULT '{"wheat":0,"corn":0,"carrot":0,"tomato":0,"cotton":0,"milk":0,"egg":0,"wool":0,"meat":0,"leather":0}'::jsonb NOT NULL,
	"last_harvest" timestamp,
	"last_animal_collection" timestamp,
	"total_earnings" integer DEFAULT 0 NOT NULL,
	"has_manager" boolean DEFAULT false NOT NULL,
	"manager_bonus" real DEFAULT 1 NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL,
	"updated_at" timestamp DEFAULT now() NOT NULL,
	CONSTRAINT "bot_farms_user_id_unique" UNIQUE("user_id")
);
--> statement-breakpoint
CREATE TABLE "bot_gangue_convites" (
	"id" text PRIMARY KEY NOT NULL,
	"gangue_id" text NOT NULL,
	"convidado_id" text NOT NULL,
	"convidador_id" text NOT NULL,
	"criado_em" timestamp DEFAULT now() NOT NULL,
	"expira_em" timestamp NOT NULL,
	"status" text DEFAULT 'pendente' NOT NULL
);
--> statement-breakpoint
CREATE TABLE "bot_gangue_membros" (
	"id" text PRIMARY KEY NOT NULL,
	"gangue_id" text NOT NULL,
	"user_id" text NOT NULL,
	"cargo" text DEFAULT 'membro_regular' NOT NULL,
	"doado_prata" integer DEFAULT 0 NOT NULL,
	"doado_ouro" integer DEFAULT 0 NOT NULL,
	"entrada_em" timestamp DEFAULT now() NOT NULL,
	"ultimo_convite" timestamp,
	CONSTRAINT "bot_gangue_membros_gangue_id_user_id_unique" UNIQUE("gangue_id","user_id")
);
--> statement-breakpoint
CREATE TABLE "bot_gangues" (
	"id" text PRIMARY KEY NOT NULL,
	"server_id" text NOT NULL,
	"nome" text NOT NULL,
	"level" integer DEFAULT 1 NOT NULL,
	"xp_total" integer DEFAULT 0 NOT NULL,
	"tesouro_prata" integer DEFAULT 0 NOT NULL,
	"tesouro_ouro" integer DEFAULT 0 NOT NULL,
	"max_membros" integer DEFAULT 30 NOT NULL,
	"criado_em" timestamp DEFAULT now() NOT NULL,
	"atualizado_em" timestamp DEFAULT now() NOT NULL,
	CONSTRAINT "bot_gangues_server_id_nome_unique" UNIQUE("server_id","nome")
);
--> statement-breakpoint
CREATE TABLE "bot_guild_join_requests" (
	"id" text PRIMARY KEY NOT NULL,
	"user_id" text NOT NULL,
	"guild_id" text NOT NULL,
	"requested_at" timestamp DEFAULT now() NOT NULL,
	"status" text DEFAULT 'pending' NOT NULL
);
--> statement-breakpoint
CREATE TABLE "bot_guild_members" (
	"id" text PRIMARY KEY NOT NULL,
	"guild_id" text NOT NULL,
	"user_id" text NOT NULL,
	"joined_at" timestamp DEFAULT now() NOT NULL,
	"role" text DEFAULT 'member' NOT NULL
);
--> statement-breakpoint
CREATE TABLE "bot_inventory_items" (
	"id" text PRIMARY KEY NOT NULL,
	"user_id" text NOT NULL,
	"item_id" text NOT NULL,
	"name" text NOT NULL,
	"quantity" real DEFAULT 1 NOT NULL,
	"weight" real NOT NULL,
	"value" integer NOT NULL,
	"type" text NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL,
	CONSTRAINT "bot_inventory_items_user_id_item_id_unique" UNIQUE("user_id","item_id")
);
--> statement-breakpoint
CREATE TABLE "bot_logs" (
	"id" text PRIMARY KEY NOT NULL,
	"timestamp" timestamp DEFAULT now() NOT NULL,
	"type" text NOT NULL,
	"guild_id" text NOT NULL,
	"user_id" text,
	"details" jsonb NOT NULL
);
--> statement-breakpoint
CREATE TABLE "bot_mercadopago_payments" (
	"id" text PRIMARY KEY NOT NULL,
	"user_id" text NOT NULL,
	"package_id" text NOT NULL,
	"external_reference" text NOT NULL,
	"preference_id" text,
	"mp_payment_id" text,
	"status" text DEFAULT 'pending' NOT NULL,
	"amount" integer NOT NULL,
	"currency" text DEFAULT 'BRL' NOT NULL,
	"paid_at" timestamp,
	"raw_payload" jsonb,
	"processed" boolean DEFAULT false NOT NULL,
	"rex_buck_transaction_id" text,
	"created_at" timestamp DEFAULT now() NOT NULL,
	"updated_at" timestamp DEFAULT now() NOT NULL,
	CONSTRAINT "bot_mercadopago_payments_external_reference_unique" UNIQUE("external_reference"),
	CONSTRAINT "bot_mercadopago_payments_mp_payment_id_unique" UNIQUE("mp_payment_id")
);
--> statement-breakpoint
CREATE TABLE "bot_player_guilds" (
	"id" text PRIMARY KEY NOT NULL,
	"name" text NOT NULL,
	"description" text NOT NULL,
	"leader_id" text NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL,
	"level" integer DEFAULT 1 NOT NULL,
	"xp" integer DEFAULT 0 NOT NULL,
	"max_members" integer DEFAULT 10 NOT NULL,
	"is_public" boolean DEFAULT true NOT NULL,
	"require_approval" boolean DEFAULT false NOT NULL,
	CONSTRAINT "bot_player_guilds_name_unique" UNIQUE("name")
);
--> statement-breakpoint
CREATE TABLE "bot_punishments" (
	"id" text PRIMARY KEY NOT NULL,
	"user_id" text NOT NULL,
	"reason" text NOT NULL,
	"start_time" timestamp NOT NULL,
	"duration" integer NOT NULL,
	"active" boolean DEFAULT true NOT NULL
);
--> statement-breakpoint
CREATE TABLE "bot_redemption_codes" (
	"code" text PRIMARY KEY NOT NULL,
	"product_id" text NOT NULL,
	"product_name" text NOT NULL,
	"tokens" integer DEFAULT 0 NOT NULL,
	"coins" integer DEFAULT 0 NOT NULL,
	"rex_bucks" integer DEFAULT 0 NOT NULL,
	"vip" boolean DEFAULT false NOT NULL,
	"background" boolean DEFAULT false NOT NULL,
	"backpack" integer,
	"created_at" timestamp DEFAULT now() NOT NULL,
	"created_by" text NOT NULL,
	"redeemed" boolean DEFAULT false NOT NULL,
	"redeemed_by" text,
	"redeemed_at" timestamp
);
--> statement-breakpoint
CREATE TABLE "bot_rex_buck_packages" (
	"id" text PRIMARY KEY NOT NULL,
	"name" text NOT NULL,
	"description" text NOT NULL,
	"amount_rexbucks" integer NOT NULL,
	"bonus_rexbucks" integer DEFAULT 0 NOT NULL,
	"price_cents" integer NOT NULL,
	"currency" text DEFAULT 'BRL' NOT NULL,
	"active" boolean DEFAULT true NOT NULL,
	"display_order" integer DEFAULT 0 NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL,
	"updated_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "bot_rex_buck_transactions" (
	"id" text PRIMARY KEY NOT NULL,
	"user_id" text NOT NULL,
	"amount" integer NOT NULL,
	"type" text NOT NULL,
	"redemption_code" text,
	"balance_before" integer NOT NULL,
	"balance_after" integer NOT NULL,
	"metadata" jsonb,
	"timestamp" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "bot_rp_action_history" (
	"id" text PRIMARY KEY NOT NULL,
	"user_id" text NOT NULL,
	"session_id" text,
	"action_type" text NOT NULL,
	"action" text NOT NULL,
	"narration" text,
	"health_effects" jsonb,
	"timestamp" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "bot_rp_events" (
	"id" text PRIMARY KEY NOT NULL,
	"event_type" text NOT NULL,
	"name" text NOT NULL,
	"description" text NOT NULL,
	"triggered_by" text,
	"channel_id" text,
	"guild_id" text,
	"participants" jsonb DEFAULT '[]'::jsonb NOT NULL,
	"outcome" text,
	"rewards" jsonb,
	"penalties" jsonb,
	"status" text DEFAULT 'active' NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL,
	"resolved_at" timestamp
);
--> statement-breakpoint
CREATE TABLE "bot_rp_locations" (
	"id" text PRIMARY KEY NOT NULL,
	"guild_id" text NOT NULL,
	"name" text NOT NULL,
	"description" text NOT NULL,
	"type" text NOT NULL,
	"default_weather" text DEFAULT 'clear' NOT NULL,
	"danger_level" integer DEFAULT 1 NOT NULL,
	"resources" jsonb DEFAULT '[]'::jsonb NOT NULL,
	"npcs" jsonb DEFAULT '[]'::jsonb NOT NULL,
	"created_by" text,
	"created_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "bot_rp_npc_memory" (
	"id" text PRIMARY KEY NOT NULL,
	"npc_type" text NOT NULL,
	"user_id" text NOT NULL,
	"channel_id" text NOT NULL,
	"memory" text NOT NULL,
	"importance" integer DEFAULT 1 NOT NULL,
	"emotional_tone" text DEFAULT 'neutral' NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL,
	CONSTRAINT "bot_rp_npc_memory_user_id_npc_type_channel_id_id_unique" UNIQUE("user_id","npc_type","channel_id","id")
);
--> statement-breakpoint
CREATE TABLE "bot_rp_reputation" (
	"id" text PRIMARY KEY NOT NULL,
	"user_id" text NOT NULL,
	"npc_type" text NOT NULL,
	"reputation" integer DEFAULT 0 NOT NULL,
	"interaction_count" integer DEFAULT 0 NOT NULL,
	"last_interaction" timestamp,
	"notes" jsonb DEFAULT '[]'::jsonb NOT NULL,
	CONSTRAINT "bot_rp_reputation_user_id_npc_type_unique" UNIQUE("user_id","npc_type")
);
--> statement-breakpoint
CREATE TABLE "bot_rp_sessions" (
	"id" text PRIMARY KEY NOT NULL,
	"guild_id" text NOT NULL,
	"channel_id" text NOT NULL,
	"name" text NOT NULL,
	"description" text,
	"narrator_id" text,
	"status" text DEFAULT 'active' NOT NULL,
	"current_scene" text,
	"weather" text DEFAULT 'clear' NOT NULL,
	"time_of_day" text DEFAULT 'day' NOT NULL,
	"temperature" integer DEFAULT 25 NOT NULL,
	"location" text,
	"participants" jsonb DEFAULT '[]'::jsonb NOT NULL,
	"event_log" jsonb DEFAULT '[]'::jsonb NOT NULL,
	"started_at" timestamp DEFAULT now() NOT NULL,
	"ended_at" timestamp
);
--> statement-breakpoint
CREATE TABLE "bot_territories" (
	"id" text PRIMARY KEY NOT NULL,
	"name" text NOT NULL,
	"owner_id" text,
	"controlled_guild_id" text,
	"income" integer DEFAULT 0 NOT NULL,
	"defense_level" integer DEFAULT 1 NOT NULL,
	"last_income_time" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "user_sessions" (
	"sid" varchar PRIMARY KEY NOT NULL,
	"sess" jsonb NOT NULL,
	"expire" timestamp NOT NULL
);
--> statement-breakpoint
CREATE TABLE "bot_users" (
	"user_id" text PRIMARY KEY NOT NULL,
	"username" text NOT NULL,
	"gold" integer DEFAULT 0 NOT NULL,
	"silver" integer DEFAULT 0 NOT NULL,
	"saloon_tokens" integer DEFAULT 0 NOT NULL,
	"bank" integer DEFAULT 0 NOT NULL,
	"rex_bucks" integer DEFAULT 0 NOT NULL,
	"level" integer DEFAULT 1 NOT NULL,
	"xp" integer DEFAULT 0 NOT NULL,
	"last_message" timestamp,
	"last_claim_daily" timestamp,
	"daily_streak" integer DEFAULT 0 NOT NULL,
	"custom_background" text,
	"is_vip" boolean DEFAULT false NOT NULL,
	"badges" jsonb DEFAULT '[]'::jsonb NOT NULL,
	"games_played" integer DEFAULT 0 NOT NULL,
	"bounties_captured" integer DEFAULT 0 NOT NULL,
	"mining_sessions" integer DEFAULT 0 NOT NULL,
	"total_earnings" integer DEFAULT 0 NOT NULL,
	"total_spent" integer DEFAULT 0 NOT NULL,
	"language" text DEFAULT 'pt-BR' NOT NULL,
	"show_stats" boolean DEFAULT true NOT NULL,
	"private_profile" boolean DEFAULT false NOT NULL,
	"backpack_capacity" integer DEFAULT 100 NOT NULL,
	"last_mining_time" timestamp,
	"total_mined" integer DEFAULT 0 NOT NULL,
	"health" integer DEFAULT 100 NOT NULL,
	"max_health" integer DEFAULT 100 NOT NULL,
	"stamina" integer DEFAULT 100 NOT NULL,
	"max_stamina" integer DEFAULT 100 NOT NULL,
	"thirst" integer DEFAULT 100 NOT NULL,
	"max_thirst" integer DEFAULT 100 NOT NULL,
	"hunger" integer DEFAULT 100 NOT NULL,
	"max_hunger" integer DEFAULT 100 NOT NULL,
	"blood" integer DEFAULT 100 NOT NULL,
	"max_blood" integer DEFAULT 100 NOT NULL,
	"temperature" integer DEFAULT 37 NOT NULL,
	"is_bleeding" boolean DEFAULT false NOT NULL,
	"bleeding_amount" integer DEFAULT 0 NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL,
	"updated_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "bot_welcome_settings" (
	"guild_id" text PRIMARY KEY NOT NULL,
	"channel_id" text,
	"message" text,
	"enabled" boolean DEFAULT false NOT NULL
);
--> statement-breakpoint
ALTER TABLE "bot_active_mining" ADD CONSTRAINT "bot_active_mining_user_id_bot_users_user_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."bot_users"("user_id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "bot_bounties" ADD CONSTRAINT "bot_bounties_target_id_bot_users_user_id_fk" FOREIGN KEY ("target_id") REFERENCES "public"."bot_users"("user_id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "bot_bounties" ADD CONSTRAINT "bot_bounties_issuer_id_bot_users_user_id_fk" FOREIGN KEY ("issuer_id") REFERENCES "public"."bot_users"("user_id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "bot_character_sheets" ADD CONSTRAINT "bot_character_sheets_user_id_bot_users_user_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."bot_users"("user_id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "bot_farm_animals" ADD CONSTRAINT "bot_farm_animals_farm_id_bot_farms_id_fk" FOREIGN KEY ("farm_id") REFERENCES "public"."bot_farms"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "bot_farm_buildings" ADD CONSTRAINT "bot_farm_buildings_farm_id_bot_farms_id_fk" FOREIGN KEY ("farm_id") REFERENCES "public"."bot_farms"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "bot_farm_crops" ADD CONSTRAINT "bot_farm_crops_farm_id_bot_farms_id_fk" FOREIGN KEY ("farm_id") REFERENCES "public"."bot_farms"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "bot_farm_workers" ADD CONSTRAINT "bot_farm_workers_farm_id_bot_farms_id_fk" FOREIGN KEY ("farm_id") REFERENCES "public"."bot_farms"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "bot_farms" ADD CONSTRAINT "bot_farms_user_id_bot_users_user_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."bot_users"("user_id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "bot_gangue_convites" ADD CONSTRAINT "bot_gangue_convites_gangue_id_bot_gangues_id_fk" FOREIGN KEY ("gangue_id") REFERENCES "public"."bot_gangues"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "bot_gangue_convites" ADD CONSTRAINT "bot_gangue_convites_convidado_id_bot_users_user_id_fk" FOREIGN KEY ("convidado_id") REFERENCES "public"."bot_users"("user_id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "bot_gangue_convites" ADD CONSTRAINT "bot_gangue_convites_convidador_id_bot_users_user_id_fk" FOREIGN KEY ("convidador_id") REFERENCES "public"."bot_users"("user_id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "bot_gangue_membros" ADD CONSTRAINT "bot_gangue_membros_gangue_id_bot_gangues_id_fk" FOREIGN KEY ("gangue_id") REFERENCES "public"."bot_gangues"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "bot_gangue_membros" ADD CONSTRAINT "bot_gangue_membros_user_id_bot_users_user_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."bot_users"("user_id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "bot_guild_join_requests" ADD CONSTRAINT "bot_guild_join_requests_user_id_bot_users_user_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."bot_users"("user_id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "bot_guild_join_requests" ADD CONSTRAINT "bot_guild_join_requests_guild_id_bot_player_guilds_id_fk" FOREIGN KEY ("guild_id") REFERENCES "public"."bot_player_guilds"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "bot_guild_members" ADD CONSTRAINT "bot_guild_members_guild_id_bot_player_guilds_id_fk" FOREIGN KEY ("guild_id") REFERENCES "public"."bot_player_guilds"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "bot_guild_members" ADD CONSTRAINT "bot_guild_members_user_id_bot_users_user_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."bot_users"("user_id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "bot_inventory_items" ADD CONSTRAINT "bot_inventory_items_user_id_bot_users_user_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."bot_users"("user_id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "bot_mercadopago_payments" ADD CONSTRAINT "bot_mercadopago_payments_user_id_bot_users_user_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."bot_users"("user_id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "bot_mercadopago_payments" ADD CONSTRAINT "bot_mercadopago_payments_package_id_bot_rex_buck_packages_id_fk" FOREIGN KEY ("package_id") REFERENCES "public"."bot_rex_buck_packages"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "bot_player_guilds" ADD CONSTRAINT "bot_player_guilds_leader_id_bot_users_user_id_fk" FOREIGN KEY ("leader_id") REFERENCES "public"."bot_users"("user_id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "bot_punishments" ADD CONSTRAINT "bot_punishments_user_id_bot_users_user_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."bot_users"("user_id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "bot_rex_buck_transactions" ADD CONSTRAINT "bot_rex_buck_transactions_user_id_bot_users_user_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."bot_users"("user_id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "bot_rp_action_history" ADD CONSTRAINT "bot_rp_action_history_user_id_bot_users_user_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."bot_users"("user_id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "bot_rp_action_history" ADD CONSTRAINT "bot_rp_action_history_session_id_bot_rp_sessions_id_fk" FOREIGN KEY ("session_id") REFERENCES "public"."bot_rp_sessions"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "bot_rp_events" ADD CONSTRAINT "bot_rp_events_triggered_by_bot_users_user_id_fk" FOREIGN KEY ("triggered_by") REFERENCES "public"."bot_users"("user_id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "bot_rp_locations" ADD CONSTRAINT "bot_rp_locations_created_by_bot_users_user_id_fk" FOREIGN KEY ("created_by") REFERENCES "public"."bot_users"("user_id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "bot_rp_npc_memory" ADD CONSTRAINT "bot_rp_npc_memory_user_id_bot_users_user_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."bot_users"("user_id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "bot_rp_reputation" ADD CONSTRAINT "bot_rp_reputation_user_id_bot_users_user_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."bot_users"("user_id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "bot_rp_sessions" ADD CONSTRAINT "bot_rp_sessions_narrator_id_bot_users_user_id_fk" FOREIGN KEY ("narrator_id") REFERENCES "public"."bot_users"("user_id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "bot_territories" ADD CONSTRAINT "bot_territories_owner_id_bot_users_user_id_fk" FOREIGN KEY ("owner_id") REFERENCES "public"."bot_users"("user_id") ON DELETE set null ON UPDATE no action;