# Guia de Migração: JSON para PostgreSQL

## ✅ O Que Já Foi Feito

### Novos Managers PostgreSQL Criados

1. **postgresEconomyManager.ts** - Gerenciamento de economia
   - `ensureUser()` - Garante que usuário existe
   - `getUserGold()`, `setUserGold()`, `addUserGold()`, `removeUserGold()`
   - `getUserSilver()`, `setUserSilver()`, `addUserSilver()`, `removeUserSilver()`
   - `getUserBank()`, `depositToBank()`, `withdrawFromBank()`
   - `transferGold()`, `transferSilver()`
   - `incrementGamesPlayed()`, `incrementMiningSessions()`, `incrementBountiesCaptured()`

2. **postgresXpManager.ts** - Gerenciamento de XP e níveis
   - `getUserXpData()` - Obtém XP e level do usuário
   - `addUserXp()` - Adiciona XP e verifica level up
   - `setUserXp()`, `setUserLevel()` - Define valores diretamente
   - `getXpLeaderboard()` - Ranking de XP
   - `getUserLevelProgress()` - Progresso para próximo nível
   - `calculateXpForLevel()`, `calculateLevelFromXp()` - Cálculos de XP

## 📋 Como Migrar um Comando

### Exemplo: Migrar comando `/daily`

**ANTES (usando JSON):**
```typescript
import { getUserGold, addUserGold } from "../utils/dataManager";
import { getUserXpData, addUserXp } from "../utils/xpManager";

// No comando...
const currentGold = getUserGold(userId);
await addUserGold(userId, 100);

const xpData = await getUserXpData(userId);
await addUserXp(userId, username, 50);
```

**DEPOIS (usando PostgreSQL):**
```typescript
import { getUserGold, addUserGold, ensureUser } from "../utils/postgresEconomyManager";
import { getUserXpData, addUserXp } from "../utils/postgresXpManager";

// No comando...
await ensureUser(userId, username); // Importante: garantir que usuário existe

const currentGold = await getUserGold(userId); // Agora é async
await addUserGold(userId, 100);

const xpData = await getUserXpData(userId);
await addUserXp(userId, username, 50);
```

### Mudanças Principais

1. **Todas as funções são async** - Use `await`
2. **Sempre chamar `ensureUser()` primeiro** - Garante que usuário existe no banco
3. **Import dos novos managers** - `postgresEconomyManager` e `postgresXpManager`

## 🚀 Próximos Passos

### Managers que Ainda Precisam Ser Criados

1. **postgresProfileManager.ts** - Perfis de usuário
   - Bio, background, phrase, colorTheme
   - Badges, VIP status

2. **postgresInventoryManager.ts** - Inventário
   - Items, weight, capacity
   - Adicionar/remover items

3. **postgresBountyManager.ts** - Sistema de recompensas
   - Criar/remover bounties
   - Listar bounties ativos

4. **postgresMiningManager.ts** - Sistema de mineração
   - Sessões ativas
   - Histórico de mineração

5. **postgresDailyManager.ts** - Daily rewards
   - Streaks, última claim

### Comandos Prioritários para Migrar

1. `/daily` - Daily rewards
2. `/profile` - Perfil do usuário  
3. `/leaderboard` - Ranking
4. `/give` - Transferir gold
5. `/mine` - Mineração
6. `/wanted` e `/capture` - Bounty system

## 🔧 Testes

Após migrar um comando:

1. Testar em ambiente de desenvolvimento
2. Verificar se dados são salvos corretamente no PostgreSQL
3. Comparar comportamento com versão JSON
4. Validar transações e race conditions

## ⚠️ Importante

- **Não deletar os arquivos JSON ainda** - Manter como backup
- **Migrar gradualmente** - Um comando de cada vez
- **Testar bastante** - Economia é crítica
- **Usar transações** - Para operações que modificam múltiplos registros

## 📊 Status da Migração

- ✅ Estrutura do banco (shared/schema.ts)
- ✅ Conexão com PostgreSQL (bot_source/server/db.ts)
- ✅ Managers de economia criados
- ✅ Managers de XP criados
- ⏳ Migração dos comandos
- ⏳ Testes de integração
- ⏳ Deprecação dos arquivos JSON
