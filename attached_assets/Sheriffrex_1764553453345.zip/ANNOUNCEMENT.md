# 🤠 Sheriff Rex Bot - Novidades Incríveis! 🎉

Olá vaqueiros e vaqueiras! Temos novidades emocionantes para melhorar sua experiência no Velho Oeste!

---

## 📋 **Sistema de Missões Diárias** 
Use `/missoes` para desafios diários!

<:backpack:1440185962918318181> **3 Missões Diárias** - Reset todo dia
- Ganha recompensas em <:silver_coin:1440185957675438080> Silver Coins, <:saloon_token:1440185942999695391> Tokens e XP
- Mantenha seu **streak** e ganhe bônus de até 100%!

<:scroll_west:1440185935852605564> **2 Missões Semanais** - Recompensas maiores
- Tarefas especiais com <:gift_west:1440185939904167967> Prêmios exclusivos

💡 **Dica:** Complete todas as diárias para manter seu streak ativo!

---

## 🔔 **Lembretes Automáticos**
Use `/lembretes` para nunca mais perder um cooldown!

Configure notificações por DM quando:
- <:pickaxe:1440185926889377872> Mineração terminar
- 🦌 Caçada terminar  
- <:fishing_rod_emoji:1441537977586155592> Pesca terminar
- 📅 Daily ficar disponível

⚙️ Ative/desative lembretes individuais ou todos de uma vez!

---

## 📖 **Tutorial Interativo**
Use `/tutorial` para guiar novos jogadores!

<:cowboy:1440185964684378163> **8 Passos Interativos** ensinando:
- Como ganhar dinheiro
- Sistema de mineração
- Caça e pesca
- Missões diárias
- E muito mais!

🎁 **Kit de Iniciante** ao completar:
- <:silver_coin:1440185957675438080> 1.000 Silver Coins
- <:saloon_token:1440185942999695391> 10 Saloon Tokens  
- <:gem_west:1440185978118737960> 5 Selos
- <:star_west:1440185917645262928> 200 XP

---

## 🎯 **Por Que Isso Importa?**

✅ **Mais Engajamento** - Volte todos os dias para novas missões  
✅ **Sem Esquecer** - Receba lembretes de seus cooldowns  
✅ **Melhor Onboarding** - Novos jogadores aprendem rapidinho  
✅ **Mais Diversão** - Sistema de streaks e desafios diários  

---

## 🚀 **Comece Agora!**

```
/missoes      - Ver suas missões diárias e semanais
/lembretes    - Ativar notificações por DM
/tutorial     - Completar o tutorial (ou recomeçar)
/help         - Ver todos os comandos
```

---

**Boa sorte no Velho Oeste, parceiros! 🤠**  
*Sua lealdade é recompensada no Sheriff Rex Bot*

#sheriffRex #novidades #velhooeste
