import fs from "fs";
import path from "path";
import { EMOJI_TEXT } from "./customEmojis";
import { cacheManager } from "./cacheManager";
import { getDataPath } from "./database";
import { transactionLock } from "./transactionLock";

const dataDir = getDataPath("data");
const inventoryFile = path.join(dataDir, "inventory.json");

interface Item {
  name: string;
  nameEn?: string;
  emoji: string;
  customEmoji?: string;
  weight: number;
  stackable: boolean;
  description: string;
  descriptionEn?: string;
  damage?: number;
  imageUrl?: string;
  price?: number;
  currency?: string;
  maxDurability?: number;
  story?: string;
  storyEn?: string;
}

export const ITEMS: Record<string, Item> = {
  saloon_token: {
    name: "Saloon Token",
    emoji: EMOJI_TEXT.SALOON_TOKEN,
    customEmoji: "SALOON_TOKEN",
    weight: 0.0000005,
    stackable: true,
    description: "Main saloon currency",
  },
  seal: {
    name: "Selo",
    emoji: "🎟️",
    weight: 0.000001,
    stackable: true,
    description: "Selo especial usado para expedições e documentos oficiais",
  },
  silver: {
    name: "Silver Coin",
    emoji: EMOJI_TEXT.SILVER_COIN,
    weight: 0.000005,
    stackable: true,
    description: "Valuable silver coin",
  },
  gold: {
    name: "Ouro",
    emoji: EMOJI_TEXT.GOLD_BAR,
    customEmoji: "gold_bar",
    weight: 1,
    stackable: true,
    description: "Barra de ouro preciosa obtida através da mineração",
  },
  diamond: {
    name: "Diamond",
    emoji: EMOJI_TEXT.GEM,
    customEmoji: "gem",
    weight: 0.1,
    stackable: true,
    description: "Rare diamond found in mining and bank robberies",
  },
  pickaxe: {
    name: "Picareta",
    emoji: EMOJI_TEXT.PICKAXE,
    customEmoji: "pickaxe",
    weight: 2,
    stackable: false,
    description: "Uma picareta lendária que aumenta massivamente sua produção de ouro na mineração solo (16-28 barras ao invés de 1-3)",
    maxDurability: 20,
  },
  honey: {
    name: "Mel",
    emoji: "🍯",
    weight: 0.05,
    stackable: true,
    description: "Mel doce de abelhas selvagens, encontrado em expedições",
  },
  wheat: {
    name: "Trigo",
    emoji: "🌾",
    weight: 0.0005,
    stackable: true,
    description: "Trigo dourado colhido durante expedições",
  },
  cattle: {
    name: "Cattle",
    emoji: "🐄",
    weight: 1,
    stackable: true,
    description: "Cattle from your ranch, valuable livestock for trading",
  },
  escopeta: {
    name: "Escopeta",
    nameEn: "Shotgun",
    emoji: EMOJI_TEXT.ESCOPETA,
    customEmoji: "ESCOPETA",
    weight: 3.5,
    stackable: false,
    description: "Uma escopeta potente com duplo cano, perfeita para combate próximo e caça no velho oeste. Com alcance devastador, é a arma ideal para defender sua vida.",
    descriptionEn: "A powerful double-barrel shotgun, perfect for close combat and hunting in the wild west. With devastating range, it's the ideal weapon to defend your life.",
    damage: 85,
    imageUrl: "https://i.postimg.cc/2yQnJftN/ACC0B258-8EC0-4029-96C0-5D68DE02FBF1.png",
    price: 5000,
    currency: "silver",
    maxDurability: 60,
    story: "Dizem que essa escopeta foi usada por um lendário xerife que manteve a paz em três cidades. Seus dois canos nunca falharam em proteger os inocentes das garras da vilania.",
    storyEn: "They say this shotgun was used by a legendary sheriff who kept the peace in three towns. Its twin barrels never failed to protect the innocent from the clutches of villainy.",
  },
  revolver_vaqueiro: {
    name: "Revólver de Vaqueiro",
    nameEn: "Cowboy Revolver",
    emoji: EMOJI_TEXT.REVOLVER_VAQUEIRO,
    customEmoji: "REVOLVER_VAQUEIRO",
    weight: 2.0,
    stackable: false,
    description: "O clássico revólver de todo vaqueiro honrado, rápido no gatilho e confiável na hora que importa. Símbolo de coragem e justiça no Velho Oeste.",
    descriptionEn: "The classic revolver of every honorable cowboy, quick on the trigger and reliable when it matters. A symbol of courage and justice in the Wild West.",
    damage: 65,
    imageUrl: "https://i.postimg.cc/59Bvfbs5/D9466B53-9F8A-4CB6-A12B-8635841C335D.png",
    price: 3500,
    currency: "silver",
    maxDurability: 70,
    story: "Legenda conta que este revólver pertenceu a um famoso pistoleiro que ganhou mais de cem duelos. Seus tiros são tão rápidos que parecem trovão do céu.",
    storyEn: "Legend has it this revolver belonged to a famous gunslinger who won over a hundred duels. Its shots are so fast they sound like thunder from the sky.",
  },
  revolver_38: {
    name: "Revólver Calibre 38",
    nameEn: ".38 Caliber Revolver",
    emoji: EMOJI_TEXT.REVOLVER_38,
    customEmoji: "REVOLVER_38",
    weight: 1.8,
    stackable: false,
    description: "Um revólver de calibre 38 preciso e leve, ideal para tiroteios rápidos e combate urbano. Sua pontaria é excepcional a qualquer distância.",
    descriptionEn: "A precise and lightweight .38 caliber revolver, ideal for quick shootouts and urban combat. Its aim is exceptional at any distance.",
    damage: 55,
    imageUrl: "https://i.postimg.cc/fbdy5fF8/80976BEE-60A3-4041-8E6B-3624D04A7379.png",
    price: 2500,
    currency: "silver",
    maxDurability: 80,
    story: "Este revólver compacto foi ferramenta de justiceiros que protegiam as cidades menores. Apesar de pequeno, sua precisão letal ganhou respeito em todos os cantos do oeste.",
    storyEn: "This compact revolver was the tool of vigilantes who protected smaller towns. Despite its size, its lethal precision earned respect across the west.",
  },
  rifle_de_caca: {
    name: "Rifle De Caça",
    nameEn: "Hunting Rifle",
    emoji: EMOJI_TEXT.RIFLE_DE_CACA,
    customEmoji: "RIFLE_DE_CACA",
    weight: 3.4,
    stackable: false,
    description: "Rifle de longo alcance com poder devastador, perfeito para caçadores experientes e batalhas à distância. Sua mira é precisa como um falcão no céu.",
    descriptionEn: "Long-range rifle with devastating power, perfect for experienced hunters and long-distance battles. Its aim is as precise as a hawk in the sky.",
    damage: 120,
    imageUrl: "https://i.postimg.cc/x1RwNg2d/IMG-3445.png",
    price: 7500,
    currency: "silver",
    maxDurability: 50,
    story: "O rifle mais temido do velho oeste, aquele que ganhou guerras de território. Dizem que um caçador com este rifle conseguiu proteger sua fazenda de 50 pistoleiros sozinho.",
    storyEn: "The most feared rifle of the wild west, the one that won territory wars. They say a hunter with this rifle defended his ranch against 50 gunslingers alone.",
  },
  basic_bait: {
    name: "Isca Básica",
    emoji: EMOJI_TEXT.BASIC_BAIT,
    customEmoji: "BASIC_BAIT",
    weight: 0.01,
    stackable: true,
    description: "Minhoca comum para pesca básica. Atrai peixes comuns e incomuns.",
    price: 5,
    currency: "silver",
  },
  premium_bait: {
    name: "Isca Premium",
    emoji: EMOJI_TEXT.PREMIUM_BAIT,
    customEmoji: "PREMIUM_BAIT",
    weight: 0.01,
    stackable: true,
    description: "Grilo vivo de qualidade superior. Aumenta muito a chance de pescar peixes raros, épicos e lendários!",
    price: 12,
    currency: "silver",
  },
  golden_hook: {
    name: "Anzol Dourado",
    emoji: EMOJI_TEXT.GOLDEN_HOOK,
    customEmoji: "GOLDEN_HOOK",
    weight: 0.05,
    stackable: true,
    description: "Um anzol dourado feito com uma pena vermelha rara. Aumenta significativamente o número de peixes capturados e a experiência ganha na pesca (3-5 peixes extras e XP aumentado)!",
    price: 15,
    currency: "saloon_token",
    maxDurability: 20,
  },
  deer_meat: {
    name: "Carne de Cervo",
    emoji: "🥩",
    weight: 2,
    stackable: true,
    description: "Carne fresca de cervo, valiosa para venda ou consumo",
    price: 150,
    currency: "silver",
  },
  deer_pelt: {
    name: "Pele de Cervo",
    emoji: EMOJI_TEXT.DEER_PELT,
    customEmoji: "DEER_PELT",
    weight: 1.5,
    stackable: true,
    description: "Pele de cervo de qualidade, procurada por comerciantes",
    price: 200,
    currency: "silver",
    imageUrl: "https://i.postimg.cc/sgnByvcZ/E73819F8-3974-4895-9587-003D27307C3C.png",
  },
  rabbit_meat: {
    name: "Carne de Coelho",
    emoji: "🍖",
    weight: 0.5,
    stackable: true,
    description: "Carne tenra de coelho selvagem",
    price: 50,
    currency: "silver",
  },
  rabbit_pelt: {
    name: "Pele de Coelho",
    emoji: EMOJI_TEXT.RABBIT_PELT,
    customEmoji: "RABBIT_PELT",
    weight: 0.3,
    stackable: true,
    description: "Pele macia de coelho",
    price: 75,
    currency: "silver",
    imageUrl: "https://i.postimg.cc/s2XhZpxf/D235FB82-9508-4A97-AE1C-9E1E4C6CC5AA.png",
  },
  bear_meat: {
    name: "Carne de Urso",
    emoji: "🥩",
    weight: 5,
    stackable: true,
    description: "Carne robusta de urso, extremamente valiosa",
    price: 500,
    currency: "silver",
  },
  bear_pelt: {
    name: "Pele de Urso",
    emoji: EMOJI_TEXT.BEAR_PELT,
    customEmoji: "BEAR_PELT",
    weight: 8,
    stackable: true,
    description: "Pele grossa de urso, troféu raro de caçador",
    price: 800,
    currency: "silver",
    imageUrl: "https://i.postimg.cc/52GxnvpN/90170D80-51C3-4CC0-8824-308AA796034A.png",
  },
  bison_meat: {
    name: "Carne de Bisão",
    emoji: "🥩",
    weight: 6,
    stackable: true,
    description: "Carne premium de bisão selvagem",
    price: 400,
    currency: "silver",
  },
  bison_pelt: {
    name: "Pele de Bisão",
    emoji: EMOJI_TEXT.BISON_PELT,
    customEmoji: "BISON_PELT",
    weight: 7,
    stackable: true,
    description: "Pele resistente de bisão americano",
    price: 600,
    currency: "silver",
    imageUrl: "https://i.postimg.cc/MGMGStXj/E7B908CE-3E40-4D73-A89C-54712A1935DA.png",
  },
  wolf_meat: {
    name: "Carne de Lobo",
    emoji: "🥩",
    weight: 3,
    stackable: true,
    description: "Carne de lobo cinzento",
    price: 250,
    currency: "silver",
  },
  wolf_pelt: {
    name: "Pele de Lobo",
    emoji: EMOJI_TEXT.WOLF_PELT,
    customEmoji: "WOLF_PELT",
    weight: 2,
    stackable: true,
    description: "Pele espessa de lobo, muito procurada",
    price: 350,
    currency: "silver",
    imageUrl: "https://i.postimg.cc/rsCmHmsZ/F973B0C2-BE9C-4114-8A2E-C851F99A510A.png",
  },
  eagle_feather: {
    name: "Pena de Águia",
    emoji: EMOJI_TEXT.EAGLE_FEATHER,
    customEmoji: "EAGLE_FEATHER",
    weight: 0.01,
    stackable: true,
    description: "Pena rara de águia dourada, símbolo de prestígio",
    price: 1000,
    currency: "silver",
  },
  fishing_rod: {
    name: "Vara de Pesca",
    emoji: EMOJI_TEXT.FISHING_ROD,
    customEmoji: "FISHING_ROD",
    weight: 1.5,
    stackable: false,
    description: "Vara de pesca profissional para pescar nos rios do oeste",
    damage: 0,
    price: 800,
    currency: "silver",
    maxDurability: 40,
    imageUrl: "https://i.postimg.cc/pyNMzMHD/IMG-3529.png",
  },
  catfish: {
    name: "Bagre do Rio",
    emoji: EMOJI_TEXT.CATFISH,
    customEmoji: "CATFISH",
    weight: 1.5,
    stackable: true,
    description: "Bagre comum pescado nos rios do oeste",
    price: 80,
    currency: "silver",
  },
  silver_trout: {
    name: "Truta Prateada",
    emoji: EMOJI_TEXT.SILVER_TROUT,
    customEmoji: "SILVER_TROUT",
    weight: 2,
    stackable: true,
    description: "Truta prateada de qualidade média",
    price: 180,
    currency: "silver",
  },
  wild_salmon: {
    name: "Salmão Selvagem",
    emoji: EMOJI_TEXT.WILD_SALMON,
    customEmoji: "WILD_SALMON",
    weight: 3,
    stackable: true,
    description: "Salmão selvagem raro e valioso",
    price: 350,
    currency: "silver",
  },
  giant_pike: {
    name: "Lúcio Gigante",
    emoji: EMOJI_TEXT.GIANT_PIKE,
    customEmoji: "GIANT_PIKE",
    weight: 5,
    stackable: true,
    description: "Lúcio gigante, uma pesca épica!",
    price: 700,
    currency: "silver",
  },
  golden_sturgeon: {
    name: "Esturjão Dourado",
    emoji: EMOJI_TEXT.GOLDEN_STURGEON,
    customEmoji: "GOLDEN_STURGEON",
    weight: 8,
    stackable: true,
    description: "Esturjão dourado lendário, extremamente valioso",
    price: 1200,
    currency: "silver",
  },
  mythic_western_fish: {
    name: "Peixe Mítico do Oeste",
    emoji: EMOJI_TEXT.MYTHIC_WESTERN_FISH,
    customEmoji: "MYTHIC_WESTERN_FISH",
    weight: 10,
    stackable: true,
    description: "Peixe mítico lendário das águas do oeste, raríssimo!",
    price: 2500,
    currency: "silver",
  },
};

export const MAX_WEIGHT = 100;

// Ensure data directory exists
if (!fs.existsSync(dataDir)) {
  fs.mkdirSync(dataDir, { recursive: true });
}

// Ensure inventory file exists
if (!fs.existsSync(inventoryFile)) {
  fs.writeFileSync(inventoryFile, JSON.stringify({}, null, 2));
}

interface Inventory {
  items: Record<string, number>;
  weight: number;
  maxWeight: number;
  itemDurability?: Record<string, number>;
  purchasedBackpacks?: string[];
}

export function getInventory(userId: string): Inventory {
  const defaultInventory: Inventory = {
    items: {},
    weight: 0,
    maxWeight: MAX_WEIGHT,
    itemDurability: {},
    purchasedBackpacks: [],
  };

  const cached = cacheManager.get<Inventory>("inventory", userId);
  if (cached !== null) {
    if (!cached.maxWeight) {
      cached.maxWeight = MAX_WEIGHT;
    }
    if (!cached.itemDurability) {
      cached.itemDurability = {};
    }
    if (!cached.purchasedBackpacks) {
      cached.purchasedBackpacks = [];
    }
    return cached;
  }

  try {
    const data = fs.readFileSync(inventoryFile, "utf8");
    const inventories = JSON.parse(data);

    if (!inventories[userId]) {
      cacheManager.set("inventory", userId, defaultInventory, true);
      return defaultInventory;
    }

    if (!inventories[userId].maxWeight) {
      inventories[userId].maxWeight = MAX_WEIGHT;
    }

    if (!inventories[userId].itemDurability) {
      inventories[userId].itemDurability = {};
    }

    if (!inventories[userId].purchasedBackpacks) {
      inventories[userId].purchasedBackpacks = [];
    }

    cacheManager.set("inventory", userId, inventories[userId], false);
    return inventories[userId];
  } catch (error) {
    console.error("Error reading inventory:", error);
    cacheManager.set("inventory", userId, defaultInventory, true);
    return defaultInventory;
  }
}

export function saveInventory(userId: string, inventory: Inventory): void {
  if (!inventory.maxWeight || inventory.maxWeight < MAX_WEIGHT) {
    const existing = cacheManager.get<Inventory>("inventory", userId);
    if (existing && existing.maxWeight > MAX_WEIGHT) {
      inventory.maxWeight = existing.maxWeight;
    } else {
      inventory.maxWeight = MAX_WEIGHT;
    }
  }

  cacheManager.set("inventory", userId, inventory, true);
}

export function calculateWeight(inventory: Inventory): number {
  let totalWeight = 0;

  for (const [itemId, quantity] of Object.entries(inventory.items)) {
    if (ITEMS[itemId]) {
      totalWeight += ITEMS[itemId].weight * quantity;
    }
  }

  return Math.round(totalWeight * 1000) / 1000;
}

export function checkCapacity(
  inventory: Inventory,
  itemId: string,
  quantity: number,
): { hasCapacity: boolean; required: number } {
  const itemInfo = ITEMS[itemId];
  if (!itemInfo) {
    // Or handle as an error, depending on desired behavior for unknown items
    return { hasCapacity: false, required: 0 };
  }

  const additionalWeight = itemInfo.weight * quantity;
  const currentWeight = calculateWeight(inventory);
  
  // Round the total weight to avoid floating point precision issues
  const totalWeight = Math.round((currentWeight + additionalWeight) * 1000) / 1000;

  return {
    hasCapacity: totalWeight <= inventory.maxWeight,
    required: additionalWeight,
  };
}

export async function addItem(
  userId: string,
  itemId: string,
  quantity: number = 1,
): Promise<any> {
  return await transactionLock.withLock(userId, () => {
    const inventory = getInventory(userId);

    if (!ITEMS[itemId]) {
      return { success: false, error: "Item not found!" };
    }

    const capacityResult = checkCapacity(inventory, itemId, quantity);
    if (!capacityResult.hasCapacity) {
      return {
        success: false,
        error: "🚫 You're carrying too much weight!",
        currentWeight: calculateWeight(inventory),
        maxWeight: inventory.maxWeight,
        additionalWeight: capacityResult.required,
      };
    }

    if (!inventory.items[itemId]) {
      inventory.items[itemId] = 0;
    }

    inventory.items[itemId] += quantity;
    
    if (!inventory.itemDurability) {
      inventory.itemDurability = {};
    }
    
    const item = ITEMS[itemId];
    if (item.maxDurability && !inventory.itemDurability[itemId]) {
      inventory.itemDurability[itemId] = item.maxDurability;
    }
    
    const newWeight = calculateWeight(inventory);
    inventory.weight = newWeight;

    saveInventory(userId, inventory);

    return {
      success: true,
      item: ITEMS[itemId],
      quantity: quantity,
      newWeight: newWeight,
      totalQuantity: inventory.items[itemId],
    };
  });
}

export async function removeItem(
  userId: string,
  itemId: string,
  quantity: number = 1,
): Promise<any> {
  return await transactionLock.withLock(userId, () => {
    const inventory = getInventory(userId);

    if (!inventory.items[itemId] || inventory.items[itemId] < quantity) {
      return { success: false, error: "You don't have enough items!" };
    }

    inventory.items[itemId] -= quantity;

    if (inventory.items[itemId] <= 0) {
      delete inventory.items[itemId];
    }

    inventory.weight = calculateWeight(inventory);

    saveInventory(userId, inventory);

    return {
      success: true,
      item: ITEMS[itemId],
      quantity: quantity,
      newWeight: inventory.weight,
      remainingQuantity: inventory.items[itemId] || 0,
    };
  });
}

export function getItem(userId: string, itemId: string): number {
  const inventory = getInventory(userId);
  return inventory.items[itemId] || 0;
}

export async function transferItem(
  fromUserId: string,
  toUserId: string,
  itemId: string,
  quantity: number,
): Promise<any> {
  return await transactionLock.withMultipleLocks([fromUserId, toUserId], () => {
    const fromInventory = getInventory(fromUserId);
    const toInventory = getInventory(toUserId);

    // Check sender's balance
    if (!fromInventory.items[itemId] || fromInventory.items[itemId] < quantity) {
      return { success: false, error: "You don't have enough items!" };
    }

    // Check recipient's capacity
    const capacityResult = checkCapacity(toInventory, itemId, quantity);
    if (!capacityResult.hasCapacity) {
      return {
        success: false,
        error: "The recipient does not have enough space in their inventory.",
      };
    }

    const itemInfo = ITEMS[itemId];
    if (!itemInfo) {
      return { success: false, error: "Item not found!" };
    }

    // All checks passed, now perform the state changes in memory
    fromInventory.items[itemId] -= quantity;
    if (fromInventory.items[itemId] <= 0) {
      delete fromInventory.items[itemId];
    }
    fromInventory.weight = calculateWeight(fromInventory);

    if (!toInventory.items[itemId]) {
      toInventory.items[itemId] = 0;
    }
    toInventory.items[itemId] += quantity;
    toInventory.weight = calculateWeight(toInventory);

    // Now, save both inventories.
    saveInventory(fromUserId, fromInventory);
    saveInventory(toUserId, toInventory);

    return { success: true, item: itemInfo, quantity: quantity };
  });
}

export const UPGRADE_TIERS = [
  { level: 1, capacity: 100, cost: 0, currency: null },
  { level: 2, capacity: 200, cost: 5000, currency: "silver" },
  { level: 3, capacity: 300, cost: 10000, currency: "silver" },
  { level: 4, capacity: 400, cost: 20000, currency: "silver" },
  { level: 5, capacity: 500, cost: 50000, currency: "silver" },
];

export function getBackpackLevel(userId: string): number {
  const inventory = getInventory(userId);
  const currentCapacity = inventory.maxWeight;

  for (let i = UPGRADE_TIERS.length - 1; i >= 0; i--) {
    if (currentCapacity >= UPGRADE_TIERS[i].capacity) {
      return UPGRADE_TIERS[i].level;
    }
  }

  return 1;
}

export function getNextUpgrade(userId: string): any {
  const inventory = getInventory(userId);
  const currentCapacity = inventory.maxWeight;

  const websiteUpgrades = [
    { capacity: 200, price: "2.99" },
    { capacity: 300, price: "4.99" },
    { capacity: 400, price: "6.99" },
    { capacity: 500, price: "9.99" },
  ];

  for (const upgrade of websiteUpgrades) {
    if (currentCapacity < upgrade.capacity) {
      return { capacity: upgrade.capacity, price: upgrade.price };
    }
  }

  return null;
}

export function getTopUsers(
  itemType: string,
  limit: number = 10,
): Array<{ userId: string; amount: number }> {
  const data = fs.readFileSync(inventoryFile, "utf8");
  const inventories = JSON.parse(data);

  const userAmounts: Array<{ userId: string; amount: number }> = [];

  for (const userId in inventories) {
    const inventory = inventories[userId];
    const amount = inventory.items[itemType] || 0;

    if (amount > 0) {
      userAmounts.push({ userId, amount });
    }
  }

  userAmounts.sort((a, b) => b.amount - a.amount);

  return userAmounts.slice(0, limit);
}

export async function upgradeBackpack(userId: string, newCapacity?: number): Promise<any> {
  const inventory = getInventory(userId);
  const currentLevel = getBackpackLevel(userId);

  if (newCapacity !== undefined) {
    if (newCapacity <= inventory.maxWeight) {
      return {
        success: false,
        error: "New capacity must be greater than current!",
      };
    }

    const validCapacities = [200, 300, 400, 500];
    if (!validCapacities.includes(newCapacity)) {
      return { success: false, error: "Invalid capacity tier!" };
    }

    const oldCapacity = inventory.maxWeight;
    inventory.maxWeight = newCapacity;
    saveInventory(userId, inventory);

    return {
      success: true,
      oldCapacity: oldCapacity,
      newCapacity: newCapacity,
      level: getBackpackLevel(userId),
    };
  }

  if (currentLevel >= UPGRADE_TIERS.length) {
    return { success: false, error: "Already at maximum capacity!" };
  }

  const nextTier = UPGRADE_TIERS[currentLevel];

  if (nextTier.currency && nextTier.cost > 0) {
    const userCurrency = getItem(userId, nextTier.currency);

    if (userCurrency < nextTier.cost) {
      return {
        success: false,
        error: `Not enough ${nextTier.currency}!`,
        required: nextTier.cost,
        current: userCurrency,
        missing: nextTier.cost - userCurrency,
      };
    }

    const removeResult = await removeItem(userId, nextTier.currency, nextTier.cost);

    if (!removeResult.success) {
      return removeResult;
    }
  }

  const oldCapacity = inventory.maxWeight;
  inventory.maxWeight = nextTier.capacity;
  saveInventory(userId, inventory);

  return {
    success: true,
    oldCapacity: oldCapacity,
    newCapacity: nextTier.capacity,
    level: nextTier.level,
    cost: nextTier.cost,
    currency: nextTier.currency,
  };
}

export function getItemDurability(userId: string, itemId: string): number | null {
  const inventory = getInventory(userId);
  const item = ITEMS[itemId];
  
  if (!item || !item.maxDurability) {
    return null;
  }
  
  if (!inventory.itemDurability) {
    return null;
  }
  
  return inventory.itemDurability[itemId] ?? item.maxDurability;
}

export async function reduceDurability(
  userId: string,
  itemId: string,
  amount: number = 1,
): Promise<{ success: boolean; durability: number; broken: boolean; item?: any }> {
  return await transactionLock.withLock(userId, () => {
    const inventory = getInventory(userId);
    const item = ITEMS[itemId];
    
    if (!item || !item.maxDurability) {
      return { success: false, durability: 0, broken: false };
    }
    
    if (!inventory.items[itemId] || inventory.items[itemId] <= 0) {
      return { success: false, durability: 0, broken: false };
    }
    
    if (!inventory.itemDurability) {
      inventory.itemDurability = {};
    }
    
    if (!inventory.itemDurability[itemId]) {
      inventory.itemDurability[itemId] = item.maxDurability;
    }
    
    inventory.itemDurability[itemId] -= amount;
    
    if (inventory.itemDurability[itemId] <= 0) {
      delete inventory.items[itemId];
      delete inventory.itemDurability[itemId];
      inventory.weight = calculateWeight(inventory);
      saveInventory(userId, inventory);
      
      return {
        success: true,
        durability: 0,
        broken: true,
        item: item,
      };
    }
    
    saveInventory(userId, inventory);
    
    return {
      success: true,
      durability: inventory.itemDurability[itemId],
      broken: false,
      item: item,
    };
  });
}
