import { GoogleGenerativeAI } from "@google/generative-ai";

export interface GeminiMessage {
  role: "user" | "model";
  parts: Array<{ text: string }>;
}

export class GeminiService {
  private client: GoogleGenerativeAI;
  private apiKey: string;
  private defaultModel = "gemini-flash-latest";
  private maxRetries = 5;
  private retryDelay = 1000; // ms

  constructor(apiKey?: string) {
    this.apiKey = apiKey || process.env.GOOGLE_API_KEY || "";

    if (!this.apiKey) {
      console.warn("⚠️ Google API key not configured. AI features will not work.");
    }

    this.client = new GoogleGenerativeAI(this.apiKey);
  }

  private async delay(ms: number): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  async chat(
    messages: GeminiMessage[],
    model?: string,
    maxTokens: number = 500,
  ): Promise<string> {
    if (!this.apiKey) {
      throw new Error(
        "Google API key not configured. Please set GOOGLE_API_KEY environment variable.",
      );
    }

    let lastError: Error | null = null;

    for (let attempt = 0; attempt < this.maxRetries; attempt++) {
      try {
        const geminiModel = this.client.getGenerativeModel({
          model: model || this.defaultModel,
          generationConfig: {
            maxOutputTokens: maxTokens,
          },
        });

        // Convert messages to Gemini format
        const history = messages.slice(0, -1).map(msg => ({
          role: msg.role === "user" ? "user" : "model",
          parts: msg.parts,
        }));

        const lastMessage = messages[messages.length - 1];
        const chat = geminiModel.startChat({
          history: history.length > 0 ? history : undefined,
        });

        // Use a timeout to prevent hanging
        const timeoutPromise = new Promise<never>((_, reject) =>
          setTimeout(() => reject(new Error("API request timeout (15s)")), 15000)
        );

        const result = await Promise.race([
          chat.sendMessage(lastMessage.parts[0].text),
          timeoutPromise,
        ]);

        const response = result.response;
        const text = response.text();

        if (!text || text.trim().length === 0) {
          console.warn("⚠️ Gemini returned empty response, retrying...");
          throw new Error("Empty response from AI model");
        }

        return text.trim();
      } catch (error: any) {
        lastError = error;

        // Check for rate limit or quota errors
        if (error?.message?.includes("429") || error?.message?.includes("RESOURCE_EXHAUSTED") || error?.message?.includes("Empty response")) {
          if (attempt < this.maxRetries - 1) {
            const backoffDelay = this.retryDelay * Math.pow(2, attempt);
            console.warn(
              `⏳ Retry needed. Retrying in ${backoffDelay}ms (attempt ${attempt + 1}/${this.maxRetries}): ${error.message}`
            );
            await this.delay(backoffDelay);
            continue;
          }
        } else if (error?.message?.includes("401") || error?.message?.includes("UNAUTHENTICATED")) {
          throw new Error("Invalid API key. Please check your Google API key.");
        } else if (error?.message?.includes("403") || error?.message?.includes("PERMISSION_DENIED")) {
          throw new Error("Permission denied. Check your Google API key permissions.");
        } else if (error?.message?.includes("timeout")) {
          if (attempt < this.maxRetries - 1) {
            console.warn(`⏳ Request timeout. Retrying... (attempt ${attempt + 1}/${this.maxRetries})`);
            await this.delay(this.retryDelay * Math.pow(2, attempt));
            continue;
          }
        } else {
          // For other errors, throw immediately to avoid delays
          throw error;
        }
      }
    }

    throw lastError || new Error("API request failed. Please try again later.");
  }

  isConfigured(): boolean {
    return !!this.apiKey && this.apiKey.length > 0;
  }
}

export const geminiService = new GeminiService();
