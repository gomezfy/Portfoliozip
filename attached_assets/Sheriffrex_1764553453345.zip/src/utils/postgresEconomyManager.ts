import { db } from "../../server/db";
import { users } from "../../shared/schema";
import { eq } from "drizzle-orm";

/**
 * PostgreSQL Economy Manager
 * Substitui o dataManager.ts baseado em JSON
 */

// ===================================
// USER MANAGEMENT
// ===================================

/**
 * Garante que o usuário existe no banco de dados
 */
export async function ensureUser(userId: string, username: string): Promise<void> {
  const [existing] = await db
    .select()
    .from(users)
    .where(eq(users.userId, userId))
    .limit(1);

  if (!existing) {
    await db.insert(users).values({
      userId,
      username,
    });
  }
}

/**
 * Atualiza o username do usuário se mudou
 */
export async function updateUsername(userId: string, username: string): Promise<void> {
  await db
    .update(users)
    .set({ username, updatedAt: new Date() })
    .where(eq(users.userId, userId));
}

// ===================================
// GOLD (Saloon Tokens) OPERATIONS
// ===================================

export async function getUserGold(userId: string): Promise<number> {
  const [user] = await db
    .select({ saloonTokens: users.saloonTokens })
    .from(users)
    .where(eq(users.userId, userId))
    .limit(1);

  return user?.saloonTokens ?? 0;
}

export async function setUserGold(userId: string, amount: number): Promise<void> {
  await db
    .update(users)
    .set({ 
      saloonTokens: Math.max(0, amount),
      updatedAt: new Date()
    })
    .where(eq(users.userId, userId));
}

export async function addUserGold(userId: string, amount: number): Promise<void> {
  const current = await getUserGold(userId);
  await setUserGold(userId, current + amount);
  
  // Atualizar totalEarnings se for positivo
  if (amount > 0) {
    await db
      .update(users)
      .set({ 
        totalEarnings: (await getTotalEarnings(userId)) + amount,
        updatedAt: new Date()
      })
      .where(eq(users.userId, userId));
  } else if (amount < 0) {
    await db
      .update(users)
      .set({ 
        totalSpent: (await getTotalSpent(userId)) + Math.abs(amount),
        updatedAt: new Date()
      })
      .where(eq(users.userId, userId));
  }
}

export async function removeUserGold(userId: string, amount: number): Promise<boolean> {
  const current = await getUserGold(userId);
  if (current < amount) {
    return false; // Saldo insuficiente
  }
  
  await setUserGold(userId, current - amount);
  
  // Atualizar totalSpent
  await db
    .update(users)
    .set({ 
      totalSpent: (await getTotalSpent(userId)) + amount,
      updatedAt: new Date()
    })
    .where(eq(users.userId, userId));
  
  return true;
}

export async function transferGold(fromUserId: string, toUserId: string, amount: number): Promise<boolean> {
  const fromBalance = await getUserGold(fromUserId);
  if (fromBalance < amount) {
    return false;
  }
  
  // Usar transação para garantir atomicidade
  try {
    await db.transaction(async (tx) => {
      // Ler dados do remetente dentro da transação
      const [fromUser] = await tx
        .select()
        .from(users)
        .where(eq(users.userId, fromUserId));
      
      if (!fromUser || fromUser.saloonTokens < amount) {
        throw new Error("Saldo insuficiente");
      }
      
      // Ler dados do destinatário dentro da transação
      const [toUser] = await tx
        .select()
        .from(users)
        .where(eq(users.userId, toUserId));
      
      if (!toUser) {
        throw new Error("Destinatário não encontrado");
      }
      
      // Atualizar remetente
      await tx
        .update(users)
        .set({ 
          saloonTokens: fromUser.saloonTokens - amount,
          totalSpent: fromUser.totalSpent + amount,
          updatedAt: new Date()
        })
        .where(eq(users.userId, fromUserId));
      
      // Atualizar destinatário
      await tx
        .update(users)
        .set({ 
          saloonTokens: toUser.saloonTokens + amount,
          totalEarnings: toUser.totalEarnings + amount,
          updatedAt: new Date()
        })
        .where(eq(users.userId, toUserId));
    });
    
    return true;
  } catch (error) {
    console.error("Erro na transferência de gold:", error);
    return false;
  }
}

// ===================================
// SILVER OPERATIONS
// ===================================

export async function getUserSilver(userId: string): Promise<number> {
  const [user] = await db
    .select({ silver: users.silver })
    .from(users)
    .where(eq(users.userId, userId))
    .limit(1);

  return user?.silver ?? 0;
}

export async function setUserSilver(userId: string, amount: number): Promise<void> {
  await db
    .update(users)
    .set({ 
      silver: Math.max(0, amount),
      updatedAt: new Date()
    })
    .where(eq(users.userId, userId));
}

export async function addUserSilver(userId: string, amount: number): Promise<void> {
  const current = await getUserSilver(userId);
  await setUserSilver(userId, current + amount);
}

export async function removeUserSilver(userId: string, amount: number): Promise<boolean> {
  const current = await getUserSilver(userId);
  if (current < amount) {
    return false;
  }
  
  await setUserSilver(userId, current - amount);
  return true;
}

export async function transferSilver(fromUserId: string, toUserId: string, amount: number): Promise<boolean> {
  const fromBalance = await getUserSilver(fromUserId);
  if (fromBalance < amount) {
    return false;
  }
  
  try {
    await db.transaction(async (tx) => {
      // Ler dados do remetente dentro da transação
      const [fromUser] = await tx
        .select()
        .from(users)
        .where(eq(users.userId, fromUserId));
      
      if (!fromUser || fromUser.silver < amount) {
        throw new Error("Saldo insuficiente");
      }
      
      // Ler dados do destinatário dentro da transação
      const [toUser] = await tx
        .select()
        .from(users)
        .where(eq(users.userId, toUserId));
      
      if (!toUser) {
        throw new Error("Destinatário não encontrado");
      }
      
      // Atualizar remetente
      await tx
        .update(users)
        .set({ 
          silver: fromUser.silver - amount,
          updatedAt: new Date()
        })
        .where(eq(users.userId, fromUserId));
      
      // Atualizar destinatário
      await tx
        .update(users)
        .set({ 
          silver: toUser.silver + amount,
          updatedAt: new Date()
        })
        .where(eq(users.userId, toUserId));
    });
    
    return true;
  } catch (error) {
    console.error("Erro na transferência de silver:", error);
    return false;
  }
}

// ===================================
// BANK OPERATIONS
// ===================================

export async function getUserBank(userId: string): Promise<number> {
  const [user] = await db
    .select({ bank: users.bank })
    .from(users)
    .where(eq(users.userId, userId))
    .limit(1);

  return user?.bank ?? 0;
}

export async function setUserBank(userId: string, amount: number): Promise<void> {
  await db
    .update(users)
    .set({ 
      bank: Math.max(0, amount),
      updatedAt: new Date()
    })
    .where(eq(users.userId, userId));
}

export async function depositToBank(userId: string, amount: number): Promise<boolean> {
  const gold = await getUserGold(userId);
  if (gold < amount) {
    return false;
  }
  
  try {
    await db.transaction(async (tx) => {
      // Ler dados do usuário dentro da transação
      const [user] = await tx
        .select()
        .from(users)
        .where(eq(users.userId, userId));
      
      if (!user || user.saloonTokens < amount) {
        throw new Error("Saldo insuficiente");
      }
      
      // Transferir do ouro para o banco
      await tx
        .update(users)
        .set({ 
          saloonTokens: user.saloonTokens - amount,
          bank: user.bank + amount,
          updatedAt: new Date()
        })
        .where(eq(users.userId, userId));
    });
    
    return true;
  } catch (error) {
    console.error("Erro ao depositar no banco:", error);
    return false;
  }
}

export async function withdrawFromBank(userId: string, amount: number): Promise<boolean> {
  const bank = await getUserBank(userId);
  if (bank < amount) {
    return false;
  }
  
  try {
    await db.transaction(async (tx) => {
      // Ler dados do usuário dentro da transação
      const [user] = await tx
        .select()
        .from(users)
        .where(eq(users.userId, userId));
      
      if (!user || user.bank < amount) {
        throw new Error("Saldo do banco insuficiente");
      }
      
      // Transferir do banco para ouro
      await tx
        .update(users)
        .set({ 
          bank: user.bank - amount,
          saloonTokens: user.saloonTokens + amount,
          updatedAt: new Date()
        })
        .where(eq(users.userId, userId));
    });
    
    return true;
  } catch (error) {
    console.error("Erro ao sacar do banco:", error);
    return false;
  }
}

// ===================================
// HELPER FUNCTIONS
// ===================================

async function getTotalEarnings(userId: string): Promise<number> {
  const [user] = await db
    .select({ totalEarnings: users.totalEarnings })
    .from(users)
    .where(eq(users.userId, userId))
    .limit(1);

  return user?.totalEarnings ?? 0;
}

async function getTotalSpent(userId: string): Promise<number> {
  const [user] = await db
    .select({ totalSpent: users.totalSpent })
    .from(users)
    .where(eq(users.userId, userId))
    .limit(1);

  return user?.totalSpent ?? 0;
}

// ===================================
// STATISTICS
// ===================================

export async function incrementGamesPlayed(userId: string): Promise<void> {
  const [user] = await db
    .select({ gamesPlayed: users.gamesPlayed })
    .from(users)
    .where(eq(users.userId, userId))
    .limit(1);

  await db
    .update(users)
    .set({ 
      gamesPlayed: (user?.gamesPlayed ?? 0) + 1,
      updatedAt: new Date()
    })
    .where(eq(users.userId, userId));
}

export async function incrementMiningSessions(userId: string): Promise<void> {
  const [user] = await db
    .select({ miningSessions: users.miningSessions })
    .from(users)
    .where(eq(users.userId, userId))
    .limit(1);

  await db
    .update(users)
    .set({ 
      miningSessions: (user?.miningSessions ?? 0) + 1,
      updatedAt: new Date()
    })
    .where(eq(users.userId, userId));
}

export async function incrementBountiesCaptured(userId: string): Promise<void> {
  const [user] = await db
    .select({ bountiesCaptured: users.bountiesCaptured })
    .from(users)
    .where(eq(users.userId, userId))
    .limit(1);

  await db
    .update(users)
    .set({ 
      bountiesCaptured: (user?.bountiesCaptured ?? 0) + 1,
      updatedAt: new Date()
    })
    .where(eq(users.userId, userId));
}
