import { db } from '../../server/db';
import { rpNpcMemory } from '../../shared/schema';
import { eq, and, desc } from 'drizzle-orm';
import { v4 as uuidv4 } from 'uuid';

interface NPCMemory {
  memory: string;
  importance: number;
  emotionalTone: string;
  createdAt: Date;
}

class RPNpcMemoryService {
  async saveMemory(
    npcType: string,
    userId: string,
    channelId: string,
    memory: string,
    importance: number = 1,
    emotionalTone: string = 'neutral'
  ): Promise<void> {
    await db.insert(rpNpcMemory).values({
      id: uuidv4(),
      npcType,
      userId,
      channelId,
      memory,
      importance,
      emotionalTone,
    });
  }

  async getRecentMemories(
    npcType: string,
    userId: string,
    channelId: string,
    limit: number = 5
  ): Promise<NPCMemory[]> {
    const memories = await db
      .select()
      .from(rpNpcMemory)
      .where(
        and(
          eq(rpNpcMemory.npcType, npcType),
          eq(rpNpcMemory.userId, userId),
          eq(rpNpcMemory.channelId, channelId)
        )
      )
      .orderBy(desc(rpNpcMemory.createdAt))
      .limit(limit);

    return memories.map(m => ({
      memory: m.memory,
      importance: m.importance,
      emotionalTone: m.emotionalTone,
      createdAt: m.createdAt,
    }));
  }

  formatMemoriesForPrompt(memories: NPCMemory[]): string {
    if (memories.length === 0) {
      return '';
    }

    const formatted = memories
      .map((m, i) => {
        const emotionEmoji = {
          positive: '😊',
          negative: '😠',
          neutral: '😐',
          fearful: '😨',
          excited: '🤩',
        };
        const emoji = emotionEmoji[m.emotionalTone as keyof typeof emotionEmoji] || '😐';
        return `[Memória ${i + 1}] ${emoji} ${m.memory} (Importância: ${m.importance}/10)`;
      })
      .join('\n');

    return `\n\nMEMÓRIAS ANTERIORES COM ESTE JOGADOR:\n${formatted}\n`;
  }

  createMemoryFromInteraction(
    message: string,
    response: string,
    emotionalTone: string = 'neutral'
  ): { memory: string; importance: number } {
    // Extrair pontos principais da conversa
    const memory = `Jogador disse: "${message}" → Respondi: "${response}"`;
    
    // Calcular importância baseado no comprimento e tom
    let importance = 1;
    if (message.length > 100) importance += 1;
    if (emotionalTone !== 'neutral') importance += 1;
    if (message.includes('ouro') || message.includes('tesouro') || message.includes('dinheiro')) importance += 2;
    
    return { memory, importance: Math.min(importance, 10) };
  }

  async clearUserMemories(
    npcType: string,
    userId: string,
    channelId: string
  ): Promise<void> {
    // Nota: Aqui apenas log, não deletamos pois queremos manter histórico
    console.log(`Histórico de ${npcType} para ${userId} será resetado no próximo ciclo`);
  }
}

export const rpNpcMemoryService = new RPNpcMemoryService();
