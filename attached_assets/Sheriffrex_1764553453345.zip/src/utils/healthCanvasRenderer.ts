import { createCanvas, GlobalFonts, SKRSContext2D } from '@napi-rs/canvas';
import path from 'path';
import fs from 'fs';

function roundRect(
  ctx: SKRSContext2D,
  x: number,
  y: number,
  width: number,
  height: number,
  radius: number
): void {
  ctx.beginPath();
  ctx.moveTo(x + radius, y);
  ctx.lineTo(x + width - radius, y);
  ctx.quadraticCurveTo(x + width, y, x + width, y + radius);
  ctx.lineTo(x + width, y + height - radius);
  ctx.quadraticCurveTo(x + width, y + height, x + width - radius, y + height);
  ctx.lineTo(x + radius, y + height);
  ctx.quadraticCurveTo(x, y + height, x, y + height - radius);
  ctx.lineTo(x, y + radius);
  ctx.quadraticCurveTo(x, y, x + radius, y);
  ctx.closePath();
}

let fontsRegistered = false;

function ensureFontsRegistered(): void {
  if (fontsRegistered) return;

  const fontsDir = path.join(process.cwd(), 'assets', 'fonts');
  
  const fontFiles = [
    { file: 'Nunito-Bold.ttf', family: 'Nunito-Bold' },
    { file: 'Nunito-SemiBold.ttf', family: 'Nunito-SemiBold' },
    { file: 'Nunito-Regular.ttf', family: 'Nunito' },
  ];

  for (const { file, family } of fontFiles) {
    const fontPath = path.join(fontsDir, file);
    if (fs.existsSync(fontPath)) {
      GlobalFonts.registerFromPath(fontPath, family);
    }
  }

  fontsRegistered = true;
}

interface HealthStats {
  health: number;
  maxHealth: number;
  stamina: number;
  maxStamina: number;
  thirst: number;
  maxThirst: number;
  hunger: number;
  maxHunger: number;
  blood: number;
  maxBlood: number;
  temperature: number;
  username: string;
}

const NEON_COLOR = '#f5e6c8';
const NEON_GLOW = '#fffaed';

// Intelligent color based on percentage
function getColorByPercent(percent: number): { fill: string; glow: string } {
  if (percent < 25) {
    // Crítico: Vermelho intenso
    return { fill: '#ff3333', glow: '#ff6666' };
  } else if (percent < 50) {
    // Baixo: Laranja
    return { fill: '#ff8800', glow: '#ffaa44' };
  } else if (percent < 75) {
    // Médio: Amarelo
    return { fill: '#ffdd00', glow: '#ffee66' };
  } else {
    // Alto: Verde
    return { fill: '#44dd44', glow: '#66ff66' };
  }
}

function drawBottleIcon(
  ctx: ReturnType<ReturnType<typeof createCanvas>['getContext']>,
  x: number,
  y: number,
  size: number,
  fillPercent: number
): void {
  const w = size * 0.4;
  const h = size * 0.85;
  const neckW = w * 0.4;
  const neckH = h * 0.18;
  const bodyH = h * 0.72;
  const centerX = x + size / 2;
  const startY = y + size * 0.08;

  ctx.save();

  const createBottlePath = () => {
    ctx.beginPath();
    ctx.moveTo(centerX - neckW / 2, startY);
    ctx.lineTo(centerX - neckW / 2, startY + neckH);
    ctx.lineTo(centerX - w / 2, startY + neckH + h * 0.05);
    ctx.lineTo(centerX - w / 2, startY + neckH + bodyH);
    ctx.quadraticCurveTo(centerX - w / 2, startY + h, centerX, startY + h);
    ctx.quadraticCurveTo(centerX + w / 2, startY + h, centerX + w / 2, startY + neckH + bodyH);
    ctx.lineTo(centerX + w / 2, startY + neckH + h * 0.05);
    ctx.lineTo(centerX + neckW / 2, startY + neckH);
    ctx.lineTo(centerX + neckW / 2, startY);
    ctx.closePath();
  };

  if (fillPercent > 0) {
    createBottlePath();
    ctx.save();
    ctx.clip();
    
    const totalFillableH = h * 0.95;
    const fillH = (totalFillableH * fillPercent) / 100;
    const fillY = startY + h - fillH;
    
    ctx.fillStyle = NEON_COLOR;
    ctx.globalAlpha = 0.9;
    ctx.fillRect(centerX - w / 2 - 5, fillY, w + 10, fillH + 5);
    ctx.restore();
  }

  createBottlePath();
  ctx.shadowColor = NEON_GLOW;
  ctx.shadowBlur = 6;
  ctx.strokeStyle = NEON_COLOR;
  ctx.lineWidth = 3;
  ctx.stroke();

  createBottlePath();
  ctx.shadowBlur = 3;
  ctx.stroke();

  ctx.restore();
}

function drawAppleIcon(
  ctx: ReturnType<ReturnType<typeof createCanvas>['getContext']>,
  x: number,
  y: number,
  size: number,
  fillPercent: number
): void {
  const centerX = x + size / 2;
  const centerY = y + size / 2 + size * 0.05;
  const r = size * 0.35;

  ctx.save();

  const createApplePath = () => {
    ctx.beginPath();
    ctx.moveTo(centerX, centerY - r * 1.0);
    ctx.bezierCurveTo(
      centerX - r * 0.7, centerY - r * 1.3,
      centerX - r * 1.2, centerY - r * 0.4,
      centerX - r * 1.0, centerY + r * 0.3
    );
    ctx.bezierCurveTo(
      centerX - r * 0.9, centerY + r * 0.9,
      centerX - r * 0.3, centerY + r * 1.1,
      centerX, centerY + r * 0.9
    );
    ctx.bezierCurveTo(
      centerX + r * 0.3, centerY + r * 1.1,
      centerX + r * 0.9, centerY + r * 0.9,
      centerX + r * 1.0, centerY + r * 0.3
    );
    ctx.bezierCurveTo(
      centerX + r * 1.2, centerY - r * 0.4,
      centerX + r * 0.7, centerY - r * 1.3,
      centerX, centerY - r * 1.0
    );
    ctx.closePath();
  };

  if (fillPercent > 0) {
    createApplePath();
    ctx.save();
    ctx.clip();
    const totalH = r * 2.1;
    const fillH = (totalH * fillPercent) / 100;
    const fillY = centerY + r * 1.0 - fillH;
    ctx.fillStyle = NEON_COLOR;
    ctx.globalAlpha = 0.9;
    ctx.fillRect(x - 5, fillY, size + 10, fillH + 5);
    ctx.restore();
  }

  createApplePath();
  ctx.shadowColor = NEON_GLOW;
  ctx.shadowBlur = 6;
  ctx.strokeStyle = NEON_COLOR;
  ctx.lineWidth = 3;
  ctx.stroke();

  createApplePath();
  ctx.shadowBlur = 3;
  ctx.stroke();

  ctx.beginPath();
  ctx.moveTo(centerX, centerY - r * 1.0);
  ctx.quadraticCurveTo(centerX + r * 0.2, centerY - r * 1.4, centerX + r * 0.4, centerY - r * 1.2);
  ctx.strokeStyle = NEON_COLOR;
  ctx.lineWidth = 2.5;
  ctx.stroke();

  ctx.beginPath();
  ctx.ellipse(centerX + r * 0.15, centerY - r * 1.35, r * 0.2, r * 0.12, Math.PI / 4, 0, Math.PI * 2);
  ctx.stroke();

  ctx.restore();
}

function drawThermometerIcon(
  ctx: ReturnType<ReturnType<typeof createCanvas>['getContext']>,
  x: number,
  y: number,
  size: number,
  fillPercent: number
): void {
  const centerX = x + size / 2;
  const tubeW = size * 0.14;
  const tubeH = size * 0.5;
  const bulbR = size * 0.16;
  const startY = y + size * 0.12;

  ctx.save();

  const createThermometerPath = () => {
    ctx.beginPath();
    ctx.arc(centerX, startY + tubeH + bulbR * 0.7, bulbR, 0, Math.PI * 2);
    ctx.moveTo(centerX - tubeW / 2, startY + tubeH);
    ctx.lineTo(centerX - tubeW / 2, startY);
    ctx.arc(centerX, startY, tubeW / 2, Math.PI, 0);
    ctx.lineTo(centerX + tubeW / 2, startY + tubeH);
  };

  if (fillPercent > 0) {
    createThermometerPath();
    ctx.save();
    ctx.clip();
    const totalH = tubeH + bulbR * 2;
    const fillH = (totalH * fillPercent) / 100;
    const fillY = startY + tubeH + bulbR * 1.7 - fillH;
    ctx.fillStyle = NEON_COLOR;
    ctx.globalAlpha = 0.9;
    ctx.fillRect(centerX - bulbR - 5, fillY, bulbR * 2 + 10, fillH + 5);
    ctx.restore();
  }

  createThermometerPath();
  ctx.shadowColor = NEON_GLOW;
  ctx.shadowBlur = 6;
  ctx.strokeStyle = NEON_COLOR;
  ctx.lineWidth = 3;
  ctx.stroke();

  createThermometerPath();
  ctx.shadowBlur = 3;
  ctx.stroke();

  for (let i = 0; i < 3; i++) {
    const tickY = startY + tubeH * 0.2 + (tubeH * 0.6 * i) / 2;
    ctx.beginPath();
    ctx.moveTo(centerX + tubeW / 2 + 4, tickY);
    ctx.lineTo(centerX + tubeW / 2 + 10, tickY);
    ctx.strokeStyle = NEON_COLOR;
    ctx.lineWidth = 2;
    ctx.stroke();
  }

  ctx.restore();
}

function drawDropIcon(
  ctx: ReturnType<ReturnType<typeof createCanvas>['getContext']>,
  x: number,
  y: number,
  size: number,
  fillPercent: number
): void {
  const centerX = x + size / 2;
  const centerY = y + size / 2 + size * 0.05;
  const h = size * 0.75;

  ctx.save();

  const createDropPath = () => {
    ctx.beginPath();
    ctx.moveTo(centerX, centerY - h * 0.45);
    ctx.bezierCurveTo(
      centerX - h * 0.35, centerY - h * 0.1,
      centerX - h * 0.4, centerY + h * 0.25,
      centerX, centerY + h * 0.45
    );
    ctx.bezierCurveTo(
      centerX + h * 0.4, centerY + h * 0.25,
      centerX + h * 0.35, centerY - h * 0.1,
      centerX, centerY - h * 0.45
    );
    ctx.closePath();
  };

  if (fillPercent > 0) {
    createDropPath();
    ctx.save();
    ctx.clip();
    const fillH = (h * 0.9 * fillPercent) / 100;
    const fillY = centerY + h * 0.45 - fillH;
    ctx.fillStyle = NEON_COLOR;
    ctx.globalAlpha = 0.9;
    ctx.fillRect(x - 5, fillY, size + 10, fillH + 5);
    ctx.restore();
  }

  createDropPath();
  ctx.shadowColor = NEON_GLOW;
  ctx.shadowBlur = 6;
  ctx.strokeStyle = NEON_COLOR;
  ctx.lineWidth = 3;
  ctx.stroke();

  createDropPath();
  ctx.shadowBlur = 3;
  ctx.stroke();

  ctx.restore();
}

function drawCrossIcon(
  ctx: ReturnType<ReturnType<typeof createCanvas>['getContext']>,
  x: number,
  y: number,
  size: number,
  fillPercent: number
): void {
  const centerX = x + size / 2;
  const centerY = y + size / 2;
  const armW = size * 0.22;
  const armL = size * 0.35;
  const colors = getColorByPercent(fillPercent);

  ctx.save();

  const createCrossPath = () => {
    ctx.beginPath();
    ctx.moveTo(centerX - armW / 2, centerY - armL);
    ctx.lineTo(centerX + armW / 2, centerY - armL);
    ctx.lineTo(centerX + armW / 2, centerY - armW / 2);
    ctx.lineTo(centerX + armL, centerY - armW / 2);
    ctx.lineTo(centerX + armL, centerY + armW / 2);
    ctx.lineTo(centerX + armW / 2, centerY + armW / 2);
    ctx.lineTo(centerX + armW / 2, centerY + armL);
    ctx.lineTo(centerX - armW / 2, centerY + armL);
    ctx.lineTo(centerX - armW / 2, centerY + armW / 2);
    ctx.lineTo(centerX - armL, centerY + armW / 2);
    ctx.lineTo(centerX - armL, centerY - armW / 2);
    ctx.lineTo(centerX - armW / 2, centerY - armW / 2);
    ctx.closePath();
  };

  if (fillPercent > 0) {
    createCrossPath();
    ctx.save();
    ctx.clip();
    const totalH = armL * 2;
    const fillH = (totalH * fillPercent) / 100;
    const fillY = centerY + armL - fillH;
    ctx.fillStyle = colors.fill;
    ctx.globalAlpha = 0.9;
    ctx.fillRect(x - 5, fillY, size + 10, fillH + 5);
    ctx.restore();
  }

  createCrossPath();
  ctx.shadowColor = colors.glow;
  ctx.shadowBlur = 6;
  ctx.strokeStyle = colors.fill;
  ctx.lineWidth = 3;
  ctx.stroke();

  createCrossPath();
  ctx.shadowBlur = 3;
  ctx.stroke();

  ctx.restore();
}

export async function createHealthCanvas(stats: HealthStats): Promise<Buffer> {
  ensureFontsRegistered();

  const iconSize = 60;
  const padding = 15;
  const gap = 12;
  const numIcons = 5;
  const width = padding * 2 + iconSize * numIcons + gap * (numIcons - 1);
  const staminaHeight = 15;
  const height = iconSize + padding * 2 + staminaHeight + padding;
  
  const canvas = createCanvas(width, height);
  const ctx = canvas.getContext('2d');

  ctx.fillStyle = '#1a1a1a';
  roundRect(ctx, 0, 0, width, height, 15);
  ctx.fill();

  const thirstPercent = Math.max(0, Math.min(100, (stats.thirst / stats.maxThirst) * 100));
  const hungerPercent = Math.max(0, Math.min(100, (stats.hunger / stats.maxHunger) * 100));
  const temperaturePercent = Math.max(0, Math.min(100, ((stats.temperature - 30) / 15) * 100));
  const bloodPercent = Math.max(0, Math.min(100, (stats.blood / stats.maxBlood) * 100));
  const healthPercent = Math.max(0, Math.min(100, (stats.health / stats.maxHealth) * 100));
  const staminaPercent = Math.max(0, Math.min(100, (stats.stamina / stats.maxStamina) * 100));

  let iconX = padding;
  const iconY = padding;

  drawBottleIcon(ctx, iconX, iconY, iconSize, thirstPercent);
  iconX += iconSize + gap;

  drawAppleIcon(ctx, iconX, iconY, iconSize, hungerPercent);
  iconX += iconSize + gap;

  drawThermometerIcon(ctx, iconX, iconY, iconSize, temperaturePercent);
  iconX += iconSize + gap;

  drawDropIcon(ctx, iconX, iconY, iconSize, bloodPercent);
  iconX += iconSize + gap;

  drawCrossIcon(ctx, iconX, iconY, iconSize, healthPercent);

  // Draw Stamina Bar
  const staminaY = iconSize + padding + padding / 2;
  drawStaminaBar(ctx, padding, staminaY, width - padding * 2, staminaHeight, staminaPercent);

  return canvas.toBuffer('image/png');
}

function drawStaminaBar(
  ctx: ReturnType<ReturnType<typeof createCanvas>['getContext']>,
  x: number,
  y: number,
  width: number,
  height: number,
  fillPercent: number
): void {
  const barHeight = height * 0.6;
  const barY = y + (height - barHeight) / 2;

  // Background bar (gray/dark)
  ctx.fillStyle = '#444444';
  roundRect(ctx, x, barY, width, barHeight, 5);
  ctx.fill();

  // Fill bar (white for stamina)
  const fillWidth = (width * fillPercent) / 100;
  ctx.fillStyle = 'white';
  roundRect(ctx, x, barY, fillWidth, barHeight, 5);
  ctx.fill();

  // Border
  ctx.strokeStyle = '#666666';
  ctx.lineWidth = 1;
  roundRect(ctx, x, barY, width, barHeight, 5);
  ctx.stroke();
}
