import { ChatInputCommandInteraction, PermissionFlagsBits, MessageFlags } from "discord.js";

interface PermissionCheckResult {
  allowed: boolean;
  reason?: string;
}

/**
 * Check if user has admin/mod permissions
 * Allowed roles: Admin, Administrador, Mod, Moderador, Staff
 */
export function checkAdminPermission(interaction: ChatInputCommandInteraction): PermissionCheckResult {
  if (!interaction.member) {
    return { allowed: false, reason: "Membro não encontrado" };
  }

  // Check if user is server owner
  if (interaction.guild?.ownerId === interaction.user.id) {
    return { allowed: true };
  }

  // Check if user has admin permission
  if (interaction.memberPermissions?.has(PermissionFlagsBits.Administrator)) {
    return { allowed: true };
  }

  // Check for specific roles (Admin, Mod, Staff in any case variation)
  if (interaction.member.roles && 'cache' in interaction.member.roles) {
    const roleNames = interaction.member.roles.cache.map(role => role.name.toLowerCase());
    const hasAdminRole = roleNames.some(name =>
      name.includes('admin') ||
      name.includes('mod') ||
      name.includes('staff') ||
      name.includes('moderador')
    );

    if (hasAdminRole) {
      return { allowed: true };
    }
  }

  return {
    allowed: false,
    reason: "❌ Apenas **Administradores** e **Moderadores** podem usar este comando!"
  };
}

/**
 * Send a permission denied message (ephemeral)
 */
export async function sendPermissionDenied(
  interaction: ChatInputCommandInteraction,
  reason: string = "❌ Você não tem permissão para usar este comando!"
): Promise<void> {
  await interaction.reply({
    content: reason,
    flags: MessageFlags.Ephemeral,
  });
}

/**
 * Middleware to check admin permission at start of command
 */
export async function requireAdmin(
  interaction: ChatInputCommandInteraction
): Promise<boolean> {
  const check = checkAdminPermission(interaction);

  if (!check.allowed) {
    await sendPermissionDenied(interaction, check.reason);
    return false;
  }

  return true;
}
