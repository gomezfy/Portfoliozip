import { db } from '../../server/db';
import { users } from '../../shared/schema';
import { eq } from 'drizzle-orm';
import { modernLogger } from './modernLogger';

let bleedingIntervalId: NodeJS.Timeout | null = null;

export async function processBleeding(): Promise<void> {
  try {
    const bleedingUsers = await db
      .select()
      .from(users)
      .where(eq(users.isBleeding, true));

    for (const user of bleedingUsers) {
      const healthLoss = Math.ceil(user.bleedingAmount);
      const newHealth = Math.max(0, user.health - healthLoss);

      await db
        .update(users)
        .set({
          health: newHealth,
          updatedAt: new Date(),
        })
        .where(eq(users.userId, user.userId));

      if (newHealth <= 0) {
        await db
          .update(users)
          .set({
            isBleeding: false,
            bleedingAmount: 0,
          })
          .where(eq(users.userId, user.userId));
      }

      modernLogger.debug(`🩸 User ${user.userId} bleeding: ❤️ ${user.health}→${newHealth}`);
    }
  } catch (error: any) {
    // Only log if it's not a database connection error during startup
    if (error?.message && !error.message.includes('Invalid URL')) {
      modernLogger.warn(`Bleeding system error: ${error?.message || 'Unknown error'}`);
    }
  }
}

export function startBleedingSystem(): void {
  if (bleedingIntervalId) return;

  bleedingIntervalId = setInterval(() => {
    processBleeding().catch(() => {
      // Silently fail to avoid spam logs
    });
  }, 30000); // Every 30 seconds

  modernLogger.info('🩸 Bleeding system initialized (runs every 30 seconds)');
}

export function stopBleedingSystem(): void {
  if (bleedingIntervalId) {
    clearInterval(bleedingIntervalId);
    bleedingIntervalId = null;
    modernLogger.info('🩸 Bleeding system stopped');
  }
}
