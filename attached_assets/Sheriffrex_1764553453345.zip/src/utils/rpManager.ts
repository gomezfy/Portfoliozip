import fs from "fs";
import path from "path";
import { EmbedBuilder, Message, TextChannel } from "discord.js";
import { getDataPath } from "./database";
import { rpHealthService } from "./rpHealthService";
import { geminiService } from "./geminiService";

const rpConfigPath = path.join(getDataPath("data"), "rp-config.json");

let configCache: Record<string, RPGuildConfig> | null = null;
let cacheLastUpdated: number = 0;
const CACHE_TTL = 60000;

export interface RPChannelConfig {
  channelId: string;
  enabled: boolean;
  strictMode: boolean;
  warningMode: "reply" | "dm" | "delete" | "none";
  aiNarration: boolean;
}

export interface RPGuildConfig {
  enabled: boolean;
  channels: RPChannelConfig[];
  warningCooldown: number;
  maxWarningsPerHour: number;
}

export enum RPMessageType {
  ON_RP_SPEECH = "ON_RP_SPEECH",
  OFF_RP_SPEECH = "OFF_RP_SPEECH",
  ACTION = "ACTION",
  THOUGHT = "THOUGHT",
  INVALID = "INVALID",
}

export interface RPValidationResult {
  isValid: boolean;
  type: RPMessageType;
  suggestedFix?: string;
  warningMessage?: string;
  formattedContent?: string;
}

const westernWarnings = {
  missingHyphen: [
    "🤠 Ei, forasteiro! Para falar no RP, use um hífen (-) antes da sua fala.",
    "🌵 Pare aí, parceiro! Suas palavras precisam de um hífen (-) na frente.",
    "⭐ Xerife Rex avisa: Use `-` antes da sua fala para manter a ordem no saloon!",
    "🐎 Opa! Esqueceu o hífen? Use `- Sua fala aqui` para falar no RP.",
  ],
  incompleteAction: [
    "🔫 Calma lá, pistoleiro! Ações precisam de ** no início E no fim.",
    "🤠 Xerife Rex: Uma ação sem asteriscos é como um revólver sem balas!",
    "⭐ Para fazer uma ação, use `**sua ação aqui**`.",
    "🌵 Ei, cowboy! Feche sua ação com ** no final.",
  ],
  incompleteThought: [
    "💭 Seus pensamentos estão escapando! Use parênteses: `(seu pensamento)`",
    "🤠 Xerife Rex: Pensamentos precisam estar entre parênteses!",
    "⭐ Para pensar, use `(seu pensamento aqui)`.",
    "🌵 Feche seus pensamentos com `)` no final, parceiro!",
  ],
  mixedFormat: [
    "📜 Não misture formatos, forasteiro! Escolha um: fala (-), ação (**), pensamento (()) ou off-rp (//).",
    "🤠 Xerife Rex: Uma coisa de cada vez! Não misture os formatos de RP.",
    "⭐ Mantenha a ordem: use apenas um formato por mensagem.",
  ],
};

const Colors = {
  WESTERN_GOLD: 0xd4a03a,
  WESTERN_BROWN: 0x8b4513,
  WESTERN_RED: 0xcd5c5c,
  PARCHMENT: 0xf5e5c7,
  SUCCESS: 0x10b981,
  WARNING: 0xf59e0b,
} as const;

function ensureRPConfigFile(): void {
  const dataDir = path.dirname(rpConfigPath);
  if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true });
  }
  if (!fs.existsSync(rpConfigPath)) {
    fs.writeFileSync(rpConfigPath, "{}");
  }
}

export function loadRPConfigs(): Record<string, RPGuildConfig> {
  const now = Date.now();
  if (configCache && now - cacheLastUpdated < CACHE_TTL) {
    return configCache;
  }

  ensureRPConfigFile();
  try {
    const data = fs.readFileSync(rpConfigPath, "utf-8");
    configCache = JSON.parse(data);
    cacheLastUpdated = now;
    return configCache!;
  } catch {
    configCache = {};
    cacheLastUpdated = now;
    return {};
  }
}

export function invalidateRPCache(): void {
  configCache = null;
  cacheLastUpdated = 0;
}

export function loadRPGuildConfig(guildId: string): RPGuildConfig {
  const configs = loadRPConfigs();
  return (
    configs[guildId] || {
      enabled: false,
      channels: [],
      warningCooldown: 30000,
      maxWarningsPerHour: 5,
    }
  );
}

export function saveRPGuildConfig(guildId: string, config: RPGuildConfig): void {
  ensureRPConfigFile();
  const configs = loadRPConfigs();
  configs[guildId] = config;
  fs.writeFileSync(rpConfigPath, JSON.stringify(configs, null, 2));
  invalidateRPCache();
}

export function isRPChannel(guildId: string, channelId: string): boolean {
  const config = loadRPGuildConfig(guildId);
  if (!config.enabled) return false;
  const channelConfig = config.channels.find((c) => c.channelId === channelId);
  return channelConfig?.enabled ?? false;
}

export function hasAINarration(guildId: string, channelId: string): boolean {
  const config = getRPChannelConfig(guildId, channelId);
  return config?.aiNarration ?? false;
}

export function getRPChannelConfig(guildId: string, channelId: string): RPChannelConfig | null {
  const config = loadRPGuildConfig(guildId);
  return config.channels.find((c) => c.channelId === channelId) || null;
}

export function addRPChannel(
  guildId: string,
  channelId: string,
  strictMode: boolean = false,
  warningMode: "reply" | "dm" | "delete" | "none" = "reply",
  aiNarration: boolean = false
): void {
  const config = loadRPGuildConfig(guildId);
  config.enabled = true;
  
  const existingIndex = config.channels.findIndex((c) => c.channelId === channelId);
  if (existingIndex >= 0) {
    config.channels[existingIndex] = { channelId, enabled: true, strictMode, warningMode, aiNarration };
  } else {
    config.channels.push({ channelId, enabled: true, strictMode, warningMode, aiNarration });
  }
  
  saveRPGuildConfig(guildId, config);
}

export function removeRPChannel(guildId: string, channelId: string): boolean {
  const config = loadRPGuildConfig(guildId);
  const index = config.channels.findIndex((c) => c.channelId === channelId);
  
  if (index >= 0) {
    config.channels.splice(index, 1);
    if (config.channels.length === 0) {
      config.enabled = false;
    }
    saveRPGuildConfig(guildId, config);
    return true;
  }
  return false;
}

export function validateRPMessage(content: string): RPValidationResult {
  const trimmedContent = content.trim();
  
  if (trimmedContent.startsWith("//")) {
    return {
      isValid: true,
      type: RPMessageType.OFF_RP_SPEECH,
      formattedContent: trimmedContent.substring(2).trim(),
    };
  }
  
  if (trimmedContent.startsWith("**") && trimmedContent.endsWith("**") && trimmedContent.length > 4) {
    return {
      isValid: true,
      type: RPMessageType.ACTION,
      formattedContent: trimmedContent.slice(2, -2).trim(),
    };
  }
  
  if (trimmedContent.startsWith("**") && !trimmedContent.endsWith("**")) {
    const randomWarning = westernWarnings.incompleteAction[
      Math.floor(Math.random() * westernWarnings.incompleteAction.length)
    ];
    return {
      isValid: false,
      type: RPMessageType.INVALID,
      suggestedFix: `**${trimmedContent.substring(2).trim()}**`,
      warningMessage: randomWarning,
    };
  }
  
  if (trimmedContent.startsWith("(") && trimmedContent.endsWith(")") && trimmedContent.length > 2) {
    return {
      isValid: true,
      type: RPMessageType.THOUGHT,
      formattedContent: trimmedContent.slice(1, -1).trim(),
    };
  }
  
  if (trimmedContent.startsWith("(") && !trimmedContent.endsWith(")")) {
    const randomWarning = westernWarnings.incompleteThought[
      Math.floor(Math.random() * westernWarnings.incompleteThought.length)
    ];
    return {
      isValid: false,
      type: RPMessageType.INVALID,
      suggestedFix: `(${trimmedContent.substring(1).trim()})`,
      warningMessage: randomWarning,
    };
  }
  
  if (trimmedContent.startsWith("-") || trimmedContent.startsWith("- ")) {
    return {
      isValid: true,
      type: RPMessageType.ON_RP_SPEECH,
      formattedContent: trimmedContent.substring(1).trim(),
    };
  }
  
  const randomWarning = westernWarnings.missingHyphen[
    Math.floor(Math.random() * westernWarnings.missingHyphen.length)
  ];
  return {
    isValid: false,
    type: RPMessageType.INVALID,
    suggestedFix: `- ${trimmedContent}`,
    warningMessage: randomWarning,
  };
}

export function createRPWarningEmbed(validation: RPValidationResult, originalContent: string): EmbedBuilder {
  const embed = new EmbedBuilder()
    .setColor(Colors.WESTERN_GOLD)
    .setTitle("📜 Regras de Conduta RP")
    .setDescription(validation.warningMessage || "Formato de mensagem inválido.")
    .setTimestamp();

  if (validation.suggestedFix) {
    embed.addFields({
      name: "💡 Sugestão de Correção",
      value: `\`\`\`${validation.suggestedFix}\`\`\``,
      inline: false,
    });
  }

  embed.setFooter({ text: "🤠 Xerife Rex - Guardião do RP" });

  return embed;
}

export function createRPRulesEmbed(): EmbedBuilder {
  return new EmbedBuilder()
    .setColor(Colors.PARCHMENT)
    .setTitle("📜 REGRAS DE CONDUTA: COMO INTERPRETAR?")
    .setDescription("*Livro de Leis do Velho Oeste*")
    .addFields(
      {
        name: "🗣️ Regra 1: Fala ON-RP",
        value: [
          "Use o sinal `-` (hífen) antes da frase.",
          "```",
          "- Olá, forasteiro!",
          "- Não sei do que está falando.",
          "```",
        ].join("\n"),
        inline: false,
      },
      {
        name: "📻 Regra 2: Fala OFF-RP",
        value: [
          "Use o sinal `//` (duas barras) antes da frase.",
          "```",
          "// Meu personagem não está aqui",
          "// Estou indo dormir, amanhã continuamos.",
          "```",
        ].join("\n"),
        inline: false,
      },
      {
        name: "🔫 Regra 3: Ação",
        value: [
          "Use `**` (dois asteriscos) no início E no fim da ação.",
          "```",
          "**Meu personagem anda até o Saloon**",
          "**Ele abre a porta lentamente**",
          "```",
        ].join("\n"),
        inline: false,
      },
      {
        name: "💭 Regra 4: Pensamento",
        value: [
          "Use `(` no início e `)` no fim do pensamento.",
          "```",
          "(Quem é esse forasteiro?)",
          "(Devo confiar nele?)",
          "```",
        ].join("\n"),
        inline: false,
      }
    )
    .setFooter({ text: "🤠 Xerife Rex - Mantenha a ordem no saloon!" })
    .setTimestamp();
}

export function createRPFormattedEmbed(
  type: RPMessageType,
  content: string,
  authorName: string,
  authorAvatar?: string
): EmbedBuilder {
  const embed = new EmbedBuilder().setTimestamp();

  switch (type) {
    case RPMessageType.ON_RP_SPEECH:
      embed
        .setColor(Colors.WESTERN_BROWN)
        .setAuthor({ name: `🗣️ ${authorName} diz:`, iconURL: authorAvatar })
        .setDescription(`*"${content}"*`);
      break;

    case RPMessageType.OFF_RP_SPEECH:
      embed
        .setColor(0x6b7280)
        .setAuthor({ name: `📻 ${authorName} (OFF-RP):`, iconURL: authorAvatar })
        .setDescription(content);
      break;

    case RPMessageType.ACTION:
      embed
        .setColor(Colors.WESTERN_RED)
        .setAuthor({ name: `🔫 ${authorName}`, iconURL: authorAvatar })
        .setDescription(`***${content}***`);
      break;

    case RPMessageType.THOUGHT:
      embed
        .setColor(0x9ca3af)
        .setAuthor({ name: `💭 ${authorName} pensa:`, iconURL: authorAvatar })
        .setDescription(`*${content}*`);
      break;

    default:
      embed
        .setColor(Colors.WESTERN_GOLD)
        .setAuthor({ name: authorName, iconURL: authorAvatar })
        .setDescription(content);
  }

  return embed;
}

const warningCooldowns = new Map<string, number>();

export function canSendWarning(userId: string, cooldownMs: number = 30000): boolean {
  const lastWarning = warningCooldowns.get(userId);
  const now = Date.now();
  
  if (!lastWarning || now - lastWarning > cooldownMs) {
    warningCooldowns.set(userId, now);
    return true;
  }
  
  return false;
}

export async function handleRPMessage(message: Message): Promise<boolean> {
  if (!message.guild || message.author.bot) return false;
  
  const channelConfig = getRPChannelConfig(message.guild.id, message.channel.id);
  if (!channelConfig || !channelConfig.enabled) return false;
  
  const validation = validateRPMessage(message.content);
  
  if (validation.isValid) {
    if (channelConfig.aiNarration && geminiService.isConfigured()) {
      if (validation.type === RPMessageType.ACTION && validation.formattedContent) {
        try {
          const analysis = await rpHealthService.analyzeAction(validation.formattedContent);
          
          const hasEffects = analysis.effects && (
            analysis.effects.health !== 0 || analysis.effects.stamina !== 0 ||
            analysis.effects.thirst !== 0 || analysis.effects.hunger !== 0 ||
            analysis.effects.blood !== 0 || analysis.effects.temperature !== 0
          );

          if (hasEffects) {
            const result = await rpHealthService.applyEffects(message.author.id, analysis.effects);
            
            await rpHealthService.logAction(
              message.author.id,
              null,
              'auto_action',
              validation.formattedContent,
              analysis.narration,
              analysis.effects
            );

            if (result.warnings.length > 0) {
              const warningEmbed = new EmbedBuilder()
                .setColor(0xf59e0b)
                .setTitle("⚠️ Alerta de Status")
                .setDescription(result.warnings.join('\n'))
                .setFooter({ text: "Use /saude para ver seu status completo" })
                .setTimestamp();
              
              const warningMsg = await (message.channel as TextChannel).send({
                content: `${message.author}`,
                embeds: [warningEmbed],
              });
              setTimeout(() => warningMsg.delete().catch(() => {}), 10000);
            }
          }
        } catch (error) {
          console.error("Error analyzing RP action:", error);
        }
      }
    }
    return true;
  }
  
  if (channelConfig.strictMode) {
    try {
      await message.delete().catch(() => {});
      
      const guildConfig = loadRPGuildConfig(message.guild.id);
      if (canSendWarning(message.author.id, guildConfig.warningCooldown)) {
        const strictEmbed = new EmbedBuilder()
          .setColor(0xcd5c5c)
          .setTitle("⚠️ Modo Estrito Ativado")
          .setDescription(
            `${message.author}, sua mensagem foi removida por não seguir o formato RP.\n\n` +
            `${validation.warningMessage || "Use o formato correto."}`
          )
          .addFields({
            name: "💡 Correção Sugerida",
            value: `\`\`\`${validation.suggestedFix || message.content}\`\`\``,
            inline: false,
          })
          .setFooter({ text: "🤠 Xerife Rex - Modo Estrito" })
          .setTimestamp();
        
        const warningMsg = await (message.channel as TextChannel).send({
          content: `${message.author}`,
          embeds: [strictEmbed],
        });
        setTimeout(() => warningMsg.delete().catch(() => {}), 15000);
      }
    } catch (error) {
      console.error("Error handling strict mode RP message:", error);
    }
    return false;
  }
  
  if (channelConfig.warningMode === "none") return false;
  
  const guildConfig = loadRPGuildConfig(message.guild.id);
  if (!canSendWarning(message.author.id, guildConfig.warningCooldown)) {
    return false;
  }
  
  const warningEmbed = createRPWarningEmbed(validation, message.content);
  
  try {
    switch (channelConfig.warningMode) {
      case "reply":
        const reply = await message.reply({ embeds: [warningEmbed] });
        setTimeout(() => reply.delete().catch(() => {}), 15000);
        break;
        
      case "dm":
        await message.author.send({ embeds: [warningEmbed] }).catch(() => {});
        break;
        
      case "delete":
        await message.delete().catch(() => {});
        await (message.channel as TextChannel).send({
          content: `${message.author}, sua mensagem foi removida por não seguir o formato RP.`,
          embeds: [warningEmbed],
        }).then((msg) => setTimeout(() => msg.delete().catch(() => {}), 10000));
        break;
    }
  } catch (error) {
    console.error("Error handling RP message:", error);
  }
  
  return false;
}

export function listRPChannels(guildId: string): RPChannelConfig[] {
  const config = loadRPGuildConfig(guildId);
  return config.channels.filter((c) => c.enabled);
}
