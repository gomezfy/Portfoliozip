import { db } from '../../server/db';
import { rpEvents, rpNpcMemory, users } from '../../shared/schema';
import { eq, and, desc } from 'drizzle-orm';
import { v4 as uuidv4 } from 'uuid';
import { HealthEffects } from './rpHealthService';

export interface RPEvent {
  id: string;
  type: EventType;
  name: string;
  description: string;
  narration: string;
  effects?: Partial<HealthEffects>;
  rewards?: EventReward;
  choices?: EventChoice[];
  npcInvolved?: string;
}

export interface EventReward {
  gold?: number;
  silver?: number;
  xp?: number;
  reputation?: { npcType: string; change: number };
  item?: string;
}

export interface EventChoice {
  id: string;
  label: string;
  description: string;
  effects?: Partial<HealthEffects>;
  rewards?: EventReward;
  outcome: string;
}

export type EventType = 
  | 'ambush'
  | 'duel'
  | 'robbery'
  | 'stranger'
  | 'accident'
  | 'discovery'
  | 'encounter'
  | 'weather'
  | 'rumor'
  | 'opportunity';

const RANDOM_EVENTS: Record<EventType, RPEvent[]> = {
  ambush: [
    {
      id: 'ambush_bandits',
      type: 'ambush',
      name: 'Emboscada de Bandidos',
      description: 'Um grupo de bandidos surge das rochas!',
      narration: 'O som de esporas ecoou pelas pedras. Antes que pudesse reagir, três figuras encapuzadas emergiram das sombras, rifles apontados. "Passa tudo que tem, forasteiro!"',
      effects: { stamina: -10, health: -5 },
      choices: [
        {
          id: 'fight',
          label: '🔫 Lutar',
          description: 'Sacar sua arma e enfrentar os bandidos',
          effects: { stamina: -20, health: -15, blood: -10 },
          rewards: { gold: 50, xp: 100, reputation: { npcType: 'sheriff', change: 5 } },
          outcome: 'Você sacou rápido como um raio! Os bandidos caíram um a um, e você emergiu vitorioso, embora ferido.'
        },
        {
          id: 'surrender',
          label: '🤝 Render-se',
          description: 'Entregar seus pertences',
          effects: { stamina: -5 },
          rewards: { gold: -30, reputation: { npcType: 'outlaw', change: -3 } },
          outcome: 'Os bandidos pegaram suas moedas e fugiram rindo. Pelo menos você está vivo.'
        },
        {
          id: 'flee',
          label: '🏃 Fugir',
          description: 'Correr para escapar',
          effects: { stamina: -25 },
          rewards: { xp: 20 },
          outcome: 'Você correu como o vento! Os tiros passaram de raspão, mas conseguiu escapar.'
        }
      ]
    },
    {
      id: 'ambush_natives',
      type: 'ambush',
      name: 'Encontro Tenso',
      description: 'Guerreiros nativos bloqueiam seu caminho.',
      narration: 'Flechas cravaram-se na poeira a seus pés. Figuras pintadas de guerra emergiram da vegetação rasteira, olhares tão afiados quanto suas armas.',
      effects: { stamina: -5 },
      choices: [
        {
          id: 'talk',
          label: '🤝 Negociar',
          description: 'Tentar uma comunicação pacífica',
          effects: {},
          rewards: { xp: 75, reputation: { npcType: 'merchant', change: 3 } },
          outcome: 'Com gestos cuidadosos, você mostrou que não era uma ameaça. Os guerreiros baixaram suas armas e indicaram o caminho seguro.'
        },
        {
          id: 'gift',
          label: '🎁 Oferecer Presente',
          description: 'Dar algo de valor como sinal de paz',
          effects: {},
          rewards: { silver: -20, xp: 100 },
          outcome: 'Você ofereceu uma faca prateada. O líder aceitou com um aceno respeitoso e abriu caminho.'
        }
      ]
    }
  ],
  duel: [
    {
      id: 'duel_stranger',
      type: 'duel',
      name: 'Desafio de Duelo',
      description: 'Um pistoleiro desconhecido te desafia!',
      narration: 'O saloon ficou em silêncio mortal. Um homem de olhos frios se levantou, a mão pairando sobre o coldre. "Ouvi dizer que você se acha rápido, forasteiro. Prove."',
      effects: { stamina: -10 },
      choices: [
        {
          id: 'accept',
          label: '🔫 Aceitar',
          description: 'Enfrentar o duelo',
          effects: { stamina: -15, health: -20, blood: -5 },
          rewards: { gold: 75, xp: 150, reputation: { npcType: 'gambler', change: 5 } },
          outcome: 'O sol refletiu nos canos. Dois tiros ecoaram como um só. O pistoleiro caiu. Você tinha um novo furo no chapéu, mas estava vivo.'
        },
        {
          id: 'decline',
          label: '✋ Recusar',
          description: 'Negar o desafio',
          effects: {},
          rewards: { reputation: { npcType: 'gambler', change: -5 } },
          outcome: 'O saloon riu de você enquanto o pistoleiro cuspia no chão. "Covarde." A palavra ecoou em seus ouvidos pelo resto da noite.'
        },
        {
          id: 'trick',
          label: '🃏 Trapacear',
          description: 'Usar um truque sujo',
          effects: { stamina: -10 },
          rewards: { gold: 75, xp: 50, reputation: { npcType: 'gambler', change: 5 } },
          outcome: 'Você jogou poeira nos olhos dele antes do sinal. Um tiro certeiro depois, o "duelo" acabou. Desonroso, mas eficaz.'
        }
      ]
    }
  ],
  robbery: [
    {
      id: 'robbery_stagecoach',
      type: 'robbery',
      name: 'Assalto à Diligência',
      description: 'Uma diligência está sendo assaltada na estrada!',
      narration: 'Gritos e tiros ecoaram pela trilha poeirenta. Uma diligência parada, bandidos mascarados cercando os passageiros aterrorizados. Esta é sua chance de ser herói... ou vilão.',
      effects: {},
      choices: [
        {
          id: 'help',
          label: '⭐ Ajudar as Vítimas',
          description: 'Intervir e salvar os passageiros',
          effects: { stamina: -20, health: -10 },
          rewards: { gold: 100, xp: 200, reputation: { npcType: 'sheriff', change: 15 } },
          outcome: 'Você atacou como um anjo vingador! Os bandidos fugiram, e os passageiros choraram de gratidão. O xerife vai ouvir sobre isso.'
        },
        {
          id: 'join',
          label: '🔫 Juntar-se ao Assalto',
          description: 'Ajudar os bandidos',
          effects: { stamina: -10 },
          rewards: { gold: 150, xp: 100, reputation: { npcType: 'outlaw', change: 15 } },
          outcome: 'Você ajudou os bandidos a limpar os passageiros. Sua parte do butim foi generosa, mas agora há um cartaz com seu rosto.'
        },
        {
          id: 'ignore',
          label: '🚶 Ignorar',
          description: 'Seguir seu caminho',
          effects: {},
          rewards: {},
          outcome: 'Você olhou para o outro lado e seguiu em frente. Os gritos ficaram para trás. Não era problema seu.'
        }
      ]
    }
  ],
  stranger: [
    {
      id: 'stranger_wounded',
      type: 'stranger',
      name: 'Forasteiro Ferido',
      description: 'Um homem ferido pede ajuda na beira da estrada.',
      narration: 'Sob o sol impiedoso, uma figura se arrastava pela poeira. Sangue manchava sua camisa rasgada. "Por favor... água..." ele gemeu, estendendo uma mão trêmula.',
      effects: {},
      choices: [
        {
          id: 'help',
          label: '💊 Ajudar',
          description: 'Dar água e cuidados',
          effects: { thirst: -10 },
          rewards: { xp: 80, reputation: { npcType: 'doctor', change: 10 } },
          outcome: 'Você compartilhou sua água e enfaixou seus ferimentos. O homem sussurrou sobre um tesouro escondido nas colinas como agradecimento.'
        },
        {
          id: 'rob',
          label: '💰 Roubar',
          description: 'Verificar se ele tem algo de valor',
          effects: {},
          rewards: { silver: 35, reputation: { npcType: 'outlaw', change: 8 } },
          outcome: 'Você vasculhou os bolsos do moribundo. Algumas moedas de prata. Ele não vai precisar mais delas mesmo.'
        },
        {
          id: 'ignore',
          label: '🚶 Passar',
          description: 'Continuar seu caminho',
          effects: {},
          rewards: {},
          outcome: 'Você olhou para longe e seguiu andando. Os gemidos ficaram cada vez mais fracos atrás de você.'
        }
      ]
    },
    {
      id: 'stranger_merchant',
      type: 'stranger',
      name: 'Comerciante Viajante',
      description: 'Um comerciante ambulante oferece suas mercadorias.',
      narration: 'Uma carroça colorida parou ao seu lado. Um homem de bigode encerado sorriu, revelando um dente de ouro. "Tenho exatamente o que você precisa, amigo! Raridades do Oriente!"',
      effects: {},
      choices: [
        {
          id: 'buy',
          label: '💰 Comprar',
          description: 'Ver as mercadorias',
          effects: {},
          rewards: { silver: -25, xp: 30 },
          outcome: 'Você comprou um amuleto "mágico". Provavelmente é falso, mas quem sabe? No Velho Oeste, tudo é possível.'
        },
        {
          id: 'bargain',
          label: '🤝 Pechinchar',
          description: 'Tentar um desconto',
          effects: {},
          rewards: { silver: -10, xp: 50, reputation: { npcType: 'merchant', change: 5 } },
          outcome: 'Depois de muito regatear, você conseguiu um bom negócio. O comerciante riu e disse que gostou de você.'
        }
      ]
    }
  ],
  accident: [
    {
      id: 'accident_horse',
      type: 'accident',
      name: 'Cavalo Descontrolado',
      description: 'Um cavalo assustado corre em sua direção!',
      narration: 'O relincho agudo cortou o ar. Um garanhão negro, olhos arregalados de terror, galopava descontrolado pela rua principal, derrubando tudo em seu caminho.',
      effects: { stamina: -5 },
      choices: [
        {
          id: 'dodge',
          label: '🏃 Esquivar',
          description: 'Pular para o lado',
          effects: { stamina: -10 },
          rewards: { xp: 30 },
          outcome: 'Você rolou para o lado bem a tempo. O cavalo passou como um trovão, arrancando poeira e gritos.'
        },
        {
          id: 'catch',
          label: '🐎 Domar',
          description: 'Tentar parar o cavalo',
          effects: { stamina: -25, health: -10 },
          rewards: { xp: 150, reputation: { npcType: 'cowgirl', change: 15 } },
          outcome: 'Você agarrou as rédeas e foi arrastado pela poeira. Com força e determinação, finalmente acalmou a fera. A multidão aplaudiu.'
        }
      ]
    }
  ],
  discovery: [
    {
      id: 'discovery_gold',
      type: 'discovery',
      name: 'Pepita de Ouro',
      description: 'Você encontra algo brilhando no chão!',
      narration: 'O sol refletiu em algo entre as pedras. Seu coração disparou quando você se abaixou e viu: uma pepita de ouro puro, do tamanho de uma noz!',
      effects: { stamina: -5 },
      rewards: { gold: 25, xp: 50 },
      choices: []
    },
    {
      id: 'discovery_map',
      type: 'discovery',
      name: 'Mapa Misterioso',
      description: 'Um papel velho voa até seus pés.',
      narration: 'O vento trouxe um pedaço de couro envelhecido. Ao examiná-lo, você viu: era um mapa! Marcações em X, rotas secretas, e algo que parecia ser... uma mina abandonada?',
      effects: {},
      rewards: { xp: 100 },
      choices: []
    }
  ],
  encounter: [
    {
      id: 'encounter_sheriff',
      type: 'encounter',
      name: 'Patrulha do Xerife',
      description: 'O xerife está fazendo ronda.',
      narration: 'Botas pesadas se aproximaram. O Xerife ajustou o chapéu e te encarou com olhos que já viram muita coisa. "Tudo em ordem, forasteiro? Vou ficar de olho em você."',
      effects: {},
      npcInvolved: 'sheriff',
      choices: [
        {
          id: 'respect',
          label: '⭐ Mostrar Respeito',
          description: 'Cumprimentar com cortesia',
          effects: {},
          rewards: { reputation: { npcType: 'sheriff', change: 5 }, xp: 30 },
          outcome: 'Você tocou a aba do chapéu em sinal de respeito. O Xerife acenou brevemente e seguiu em frente.'
        },
        {
          id: 'nervous',
          label: '😰 Ficar Nervoso',
          description: 'Demonstrar desconforto',
          effects: { stamina: -5 },
          rewards: { xp: 10 },
          outcome: 'Suas mãos tremeram ligeiramente. O Xerife estreitou os olhos. "Hmm... vou lembrar desse rosto."'
        }
      ]
    }
  ],
  weather: [
    {
      id: 'weather_storm',
      type: 'weather',
      name: 'Tempestade de Areia',
      description: 'Uma tempestade de areia se aproxima rapidamente!',
      narration: 'O horizonte escureceu com uma parede de poeira dourada. O vento uivava como lobos famintos, e a areia começou a picar sua pele exposta.',
      effects: { stamina: -15, health: -5, thirst: -20 },
      choices: [
        {
          id: 'shelter',
          label: '🏠 Procurar Abrigo',
          description: 'Encontrar um lugar para se proteger',
          effects: { stamina: -10 },
          rewards: { xp: 40 },
          outcome: 'Você encontrou uma formação rochosa e se abrigou até a tempestade passar. Areia por toda parte, mas você está inteiro.'
        },
        {
          id: 'push',
          label: '💨 Seguir em Frente',
          description: 'Continuar apesar da tempestade',
          effects: { stamina: -30, health: -15, thirst: -30 },
          rewards: { xp: 100, reputation: { npcType: 'cowgirl', change: 5 } },
          outcome: 'Você enfrentou a fúria da natureza com determinação. Quando a tempestade passou, você estava exausto, mas mais forte.'
        }
      ]
    }
  ],
  rumor: [
    {
      id: 'rumor_treasure',
      type: 'rumor',
      name: 'Boato no Saloon',
      description: 'Você ouve uma conversa interessante...',
      narration: 'No canto escuro do saloon, dois homens sussurravam sobre um tesouro confederado enterrado nas colinas. Quando notaram seu olhar, ficaram em silêncio.',
      effects: {},
      choices: [
        {
          id: 'approach',
          label: '🍺 Oferecer Bebida',
          description: 'Tentar extrair mais informações',
          effects: { thirst: -10 },
          rewards: { silver: -10, xp: 80, reputation: { npcType: 'gambler', change: 5 } },
          outcome: 'Depois de algumas rodadas, os homens soltaram a língua. Agora você sabe onde começar a procurar...'
        },
        {
          id: 'ignore',
          label: '🤫 Fingir que não ouviu',
          description: 'Manter distância',
          effects: {},
          rewards: { xp: 5 },
          outcome: 'Você voltou a olhar para sua bebida. Alguns segredos é melhor não saber.'
        }
      ]
    }
  ],
  opportunity: [
    {
      id: 'opportunity_job',
      type: 'opportunity',
      name: 'Oferta de Trabalho',
      description: 'Alguém precisa de ajuda para um serviço.',
      narration: 'Um fazendeiro de aparência cansada se aproximou. "Ei, forasteiro. Preciso de alguém para escoltar meu gado até a próxima cidade. Pago bem. Interessado?"',
      effects: {},
      choices: [
        {
          id: 'accept',
          label: '✅ Aceitar',
          description: 'Fazer o trabalho',
          effects: { stamina: -30, hunger: -20, thirst: -20 },
          rewards: { gold: 80, xp: 120, reputation: { npcType: 'merchant', change: 10 } },
          outcome: 'O trabalho foi duro, mas honesto. O fazendeiro pagou como prometeu e recomendou você para outros.'
        },
        {
          id: 'negotiate',
          label: '💰 Negociar',
          description: 'Pedir mais dinheiro',
          effects: { stamina: -30, hunger: -20, thirst: -20 },
          rewards: { gold: 120, xp: 100 },
          outcome: 'Depois de alguma discussão, ele concordou em pagar mais. O trabalho valeu a pena.'
        },
        {
          id: 'decline',
          label: '❌ Recusar',
          description: 'Não está interessado',
          effects: {},
          rewards: {},
          outcome: 'Você balançou a cabeça e seguiu seu caminho. Trabalho não é para todos.'
        }
      ]
    }
  ]
};

const EVENT_CHANCES: Record<string, number> = {
  bartender: 0.15,
  sheriff: 0.20,
  outlaw: 0.35,
  merchant: 0.15,
  doctor: 0.10,
  gambler: 0.25,
  cowgirl: 0.30,
};

const NPC_EVENT_WEIGHTS: Record<string, EventType[]> = {
  bartender: ['rumor', 'stranger', 'opportunity'],
  sheriff: ['encounter', 'robbery', 'duel'],
  outlaw: ['ambush', 'robbery', 'duel'],
  merchant: ['stranger', 'discovery', 'opportunity'],
  doctor: ['accident', 'stranger', 'weather'],
  gambler: ['duel', 'rumor', 'opportunity'],
  cowgirl: ['ambush', 'weather', 'discovery', 'encounter'],
};

class RPEventsService {
  shouldTriggerEvent(npcType: string): boolean {
    const chance = EVENT_CHANCES[npcType] || 0.15;
    return Math.random() < chance;
  }

  getRandomEvent(npcType: string): RPEvent | null {
    const preferredTypes = NPC_EVENT_WEIGHTS[npcType] || ['stranger', 'discovery'];
    
    const eventType = preferredTypes[Math.floor(Math.random() * preferredTypes.length)];
    const eventsOfType = RANDOM_EVENTS[eventType];
    
    if (!eventsOfType || eventsOfType.length === 0) {
      return null;
    }
    
    return eventsOfType[Math.floor(Math.random() * eventsOfType.length)];
  }

  async logEvent(
    event: RPEvent,
    userId: string,
    channelId: string,
    guildId: string,
    choiceId?: string,
    outcome?: string
  ): Promise<void> {
    const choice = event.choices?.find(c => c.id === choiceId);
    
    await db.insert(rpEvents).values({
      id: uuidv4(),
      eventType: event.type,
      name: event.name,
      description: event.description,
      triggeredBy: userId,
      channelId,
      guildId,
      participants: [userId],
      outcome: outcome || choice?.outcome || event.narration,
      rewards: choice?.rewards || event.rewards,
      penalties: choice?.effects,
      status: 'resolved',
      resolvedAt: new Date(),
    });
  }

  formatEventEmbed(event: RPEvent): {
    title: string;
    description: string;
    color: number;
  } {
    const colors: Record<EventType, number> = {
      ambush: 0xdc2626,
      duel: 0xf59e0b,
      robbery: 0x991b1b,
      stranger: 0x6b7280,
      accident: 0xfbbf24,
      discovery: 0x10b981,
      encounter: 0x3b82f6,
      weather: 0x6366f1,
      rumor: 0x8b5cf6,
      opportunity: 0x22c55e,
    };

    const icons: Record<EventType, string> = {
      ambush: '⚔️',
      duel: '🔫',
      robbery: '💰',
      stranger: '👤',
      accident: '💥',
      discovery: '✨',
      encounter: '🤝',
      weather: '🌪️',
      rumor: '🗣️',
      opportunity: '💼',
    };

    return {
      title: `${icons[event.type]} ${event.name}`,
      description: event.narration,
      color: colors[event.type],
    };
  }

  getEventTypes(): EventType[] {
    return Object.keys(RANDOM_EVENTS) as EventType[];
  }
}

export const rpEventsService = new RPEventsService();
