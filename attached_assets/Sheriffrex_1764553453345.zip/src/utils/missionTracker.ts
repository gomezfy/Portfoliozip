import { updateMissionProgress, MissionObjective } from "./missionsManager";
import { registerCooldown } from "./reminderManager";

export function trackMissionAction(
  userId: string,
  username: string,
  action: MissionObjective["action"],
  amount: number = 1
): { missionsCompleted: string[] } {
  const result = updateMissionProgress(userId, action, amount);
  
  return {
    missionsCompleted: result.completed.map(m => m.name)
  };
}

export function trackMiningComplete(userId: string, username: string, goldAmount: number): void {
  trackMissionAction(userId, username, "mine", 1);
  
  if (goldAmount > 0) {
    trackMissionAction(userId, username, "earn", goldAmount * 100);
  }
}

export function trackHuntComplete(userId: string, username: string, animalsCaught: number = 1): void {
  trackMissionAction(userId, username, "hunt", animalsCaught);
}

export function trackFishComplete(userId: string, username: string, fishCaught: number = 1): void {
  trackMissionAction(userId, username, "fish", fishCaught);
}

export function trackDailyCollect(userId: string, username: string): void {
  trackMissionAction(userId, username, "daily", 1);
}

export function trackDuelComplete(userId: string, username: string): void {
  trackMissionAction(userId, username, "duel", 1);
}

export function trackGiveAction(userId: string, username: string): void {
  trackMissionAction(userId, username, "give", 1);
}

export function trackSpending(userId: string, username: string, amount: number): void {
  trackMissionAction(userId, username, "spend", amount);
}

export function trackEarning(userId: string, username: string, amount: number): void {
  trackMissionAction(userId, username, "earn", amount);
}

export function trackCapture(userId: string, username: string): void {
  trackMissionAction(userId, username, "capture", 1);
}

export function trackFarmAction(userId: string, username: string): void {
  trackMissionAction(userId, username, "farm", 1);
}

export function trackCrimeAction(userId: string, username: string): void {
  trackMissionAction(userId, username, "crime", 1);
}

export function trackDiceAction(userId: string, username: string): void {
  trackMissionAction(userId, username, "dice", 1);
}

export function trackBankrobAction(userId: string, username: string): void {
  trackMissionAction(userId, username, "bankrob", 1);
}

export function trackSellAction(userId: string, username: string, amount: number = 1): void {
  trackMissionAction(userId, username, "sell", amount);
}

export function trackProfileView(userId: string, username: string): void {
  trackMissionAction(userId, username, "profile", 1);
}

export function trackTerritoryAction(userId: string, username: string): void {
  trackMissionAction(userId, username, "territory", 1);
}

export function trackGuildAction(userId: string, username: string): void {
  trackMissionAction(userId, username, "guild", 1);
}

export function registerActivityCooldown(
  userId: string,
  activity: "mining" | "hunting" | "fishing" | "daily",
  durationMs: number
): void {
  registerCooldown(userId, activity, durationMs);
}
