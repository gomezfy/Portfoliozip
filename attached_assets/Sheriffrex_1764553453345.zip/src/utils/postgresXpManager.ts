import { db } from "../../server/db";
import { users } from "../../shared/schema";
import { eq, desc } from "drizzle-orm";

/**
 * PostgreSQL XP Manager
 * Substitui o xpManager.ts baseado em JSON
 */

const XP_PER_LEVEL = 200;
const XP_MULTIPLIER = 1.8;
const MAX_LEVEL = 70;
const LEGENDARY_LEVEL_THRESHOLD = 70;

// ===================================
// XP OPERATIONS
// ===================================

/**
 * Calcula o XP necessário para um nível específico
 */
export function calculateXpForLevel(level: number): number {
  if (level <= 1) return 0;
  const cappedLevel = Math.min(level, MAX_LEVEL);
  let totalXp = 0;
  for (let i = 1; i < cappedLevel; i++) {
    totalXp += Math.floor(XP_PER_LEVEL * Math.pow(XP_MULTIPLIER, i - 1));
  }
  return totalXp;
}

/**
 * Calcula o nível baseado no XP total (máximo 70)
 */
export function calculateLevelFromXp(xp: number): number {
  let level = 1;
  let xpRequired = 0;
  
  while (level < MAX_LEVEL && xp >= xpRequired + Math.floor(XP_PER_LEVEL * Math.pow(XP_MULTIPLIER, level - 1))) {
    xpRequired += Math.floor(XP_PER_LEVEL * Math.pow(XP_MULTIPLIER, level - 1));
    level++;
  }
  
  return level;
}

/**
 * Obtém o status do nível (normal ou lendário)
 */
export function getLevelStatus(level: number): string {
  if (level >= LEGENDARY_LEVEL_THRESHOLD) {
    return "🌟 Lendário";
  }
  return "";
}

/**
 * Obtém os dados de XP do usuário
 */
export async function getUserXpData(userId: string): Promise<{
  xp: number;
  level: number;
  lastMessage: Date | null;
}> {
  const [user] = await db
    .select({
      xp: users.xp,
      level: users.level,
      lastMessage: users.lastMessage
    })
    .from(users)
    .where(eq(users.userId, userId))
    .limit(1);

  return {
    xp: user?.xp ?? 0,
    level: user?.level ?? 1,
    lastMessage: user?.lastMessage ?? null
  };
}

/**
 * Adiciona XP ao usuário e verifica se subiu de nível
 */
export async function addUserXp(
  userId: string, 
  username: string,
  amount: number
): Promise<{
  leveledUp: boolean;
  oldLevel: number;
  newLevel: number;
  currentXp: number;
  xpGained: number;
}> {
  const userData = await getUserXpData(userId);
  const oldLevel = userData.level;
  const newXp = userData.xp + amount;
  const newLevel = calculateLevelFromXp(newXp);
  const leveledUp = newLevel > oldLevel;

  await db
    .update(users)
    .set({ 
      xp: newXp,
      level: newLevel,
      lastMessage: new Date(),
      updatedAt: new Date()
    })
    .where(eq(users.userId, userId));

  return {
    leveledUp,
    oldLevel,
    newLevel,
    currentXp: newXp,
    xpGained: amount
  };
}

/**
 * Define o XP do usuário diretamente
 */
export async function setUserXp(userId: string, xp: number): Promise<void> {
  const newLevel = calculateLevelFromXp(xp);
  
  await db
    .update(users)
    .set({ 
      xp,
      level: newLevel,
      updatedAt: new Date()
    })
    .where(eq(users.userId, userId));
}

/**
 * Define o nível do usuário diretamente
 */
export async function setUserLevel(userId: string, level: number): Promise<void> {
  const requiredXp = calculateXpForLevel(level);
  
  await db
    .update(users)
    .set({ 
      level,
      xp: requiredXp,
      updatedAt: new Date()
    })
    .where(eq(users.userId, userId));
}

/**
 * Obtém o leaderboard de XP
 */
export async function getXpLeaderboard(limit: number = 10): Promise<Array<{
  userId: string;
  username: string;
  xp: number;
  level: number;
}>> {
  const leaderboard = await db
    .select({
      userId: users.userId,
      username: users.username,
      xp: users.xp,
      level: users.level
    })
    .from(users)
    .orderBy(desc(users.xp))
    .limit(Math.min(limit, 50));

  return leaderboard;
}

/**
 * Calcula o XP necessário para o próximo nível
 */
export function getXpForNextLevel(currentLevel: number): number {
  return Math.floor(XP_PER_LEVEL * Math.pow(XP_MULTIPLIER, currentLevel - 1));
}

/**
 * Obtém o progresso do usuário para o próximo nível
 */
export async function getUserLevelProgress(userId: string): Promise<{
  currentLevel: number;
  currentXp: number;
  xpForCurrentLevel: number;
  xpForNextLevel: number;
  progressPercent: number;
}> {
  const userData = await getUserXpData(userId);
  const xpForCurrentLevel = calculateXpForLevel(userData.level);
  const xpForNextLevel = getXpForNextLevel(userData.level);
  const xpInCurrentLevel = userData.xp - xpForCurrentLevel;
  const progressPercent = Math.min(100, (xpInCurrentLevel / xpForNextLevel) * 100);

  return {
    currentLevel: userData.level,
    currentXp: userData.xp,
    xpForCurrentLevel,
    xpForNextLevel,
    progressPercent
  };
}
