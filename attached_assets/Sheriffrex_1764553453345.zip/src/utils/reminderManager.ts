import { Client, User, EmbedBuilder } from "discord.js";
import { readData, writeData } from "./database";
import { getEmoji } from "./customEmojis";

export interface UserReminders {
  mining: ReminderSettings;
  hunting: ReminderSettings;
  fishing: ReminderSettings;
  daily: ReminderSettings;
  enabled: boolean;
}

export interface ReminderSettings {
  enabled: boolean;
  lastNotified?: number;
}

export interface ActiveCooldown {
  action: "mining" | "hunting" | "fishing" | "daily";
  userId: string;
  endsAt: number;
  notified: boolean;
}

const DEFAULT_REMINDERS: UserReminders = {
  mining: { enabled: true },
  hunting: { enabled: true },
  fishing: { enabled: true },
  daily: { enabled: true },
  enabled: true
};

let activeCooldowns: ActiveCooldown[] = [];
let reminderInterval: NodeJS.Timeout | null = null;
let discordClient: Client | null = null;

function getRemindersData(): Record<string, UserReminders> {
  return readData("reminders.json") || {};
}

function saveRemindersData(data: Record<string, UserReminders>): void {
  writeData("reminders.json", data);
}

function getCooldownsData(): ActiveCooldown[] {
  const data = readData("active-cooldowns.json");
  if (!Array.isArray(data)) {
    return [];
  }
  return data;
}

function saveCooldownsData(data: ActiveCooldown[]): void {
  writeData("active-cooldowns.json", data);
}

export function getUserReminders(userId: string): UserReminders {
  const data = getRemindersData();
  if (!data[userId]) {
    data[userId] = { ...DEFAULT_REMINDERS };
    saveRemindersData(data);
  }
  return data[userId];
}

export function updateUserReminders(userId: string, settings: Partial<UserReminders>): void {
  const data = getRemindersData();
  if (!data[userId]) {
    data[userId] = { ...DEFAULT_REMINDERS };
  }
  data[userId] = { ...data[userId], ...settings };
  saveRemindersData(data);
}

export function toggleReminder(userId: string, action: keyof Omit<UserReminders, "enabled">): boolean {
  const data = getRemindersData();
  if (!data[userId]) {
    data[userId] = { ...DEFAULT_REMINDERS };
  }
  
  const current = data[userId][action] as ReminderSettings;
  current.enabled = !current.enabled;
  data[userId][action] = current;
  saveRemindersData(data);
  
  return current.enabled;
}

export function toggleAllReminders(userId: string): boolean {
  const data = getRemindersData();
  if (!data[userId]) {
    data[userId] = { ...DEFAULT_REMINDERS };
  }
  
  data[userId].enabled = !data[userId].enabled;
  saveRemindersData(data);
  
  return data[userId].enabled;
}

export function registerCooldown(userId: string, action: ActiveCooldown["action"], durationMs: number): void {
  const endsAt = Date.now() + durationMs;
  
  activeCooldowns = activeCooldowns.filter(c => !(c.userId === userId && c.action === action));
  
  activeCooldowns.push({
    action,
    userId,
    endsAt,
    notified: false
  });
  
  saveCooldownsData(activeCooldowns);
}

export function removeCooldown(userId: string, action: ActiveCooldown["action"]): void {
  activeCooldowns = activeCooldowns.filter(c => !(c.userId === userId && c.action === action));
  saveCooldownsData(activeCooldowns);
}

async function sendReminder(client: Client, cooldown: ActiveCooldown): Promise<boolean> {
  try {
    const userReminders = getUserReminders(cooldown.userId);
    
    if (!userReminders.enabled) return false;
    
    const actionSettings = userReminders[cooldown.action] as ReminderSettings;
    if (!actionSettings.enabled) return false;
    
    const user = await client.users.fetch(cooldown.userId).catch(() => null);
    if (!user) return false;
    
    const actionNames: Record<string, { name: string; emoji: string; tip: string }> = {
      mining: { 
        name: "Mineração", 
        emoji: "⛏️",
        tip: "Use `/mine` para começar a minerar!"
      },
      hunting: { 
        name: "Caçada", 
        emoji: "🦌",
        tip: "Use `/hunt` para caçar animais!"
      },
      fishing: { 
        name: "Pesca", 
        emoji: "🎣",
        tip: "Use `/fish` para pescar!"
      },
      expedition: { 
        name: "Expedição", 
        emoji: "🗺️",
        tip: "Use `/expedition` para explorar!"
      },
      daily: { 
        name: "Recompensa Diária", 
        emoji: "📅",
        tip: "Use `/daily` para coletar!"
      }
    };
    
    const action = actionNames[cooldown.action];
    
    const embed = new EmbedBuilder()
      .setColor(0xFFD700)
      .setTitle(`${action.emoji} ${action.name} Disponível!`)
      .setDescription(`Howdy, parceiro! Sua **${action.name.toLowerCase()}** está pronta!\n\n${action.tip}`)
      .setFooter({ text: "🔔 Use /lembretes para gerenciar suas notificações" })
      .setTimestamp();
    
    await user.send({ embeds: [embed] }).catch(() => null);
    return true;
  } catch (error) {
    console.error(`Failed to send reminder to ${cooldown.userId}:`, error);
    return false;
  }
}

async function checkAndSendReminders(): Promise<void> {
  if (!discordClient) return;
  
  const now = Date.now();
  const cooldowns = getCooldownsData();
  
  if (!Array.isArray(cooldowns)) {
    activeCooldowns = [];
    return;
  }
  
  activeCooldowns = cooldowns;
  
  let updated = false;
  
  for (const cooldown of activeCooldowns) {
    if (cooldown.notified) continue;
    if (cooldown.endsAt > now) continue;
    
    const sent = await sendReminder(discordClient, cooldown);
    if (sent) {
      cooldown.notified = true;
      updated = true;
    }
  }
  
  activeCooldowns = activeCooldowns.filter(c => {
    if (c.notified) return false;
    if (now - c.endsAt > 24 * 60 * 60 * 1000) return false;
    return true;
  });
  
  if (updated || activeCooldowns.length !== cooldowns.length) {
    saveCooldownsData(activeCooldowns);
  }
}

export function startReminderSystem(client: Client): void {
  discordClient = client;
  activeCooldowns = getCooldownsData();
  
  if (reminderInterval) {
    clearInterval(reminderInterval);
  }
  
  reminderInterval = setInterval(() => {
    checkAndSendReminders().catch(console.error);
  }, 30000);
  
  console.log("✅ Sistema de lembretes iniciado!");
}

export function stopReminderSystem(): void {
  if (reminderInterval) {
    clearInterval(reminderInterval);
    reminderInterval = null;
  }
  discordClient = null;
}

export function getReminderStatusText(reminders: UserReminders): string {
  const status = (enabled: boolean) => enabled ? "✅" : "❌";
  
  return `
**Status Geral:** ${status(reminders.enabled)} ${reminders.enabled ? "Ativado" : "Desativado"}

⛏️ Mineração: ${status(reminders.mining.enabled)}
🦌 Caçada: ${status(reminders.hunting.enabled)}
🎣 Pesca: ${status(reminders.fishing.enabled)}
📅 Daily: ${status(reminders.daily.enabled)}
  `.trim();
}
