import { createCanvas, loadImage, GlobalFonts, SKRSContext2D, Image } from '@napi-rs/canvas';
import path from 'path';
import fs from 'fs';
import { GeneralStoreItem } from './generalStoreManager';
import { APPLICATION_EMOJIS } from './customEmojis';
import { canvasCache } from './canvasCache';

function getEmojiImageUrl(emojiCode: string): string | null {
  const match = emojiCode.match(/<:(\w+):(\d+)>/);
  if (match) {
    const emojiId = match[2];
    return `https://cdn.discordapp.com/emojis/${emojiId}.png`;
  }
  return null;
}

async function loadEmojiImage(emojiKey: keyof typeof APPLICATION_EMOJIS): Promise<Image | null> {
  const emojiCode = APPLICATION_EMOJIS[emojiKey];
  if (!emojiCode) return null;
  
  const url = getEmojiImageUrl(emojiCode);
  if (!url) return null;
  
  try {
    return await canvasCache.loadImageWithCache(url);
  } catch (error) {
    console.error(`Error loading emoji ${emojiKey}:`, error);
    return null;
  }
}

let fontsRegistered = false;

function ensureFontsRegistered(): void {
  if (fontsRegistered) return;

  const fontsDir = path.join(process.cwd(), 'assets', 'fonts');
  
  const fontFiles = [
    { file: 'Nunito-Bold.ttf', family: 'Nunito-Bold' },
    { file: 'Nunito-SemiBold.ttf', family: 'Nunito-SemiBold' },
    { file: 'Nunito-Regular.ttf', family: 'Nunito' },
    { file: 'BleedingCowboys.ttf', family: 'BleedingCowboys' },
  ];

  for (const { file, family } of fontFiles) {
    const fontPath = path.join(fontsDir, file);
    if (fs.existsSync(fontPath)) {
      GlobalFonts.registerFromPath(fontPath, family);
    }
  }

  fontsRegistered = true;
}

function drawPaperTexture(ctx: SKRSContext2D, x: number, y: number, width: number, height: number) {
  const bgGradient = ctx.createLinearGradient(x, y, x, y + height);
  bgGradient.addColorStop(0, "#E8DCC8");
  bgGradient.addColorStop(0.5, "#DFD5C3");
  bgGradient.addColorStop(1, "#D9CDB8");
  ctx.fillStyle = bgGradient;
  ctx.fillRect(x, y, width, height);

  for (let i = 0; i < 100; i++) {
    ctx.fillStyle = `rgba(139, 127, 101, ${Math.random() * 0.02})`;
    ctx.fillRect(
      x + Math.random() * width,
      y + Math.random() * height,
      Math.random() * 8 + 2,
      Math.random() * 8 + 2
    );
  }

  ctx.fillStyle = "rgba(139, 127, 101, 0.05)";
  for (let i = 0; i < 50; i++) {
    const randomX = x + Math.random() * width;
    const randomY = y + Math.random() * height;
    ctx.beginPath();
    ctx.arc(randomX, randomY, Math.random() * 15 + 5, 0, Math.PI * 2);
    ctx.fill();
  }
}

function wrapText(
  ctx: SKRSContext2D,
  text: string,
  x: number,
  y: number,
  maxWidth: number,
  lineHeight: number,
): number {
  const words = text.split(' ');
  let line = '';
  let currentY = y;

  for (let i = 0; i < words.length; i++) {
    const testLine = line + words[i] + ' ';
    const metrics = ctx.measureText(testLine);
    const testWidth = metrics.width;

    if (testWidth > maxWidth && i > 0) {
      ctx.fillText(line, x, currentY);
      line = words[i] + ' ';
      currentY += lineHeight;
    } else {
      line = testLine;
    }
  }
  ctx.fillText(line, x, currentY);
  return currentY;
}

const storeTranslations = {
  'pt-BR': {
    storeTitle: 'LOJA GERAL',
    storyTitle: '★ HISTÓRIA DO VELHO OESTE',
    insufficientBalance: 'SALDO INSUFICIENTE',
    silverCoins: 'Moedas de Prata',
    saloonTokens: 'Saloon Tokens',
    capacity: 'de Capacidade',
    owned: 'JÁ POSSUI',
    available: 'DISPONÍVEL',
    price: 'PREÇO',
  },
  'en-US': {
    storeTitle: 'GENERAL STORE',
    storyTitle: '★ OLD WEST TALE',
    insufficientBalance: 'INSUFFICIENT BALANCE',
    silverCoins: 'Silver Coins',
    saloonTokens: 'Saloon Tokens',
    capacity: 'Capacity',
    owned: 'OWNED',
    available: 'AVAILABLE',
    price: 'PRICE',
  },
};

function drawTransitionEffect(ctx: SKRSContext2D, width: number, height: number): void {
  const vignette = ctx.createRadialGradient(width / 2, height / 2, 0, width / 2, height / 2, Math.max(width, height));
  vignette.addColorStop(0, 'rgba(255, 255, 255, 0.08)');
  vignette.addColorStop(1, 'rgba(0, 0, 0, 0.15)');
  ctx.fillStyle = vignette;
  ctx.fillRect(0, 0, width, height);

  const topGlow = ctx.createLinearGradient(0, 0, 0, 30);
  topGlow.addColorStop(0, 'rgba(255, 255, 255, 0.1)');
  topGlow.addColorStop(1, 'rgba(255, 255, 255, 0)');
  ctx.fillStyle = topGlow;
  ctx.fillRect(0, 0, width, 30);
}

export async function createStoreItemCanvas(
  item: GeneralStoreItem,
  userTokens: number,
  userHasItem: boolean,
  userSilver: number = 0,
  language: 'pt-BR' | 'en-US' = 'pt-BR',
): Promise<Buffer> {
  ensureFontsRegistered();
  const t = storeTranslations[language];
  const isPtBr = language === 'pt-BR';

  const width = 900;
  const height = 550;
  const canvas = createCanvas(width, height);
  const ctx = canvas.getContext('2d');

  drawPaperTexture(ctx, 0, 0, width, height);

  ctx.fillStyle = "#1C1814";
  ctx.font = "bold 48px BleedingCowboys";
  ctx.textAlign = "center";
  ctx.fillText(t.storeTitle, width / 2, 55);

  let itemImage;
  if (item.imageFile) {
    if (item.imageFile.startsWith('http://') || item.imageFile.startsWith('https://')) {
      try {
        itemImage = await canvasCache.loadImageWithCache(item.imageFile);
      } catch (error) {
        console.error('Error loading image from URL:', error);
      }
    } else {
      const imagePath = path.join(process.cwd(), 'assets', 'shop-items', item.imageFile);
      if (fs.existsSync(imagePath)) {
        try {
          itemImage = await canvasCache.loadImageWithCache(imagePath);
        } catch (error) {
          console.error(`Error loading image from path ${imagePath}:`, error);
        }
      }
    }
  }

  const imageSize = 280;
  const imageX = 60;
  const imageY = 85;

  if (itemImage) {
    ctx.drawImage(itemImage, imageX, imageY, imageSize, imageSize);
  }

  const contentX = imageX + imageSize + 40;
  const contentMaxWidth = width - contentX - 40;

  const itemName = isPtBr ? item.name : (item.nameEn || item.name);
  ctx.fillStyle = "#1C1814";
  ctx.font = "bold 32px BleedingCowboys";
  ctx.textAlign = "left";
  ctx.fillText(itemName, contentX, 130);

  const description = isPtBr ? item.description : (item.descriptionEn || item.description);
  ctx.fillStyle = "#3C3428";
  ctx.font = "20px Nunito";
  ctx.textAlign = "left";
  let descY = 165;
  descY = wrapText(ctx, description, contentX, descY, contentMaxWidth, 28) + 35;

  const story = isPtBr ? item.story : (item.storyEn || item.story);
  if (story) {
    ctx.strokeStyle = "#000000";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(contentX, descY);
    ctx.lineTo(width - 40, descY);
    ctx.stroke();
    
    descY += 25;

    ctx.fillStyle = "#8B2323";
    ctx.font = "bold 15px Nunito-SemiBold";
    ctx.fillText(t.storyTitle, contentX, descY);

    descY += 18;

    ctx.fillStyle = "#6B5D4F";
    ctx.font = "italic 16px Nunito";
    descY = wrapText(ctx, story, contentX, descY, contentMaxWidth, 24);
  }

  if (item.category === 'backpacks' && item.backpackCapacity) {
    ctx.fillStyle = "#8B2323";
    ctx.font = "bold 18px Nunito-Bold";
    ctx.fillText(`+${item.backpackCapacity}kg ${t.capacity}`, contentX, descY + 18);
  }

  const priceBoxY = height - 75;
  
  ctx.fillStyle = "rgba(232, 220, 200, 0.25)";
  ctx.fillRect(40, priceBoxY, width - 80, 75);

  ctx.fillStyle = "#000000";
  ctx.font = "bold 60px BleedingCowboys";
  ctx.textAlign = "left";
  ctx.fillText(`$${item.price.toLocaleString()}`, 70, priceBoxY + 35);

  const currencyLabel = item.currency === 'silver' ? t.silverCoins : t.saloonTokens;
  ctx.fillStyle = "#3C3428";
  ctx.font = "14px Nunito-SemiBold";
  ctx.textAlign = "left";
  ctx.fillText(currencyLabel, 70, priceBoxY + 55);

  if (userHasItem) {
    ctx.fillStyle = "#2E7D32";
    ctx.font = "bold 24px Nunito-Bold";
    ctx.textAlign = "right";
    ctx.fillText(`✓ ${t.owned}`, width - 70, priceBoxY + 40);
  }

  drawTransitionEffect(ctx, width, height);

  return canvas.toBuffer('image/png');
}
