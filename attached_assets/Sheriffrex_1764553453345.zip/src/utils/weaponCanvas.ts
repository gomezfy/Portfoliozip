import { createCanvas, loadImage, GlobalFonts } from "@napi-rs/canvas";
import path from "path";
import { CanvasOptimizer } from "./canvasOptimizer";
import axios from "axios";

GlobalFonts.registerFromPath(
  path.join(process.cwd(), "assets/fonts/Nunito-Bold.ttf"),
  "Nunito",
);
GlobalFonts.registerFromPath(
  path.join(process.cwd(), "assets/fonts/Nunito-SemiBold.ttf"),
  "Nunito SemiBold",
);
GlobalFonts.registerFromPath(
  path.join(process.cwd(), "assets/fonts/BleedingCowboys.ttf"),
  "BleedingCowboys",
);

export interface WeaponData {
  name: string;
  nameEn?: string;
  damage: number;
  imageUrl: string;
  price: number;
  currency: string;
  description: string;
  descriptionEn?: string;
  story?: string;
  storyEn?: string;
  language?: 'pt-BR' | 'en-US';
}

const translations = {
  'pt-BR': {
    damage: 'DANO',
    legend: '★ LENDA DO VELHO OESTE',
    silverCoins: 'Moedas de Prata',
    goldBars: 'Barras de Ouro',
    armoryTitle: 'ARMARIA',
    price: 'PREÇO',
    loadingError: 'Erro ao carregar imagem',
  },
  'en-US': {
    damage: 'DAMAGE',
    legend: '★ WILD WEST LEGEND',
    silverCoins: 'Silver Coins',
    goldBars: 'Gold Bars',
    armoryTitle: 'ARMORY',
    price: 'PRICE',
    loadingError: 'Error loading image',
  },
};

function drawPaperTexture(ctx: any, x: number, y: number, width: number, height: number) {
  const bgGradient = ctx.createLinearGradient(x, y, x, y + height);
  bgGradient.addColorStop(0, "#E8DCC8");
  bgGradient.addColorStop(0.5, "#DFD5C3");
  bgGradient.addColorStop(1, "#D9CDB8");
  ctx.fillStyle = bgGradient;
  ctx.fillRect(x, y, width, height);

  for (let i = 0; i < 100; i++) {
    ctx.fillStyle = `rgba(139, 127, 101, ${Math.random() * 0.02})`;
    ctx.fillRect(
      x + Math.random() * width,
      y + Math.random() * height,
      Math.random() * 8 + 2,
      Math.random() * 8 + 2
    );
  }

  ctx.fillStyle = "rgba(139, 127, 101, 0.05)";
  for (let i = 0; i < 50; i++) {
    const randomX = x + Math.random() * width;
    const randomY = y + Math.random() * height;
    ctx.beginPath();
    ctx.arc(randomX, randomY, Math.random() * 15 + 5, 0, Math.PI * 2);
    ctx.fill();
  }
}

function drawTransitionEffect(ctx: any, width: number, height: number): void {
  const vignette = ctx.createRadialGradient(width / 2, height / 2, 0, width / 2, height / 2, Math.max(width, height));
  vignette.addColorStop(0, 'rgba(255, 255, 255, 0.08)');
  vignette.addColorStop(1, 'rgba(0, 0, 0, 0.15)');
  ctx.fillStyle = vignette;
  ctx.fillRect(0, 0, width, height);

  const topGlow = ctx.createLinearGradient(0, 0, 0, 30);
  topGlow.addColorStop(0, 'rgba(255, 255, 255, 0.1)');
  topGlow.addColorStop(1, 'rgba(255, 255, 255, 0)');
  ctx.fillStyle = topGlow;
  ctx.fillRect(0, 0, width, 30);
}


export async function generateWeaponCard(weapon: WeaponData): Promise<Buffer> {
  const width = 900;
  const height = 520;
  const lang = weapon.language || 'pt-BR';
  const isPtBr = lang === 'pt-BR';
  const t = translations[lang];

  const canvas = createCanvas(width, height);
  const ctx = canvas.getContext("2d");

  drawPaperTexture(ctx, 0, 0, width, height);

  ctx.fillStyle = "#1C1814";
  ctx.font = "bold 54px BleedingCowboys";
  ctx.textAlign = "center";
  ctx.fillText(weapon.name.toUpperCase(), width / 2, 70);

  try {
    const response = await axios.get(weapon.imageUrl, {
      responseType: "arraybuffer",
      timeout: 5000,
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
      }
    });
    const weaponImage = await loadImage(Buffer.from(response.data));

    const imageSize = 280;
    const imageX = 60;
    const imageY = 120;

    ctx.drawImage(weaponImage, imageX, imageY, imageSize, imageSize);
  } catch (error) {
    console.error("Error loading weapon image:", error);
  }

  const descX = 380;
  const descY = 130;
  const maxDescWidth = 480;

  const description = isPtBr ? weapon.description : (weapon.descriptionEn || weapon.description);
  ctx.fillStyle = "#3C3428";
  ctx.font = "22px Nunito";
  ctx.textAlign = "left";
  
  const words = description.split(' ');
  let line = '';
  let currentY = descY;
  
  for (const word of words) {
    const testLine = line + (line ? ' ' : '') + word;
    const metrics = ctx.measureText(testLine);
    if (metrics.width > maxDescWidth && line) {
      ctx.fillText(line, descX, currentY);
      line = word;
      currentY += 32;
    } else {
      line = testLine;
    }
  }
  ctx.fillText(line, descX, currentY);

  const story = isPtBr ? weapon.story : (weapon.storyEn || weapon.story);
  if (story) {
    currentY += 50;
    
    ctx.strokeStyle = "#000000";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(descX, currentY - 10);
    ctx.lineTo(width - 40, currentY - 10);
    ctx.stroke();
    
    currentY += 35;
    
    ctx.fillStyle = "#8B2323";
    ctx.font = "bold 16px Nunito SemiBold";
    ctx.fillText(t.legend, descX, currentY);
    
    currentY += 26;
    
    ctx.fillStyle = "#6B5D4F";
    ctx.font = "italic 16px Nunito";
    const storyWords = story.split(' ');
    let storyLine = '';
    
    for (const word of storyWords) {
      const testLine = storyLine + (storyLine ? ' ' : '') + word;
      const metrics = ctx.measureText(testLine);
      if (metrics.width > maxDescWidth && storyLine) {
        ctx.fillText(storyLine, descX, currentY);
        storyLine = word;
        currentY += 26;
      } else {
        storyLine = testLine;
      }
    }
    ctx.fillText(storyLine, descX, currentY);
  }

  const infoBoxY = 410;
  ctx.fillStyle = "#3C3428";
  ctx.font = "bold 18px Nunito SemiBold";
  ctx.textAlign = "left";
  ctx.fillText(t.damage, 60, infoBoxY);

  ctx.fillStyle = "#8B2323";
  ctx.font = "bold 56px Nunito";
  ctx.fillText(weapon.damage.toString(), 60, infoBoxY + 70);

  ctx.fillStyle = "#000000";
  ctx.font = "bold 56px Nunito";
  ctx.textAlign = "right";
  const currencySymbol = weapon.currency === "silver" ? "$" : "⭐";
  ctx.fillText(`${currencySymbol}${weapon.price.toLocaleString()}`, width - 60, infoBoxY + 70);

  const currencyLabel = weapon.currency === "silver" ? t.silverCoins : t.goldBars;
  ctx.fillStyle = "#3C3428";
  ctx.font = "14px Nunito-SemiBold";
  ctx.textAlign = "right";
  ctx.fillText(currencyLabel, width - 60, infoBoxY + 90);

  drawTransitionEffect(ctx, width, height);

  return canvas.toBuffer("image/png");
}
