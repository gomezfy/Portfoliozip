/**
 * Modern Logger System - Production Grade
 * Handles all console output with security, formatting, and colored output
 */

const Colors = {
  RESET: '\x1b[0m',
  BRIGHT: '\x1b[1m',
  DIM: '\x1b[2m',
  RED: '\x1b[31m',
  GREEN: '\x1b[32m',
  YELLOW: '\x1b[33m',
  BLUE: '\x1b[34m',
  MAGENTA: '\x1b[35m',
  CYAN: '\x1b[36m',
  BRIGHT_RED: '\x1b[91m',
  BRIGHT_GREEN: '\x1b[92m',
  BRIGHT_YELLOW: '\x1b[93m',
  BRIGHT_CYAN: '\x1b[96m',
};

class ModernLogger {
  private maskSensitiveData(str: string): string {
    if (!str || typeof str !== 'string') return str;
    return str
      .replace(/token[=:]?\s*['"]?[^\s'",}]+['"]?/gi, 'token=***')
      .replace(/DATABASE_URL[=:]?\s*['"]?postgresql:\/\/[^\s'",}]+['"]?/gi, 'DATABASE_URL=***')
      .replace(/API_KEY[=:]?\s*['"]?[^\s'",}]+['"]?/gi, 'API_KEY=***')
      .replace(/SECRET[=:]?\s*['"]?[^\s'",}]+['"]?/gi, 'SECRET=***')
      .replace(/password[=:]?\s*['"]?[^\s'",}]+['"]?/gi, 'password=***');
  }

  private getTime(): string {
    const now = new Date();
    return `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}:${String(now.getSeconds()).padStart(2, '0')}`;
  }

  info(msg: string, ctx?: string): void {
    const time = this.getTime();
    const context = ctx ? ` ${Colors.DIM}(${ctx})${Colors.RESET}` : '';
    console.log(`[${time}] ${Colors.BLUE}ℹ️  INFO${Colors.RESET}${context} ${msg}`);
  }

  success(msg: string, ctx?: string): void {
    const time = this.getTime();
    const context = ctx ? ` ${Colors.DIM}(${ctx})${Colors.RESET}` : '';
    console.log(`[${time}] ${Colors.GREEN}✅ SUCCESS${Colors.RESET}${context} ${msg}`);
  }

  warn(msg: string, ctx?: string): void {
    const time = this.getTime();
    const context = ctx ? ` ${Colors.DIM}(${ctx})${Colors.RESET}` : '';
    console.warn(`[${time}] ${Colors.YELLOW}⚠️  WARN${Colors.RESET}${context} ${msg}`);
  }

  error(msg: string, err?: Error | string, ctx?: string): void {
    const time = this.getTime();
    const context = ctx ? ` ${Colors.DIM}(${ctx})${Colors.RESET}` : '';
    console.error(`[${time}] ${Colors.BRIGHT_RED}❌ ERROR${Colors.RESET}${context} ${msg}`);
    
    if (err) {
      if (err instanceof Error) {
        console.error(`${Colors.RED}${err.message}${Colors.RESET}`);
      } else {
        const masked = this.maskSensitiveData(String(err));
        console.error(`${Colors.RED}${masked}${Colors.RESET}`);
      }
    }
  }

  debug(msg: string, meta?: any): void {
    if (process.env.LOG_LEVEL === 'debug') {
      const time = this.getTime();
      console.log(`[${time}] ${Colors.DIM}🔍 DEBUG${Colors.RESET} ${msg}`);
      if (meta) console.log(Colors.DIM, meta, Colors.RESET);
    }
  }

  section(title: string): void {
    const w = 50;
    const p = Math.max(0, Math.floor((w - title.length) / 2));
    console.log(`\n${Colors.BRIGHT}${Colors.CYAN}${'═'.repeat(w)}${Colors.RESET}`);
    console.log(`${Colors.BRIGHT}${Colors.CYAN}${' '.repeat(p)}${title}${Colors.RESET}`);
    console.log(`${Colors.BRIGHT}${Colors.CYAN}${'═'.repeat(w)}${Colors.RESET}\n`);
  }

  banner(title: string): void {
    console.log(`${Colors.BRIGHT}${Colors.GREEN}╔${'═'.repeat(46)}╗${Colors.RESET}`);
    console.log(`${Colors.BRIGHT}${Colors.GREEN}║  ${title.padEnd(42)}  ║${Colors.RESET}`);
    console.log(`${Colors.BRIGHT}${Colors.GREEN}╚${'═'.repeat(46)}╝${Colors.RESET}`);
  }

  table(data: Record<string, boolean | string>): void {
    console.log(`${Colors.BRIGHT}┌${'─'.repeat(35)}┐${Colors.RESET}`);
    
    for (const [key, value] of Object.entries(data)) {
      const status = typeof value === 'boolean'
        ? value ? `${Colors.GREEN}✓${Colors.RESET}` : `${Colors.RED}✗${Colors.RESET}`
        : value;
      const line = `│ ${Colors.CYAN}${key.padEnd(15)}${Colors.RESET} ${String(status).padEnd(15)} │`;
      console.log(line);
    }
    
    console.log(`${Colors.BRIGHT}└${'─'.repeat(35)}┘${Colors.RESET}`);
  }

  divider(): void {
    console.log(`${Colors.BRIGHT}${Colors.CYAN}${'═'.repeat(50)}${Colors.RESET}`);
  }
}

export const modernLogger = new ModernLogger();
