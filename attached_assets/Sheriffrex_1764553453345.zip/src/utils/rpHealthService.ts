import { db } from '../../server/db';
import { users, rpActionHistory, rpReputation } from '../../shared/schema';
import { eq, and, sql } from 'drizzle-orm';
import { geminiService, GeminiMessage } from './geminiService';
import { v4 as uuidv4 } from 'uuid';

export interface HealthEffects {
  health?: number;
  stamina?: number;
  thirst?: number;
  hunger?: number;
  blood?: number;
  temperature?: number;
  description: string;
  severity: 'minor' | 'moderate' | 'severe' | 'critical';
}

interface ActionAnalysis {
  effects: HealthEffects;
  narration: string;
  reputationChange?: {
    npcType: string;
    change: number;
  };
}

const HEALTH_ANALYZER_PROMPT = `Você é um sistema de análise de ações de Roleplay do Velho Oeste.
Sua função é analisar ações dos jogadores e determinar os efeitos na saúde do personagem.

REGRAS DE ANÁLISE:
- Analise a ação e determine os efeitos físicos realistas
- Considere: esforço físico, clima, perigos, alimentação, hidratação
- Seja justo mas realista - ações perigosas têm consequências
- Ações simples geralmente não afetam a saúde

EFEITOS POSSÍVEIS (valores de -50 a +50):
- health: Vida (ferimentos, cura) - apenas em combate ou acidentes
- stamina: Energia (esforço físico, descanso)
- thirst: Sede (beber, calor intenso)
- hunger: Fome (comer, esforço prolongado)
- blood: Sangue (ferimentos com sangramento)
- temperature: Temperatura corporal (37 é normal, 35-39 é seguro)

SEVERIDADE:
- minor: Efeitos leves (-5 a +5)
- moderate: Efeitos moderados (-15 a +15)
- severe: Efeitos graves (-30 a +30)
- critical: Efeitos críticos (-50 a +50)

RESPONDA APENAS EM JSON:
{
  "effects": {
    "health": 0,
    "stamina": -10,
    "thirst": -5,
    "hunger": 0,
    "blood": 0,
    "temperature": 0,
    "description": "Descrição breve do efeito",
    "severity": "minor"
  },
  "narration": "Narração cinematográfica da ação (2-3 frases)"
}

EXEMPLOS:
Ação: "Corre pelo deserto sob sol escaldante"
{
  "effects": {
    "health": 0,
    "stamina": -20,
    "thirst": -15,
    "hunger": -5,
    "blood": 0,
    "temperature": 2,
    "description": "O esforço sob o sol causou desidratação e fadiga",
    "severity": "moderate"
  },
  "narration": "O sol impiedoso castigava suas costas enquanto seus pés afundavam na areia quente. Cada respiração queimava seus pulmões secos."
}

Ação: "Bebe água no poço"
{
  "effects": {
    "health": 0,
    "stamina": 5,
    "thirst": 30,
    "hunger": 0,
    "blood": 0,
    "temperature": -1,
    "description": "A água fresca restaurou sua hidratação",
    "severity": "minor"
  },
  "narration": "A água cristalina escorreu por sua garganta ressecada, trazendo alívio imediato ao corpo castigado pelo calor."
}`;

const ACTION_KEYWORDS = {
  combat: ['atira', 'saca', 'luta', 'soco', 'chuta', 'esfaqueia', 'golpeia', 'ataca', 'defende', 'esquiva', 'mata', 'fere'],
  physical: ['corre', 'pula', 'escala', 'carrega', 'empurra', 'puxa', 'nada', 'cavalga', 'persegue', 'foge'],
  rest: ['descansa', 'dorme', 'senta', 'deita', 'relaxa', 'medita', 'cochila'],
  consume: ['bebe', 'come', 'mastiga', 'engole', 'devora', 'saboreia'],
  weather: ['sol', 'calor', 'frio', 'neve', 'chuva', 'tempestade', 'vento', 'deserto'],
  danger: ['cai', 'tropeça', 'queima', 'afoga', 'envenenado', 'mordido', 'picado'],
  healing: ['curativo', 'bandagem', 'remédio', 'médico', 'tratamento', 'curar'],
};

class RPHealthService {
  private actionCache: Map<string, ActionAnalysis> = new Map();

  /**
   * Detecta menções (@user) na ação e extrai o ID do usuário alvo
   */
  extractTargetUserId(action: string): string | null {
    // Procura por padrão <@ID> (Discord mention)
    const mentionMatch = action.match(/<@!?(\d+)>/);
    if (mentionMatch && mentionMatch[1]) {
      return mentionMatch[1];
    }
    
    // Procura por @username
    const usernameMatch = action.match(/@(\w+)/);
    if (usernameMatch) {
      // Retorna null se não conseguir extrair ID - será tratado no comando
      return null;
    }
    
    return null;
  }

  /**
   * Calcula dano baseado na ação (se houver menção de combate)
   */
  calculateTargetDamage(action: string): HealthEffects | null {
    const lowerAction = action.toLowerCase();
    
    // Apenas aplicar dano se for uma ação de combate
    if (!ACTION_KEYWORDS.combat.some(k => lowerAction.includes(k))) {
      return null;
    }

    // Determinar severidade do dano
    if (lowerAction.includes('mata') || lowerAction.includes('executa')) {
      return {
        health: -40,
        blood: -30,
        stamina: -20,
        description: 'Ataque mortal!',
        severity: 'critical',
      };
    } else if (lowerAction.includes('atira')) {
      return {
        health: -25,
        blood: -15,
        stamina: -10,
        description: 'Ferimento de bala',
        severity: 'severe',
      };
    } else if (lowerAction.includes('soca') || lowerAction.includes('socar')) {
      return {
        health: -15,
        blood: -5,
        stamina: -8,
        description: 'Golpe forte',
        severity: 'moderate',
      };
    } else if (lowerAction.includes('chuta')) {
      return {
        health: -18,
        blood: -8,
        stamina: -10,
        description: 'Chute poderoso',
        severity: 'moderate',
      };
    } else if (lowerAction.includes('esfaqueia') || lowerAction.includes('faca')) {
      return {
        health: -30,
        blood: -20,
        stamina: -12,
        description: 'Ferimento com faca',
        severity: 'severe',
      };
    } else if (lowerAction.includes('golpeia') || lowerAction.includes('ataca')) {
      return {
        health: -12,
        blood: -5,
        stamina: -8,
        description: 'Golpe',
        severity: 'moderate',
      };
    }

    return null;
  }

  /**
   * Aplica dano a um usuário alvo
   */
  async applyTargetDamage(targetUserId: string, damage: HealthEffects): Promise<{ 
    targetFound: boolean; 
    before?: Record<string, number>;
    after?: Record<string, number>;
    warnings?: string[];
  }> {
    try {
      const targetResult = await db
        .select()
        .from(users)
        .where(eq(users.userId, targetUserId))
        .limit(1);

      if (!targetResult.length) {
        return { targetFound: false };
      }

      const effects = await this.applyEffects(targetUserId, damage);
      return {
        targetFound: true,
        before: effects.before,
        after: effects.after,
        warnings: effects.warnings,
      };
    } catch (error) {
      console.error('Error applying target damage:', error);
      return { targetFound: false };
    }
  }

  async analyzeAction(
    action: string,
    context?: string,
    weather?: string,
    temperature?: number
  ): Promise<ActionAnalysis> {
    const cacheKey = `${action}-${context}-${weather}-${temperature}`;
    
    if (this.actionCache.has(cacheKey)) {
      return this.actionCache.get(cacheKey)!;
    }

    if (!geminiService.isConfigured()) {
      return this.fallbackAnalysis(action, weather, temperature);
    }

    try {
      const messages: GeminiMessage[] = [
        {
          role: 'user',
          parts: [{ text: `${HEALTH_ANALYZER_PROMPT}\n\n${this.buildAnalysisPrompt(action, context, weather, temperature)}` }],
        },
      ];

      const response = await geminiService.chat(messages, undefined, 500);
      const analysis = this.parseAnalysisResponse(response);
      
      this.actionCache.set(cacheKey, analysis);
      
      if (this.actionCache.size > 100) {
        const firstKey = this.actionCache.keys().next().value;
        if (firstKey) this.actionCache.delete(firstKey);
      }
      
      return analysis;
    } catch (error) {
      console.error('Error analyzing action:', error);
      return this.fallbackAnalysis(action, weather, temperature);
    }
  }

  private buildAnalysisPrompt(
    action: string,
    context?: string,
    weather?: string,
    temperature?: number
  ): string {
    let prompt = `Ação do jogador: "${action}"`;
    
    if (context) {
      prompt += `\nContexto da cena: ${context}`;
    }
    
    if (weather) {
      prompt += `\nClima atual: ${weather}`;
    }
    
    if (temperature !== undefined) {
      prompt += `\nTemperatura ambiente: ${temperature}°C`;
    }
    
    prompt += '\n\nAnalise esta ação e retorne os efeitos na saúde do personagem em JSON.';
    
    return prompt;
  }

  private parseAnalysisResponse(response: string): ActionAnalysis {
    try {
      const jsonMatch = response.match(/\{[\s\S]*\}/);
      if (!jsonMatch) {
        throw new Error('No JSON found in response');
      }
      
      const parsed = JSON.parse(jsonMatch[0]);
      
      return {
        effects: {
          health: this.clampEffect(parsed.effects?.health || 0),
          stamina: this.clampEffect(parsed.effects?.stamina || 0),
          thirst: this.clampEffect(parsed.effects?.thirst || 0),
          hunger: this.clampEffect(parsed.effects?.hunger || 0),
          blood: this.clampEffect(parsed.effects?.blood || 0),
          temperature: this.clampTemperatureEffect(parsed.effects?.temperature || 0),
          description: parsed.effects?.description || 'Sem efeitos significativos',
          severity: parsed.effects?.severity || 'minor',
        },
        narration: parsed.narration || '',
        reputationChange: parsed.reputationChange,
      };
    } catch (error) {
      console.error('Error parsing analysis response:', error);
      return this.getDefaultAnalysis();
    }
  }

  private fallbackAnalysis(
    action: string,
    weather?: string,
    temperature?: number
  ): ActionAnalysis {
    const lowerAction = action.toLowerCase();
    const effects: HealthEffects = {
      health: 0,
      stamina: 0,
      thirst: 0,
      hunger: 0,
      blood: 0,
      temperature: 0,
      description: '',
      severity: 'minor',
    };

    if (ACTION_KEYWORDS.combat.some(k => lowerAction.includes(k))) {
      effects.stamina = -15;
      effects.health = -10;
      effects.blood = -5;
      effects.severity = 'moderate';
      effects.description = 'Combate físico intenso';
    }
    else if (ACTION_KEYWORDS.physical.some(k => lowerAction.includes(k))) {
      effects.stamina = -10;
      effects.thirst = -5;
      effects.hunger = -3;
      effects.severity = 'minor';
      effects.description = 'Esforço físico moderado';
    }
    else if (ACTION_KEYWORDS.rest.some(k => lowerAction.includes(k))) {
      effects.stamina = 20;
      effects.health = 5;
      effects.severity = 'minor';
      effects.description = 'Descanso restaurador';
    }
    else if (ACTION_KEYWORDS.consume.some(k => lowerAction.includes(k))) {
      if (lowerAction.includes('bebe') || lowerAction.includes('água')) {
        effects.thirst = 25;
        effects.temperature = -1;
      }
      if (lowerAction.includes('come') || lowerAction.includes('comida')) {
        effects.hunger = 25;
        effects.stamina = 5;
      }
      effects.severity = 'minor';
      effects.description = 'Consumo de recursos';
    }
    else if (ACTION_KEYWORDS.danger.some(k => lowerAction.includes(k))) {
      effects.health = -20;
      effects.blood = -10;
      effects.severity = 'severe';
      effects.description = 'Situação perigosa';
    }
    else if (ACTION_KEYWORDS.healing.some(k => lowerAction.includes(k))) {
      effects.health = 15;
      effects.blood = 10;
      effects.severity = 'minor';
      effects.description = 'Tratamento médico';
    }

    if (weather) {
      if (weather.includes('calor') || weather.includes('sol')) {
        effects.thirst = (effects.thirst || 0) - 5;
        effects.temperature = (effects.temperature || 0) + 1;
      }
      if (weather.includes('frio') || weather.includes('neve')) {
        effects.temperature = (effects.temperature || 0) - 2;
        effects.stamina = (effects.stamina || 0) - 5;
      }
    }

    if (temperature !== undefined) {
      if (temperature > 35) {
        effects.thirst = (effects.thirst || 0) - 5;
        effects.temperature = (effects.temperature || 0) + 1;
      } else if (temperature < 10) {
        effects.temperature = (effects.temperature || 0) - 1;
        effects.stamina = (effects.stamina || 0) - 5;
      }
    }

    return {
      effects,
      narration: this.generateFallbackNarration(action, effects),
    };
  }

  private generateFallbackNarration(action: string, effects: HealthEffects): string {
    const narrations: string[] = [];
    
    if (effects.stamina && effects.stamina < -10) {
      narrations.push('O esforço cobrou seu preço, deixando músculos doloridos.');
    }
    if (effects.thirst && effects.thirst < -10) {
      narrations.push('A sede começou a apertar sua garganta.');
    }
    if (effects.health && effects.health < 0) {
      narrations.push('A dor atravessou seu corpo como fogo.');
    }
    if (effects.blood && effects.blood < 0) {
      narrations.push('O sangue escorreu, manchando a poeira seca.');
    }
    
    if (narrations.length === 0) {
      narrations.push('A ação foi concluída sem maiores consequências.');
    }
    
    return narrations.join(' ');
  }

  private clampEffect(value: number): number {
    return Math.max(-50, Math.min(50, value));
  }

  private clampTemperatureEffect(value: number): number {
    return Math.max(-5, Math.min(5, value));
  }

  private getDefaultAnalysis(): ActionAnalysis {
    return {
      effects: {
        health: 0,
        stamina: 0,
        thirst: 0,
        hunger: 0,
        blood: 0,
        temperature: 0,
        description: 'Sem efeitos significativos',
        severity: 'minor',
      },
      narration: '',
    };
  }

  async applyEffects(userId: string, effects: HealthEffects): Promise<{
    before: Record<string, number>;
    after: Record<string, number>;
    warnings: string[];
  }> {
    const userResult = await db
      .select()
      .from(users)
      .where(eq(users.userId, userId))
      .limit(1);

    if (!userResult.length) {
      throw new Error('Usuário não encontrado');
    }

    const user = userResult[0];
    const warnings: string[] = [];

    const before = {
      health: user.health,
      stamina: user.stamina,
      thirst: user.thirst,
      hunger: user.hunger,
      blood: user.blood,
      temperature: user.temperature,
    };

    const newHealth = Math.max(0, Math.min(user.maxHealth, user.health + (effects.health || 0)));
    const newStamina = Math.max(0, Math.min(user.maxStamina, user.stamina + (effects.stamina || 0)));
    const newThirst = Math.max(0, Math.min(user.maxThirst, user.thirst + (effects.thirst || 0)));
    const newHunger = Math.max(0, Math.min(user.maxHunger, user.hunger + (effects.hunger || 0)));
    const newBlood = Math.max(0, Math.min(user.maxBlood, user.blood + (effects.blood || 0)));
    const newTemperature = Math.max(30, Math.min(45, user.temperature + (effects.temperature || 0)));

    // Ativar sangramento se tiver dano de sangue
    let isBleeding = user.isBleeding;
    let bleedingAmount = user.bleedingAmount;
    if ((effects.blood || 0) < 0) {
      isBleeding = true;
      bleedingAmount = Math.max(1, Math.abs(effects.blood || 0) / 2);
      warnings.push('🩸 **SANGRANDO!** Você está perdendo sangue! Use Curar ou chame um médico!');
    }

    if (newHealth <= 0) {
      warnings.push('⚠️ **CRÍTICO:** Você está à beira da morte!');
    } else if (newHealth <= 20) {
      warnings.push('🩸 Você está gravemente ferido!');
    }

    if (newBlood <= 20) {
      warnings.push('🩸 Você está perdendo muito sangue!');
    }

    if (newThirst <= 10) {
      warnings.push('💧 Você está severamente desidratado!');
    } else if (newThirst <= 25) {
      warnings.push('💧 Você está com muita sede!');
    }

    if (newHunger <= 10) {
      warnings.push('🍖 Você está passando fome!');
    } else if (newHunger <= 25) {
      warnings.push('🍖 Você está com muita fome!');
    }

    if (newStamina <= 10) {
      warnings.push('⚡ Você está completamente exausto!');
    }

    if (newTemperature >= 40) {
      warnings.push('🌡️ Você está com febre alta!');
    } else if (newTemperature <= 34) {
      warnings.push('🥶 Você está com hipotermia!');
    }

    await db
      .update(users)
      .set({
        health: newHealth,
        stamina: newStamina,
        thirst: newThirst,
        hunger: newHunger,
        blood: newBlood,
        temperature: newTemperature,
        isBleeding,
        bleedingAmount,
        updatedAt: new Date(),
      })
      .where(eq(users.userId, userId));

    console.log(`✅ RP Saúde atualizada - ${userId}: ❤️${before.health}→${newHealth}, ⚡${before.stamina}→${newStamina}, 🩸${isBleeding ? 'SANGRANDO' : 'OK'}`);

    const after = {
      health: newHealth,
      stamina: newStamina,
      thirst: newThirst,
      hunger: newHunger,
      blood: newBlood,
      temperature: newTemperature,
    };

    return { before, after, warnings };
  }

  async logAction(
    userId: string,
    sessionId: string | null,
    actionType: string,
    action: string,
    narration?: string,
    healthEffects?: HealthEffects
  ): Promise<void> {
    await db.insert(rpActionHistory).values({
      id: uuidv4(),
      userId,
      sessionId,
      actionType,
      action,
      narration,
      healthEffects: healthEffects as any,
    });
  }

  async updateReputation(
    userId: string,
    npcType: string,
    change: number
  ): Promise<{ newReputation: number; title: string }> {
    const existing = await db
      .select()
      .from(rpReputation)
      .where(and(
        eq(rpReputation.userId, userId),
        eq(rpReputation.npcType, npcType)
      ))
      .limit(1);

    let newReputation: number;

    if (existing.length > 0) {
      newReputation = Math.max(-100, Math.min(100, existing[0].reputation + change));
      
      await db
        .update(rpReputation)
        .set({
          reputation: newReputation,
          interactionCount: existing[0].interactionCount + 1,
          lastInteraction: new Date(),
        })
        .where(eq(rpReputation.id, existing[0].id));
    } else {
      newReputation = Math.max(-100, Math.min(100, change));
      
      await db.insert(rpReputation).values({
        id: uuidv4(),
        userId,
        npcType,
        reputation: newReputation,
        interactionCount: 1,
        lastInteraction: new Date(),
      });
    }

    return {
      newReputation,
      title: this.getReputationTitle(newReputation),
    };
  }

  getReputationTitle(reputation: number): string {
    if (reputation >= 80) return '🌟 Herói Lendário';
    if (reputation >= 60) return '⭐ Respeitado';
    if (reputation >= 40) return '👍 Amigável';
    if (reputation >= 20) return '🤝 Conhecido';
    if (reputation >= -20) return '😐 Neutro';
    if (reputation >= -40) return '👎 Desconfiado';
    if (reputation >= -60) return '😠 Hostil';
    if (reputation >= -80) return '💀 Inimigo';
    return '☠️ Procurado Morto';
  }

  /**
   * Curar sangramento de um usuário
   */
  async healBleeding(userId: string): Promise<{ healed: boolean; healthRestored: number }> {
    const userResult = await db
      .select()
      .from(users)
      .where(eq(users.userId, userId))
      .limit(1);

    if (!userResult.length) {
      return { healed: false, healthRestored: 0 };
    }

    const user = userResult[0];
    const healthRestored = Math.min(30, Math.max(0, user.maxHealth - user.health));
    const newHealth = user.health + healthRestored;

    await db
      .update(users)
      .set({
        isBleeding: false,
        bleedingAmount: 0,
        blood: Math.min(user.maxBlood, user.blood + 20),
        health: newHealth,
        updatedAt: new Date(),
      })
      .where(eq(users.userId, userId));

    return { healed: true, healthRestored };
  }

  async getPlayerReputation(userId: string): Promise<Map<string, { reputation: number; title: string }>> {
    const reputations = await db
      .select()
      .from(rpReputation)
      .where(eq(rpReputation.userId, userId));

    const result = new Map<string, { reputation: number; title: string }>();
    
    for (const rep of reputations) {
      result.set(rep.npcType, {
        reputation: rep.reputation,
        title: this.getReputationTitle(rep.reputation),
      });
    }

    return result;
  }

  formatEffectsEmbed(effects: HealthEffects, before: Record<string, number>, after: Record<string, number>): string {
    const lines: string[] = [];
    const emoji = {
      health: '❤️',
      stamina: '⚡',
      thirst: '💧',
      hunger: '🍖',
      blood: '🩸',
      temperature: '🌡️',
    };

    const labels = {
      health: 'Vida',
      stamina: 'Stamina',
      thirst: 'Sede',
      hunger: 'Fome',
      blood: 'Sangue',
      temperature: 'Temperatura',
    };

    for (const [key, value] of Object.entries(effects)) {
      if (key === 'description' || key === 'severity') continue;
      if (value === 0) continue;

      const beforeVal = before[key as keyof typeof before];
      const afterVal = after[key as keyof typeof after];
      const arrow = value > 0 ? '↑' : '↓';
      const color = value > 0 ? '+' : '';
      
      if (key === 'temperature') {
        lines.push(`${emoji[key]} ${labels[key]}: ${beforeVal}°C → ${afterVal}°C (${color}${value}°C)`);
      } else {
        lines.push(`${emoji[key as keyof typeof emoji]} ${labels[key as keyof typeof labels]}: ${beforeVal} → ${afterVal} (${color}${value}) ${arrow}`);
      }
    }

    return lines.length > 0 ? lines.join('\n') : 'Sem alterações significativas';
  }
}

export const rpHealthService = new RPHealthService();

export async function applyTimePassageEffects(): Promise<{ affected: number; critical: string[] }> {
  const allUsers = await db
    .select()
    .from(users)
    .where(sql`${users.thirst} > 0 OR ${users.hunger} > 0 OR ${users.stamina} < ${users.maxStamina}`);

  let affected = 0;
  const critical: string[] = [];

  for (const user of allUsers) {
    const newThirst = Math.max(0, user.thirst - 2);
    const newHunger = Math.max(0, user.hunger - 1);
    const newStamina = Math.min(user.maxStamina, user.stamina + 3);
    
    let newHealth = user.health;
    if (newThirst <= 5 || newHunger <= 5) {
      newHealth = Math.max(0, user.health - 2);
    }

    if (newThirst !== user.thirst || newHunger !== user.hunger || 
        newStamina !== user.stamina || newHealth !== user.health) {
      await db
        .update(users)
        .set({
          thirst: newThirst,
          hunger: newHunger,
          stamina: newStamina,
          health: newHealth,
          updatedAt: new Date(),
        })
        .where(eq(users.userId, user.userId));

      affected++;

      if (newHealth <= 10 || newThirst <= 10 || newHunger <= 10) {
        critical.push(user.userId);
      }
    }
  }

  return { affected, critical };
}

export function startTimePassageSystem(client: any): void {
  const cron = require('node-cron');
  
  cron.schedule('0 * * * *', async () => {
    try {
      console.log('⏰ Aplicando efeitos de passagem de tempo...');
      const result = await applyTimePassageEffects();
      console.log(`⏰ ${result.affected} usuários afetados pela passagem de tempo`);
      
      if (result.critical.length > 0) {
        console.log(`⚠️ ${result.critical.length} usuários em estado crítico`);
      }
    } catch (error) {
      console.error('Erro ao aplicar efeitos de passagem de tempo:', error);
    }
  });

  console.log('⏰ Sistema de passagem de tempo iniciado (a cada hora)');
}
