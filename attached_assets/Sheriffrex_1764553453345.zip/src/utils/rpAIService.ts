import { EmbedBuilder, Message, TextChannel, User } from "discord.js";
import { geminiService, GeminiMessage } from "./geminiService";
import { rpNpcMemoryService } from "./rpNpcMemoryService";

const WESTERN_NARRATOR_PROMPT = `Você é um narrador de histórias do Velho Oeste americano. Seu estilo é dramático, cinematográfico e evocativo, como nos grandes westerns clássicos.

REGRAS:
- Escreva narrações curtas (2-3 frases no máximo)
- Use descrições sensoriais: sons, cheiros, texturas, luz
- Mantenha o tom sério e atmosférico do western noir
- Nunca quebre a quarta parede
- Use vocabulário da época: forasteiro, parceiro, xerife, pistoleiro, saloon, etc.
- Adicione detalhes ambientais: poeira, sol escaldante, rangido de madeira, etc.
- Responda APENAS com a narração, sem explicações

EXEMPLO:
Ação do jogador: "Abre a porta do saloon"
Narração: "A porta de madeira rangeu em seus gonzos enferrujados enquanto ele a empurrava. O som do piano cessou abruptamente, e todos os olhos se voltaram para o forasteiro parado na entrada, sua silhueta recortada contra a luz dourada do pôr-do-sol."`;

const WESTERN_ASSISTANT_PROMPT = `Você é um assistente de Roleplay do Velho Oeste. Você ajuda jogadores a criar ações, diálogos e pensamentos para seus personagens.

REGRAS:
- Dê sugestões curtas e variadas
- Mantenha o tom e vocabulário western
- Ofereça 3 opções diferentes para cada pedido
- Formate as sugestões corretamente:
  - Falas: começam com "-"
  - Ações: entre "**" (ex: **ação**)
  - Pensamentos: entre parênteses "()"
- Seja criativo mas mantenha a coerência com o cenário
- Adapte ao contexto fornecido pelo jogador

FORMATO DE RESPOSTA:
🗣️ **Sugestões de Fala:**
1. - [fala 1]
2. - [fala 2]
3. - [fala 3]

🔫 **Sugestões de Ação:**
1. **[ação 1]**
2. **[ação 2]**
3. **[ação 3]**

💭 **Sugestões de Pensamento:**
1. ([pensamento 1])
2. ([pensamento 2])
3. ([pensamento 3])`;

const NPC_BASE_PROMPT = `Você é um personagem do Velho Oeste americano. Você está em um roleplay e deve agir como seu personagem responderia.

REGRAS:
- Mantenha-se 100% no personagem
- Use o formato correto: falas com "-", ações com "**", pensamentos com "()"
- Responda de forma natural e breve (1-3 mensagens)
- Reaja ao contexto da cena
- Mantenha o vocabulário e maneirismos da época
- Tenha personalidade consistente`;

interface NPCPersonality {
  name: string;
  role: string;
  personality: string;
  speech: string;
  backstory: string;
}

const NPC_TEMPLATES: Record<string, NPCPersonality> = {
  bartender: {
    name: "Joe 'Mãos de Ferro' McGraw",
    role: "Bartender do Saloon",
    personality: "Amigável mas cauteloso, conhece todos os segredos da cidade",
    speech: "Fala de forma calma e sábia, sempre limpando um copo",
    backstory: "Ex-boxeador que abandonou os ringues após um acidente. Agora serve whisky e conselhos no saloon mais famoso da cidade."
  },
  sheriff: {
    name: "Xerife Thomas 'Trovão' Williams",
    role: "Xerife da Cidade",
    personality: "Justo e implacável, defensor da lei acima de tudo",
    speech: "Fala com autoridade, sempre direto ao ponto",
    backstory: "Veterano da Guerra Civil, carrega as cicatrizes do passado. Jurou proteger esta cidade com sua vida."
  },
  outlaw: {
    name: "El Diablo Negro",
    role: "Fora-da-lei Procurado",
    personality: "Misterioso, perigoso, mas com código de honra próprio",
    speech: "Fala pouco, cada palavra carrega peso",
    backstory: "Ninguém sabe seu verdadeiro nome. Dizem que matou 20 homens, mas só os que mereciam."
  },
  merchant: {
    name: "Samuel 'Calculista' Greene",
    role: "Comerciante da Loja Geral",
    personality: "Ganancioso mas justo nos negócios, sempre buscando lucro",
    speech: "Fala rápido, sempre calculando mentalmente",
    backstory: "Veio do leste fugindo de dívidas. Construiu seu império vendendo de tudo um pouco."
  },
  doctor: {
    name: "Dra. Elizabeth 'Mãos Firmes' Carter",
    role: "Médica da Cidade",
    personality: "Compassiva, determinada, uma das poucas mulheres respeitadas na cidade",
    speech: "Fala com calma e precisão, como opera",
    backstory: "Estudou medicina contra a vontade da família. Fugiu para o Oeste onde suas habilidades são mais valorizadas que seu gênero."
  },
  gambler: {
    name: "Jack 'Ás de Espadas' Monroe",
    role: "Jogador Profissional",
    personality: "Charmoso, sorrateiro, sempre com um truque na manga",
    speech: "Fala de forma elegante e persuasiva",
    backstory: "Expulso de todos os cassinos do Mississippi por trapaça. No Oeste, encontrou jogadores menos atentos."
  },
  cowgirl: {
    name: "Rosa 'Relâmpago' Vargas",
    role: "Vaqueira e Caçadora de Recompensas",
    personality: "Destemida, independente, não leva desaforo para casa",
    speech: "Fala direta, às vezes sarcástica",
    backstory: "Filha de um rancho mexicano, aprendeu a atirar antes de andar. Agora caça criminosos por dinheiro e justiça."
  }
};

const Colors = {
  NARRATOR: 0x8b4513,
  ASSISTANT: 0xd4a03a,
  NPC: 0x4a5568,
  ERROR: 0xef4444,
} as const;

export class RPAIService {
  private conversationHistory: Map<string, GeminiMessage[]> = new Map();
  private activeNPCs: Map<string, string> = new Map();

  async generateNarration(action: string, context?: string): Promise<string> {
    if (!geminiService.isConfigured()) {
      throw new Error("IA não configurada. Configure a GOOGLE_API_KEY.");
    }

    const messages: GeminiMessage[] = [
      { role: "user", parts: [{ text: WESTERN_NARRATOR_PROMPT }] },
      {
        role: "model",
        parts: [{ text: "Entendi. Serei um narrador de histórias do Velho Oeste, mantendo o tom dramático e cinematográfico." }]
      },
      {
        role: "user",
        parts: [{
          text: context
            ? `Contexto da cena: ${context}\n\nAção do jogador: "${action}"\n\nGere uma narração cinematográfica para esta ação.`
            : `Ação do jogador: "${action}"\n\nGere uma narração cinematográfica para esta ação.`,
        }],
      },
    ];

    const response = await geminiService.chat(messages, undefined, 200);
    return response.trim();
  }

  async generateSuggestions(
    situation: string,
    characterInfo?: string
  ): Promise<string> {
    if (!geminiService.isConfigured()) {
      throw new Error("IA não configurada. Configure a GOOGLE_API_KEY.");
    }

    const messages: GeminiMessage[] = [
      { role: "user", parts: [{ text: WESTERN_ASSISTANT_PROMPT }] },
      { role: "model", parts: [{ text: "Entendi. Serei um assistente de roleplay do Velho Oeste e darei sugestões criativas." }] },
      {
        role: "user",
        parts: [{
          text: characterInfo
            ? `Meu personagem: ${characterInfo}\n\nSituação atual: ${situation}\n\nMe dê sugestões de como agir.`
            : `Situação atual: ${situation}\n\nMe dê sugestões de como agir.`,
        }],
      },
    ];

    const response = await geminiService.chat(messages, undefined, 500);
    return response.trim();
  }

  async npcRespond(
    npcType: string,
    playerMessage: string,
    channelId: string,
    sceneContext?: string,
    userId?: string
  ): Promise<{ response: string; npcName: string }> {
    if (!geminiService.isConfigured()) {
      throw new Error("IA não configurada. Configure a GOOGLE_API_KEY.");
    }

    const npc = NPC_TEMPLATES[npcType] || NPC_TEMPLATES.bartender;
    const historyKey = `${channelId}-${npcType}`;

    let npcPrompt = `${NPC_BASE_PROMPT}

VOCÊ É:
Nome: ${npc.name}
Papel: ${npc.role}
Personalidade: ${npc.personality}
Forma de falar: ${npc.speech}
História: ${npc.backstory}

Responda à interação do jogador mantendo-se completamente no personagem.`;

    // Adicionar memórias anteriores se userId for fornecido
    if (userId) {
      try {
        const recentMemories = await rpNpcMemoryService.getRecentMemories(npcType, userId, channelId, 3);
        const memoriesText = rpNpcMemoryService.formatMemoriesForPrompt(recentMemories);
        npcPrompt += memoriesText;
      } catch (error) {
        console.warn(`⚠️ Memória de NPC não disponível (tabela não criada ainda): ${error}`);
      }
    }

    let history = this.conversationHistory.get(historyKey) || [];
    
    if (history.length > 10) {
      history = history.slice(-6);
    }

    const messages: GeminiMessage[] = [
      { role: "user", parts: [{ text: npcPrompt }] },
      { role: "model", parts: [{ text: `Entendi. Sou ${npc.name}, e vou responder mantendo meu personagem.` }] },
      ...history,
      {
        role: "user",
        parts: [{
          text: sceneContext
            ? `[Contexto: ${sceneContext}]\n\nJogador: ${playerMessage}`
            : `Jogador: ${playerMessage}`,
        }],
      },
    ];

    let response: string;
    try {
      response = await geminiService.chat(messages, undefined, 300);
    } catch (error) {
      // Fallback response if AI fails
      console.warn(`⚠️ AI failed for ${npcType}, using fallback response`);
      const fallbacks: Record<string, string> = {
        bartender: "- Claro, parceiro! *serve uma bebida gelada* Aí está!",
        doctor: "Deixa comigo. *examina seus ferimentos com cuidado* Você vai ficar bem.",
        merchant: "Sem problema! *entrega o item com um sorriso* Aproveita aí!",
        sheriff: "Hm, certo. *observa com um olhar penetrante* Vamos conversar sobre isso.",
        outlaw: "Pode deixar comigo, parceiro. *faz um gesto misterioso* Entendi a mensagem.",
        gambler: "Ah, entendi! *sorri maliciosamente* Vamos colocar dinheiro em jogo!",
        cowgirl: "**Ajusta o chapéu** Tem razão, parceira. Deixa eu pensar nisso.",
      };
      response = fallbacks[npcType] || "- Entendi. *acena com a cabeça* Tá bem.";
    }

    history.push(
      { role: "user", parts: [{ text: playerMessage }] },
      { role: "model", parts: [{ text: response }] }
    );
    this.conversationHistory.set(historyKey, history);

    // Salvar memória se userId foi fornecido
    if (userId) {
      try {
        const { memory, importance } = rpNpcMemoryService.createMemoryFromInteraction(playerMessage, response);
        await rpNpcMemoryService.saveMemory(npcType, userId, channelId, memory, importance);
      } catch (error) {
        console.warn('⚠️ Memória de NPC não salva (tabela não criada ainda)');
      }
    }

    return { response: response.trim(), npcName: npc.name };
  }

  setActiveNPC(channelId: string, npcType: string): void {
    this.activeNPCs.set(channelId, npcType);
  }

  getActiveNPC(channelId: string): string | undefined {
    return this.activeNPCs.get(channelId);
  }

  removeActiveNPC(channelId: string): void {
    this.activeNPCs.delete(channelId);
    const keysToRemove = Array.from(this.conversationHistory.keys()).filter(
      (key) => key.startsWith(channelId)
    );
    keysToRemove.forEach((key) => this.conversationHistory.delete(key));
  }

  clearConversation(channelId: string, npcType: string): void {
    this.conversationHistory.delete(`${channelId}-${npcType}`);
  }

  getAvailableNPCs(): Array<{ id: string; name: string; role: string }> {
    return Object.entries(NPC_TEMPLATES).map(([id, npc]) => ({
      id,
      name: npc.name,
      role: npc.role,
    }));
  }

  createNarrationEmbed(narration: string, originalAction: string, authorName: string): EmbedBuilder {
    return new EmbedBuilder()
      .setColor(Colors.NARRATOR)
      .setTitle("📖 Narrador")
      .setDescription(`*${narration}*`)
      .addFields({
        name: "🎬 Ação Original",
        value: `**${originalAction}**`,
        inline: false,
      })
      .setFooter({ text: `Ação de ${authorName}` })
      .setTimestamp();
  }

  createSuggestionEmbed(suggestions: string, situation: string): EmbedBuilder {
    return new EmbedBuilder()
      .setColor(Colors.ASSISTANT)
      .setTitle("🤠 Assistente de RP")
      .setDescription(suggestions)
      .addFields({
        name: "📍 Situação",
        value: situation.length > 100 ? situation.substring(0, 100) + "..." : situation,
        inline: false,
      })
      .setFooter({ text: "Escolha uma sugestão ou crie a sua!" })
      .setTimestamp();
  }

  createNPCEmbed(npcName: string, response: string, npcType: string): EmbedBuilder {
    const npc = NPC_TEMPLATES[npcType] || NPC_TEMPLATES.bartender;
    
    return new EmbedBuilder()
      .setColor(Colors.NPC)
      .setAuthor({ name: npc.name })
      .setTitle(`🎭 ${npc.role}`)
      .setDescription(response)
      .setFooter({ text: `NPC: ${npcType}` })
      .setTimestamp();
  }
}

export const rpAIService = new RPAIService();
