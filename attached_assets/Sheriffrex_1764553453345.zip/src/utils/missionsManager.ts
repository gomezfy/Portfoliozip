import fs from "fs";
import path from "path";
import { getDataPath, readData, writeData } from "./database";

const dataDir = getDataPath("data");

export interface Mission {
  id: string;
  type: "daily" | "weekly";
  name: string;
  description: string;
  objective: MissionObjective;
  reward: MissionReward;
  emoji: string;
}

export interface MissionObjective {
  action: "mine" | "hunt" | "fish" | "daily" | "duel" | "give" | "spend" | "earn" | "capture" | "farm" | "crime" | "guild" | "dice" | "bankrob" | "sell" | "profile" | "leaderboard" | "territory";
  target: number;
  current?: number;
}

export interface MissionReward {
  silver?: number;
  tokens?: number;
  xp?: number;
  seals?: number;
  items?: { id: string; amount: number }[];
}

export interface UserMissions {
  daily: UserMissionProgress[];
  weekly: UserMissionProgress[];
  lastDailyReset: number;
  lastWeeklyReset: number;
  completedTotal: number;
  currentStreak: number;
}

export interface UserMissionProgress {
  missionId: string;
  progress: number;
  completed: boolean;
  claimed: boolean;
}

const DAILY_MISSIONS: Mission[] = [
  {
    id: "daily_mine_1",
    type: "daily",
    name: "Minerador Dedicado",
    description: "Complete 1 sessão de mineração",
    objective: { action: "mine", target: 1 },
    reward: { silver: 300, xp: 50 },
    emoji: "⛏️"
  },
  {
    id: "daily_hunt_1",
    type: "daily",
    name: "Caçador do Oeste",
    description: "Cace 2 animais",
    objective: { action: "hunt", target: 2 },
    reward: { silver: 250, xp: 40 },
    emoji: "🦌"
  },
  {
    id: "daily_fish_1",
    type: "daily",
    name: "Pescador Paciente",
    description: "Pesque 3 peixes",
    objective: { action: "fish", target: 3 },
    reward: { silver: 200, xp: 35 },
    emoji: "🎣"
  },
  {
    id: "daily_claim",
    type: "daily",
    name: "Cidadão Exemplar",
    description: "Colete sua recompensa diária",
    objective: { action: "daily", target: 1 },
    reward: { tokens: 3, xp: 25 },
    emoji: "📅"
  },
  {
    id: "daily_duel_1",
    type: "daily",
    name: "Pistoleiro",
    description: "Participe de 1 duelo",
    objective: { action: "duel", target: 1 },
    reward: { silver: 400, xp: 60 },
    emoji: "🔫"
  },
  {
    id: "daily_give_1",
    type: "daily",
    name: "Generoso",
    description: "Doe itens ou moedas para outro jogador",
    objective: { action: "give", target: 1 },
    reward: { tokens: 2, xp: 30 },
    emoji: "🤝"
  },
  {
    id: "daily_earn_500",
    type: "daily",
    name: "Empreendedor",
    description: "Ganhe 500 silver de qualquer forma",
    objective: { action: "earn", target: 500 },
    reward: { silver: 150, tokens: 1, xp: 45 },
    emoji: "💰"
  },
  {
    id: "daily_spend_200",
    type: "daily",
    name: "Consumidor",
    description: "Gaste 200 silver em lojas ou apostas",
    objective: { action: "spend", target: 200 },
    reward: { tokens: 2, xp: 35 },
    emoji: "🛒"
  },
  {
    id: "daily_farm_1",
    type: "daily",
    name: "Fazendeiro",
    description: "Cuide da sua fazenda 1 vez",
    objective: { action: "farm", target: 1 },
    reward: { silver: 200, xp: 30 },
    emoji: "🌾"
  },
  {
    id: "daily_crime_1",
    type: "daily",
    name: "Fora da Lei",
    description: "Cometa 1 crime",
    objective: { action: "crime", target: 1 },
    reward: { silver: 350, xp: 45 },
    emoji: "🦹"
  },
  {
    id: "daily_dice_2",
    type: "daily",
    name: "Apostador",
    description: "Jogue dados 2 vezes",
    objective: { action: "dice", target: 2 },
    reward: { silver: 300, xp: 40 },
    emoji: "🎲"
  },
  {
    id: "daily_sell_3",
    type: "daily",
    name: "Comerciante",
    description: "Venda 3 itens",
    objective: { action: "sell", target: 3 },
    reward: { silver: 250, tokens: 1, xp: 35 },
    emoji: "💵"
  },
  {
    id: "daily_profile_1",
    type: "daily",
    name: "Narcisista",
    description: "Veja seu perfil",
    objective: { action: "profile", target: 1 },
    reward: { xp: 20 },
    emoji: "🤳"
  },
  {
    id: "daily_territory_1",
    type: "daily",
    name: "Dono de Terras",
    description: "Verifique seus territórios",
    objective: { action: "territory", target: 1 },
    reward: { silver: 100, xp: 25 },
    emoji: "🏜️"
  }
];

const WEEKLY_MISSIONS: Mission[] = [
  {
    id: "weekly_mine_5",
    type: "weekly",
    name: "Mestre Minerador",
    description: "Complete 5 sessões de mineração",
    objective: { action: "mine", target: 5 },
    reward: { silver: 2000, tokens: 10, xp: 300, seals: 5 },
    emoji: "⛏️"
  },
  {
    id: "weekly_hunt_15",
    type: "weekly",
    name: "Lenda da Caça",
    description: "Cace 15 animais",
    objective: { action: "hunt", target: 15 },
    reward: { silver: 1800, tokens: 8, xp: 250 },
    emoji: "🏹"
  },
  {
    id: "weekly_duel_5",
    type: "weekly",
    name: "Campeão de Duelos",
    description: "Participe de 5 duelos",
    objective: { action: "duel", target: 5 },
    reward: { silver: 1500, tokens: 12, xp: 350 },
    emoji: "⚔️"
  },
  {
    id: "weekly_capture_2",
    type: "weekly",
    name: "Caçador de Recompensas",
    description: "Capture 2 procurados",
    objective: { action: "capture", target: 2 },
    reward: { silver: 3000, tokens: 20, xp: 500 },
    emoji: "🎯"
  },
  {
    id: "weekly_earn_5000",
    type: "weekly",
    name: "Magnata do Oeste",
    description: "Ganhe 5000 silver total",
    objective: { action: "earn", target: 5000 },
    reward: { silver: 1000, tokens: 15, xp: 400 },
    emoji: "🤑"
  },
  {
    id: "weekly_farm_7",
    type: "weekly",
    name: "Fazendeiro Mestre",
    description: "Cuide da fazenda 7 vezes",
    objective: { action: "farm", target: 7 },
    reward: { silver: 1500, tokens: 10, xp: 300 },
    emoji: "🌻"
  },
  {
    id: "weekly_crime_5",
    type: "weekly",
    name: "Bandido Notório",
    description: "Cometa 5 crimes",
    objective: { action: "crime", target: 5 },
    reward: { silver: 2500, tokens: 15, xp: 400 },
    emoji: "🤠"
  },
  {
    id: "weekly_bankrob_2",
    type: "weekly",
    name: "Assaltante de Bancos",
    description: "Assalte o banco 2 vezes",
    objective: { action: "bankrob", target: 2 },
    reward: { silver: 3500, tokens: 25, xp: 500, seals: 8 },
    emoji: "🏦"
  },
  {
    id: "weekly_fish_20",
    type: "weekly",
    name: "Pescador Lendário",
    description: "Pesque 20 peixes",
    objective: { action: "fish", target: 20 },
    reward: { silver: 1600, tokens: 8, xp: 280 },
    emoji: "🐟"
  },
  {
    id: "weekly_dice_10",
    type: "weekly",
    name: "Viciado em Apostas",
    description: "Jogue dados 10 vezes",
    objective: { action: "dice", target: 10 },
    reward: { silver: 2000, tokens: 12, xp: 350 },
    emoji: "🎰"
  },
  {
    id: "weekly_sell_15",
    type: "weekly",
    name: "Mercador do Oeste",
    description: "Venda 15 itens",
    objective: { action: "sell", target: 15 },
    reward: { silver: 1200, tokens: 10, xp: 300 },
    emoji: "🏪"
  },
  {
    id: "weekly_guild_3",
    type: "weekly",
    name: "Membro Ativo",
    description: "Interaja com sua guilda 3 vezes",
    objective: { action: "guild", target: 3 },
    reward: { silver: 1000, tokens: 8, xp: 250, seals: 3 },
    emoji: "🛡️"
  }
];

function getMissionsData(): Record<string, UserMissions> {
  return readData("missions.json") || {};
}

function saveMissionsData(data: Record<string, UserMissions>): void {
  writeData("missions.json", data);
}

function getRandomMissions(pool: Mission[], count: number): Mission[] {
  const shuffled = [...pool].sort(() => Math.random() - 0.5);
  return shuffled.slice(0, count);
}

function shouldResetDaily(lastReset: number): boolean {
  const now = new Date();
  const lastResetDate = new Date(lastReset);
  return now.getUTCDate() !== lastResetDate.getUTCDate() || 
         now.getUTCMonth() !== lastResetDate.getUTCMonth() ||
         now.getUTCFullYear() !== lastResetDate.getUTCFullYear();
}

function shouldResetWeekly(lastReset: number): boolean {
  const now = new Date();
  const lastResetDate = new Date(lastReset);
  const daysSinceReset = Math.floor((now.getTime() - lastResetDate.getTime()) / (1000 * 60 * 60 * 24));
  return daysSinceReset >= 7 || (now.getUTCDay() === 0 && lastResetDate.getUTCDay() !== 0);
}

export function getUserMissions(userId: string): UserMissions {
  const data = getMissionsData();
  const now = Date.now();
  
  if (!data[userId]) {
    const dailyMissions = getRandomMissions(DAILY_MISSIONS, 3);
    const weeklyMissions = getRandomMissions(WEEKLY_MISSIONS, 2);
    
    data[userId] = {
      daily: dailyMissions.map(m => ({ missionId: m.id, progress: 0, completed: false, claimed: false })),
      weekly: weeklyMissions.map(m => ({ missionId: m.id, progress: 0, completed: false, claimed: false })),
      lastDailyReset: now,
      lastWeeklyReset: now,
      completedTotal: 0,
      currentStreak: 0
    };
    saveMissionsData(data);
  }
  
  let updated = false;
  
  if (shouldResetDaily(data[userId].lastDailyReset)) {
    const allCompleted = data[userId].daily.every(m => m.completed);
    if (allCompleted) {
      data[userId].currentStreak++;
    } else {
      data[userId].currentStreak = 0;
    }
    
    const dailyMissions = getRandomMissions(DAILY_MISSIONS, 3);
    data[userId].daily = dailyMissions.map(m => ({ missionId: m.id, progress: 0, completed: false, claimed: false }));
    data[userId].lastDailyReset = now;
    updated = true;
  }
  
  if (shouldResetWeekly(data[userId].lastWeeklyReset)) {
    const weeklyMissions = getRandomMissions(WEEKLY_MISSIONS, 2);
    data[userId].weekly = weeklyMissions.map(m => ({ missionId: m.id, progress: 0, completed: false, claimed: false }));
    data[userId].lastWeeklyReset = now;
    updated = true;
  }
  
  if (updated) {
    saveMissionsData(data);
  }
  
  return data[userId];
}

export function getMissionById(missionId: string): Mission | undefined {
  return [...DAILY_MISSIONS, ...WEEKLY_MISSIONS].find(m => m.id === missionId);
}

export function updateMissionProgress(userId: string, action: MissionObjective["action"], amount: number = 1): { completed: Mission[]; updated: boolean } {
  const data = getMissionsData();
  const userMissions = getUserMissions(userId);
  const completedMissions: Mission[] = [];
  let updated = false;
  
  const updateProgress = (missions: UserMissionProgress[], type: "daily" | "weekly") => {
    for (const progress of missions) {
      if (progress.completed) continue;
      
      const mission = getMissionById(progress.missionId);
      if (!mission || mission.objective.action !== action) continue;
      
      progress.progress = Math.min(progress.progress + amount, mission.objective.target);
      updated = true;
      
      if (progress.progress >= mission.objective.target && !progress.completed) {
        progress.completed = true;
        completedMissions.push(mission);
      }
    }
  };
  
  updateProgress(userMissions.daily, "daily");
  updateProgress(userMissions.weekly, "weekly");
  
  if (updated) {
    data[userId] = userMissions;
    saveMissionsData(data);
  }
  
  return { completed: completedMissions, updated };
}

export function claimMissionReward(userId: string, missionId: string): { success: boolean; reward?: MissionReward; error?: string } {
  const data = getMissionsData();
  const userMissions = getUserMissions(userId);
  
  const allMissions = [...userMissions.daily, ...userMissions.weekly];
  const missionProgress = allMissions.find(m => m.missionId === missionId);
  
  if (!missionProgress) {
    return { success: false, error: "Missão não encontrada" };
  }
  
  if (!missionProgress.completed) {
    return { success: false, error: "Missão ainda não foi completada" };
  }
  
  if (missionProgress.claimed) {
    return { success: false, error: "Recompensa já foi coletada" };
  }
  
  const mission = getMissionById(missionId);
  if (!mission) {
    return { success: false, error: "Missão inválida" };
  }
  
  missionProgress.claimed = true;
  userMissions.completedTotal++;
  
  data[userId] = userMissions;
  saveMissionsData(data);
  
  return { success: true, reward: mission.reward };
}

export function getTimeUntilDailyReset(): number {
  const now = new Date();
  const tomorrow = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate() + 1, 0, 0, 0));
  return tomorrow.getTime() - now.getTime();
}

export function getTimeUntilWeeklyReset(): number {
  const now = new Date();
  const daysUntilSunday = (7 - now.getUTCDay()) % 7 || 7;
  const nextSunday = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate() + daysUntilSunday, 0, 0, 0));
  return nextSunday.getTime() - now.getTime();
}

export function formatTimeRemaining(ms: number): string {
  const hours = Math.floor(ms / (1000 * 60 * 60));
  const minutes = Math.floor((ms % (1000 * 60 * 60)) / (1000 * 60));
  
  if (hours > 24) {
    const days = Math.floor(hours / 24);
    return `${days}d ${hours % 24}h`;
  }
  
  return `${hours}h ${minutes}m`;
}

export { DAILY_MISSIONS, WEEKLY_MISSIONS };
