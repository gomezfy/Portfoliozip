import { readData, writeData } from "./database";
import { addItem } from "./inventoryManager";
import crypto from "crypto";

export interface FarmResources {
  wheat: number;
  corn: number;
  carrot: number;
  tomato: number;
  cotton: number;
  milk: number;
  egg: number;
  wool: number;
  meat: number;
  leather: number;
}

export interface FarmData {
  id: string;
  userId: string;
  name: string;
  level: number;
  xp: number;
  storageLevel: number;
  storageCapacity: number;
  houseLevel: number;
  barnLevel: number;
  siloLevel: number;
  resources: FarmResources;
  lastHarvest: number | null;
  lastAnimalCollection: number | null;
  totalEarnings: number;
  hasManager: boolean;
  managerBonus: number;
  createdAt: number;
  updatedAt: number;
}

export interface FarmBuilding {
  id: string;
  farmId: string;
  type: string;
  name: string;
  level: number;
  isBuilding: boolean;
  buildStartTime: number | null;
  buildEndTime: number | null;
  productionRate: number;
  lastCollection: number | null;
  createdAt: number;
}

export interface FarmWorker {
  id: string;
  farmId: string;
  name: string;
  role: string;
  happiness: number;
  skill: number;
  salary: number;
  assignedTo: string | null;
  isOnStrike: boolean;
  hiredAt: number;
  lastPaid: number | null;
}

export interface FarmCrop {
  id: string;
  farmId: string;
  type: string;
  name: string;
  quantity: number;
  plantedAt: number;
  harvestTime: number;
  isReady: boolean;
  yieldAmount: number;
  yieldMultiplier: number;
}

export interface FarmAnimal {
  id: string;
  farmId: string;
  type: string;
  name: string;
  quantity: number;
  productionType: string;
  productionRate: number;
  lastCollection: number | null;
  health: number;
  happiness: number;
  purchasedAt: number;
}

export interface FarmFullData {
  farm: FarmData;
  buildings: FarmBuilding[];
  workers: FarmWorker[];
  crops: FarmCrop[];
  animals: FarmAnimal[];
}

export const CROP_TYPES = {
  wheat: { name: "Trigo", emoji: "🌾", growTime: 30 * 60 * 1000, yield: 10, sellPrice: 5, buyCost: 10 },
  corn: { name: "Milho", emoji: "🌽", growTime: 45 * 60 * 1000, yield: 8, sellPrice: 8, buyCost: 15 },
  carrot: { name: "Cenoura", emoji: "🥕", growTime: 20 * 60 * 1000, yield: 15, sellPrice: 3, buyCost: 8 },
  tomato: { name: "Tomate", emoji: "🍅", growTime: 60 * 60 * 1000, yield: 12, sellPrice: 10, buyCost: 20 },
  cotton: { name: "Algodão", emoji: "🧶", growTime: 90 * 60 * 1000, yield: 5, sellPrice: 25, buyCost: 40 },
};

export const ANIMAL_TYPES = {
  chicken: { name: "Galinha", emoji: "🐔", productionType: "egg", productionTime: 30 * 60 * 1000, yield: 3, sellPrice: 4, buyCost: 100 },
  cow: { name: "Vaca", emoji: "🐄", productionType: "milk", productionTime: 60 * 60 * 1000, yield: 2, sellPrice: 15, buyCost: 500 },
  sheep: { name: "Ovelha", emoji: "🐑", productionType: "wool", productionTime: 120 * 60 * 1000, yield: 1, sellPrice: 30, buyCost: 300 },
  pig: { name: "Porco", emoji: "🐷", productionType: "meat", productionTime: 180 * 60 * 1000, yield: 1, sellPrice: 50, buyCost: 400 },
  horse: { name: "Cavalo", emoji: "🐴", productionType: "leather", productionTime: 240 * 60 * 1000, yield: 1, sellPrice: 80, buyCost: 1000 },
};

export const BUILDING_TYPES = {
  barn: { name: "Celeiro", emoji: "🏚️", baseUpgradeCost: 500, upgradeTimeBase: 10 * 60 * 1000 },
  silo: { name: "Silo", emoji: "🏗️", baseUpgradeCost: 750, upgradeTimeBase: 15 * 60 * 1000 },
  house: { name: "Casa Principal", emoji: "🏠", baseUpgradeCost: 1000, upgradeTimeBase: 20 * 60 * 1000 },
  storage: { name: "Armazém", emoji: "📦", baseUpgradeCost: 600, upgradeTimeBase: 12 * 60 * 1000 },
  well: { name: "Poço", emoji: "🪣", baseUpgradeCost: 300, upgradeTimeBase: 5 * 60 * 1000 },
  windmill: { name: "Moinho", emoji: "🌬️", baseUpgradeCost: 1500, upgradeTimeBase: 30 * 60 * 1000 },
};

export const WORKER_NAMES = [
  "Velho Joe", "Maria das Vacas", "Zé Peão", "Joana Roça",
  "Pedro Martelo", "Ana Terra", "João Cercado", "Rita Colheita",
  "Tonho Boi", "Luiza Campo", "Manoel Arado", "Rosa Pomar",
  "Chico Galinha", "Tereza Leite", "Antônio Cerca", "Benedita Horta",
];

export const WORKER_ROLES = {
  farmhand: { name: "Peão", emoji: "👨‍🌾", baseSalary: 50, skillBonus: 0.1 },
  harvester: { name: "Colhedor", emoji: "🧑‍🌾", baseSalary: 75, skillBonus: 0.15 },
  animalKeeper: { name: "Tratador", emoji: "🐄", baseSalary: 100, skillBonus: 0.2 },
  manager: { name: "Gerente", emoji: "👔", baseSalary: 200, skillBonus: 0.5 },
};

const FARM_DATA_FILE = "farms.json";

function generateId(): string {
  return crypto.randomBytes(8).toString("hex");
}

function getFarmDataFile(): Record<string, FarmFullData> {
  return readData(FARM_DATA_FILE) || {};
}

function saveFarmDataFile(data: Record<string, FarmFullData>): void {
  writeData(FARM_DATA_FILE, data);
}

export function getFarm(userId: string): FarmFullData | null {
  const data = getFarmDataFile();
  return data[userId] || null;
}

export function createFarm(userId: string, name: string = "Rancho Sem Nome"): FarmFullData {
  const data = getFarmDataFile();
  
  if (data[userId]) {
    return data[userId];
  }
  
  const now = Date.now();
  const farmId = generateId();
  
  const newFarm: FarmFullData = {
    farm: {
      id: farmId,
      userId,
      name,
      level: 1,
      xp: 0,
      storageLevel: 1,
      storageCapacity: 100,
      houseLevel: 1,
      barnLevel: 1,
      siloLevel: 1,
      resources: {
        wheat: 0,
        corn: 0,
        carrot: 0,
        tomato: 0,
        cotton: 0,
        milk: 0,
        egg: 0,
        wool: 0,
        meat: 0,
        leather: 0,
      },
      lastHarvest: null,
      lastAnimalCollection: null,
      totalEarnings: 0,
      hasManager: false,
      managerBonus: 1.0,
      createdAt: now,
      updatedAt: now,
    },
    buildings: [],
    workers: [],
    crops: [],
    animals: [],
  };
  
  data[userId] = newFarm;
  saveFarmDataFile(data);
  
  return newFarm;
}

export function updateFarm(userId: string, updates: Partial<FarmData>): FarmFullData | null {
  const data = getFarmDataFile();
  const farmData = data[userId];
  
  if (!farmData) return null;
  
  farmData.farm = {
    ...farmData.farm,
    ...updates,
    updatedAt: Date.now(),
  };
  
  data[userId] = farmData;
  saveFarmDataFile(data);
  
  return farmData;
}

export function getStorageCapacity(storageLevel: number): number {
  return 100 + (storageLevel - 1) * 50;
}

export function getTotalResources(resources: FarmResources): number {
  return Object.values(resources).reduce((sum, val) => sum + val, 0);
}

export function canStoreResources(farm: FarmData, amount: number): boolean {
  const currentTotal = getTotalResources(farm.resources);
  return currentTotal + amount <= farm.storageCapacity;
}

export function addResource(userId: string, resourceType: keyof FarmResources, amount: number): { success: boolean; error?: string } {
  const farmData = getFarm(userId);
  if (!farmData) return { success: false, error: "Fazenda não encontrada" };
  
  if (!canStoreResources(farmData.farm, amount)) {
    return { success: false, error: "Armazém cheio! Melhore seu armazém ou venda recursos." };
  }
  
  farmData.farm.resources[resourceType] += amount;
  updateFarm(userId, { resources: farmData.farm.resources });
  
  return { success: true };
}

export function removeResource(userId: string, resourceType: keyof FarmResources, amount: number): { success: boolean; error?: string } {
  const farmData = getFarm(userId);
  if (!farmData) return { success: false, error: "Fazenda não encontrada" };
  
  if (farmData.farm.resources[resourceType] < amount) {
    return { success: false, error: "Recursos insuficientes" };
  }
  
  farmData.farm.resources[resourceType] -= amount;
  updateFarm(userId, { resources: farmData.farm.resources });
  
  return { success: true };
}

export function plantCrop(userId: string, cropType: keyof typeof CROP_TYPES, quantity: number = 1): { success: boolean; crop?: FarmCrop; error?: string } {
  const farmData = getFarm(userId);
  if (!farmData) return { success: false, error: "Fazenda não encontrada" };
  
  const cropInfo = CROP_TYPES[cropType];
  if (!cropInfo) return { success: false, error: "Tipo de plantação inválido" };
  
  const now = Date.now();
  const workerBonus = getWorkerProductionBonus(farmData.workers, "harvester");
  
  const newCrop: FarmCrop = {
    id: generateId(),
    farmId: farmData.farm.id,
    type: cropType,
    name: cropInfo.name,
    quantity,
    plantedAt: now,
    harvestTime: now + cropInfo.growTime,
    isReady: false,
    yieldAmount: cropInfo.yield * quantity,
    yieldMultiplier: 1.0 + workerBonus,
  };
  
  const data = getFarmDataFile();
  data[userId].crops.push(newCrop);
  saveFarmDataFile(data);
  
  return { success: true, crop: newCrop };
}

export function harvestCrop(userId: string, cropId: string): { success: boolean; harvested?: number; resourceType?: string; error?: string } {
  const data = getFarmDataFile();
  const farmData = data[userId];
  if (!farmData) return { success: false, error: "Fazenda não encontrada" };
  
  const cropIndex = farmData.crops.findIndex(c => c.id === cropId);
  if (cropIndex === -1) return { success: false, error: "Plantação não encontrada" };
  
  const crop = farmData.crops[cropIndex];
  const now = Date.now();
  
  if (now < crop.harvestTime) {
    return { success: false, error: "Plantação ainda não está pronta para colheita" };
  }
  
  const harvestedAmount = Math.floor(crop.yieldAmount * crop.yieldMultiplier);
  const resourceType = crop.type as keyof FarmResources;
  
  if (!canStoreResources(farmData.farm, harvestedAmount)) {
    return { success: false, error: "Armazém cheio! Venda recursos primeiro." };
  }
  
  farmData.farm.resources[resourceType] += harvestedAmount;
  farmData.farm.lastHarvest = now;
  farmData.farm.xp += harvestedAmount * 2;
  
  farmData.crops.splice(cropIndex, 1);
  
  checkLevelUp(farmData.farm);
  
  data[userId] = farmData;
  saveFarmDataFile(data);
  
  return { success: true, harvested: harvestedAmount, resourceType: crop.name };
}

export function harvestAllReady(userId: string): { success: boolean; results: Array<{ name: string; amount: number }>; error?: string } {
  const data = getFarmDataFile();
  const farmData = data[userId];
  if (!farmData) return { success: false, results: [], error: "Fazenda não encontrada" };
  
  const now = Date.now();
  const readyCrops = farmData.crops.filter(c => now >= c.harvestTime);
  
  if (readyCrops.length === 0) {
    return { success: false, results: [], error: "Nenhuma plantação pronta para colheita" };
  }
  
  const results: Array<{ name: string; amount: number }> = [];
  let totalHarvested = 0;
  
  for (const crop of readyCrops) {
    const harvestedAmount = Math.floor(crop.yieldAmount * crop.yieldMultiplier);
    
    if (!canStoreResources(farmData.farm, totalHarvested + harvestedAmount)) {
      break;
    }
    
    const resourceType = crop.type as keyof FarmResources;
    farmData.farm.resources[resourceType] += harvestedAmount;
    addItem(userId, resourceType, harvestedAmount);
    totalHarvested += harvestedAmount;
    
    results.push({ name: crop.name, amount: harvestedAmount });
    
    const cropIndex = farmData.crops.findIndex(c => c.id === crop.id);
    if (cropIndex !== -1) {
      farmData.crops.splice(cropIndex, 1);
    }
  }
  
  farmData.farm.lastHarvest = now;
  farmData.farm.xp += totalHarvested * 2;
  
  checkLevelUp(farmData.farm);
  
  data[userId] = farmData;
  saveFarmDataFile(data);
  
  return { success: true, results };
}

export function buyAnimal(userId: string, animalType: keyof typeof ANIMAL_TYPES, quantity: number = 1): { success: boolean; animal?: FarmAnimal; cost?: number; error?: string } {
  const farmData = getFarm(userId);
  if (!farmData) return { success: false, error: "Fazenda não encontrada" };
  
  const animalInfo = ANIMAL_TYPES[animalType];
  if (!animalInfo) return { success: false, error: "Tipo de animal inválido" };
  
  const maxAnimals = farmData.farm.barnLevel * 5;
  const currentAnimals = farmData.animals.reduce((sum, a) => sum + a.quantity, 0);
  
  if (currentAnimals + quantity > maxAnimals) {
    return { success: false, error: `Celeiro cheio! Máximo: ${maxAnimals} animais. Melhore seu celeiro.` };
  }
  
  const totalCost = animalInfo.buyCost * quantity;
  
  const now = Date.now();
  const newAnimal: FarmAnimal = {
    id: generateId(),
    farmId: farmData.farm.id,
    type: animalType,
    name: animalInfo.name,
    quantity,
    productionType: animalInfo.productionType,
    productionRate: 1.0,
    lastCollection: now,
    health: 100,
    happiness: 100,
    purchasedAt: now,
  };
  
  const data = getFarmDataFile();
  
  const existingAnimal = data[userId].animals.find(a => a.type === animalType);
  if (existingAnimal) {
    existingAnimal.quantity += quantity;
  } else {
    data[userId].animals.push(newAnimal);
  }
  
  saveFarmDataFile(data);
  
  return { success: true, animal: newAnimal, cost: totalCost };
}

export function collectAnimalProducts(userId: string): { success: boolean; collected: Array<{ name: string; product: string; amount: number }>; error?: string } {
  const data = getFarmDataFile();
  const farmData = data[userId];
  if (!farmData) return { success: false, collected: [], error: "Fazenda não encontrada" };
  
  if (farmData.animals.length === 0) {
    return { success: false, collected: [], error: "Você não tem animais" };
  }
  
  const now = Date.now();
  const collected: Array<{ name: string; product: string; amount: number }> = [];
  const workerBonus = getWorkerProductionBonus(farmData.workers, "animalKeeper");
  
  for (const animal of farmData.animals) {
    const animalInfo = ANIMAL_TYPES[animal.type as keyof typeof ANIMAL_TYPES];
    if (!animalInfo) continue;
    
    const timeSinceLastCollection = now - (animal.lastCollection || 0);
    const productionCycles = Math.floor(timeSinceLastCollection / animalInfo.productionTime);
    
    if (productionCycles > 0) {
      const happinessMultiplier = animal.happiness >= 80 ? 1.2 : animal.happiness >= 50 ? 1.0 : 0.5;
      const amount = Math.floor(productionCycles * animalInfo.yield * animal.quantity * happinessMultiplier * (1 + workerBonus));
      
      if (amount > 0) {
        const productType = animalInfo.productionType as keyof FarmResources;
        
        if (canStoreResources(farmData.farm, amount)) {
          farmData.farm.resources[productType] += amount;
          animal.lastCollection = now;
          
          collected.push({
            name: animalInfo.name,
            product: getProductName(productType),
            amount,
          });
        }
      }
    }
  }
  
  if (collected.length === 0) {
    return { success: false, collected: [], error: "Nenhum produto disponível para coleta ainda" };
  }
  
  farmData.farm.lastAnimalCollection = now;
  farmData.farm.xp += collected.reduce((sum, c) => sum + c.amount, 0) * 3;
  
  checkLevelUp(farmData.farm);
  
  data[userId] = farmData;
  saveFarmDataFile(data);
  
  return { success: true, collected };
}

function getProductName(productType: keyof FarmResources): string {
  const names: Record<keyof FarmResources, string> = {
    wheat: "Trigo",
    corn: "Milho",
    carrot: "Cenoura",
    tomato: "Tomate",
    cotton: "Algodão",
    milk: "Leite",
    egg: "Ovos",
    wool: "Lã",
    meat: "Carne",
    leather: "Couro",
  };
  return names[productType] || productType;
}

export function hireWorker(userId: string, role: keyof typeof WORKER_ROLES): { success: boolean; worker?: FarmWorker; cost?: number; error?: string } {
  const farmData = getFarm(userId);
  if (!farmData) return { success: false, error: "Fazenda não encontrada" };
  
  const roleInfo = WORKER_ROLES[role];
  if (!roleInfo) return { success: false, error: "Cargo inválido" };
  
  const maxWorkers = farmData.farm.houseLevel * 2;
  if (farmData.workers.length >= maxWorkers) {
    return { success: false, error: `Casa cheia! Máximo: ${maxWorkers} funcionários. Melhore sua casa.` };
  }
  
  const hireCost = roleInfo.baseSalary * 5;
  
  const randomName = WORKER_NAMES[Math.floor(Math.random() * WORKER_NAMES.length)];
  
  const newWorker: FarmWorker = {
    id: generateId(),
    farmId: farmData.farm.id,
    name: randomName,
    role,
    happiness: 100,
    skill: 1.0 + Math.random() * 0.3,
    salary: roleInfo.baseSalary,
    assignedTo: null,
    isOnStrike: false,
    hiredAt: Date.now(),
    lastPaid: Date.now(),
  };
  
  const data = getFarmDataFile();
  data[userId].workers.push(newWorker);
  
  if (role === "manager" && !farmData.farm.hasManager) {
    data[userId].farm.hasManager = true;
    data[userId].farm.managerBonus = 1.0 + roleInfo.skillBonus;
  }
  
  saveFarmDataFile(data);
  
  return { success: true, worker: newWorker, cost: hireCost };
}

export function fireWorker(userId: string, workerId: string): { success: boolean; error?: string } {
  const data = getFarmDataFile();
  const farmData = data[userId];
  if (!farmData) return { success: false, error: "Fazenda não encontrada" };
  
  const workerIndex = farmData.workers.findIndex(w => w.id === workerId);
  if (workerIndex === -1) return { success: false, error: "Funcionário não encontrado" };
  
  const worker = farmData.workers[workerIndex];
  
  if (worker.role === "manager") {
    farmData.farm.hasManager = false;
    farmData.farm.managerBonus = 1.0;
  }
  
  farmData.workers.splice(workerIndex, 1);
  
  data[userId] = farmData;
  saveFarmDataFile(data);
  
  return { success: true };
}

export function payWorkers(userId: string): { success: boolean; totalPaid?: number; error?: string } {
  const data = getFarmDataFile();
  const farmData = data[userId];
  if (!farmData) return { success: false, error: "Fazenda não encontrada" };
  
  if (farmData.workers.length === 0) {
    return { success: false, error: "Você não tem funcionários" };
  }
  
  const now = Date.now();
  let totalPaid = 0;
  
  for (const worker of farmData.workers) {
    worker.lastPaid = now;
    worker.happiness = Math.min(100, worker.happiness + 20);
    worker.isOnStrike = false;
    totalPaid += worker.salary;
  }
  
  data[userId] = farmData;
  saveFarmDataFile(data);
  
  return { success: true, totalPaid };
}

export function giveWorkerBonus(userId: string, workerId: string, bonusType: "drink" | "rest"): { success: boolean; cost?: number; error?: string } {
  const data = getFarmDataFile();
  const farmData = data[userId];
  if (!farmData) return { success: false, error: "Fazenda não encontrada" };
  
  const worker = farmData.workers.find(w => w.id === workerId);
  if (!worker) return { success: false, error: "Funcionário não encontrado" };
  
  let cost = 0;
  let happinessGain = 0;
  
  if (bonusType === "drink") {
    cost = 50;
    happinessGain = 30;
  } else if (bonusType === "rest") {
    cost = 0;
    happinessGain = 15;
  }
  
  worker.happiness = Math.min(100, worker.happiness + happinessGain);
  worker.isOnStrike = false;
  
  data[userId] = farmData;
  saveFarmDataFile(data);
  
  return { success: true, cost };
}

function getWorkerProductionBonus(workers: FarmWorker[], roleType: string): number {
  const relevantWorkers = workers.filter(w => w.role === roleType && !w.isOnStrike && w.happiness > 30);
  if (relevantWorkers.length === 0) return 0;
  
  const avgSkill = relevantWorkers.reduce((sum, w) => sum + w.skill, 0) / relevantWorkers.length;
  const happinessMultiplier = relevantWorkers.reduce((sum, w) => sum + (w.happiness / 100), 0) / relevantWorkers.length;
  
  return avgSkill * happinessMultiplier * 0.2;
}

export function startUpgrade(userId: string, buildingType: keyof typeof BUILDING_TYPES): { success: boolean; building?: FarmBuilding; cost?: number; finishTime?: number; error?: string } {
  const data = getFarmDataFile();
  const farmData = data[userId];
  if (!farmData) return { success: false, error: "Fazenda não encontrada" };
  
  const buildingInfo = BUILDING_TYPES[buildingType];
  if (!buildingInfo) return { success: false, error: "Tipo de construção inválido" };
  
  const activeBuildings = farmData.buildings.filter(b => b.isBuilding);
  if (activeBuildings.length > 0) {
    return { success: false, error: "Já existe uma construção em andamento! Aguarde terminar." };
  }
  
  let currentLevel = 1;
  if (buildingType === "barn") currentLevel = farmData.farm.barnLevel;
  else if (buildingType === "silo") currentLevel = farmData.farm.siloLevel;
  else if (buildingType === "house") currentLevel = farmData.farm.houseLevel;
  else if (buildingType === "storage") currentLevel = farmData.farm.storageLevel;
  
  const upgradeCost = buildingInfo.baseUpgradeCost * currentLevel;
  const upgradeTime = buildingInfo.upgradeTimeBase * currentLevel;
  
  const workerSpeedBonus = farmData.workers.filter(w => !w.isOnStrike && w.happiness > 50).length * 0.05;
  const adjustedTime = upgradeTime * (1 - Math.min(workerSpeedBonus, 0.3));
  
  const now = Date.now();
  const finishTime = now + adjustedTime;
  
  const existingBuilding = farmData.buildings.find(b => b.type === buildingType);
  
  if (existingBuilding) {
    existingBuilding.isBuilding = true;
    existingBuilding.buildStartTime = now;
    existingBuilding.buildEndTime = finishTime;
  } else {
    const newBuilding: FarmBuilding = {
      id: generateId(),
      farmId: farmData.farm.id,
      type: buildingType,
      name: buildingInfo.name,
      level: currentLevel,
      isBuilding: true,
      buildStartTime: now,
      buildEndTime: finishTime,
      productionRate: 1.0,
      lastCollection: null,
      createdAt: now,
    };
    farmData.buildings.push(newBuilding);
  }
  
  data[userId] = farmData;
  saveFarmDataFile(data);
  
  return { 
    success: true, 
    building: farmData.buildings.find(b => b.type === buildingType),
    cost: upgradeCost, 
    finishTime 
  };
}

export function checkAndCompleteUpgrades(userId: string): { completed: string[] } {
  const data = getFarmDataFile();
  const farmData = data[userId];
  if (!farmData) return { completed: [] };
  
  const now = Date.now();
  const completed: string[] = [];
  
  for (const building of farmData.buildings) {
    if (building.isBuilding && building.buildEndTime && now >= building.buildEndTime) {
      building.isBuilding = false;
      building.level += 1;
      building.buildStartTime = null;
      building.buildEndTime = null;
      
      if (building.type === "barn") {
        farmData.farm.barnLevel = building.level;
      } else if (building.type === "silo") {
        farmData.farm.siloLevel = building.level;
      } else if (building.type === "house") {
        farmData.farm.houseLevel = building.level;
      } else if (building.type === "storage") {
        farmData.farm.storageLevel = building.level;
        farmData.farm.storageCapacity = getStorageCapacity(building.level);
      }
      
      farmData.farm.xp += building.level * 50;
      completed.push(building.name);
    }
  }
  
  if (completed.length > 0) {
    checkLevelUp(farmData.farm);
    data[userId] = farmData;
    saveFarmDataFile(data);
  }
  
  return { completed };
}

function checkLevelUp(farm: FarmData): boolean {
  const xpNeeded = farm.level * 500;
  if (farm.xp >= xpNeeded) {
    farm.level += 1;
    farm.xp -= xpNeeded;
    return true;
  }
  return false;
}

export function sellResources(userId: string, resourceType: keyof FarmResources, quantity: number): { success: boolean; earnings?: number; error?: string } {
  const data = getFarmDataFile();
  const farmData = data[userId];
  if (!farmData) return { success: false, error: "Fazenda não encontrada" };
  
  if (farmData.farm.resources[resourceType] < quantity) {
    return { success: false, error: "Recursos insuficientes" };
  }
  
  let pricePerUnit = 5;
  
  if (resourceType in CROP_TYPES) {
    pricePerUnit = CROP_TYPES[resourceType as keyof typeof CROP_TYPES].sellPrice;
  } else {
    const animalProduct = Object.values(ANIMAL_TYPES).find(a => a.productionType === resourceType);
    if (animalProduct) {
      pricePerUnit = animalProduct.sellPrice;
    }
  }
  
  const managerBonus = farmData.farm.hasManager ? farmData.farm.managerBonus : 1.0;
  const earnings = Math.floor(quantity * pricePerUnit * managerBonus);
  
  farmData.farm.resources[resourceType] -= quantity;
  farmData.farm.totalEarnings += earnings;
  farmData.farm.xp += Math.floor(earnings / 10);
  
  addItem(userId, "silver", earnings);
  
  checkLevelUp(farmData.farm);
  
  data[userId] = farmData;
  saveFarmDataFile(data);
  
  return { success: true, earnings };
}

export function decayWorkerHappiness(): void {
  const data = getFarmDataFile();
  
  for (const userId in data) {
    const farmData = data[userId];
    let hasChanges = false;
    
    for (const worker of farmData.workers) {
      if (worker.happiness > 0) {
        worker.happiness = Math.max(0, worker.happiness - 2);
        hasChanges = true;
        
        if (worker.happiness < 20 && !worker.isOnStrike) {
          worker.isOnStrike = true;
        }
      }
    }
    
    if (hasChanges) {
      data[userId] = farmData;
    }
  }
  
  saveFarmDataFile(data);
}

export function getUpgradeCost(buildingType: keyof typeof BUILDING_TYPES, currentLevel: number): number {
  const buildingInfo = BUILDING_TYPES[buildingType];
  return buildingInfo.baseUpgradeCost * currentLevel;
}

export function getUpgradeTime(buildingType: keyof typeof BUILDING_TYPES, currentLevel: number): number {
  const buildingInfo = BUILDING_TYPES[buildingType];
  return buildingInfo.upgradeTimeBase * currentLevel;
}

export function formatDuration(ms: number): string {
  const seconds = Math.floor(ms / 1000);
  const minutes = Math.floor(seconds / 60);
  const hours = Math.floor(minutes / 60);
  
  if (hours > 0) {
    return `${hours}h ${minutes % 60}m`;
  } else if (minutes > 0) {
    return `${minutes}m ${seconds % 60}s`;
  } else {
    return `${seconds}s`;
  }
}

export function getCropEmoji(cropType: string): string {
  return CROP_TYPES[cropType as keyof typeof CROP_TYPES]?.emoji || "🌱";
}

export function getAnimalEmoji(animalType: string): string {
  return ANIMAL_TYPES[animalType as keyof typeof ANIMAL_TYPES]?.emoji || "🐾";
}

export function getBuildingEmoji(buildingType: string): string {
  return BUILDING_TYPES[buildingType as keyof typeof BUILDING_TYPES]?.emoji || "🏗️";
}
