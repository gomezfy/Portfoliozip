import { ITEMS } from './inventoryManager';
import path from 'path';

export interface GeneralStoreItem {
  id: string;
  name: string;
  nameEn?: string;
  description: string;
  descriptionEn?: string;
  story?: string;
  storyEn?: string;
  price: number;
  currency?: 'tokens' | 'silver';
  emoji: string;
  imageFile?: string;
  category: 'tools' | 'consumables' | 'backpacks';
  backpackCapacity?: number;
}

export interface GeneralStoreItemImage {
  file?: string;
  url?: string;
}

export const GENERAL_STORE_ITEMS: GeneralStoreItem[] = [
  {
    id: 'fishing_rod',
    name: 'Vara de Pesca',
    nameEn: 'Fishing Rod',
    description: 'Vara de pesca profissional para pescar nos rios do oeste',
    descriptionEn: 'Professional fishing rod for fishing in the western rivers',
    story: 'Forjada nos rios selvagens do Colorado, esta vara legendária foi usada por pescadores renomados que capturavam os peixes mais raros. Cada linha traz a memória de centenas de capturas épicas.',
    storyEn: 'Forged in the wild rivers of Colorado, this legendary rod was used by renowned fishermen who caught the rarest fish. Every line carries the memory of hundreds of epic catches.',
    price: 800,
    currency: 'silver',
    emoji: ITEMS.fishing_rod.emoji,
    imageFile: 'https://i.postimg.cc/pyNMzMHD/IMG-3529.png',
    category: 'tools',
  },
  {
    id: 'pickaxe',
    name: 'Picareta Lendária',
    nameEn: 'Legendary Pickaxe',
    description: 'Uma picareta lendária que aumenta massivamente sua produção de ouro na mineração solo (16-28 barras ao invés de 1-3)',
    descriptionEn: 'A legendary pickaxe that massively increases your gold production in solo mining (16-28 bars instead of 1-3)',
    story: 'Esta picareta foi encontrada nas minas abandonadas de Deadwood. Diz-se que ela foi abençoada por um antigo prospector que descobriu a maior pepita de ouro do oeste. Sua lâmina nunca embota.',
    storyEn: 'This pickaxe was found in the abandoned mines of Deadwood. It is said to have been blessed by an old prospector who discovered the largest gold nugget in the west. Its blade never dulls.',
    price: 30,
    emoji: ITEMS.pickaxe.emoji,
    imageFile: 'https://i.postimg.cc/Hnhw0hQ7/IMG-3437.png',
    category: 'tools',
  },
  {
    id: 'leather_backpack',
    name: 'Mochila de Couro',
    nameEn: 'Leather Backpack',
    description: 'Mochila resistente de couro curtido que aumenta sua capacidade de carga em +200kg',
    descriptionEn: 'Sturdy tanned leather backpack that increases your carrying capacity by +200kg',
    story: 'Confeccionada por artesãos mexicanos tradicionais, cada mochila é costurada à mão com precisão. O couro é curtido naturalmente, melhorando com o passar do tempo e dos aventuras.',
    storyEn: 'Crafted by traditional Mexican artisans, each backpack is hand-stitched with precision. The leather is naturally tanned, improving over time and adventures.',
    price: 500,
    emoji: '🎒',
    imageFile: 'https://i.postimg.cc/JhLbQJBj/IMG-3440.png',
    category: 'backpacks',
    backpackCapacity: 200,
  },
  {
    id: 'bear_backpack',
    name: 'Mochila de Couro de Urso',
    nameEn: 'Bear Leather Backpack',
    description: 'Mochila premium feita com couro de urso, extremamente resistente. Aumenta capacidade em +350kg',
    descriptionEn: 'Premium backpack made with bear leather, extremely durable. Increases capacity by +350kg',
    story: 'Feita apenas com os melhores couros de urso grizzly do território selvagem, esta mochila é praticamente indestrutível. Lendas dizem que sobreviveu a um incêndio e ainda funciona perfeitamente.',
    storyEn: 'Made only from the finest grizzly bear leather from the wild territory, this backpack is virtually indestructible. Legends say it survived a fire and still works perfectly.',
    price: 1200,
    emoji: '🎒',
    imageFile: 'https://i.postimg.cc/tR6kjXNT/IMG-3438.png',
    category: 'backpacks',
    backpackCapacity: 350,
  },
  {
    id: 'gold_backpack',
    name: 'Mochila Banhada a Ouro',
    nameEn: 'Gold-Plated Backpack',
    description: 'A mochila definitiva! Banhada a ouro e reforçada com as melhores tecnologias. Aumenta capacidade em +500kg',
    descriptionEn: 'The ultimate backpack! Gold-plated and reinforced with the best technologies. Increases capacity by +500kg',
    story: 'A obra-prima de um mestre artesão de San Francisco. Feita de couro premium com reforços de ouro e tecnologia de compartimentos secretos. Somente a elite do velho oeste carrega uma dessas.',
    storyEn: 'The masterpiece of a master craftsman from San Francisco. Made of premium leather with gold reinforcements and secret compartment technology. Only the elite of the old west carry one of these.',
    price: 2500,
    emoji: '🎒',
    imageFile: 'https://i.postimg.cc/4NB9CMMB/IMG-3439.png',
    category: 'backpacks',
    backpackCapacity: 500,
  },
];

export function getAllStoreItems(): GeneralStoreItem[] {
  return GENERAL_STORE_ITEMS;
}

export function getStoreItemsByCategory(category: GeneralStoreItem['category'] | 'all'): GeneralStoreItem[] {
  if (category === 'all') {
    return GENERAL_STORE_ITEMS;
  }
  return GENERAL_STORE_ITEMS.filter((item) => item.category === category);
}

export function getStoreItemById(itemId: string): GeneralStoreItem | null {
  return GENERAL_STORE_ITEMS.find((item) => item.id === itemId) || null;
}

export function getCategoryName(category: string, language: 'pt-BR' | 'en-US' = 'pt-BR'): string {
  const isPtBr = language === 'pt-BR';
  switch (category) {
    case 'tools':
      return isPtBr ? 'Ferramentas' : 'Tools';
    case 'backpacks':
      return isPtBr ? 'Mochilas' : 'Backpacks';
    case 'all':
      return isPtBr ? 'Todos' : 'All';
    default:
      return isPtBr ? 'Todos' : 'All';
  }
}

export function getItemImagePath(imageFile: string): string {
  return path.join(process.cwd(), 'assets', 'shop-items', imageFile);
}

export function getCategoryEmoji(category: GeneralStoreItem['category']): string {
  switch (category) {
    case 'tools':
      return '⚒️';
    case 'consumables':
      return '🍖';
    case 'backpacks':
      return '🎒';
    default:
      return '📦';
  }
}
