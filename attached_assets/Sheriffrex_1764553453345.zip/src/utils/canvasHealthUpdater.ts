import { Client, User } from 'discord.js';
import { db } from '../../server/db';
import { users } from '../../shared/schema';
import { eq } from 'drizzle-orm';
import { createHealthCanvas } from './healthCanvasRenderer';
import { AttachmentBuilder } from 'discord.js';

/**
 * Envia um canvas atualizado de saúde para o usuário via DM
 */
export async function sendHealthCanvasUpdate(
  client: Client,
  userId: string,
  username: string
): Promise<void> {
  try {
    const userResult = await db
      .select()
      .from(users)
      .where(eq(users.userId, userId))
      .limit(1);

    if (!userResult.length) return;

    const user = userResult[0];

    const canvasBuffer = await createHealthCanvas({
      health: user.health,
      maxHealth: user.maxHealth,
      stamina: user.stamina,
      maxStamina: user.maxStamina,
      thirst: user.thirst,
      maxThirst: user.maxThirst,
      hunger: user.hunger,
      maxHunger: user.maxHunger,
      blood: user.blood,
      maxBlood: user.maxBlood,
      temperature: user.temperature,
      username: username,
    });

    const attachment = new AttachmentBuilder(canvasBuffer, { name: 'health.png' });

    const dmUser = await client.users.fetch(userId);
    await dmUser.send({
      content: '📊 **Seu status de saúde foi atualizado!**',
      files: [attachment],
    });
  } catch (error) {
    console.error(`Erro ao enviar canvas de saúde para ${userId}:`, error);
  }
}
