import { db } from "../../server/db";
import { gangues, gangueMembros, gangueConvites, users } from "../../shared/schema";
import { eq, and, desc, gt, sql, inArray } from "drizzle-orm";
import { v4 as uuidv4 } from "uuid";
import { getUserSilver, removeUserSilver, getUserGold, removeUserGold } from "./dataManager";

export type CargoGangue = "lider_1" | "lider_2" | "veterano" | "membro_regular";

export interface GangueBoosts {
  crimeBoost: number;
  duelDamageBoost: number;
  bankrobBoost: number;
  cooldownReduction: number;
}

export interface GangueInfo {
  id: string;
  serverId: string;
  nome: string;
  level: number;
  xpTotal: number;
  xpProximoNivel: number;
  tesouroPrata: number;
  tesouroOuro: number;
  maxMembros: number;
  membros: MembroInfo[];
  boosts: GangueBoosts;
}

export interface MembroInfo {
  userId: string;
  username?: string;
  cargo: CargoGangue;
  doadoPrata: number;
  doadoOuro: number;
  totalDoado: number;
}

const XP_POR_NIVEL: { [key: number]: number } = {
  1: 0,
  2: 2500,
  3: 5000,
  4: 10000,
  5: 25000,
  6: 40000,
  7: 60000,
  8: 85000,
  9: 115000,
  10: 150000,
  11: 200000,
  12: 275000,
  13: 375000,
  14: 450000,
  15: 500000,
};

const BOOSTS_POR_NIVEL: { [key: number]: GangueBoosts } = {
  1: { crimeBoost: 1, duelDamageBoost: 0, bankrobBoost: 0, cooldownReduction: 0 },
  2: { crimeBoost: 2, duelDamageBoost: 0, bankrobBoost: 0, cooldownReduction: 0 },
  3: { crimeBoost: 2, duelDamageBoost: 1, bankrobBoost: 0, cooldownReduction: 0 },
  4: { crimeBoost: 3, duelDamageBoost: 1, bankrobBoost: 2, cooldownReduction: 0 },
  5: { crimeBoost: 3, duelDamageBoost: 1, bankrobBoost: 2, cooldownReduction: 2 },
  6: { crimeBoost: 4, duelDamageBoost: 2, bankrobBoost: 3, cooldownReduction: 3 },
  7: { crimeBoost: 4, duelDamageBoost: 2, bankrobBoost: 4, cooldownReduction: 4 },
  8: { crimeBoost: 5, duelDamageBoost: 3, bankrobBoost: 5, cooldownReduction: 5 },
  9: { crimeBoost: 5, duelDamageBoost: 3, bankrobBoost: 6, cooldownReduction: 6 },
  10: { crimeBoost: 5, duelDamageBoost: 3, bankrobBoost: 5, cooldownReduction: 5 },
  11: { crimeBoost: 6, duelDamageBoost: 4, bankrobBoost: 7, cooldownReduction: 7 },
  12: { crimeBoost: 6, duelDamageBoost: 4, bankrobBoost: 8, cooldownReduction: 8 },
  13: { crimeBoost: 6, duelDamageBoost: 4, bankrobBoost: 8, cooldownReduction: 8 },
  14: { crimeBoost: 7, duelDamageBoost: 5, bankrobBoost: 9, cooldownReduction: 9 },
  15: { crimeBoost: 7, duelDamageBoost: 5, bankrobBoost: 10, cooldownReduction: 10 },
};

function calcularNivelPorXp(xp: number): number {
  let nivel = 1;
  for (let i = 15; i >= 1; i--) {
    if (xp >= XP_POR_NIVEL[i]) {
      nivel = i;
      break;
    }
  }
  return nivel;
}

function calcularXpProximoNivel(nivelAtual: number): number {
  if (nivelAtual >= 15) return XP_POR_NIVEL[15];
  return XP_POR_NIVEL[nivelAtual + 1];
}

function getBoostsParaNivel(nivel: number): GangueBoosts {
  return BOOSTS_POR_NIVEL[Math.min(nivel, 15)] || BOOSTS_POR_NIVEL[1];
}

export async function getGangueDoUsuario(userId: string, serverId: string): Promise<GangueInfo | null> {
  const membro = await db
    .select()
    .from(gangueMembros)
    .innerJoin(gangues, eq(gangueMembros.gangueId, gangues.id))
    .where(and(
      eq(gangueMembros.userId, userId),
      eq(gangues.serverId, serverId)
    ))
    .limit(1);

  if (membro.length === 0) return null;

  const gangue = membro[0].bot_gangues;
  return await getGangueInfo(gangue.id);
}

export async function getGangueInfo(gangueId: string): Promise<GangueInfo | null> {
  const [gangue] = await db
    .select()
    .from(gangues)
    .where(eq(gangues.id, gangueId))
    .limit(1);

  if (!gangue) return null;

  const membros = await db
    .select({
      id: gangueMembros.id,
      gangueId: gangueMembros.gangueId,
      userId: gangueMembros.userId,
      cargo: gangueMembros.cargo,
      doadoPrata: gangueMembros.doadoPrata,
      doadoOuro: gangueMembros.doadoOuro,
      username: users.username,
    })
    .from(gangueMembros)
    .leftJoin(users, eq(gangueMembros.userId, users.userId))
    .where(eq(gangueMembros.gangueId, gangueId))
    .orderBy(desc(sql`${gangueMembros.doadoPrata} + ${gangueMembros.doadoOuro} * 250`));

  const nivel = calcularNivelPorXp(gangue.xpTotal);

  return {
    id: gangue.id,
    serverId: gangue.serverId,
    nome: gangue.nome,
    level: nivel,
    xpTotal: gangue.xpTotal,
    xpProximoNivel: calcularXpProximoNivel(nivel),
    tesouroPrata: gangue.tesouroPrata,
    tesouroOuro: gangue.tesouroOuro,
    maxMembros: gangue.maxMembros,
    membros: membros.map(m => ({
      userId: m.userId,
      username: m.username || undefined,
      cargo: m.cargo as CargoGangue,
      doadoPrata: m.doadoPrata,
      doadoOuro: m.doadoOuro,
      totalDoado: m.doadoPrata + (m.doadoOuro * 250),
    })),
    boosts: getBoostsParaNivel(nivel),
  };
}

export async function getGangBoosts(userId: string, serverId: string): Promise<GangueBoosts> {
  const gangue = await getGangueDoUsuario(userId, serverId);
  if (!gangue) {
    return { crimeBoost: 0, duelDamageBoost: 0, bankrobBoost: 0, cooldownReduction: 0 };
  }
  return gangue.boosts;
}

export async function criarGangue(
  serverId: string,
  nome: string,
  fundadorId: string
): Promise<{ success: boolean; message: string; gangue?: GangueInfo }> {
  const gangueExistente = await getGangueDoUsuario(fundadorId, serverId);
  if (gangueExistente) {
    return { success: false, message: "Você já faz parte de uma gangue!" };
  }

  const [nomeExistente] = await db
    .select()
    .from(gangues)
    .where(and(
      eq(gangues.serverId, serverId),
      eq(gangues.nome, nome)
    ))
    .limit(1);

  if (nomeExistente) {
    return { success: false, message: "Já existe uma gangue com esse nome neste servidor!" };
  }

  if (nome.length < 3 || nome.length > 32) {
    return { success: false, message: "O nome da gangue deve ter entre 3 e 32 caracteres!" };
  }

  const gangueId = uuidv4();
  const membroId = uuidv4();

  await db.insert(gangues).values({
    id: gangueId,
    serverId,
    nome,
  });

  await db.insert(gangueMembros).values({
    id: membroId,
    gangueId,
    userId: fundadorId,
    cargo: "lider_1",
  });

  const gangueInfo = await getGangueInfo(gangueId);
  return { success: true, message: `Gangue "${nome}" criada com sucesso!`, gangue: gangueInfo! };
}

export async function convidarMembro(
  gangueId: string,
  convidadorId: string,
  convidadoId: string,
  serverId: string
): Promise<{ success: boolean; message: string }> {
  const [convidador] = await db
    .select()
    .from(gangueMembros)
    .where(and(
      eq(gangueMembros.gangueId, gangueId),
      eq(gangueMembros.userId, convidadorId)
    ))
    .limit(1);

  if (!convidador) {
    return { success: false, message: "Você não faz parte desta gangue!" };
  }

  const cargo = convidador.cargo as CargoGangue;
  if (cargo === "membro_regular") {
    return { success: false, message: "Apenas Líderes e Veteranos podem convidar membros!" };
  }

  if (cargo === "veterano") {
    const agora = new Date();
    const ultimoConvite = convidador.ultimoConvite;
    if (ultimoConvite) {
      const diff = agora.getTime() - ultimoConvite.getTime();
      const umDia = 24 * 60 * 60 * 1000;
      if (diff < umDia) {
        const horasRestantes = Math.ceil((umDia - diff) / (60 * 60 * 1000));
        return { success: false, message: `Veteranos só podem enviar 1 convite por dia. Aguarde ${horasRestantes} hora(s).` };
      }
    }
  }

  const gangueConvidado = await getGangueDoUsuario(convidadoId, serverId);
  if (gangueConvidado) {
    return { success: false, message: "Este usuário já está em uma gangue!" };
  }

  const [conviteExistente] = await db
    .select()
    .from(gangueConvites)
    .where(and(
      eq(gangueConvites.gangueId, gangueId),
      eq(gangueConvites.convidadoId, convidadoId),
      eq(gangueConvites.status, "pendente"),
      gt(gangueConvites.expiraEm, new Date())
    ))
    .limit(1);

  if (conviteExistente) {
    return { success: false, message: "Já existe um convite pendente para este usuário!" };
  }

  const gangueInfo = await getGangueInfo(gangueId);
  if (gangueInfo && gangueInfo.membros.length >= gangueInfo.maxMembros) {
    return { success: false, message: "A gangue atingiu o limite máximo de membros!" };
  }

  const expiraEm = new Date();
  expiraEm.setHours(expiraEm.getHours() + 24);

  await db.insert(gangueConvites).values({
    id: uuidv4(),
    gangueId,
    convidadoId,
    convidadorId,
    expiraEm,
  });

  if (cargo === "veterano") {
    await db
      .update(gangueMembros)
      .set({ ultimoConvite: new Date() })
      .where(eq(gangueMembros.id, convidador.id));
  }

  return { success: true, message: "Convite enviado com sucesso!" };
}

export async function aceitarConvite(
  convidadoId: string,
  nomeGangue: string,
  serverId: string
): Promise<{ success: boolean; message: string; gangue?: GangueInfo }> {
  const [gangue] = await db
    .select()
    .from(gangues)
    .where(and(
      eq(gangues.serverId, serverId),
      eq(gangues.nome, nomeGangue)
    ))
    .limit(1);

  if (!gangue) {
    return { success: false, message: "Gangue não encontrada!" };
  }

  const [convite] = await db
    .select()
    .from(gangueConvites)
    .where(and(
      eq(gangueConvites.gangueId, gangue.id),
      eq(gangueConvites.convidadoId, convidadoId),
      eq(gangueConvites.status, "pendente"),
      gt(gangueConvites.expiraEm, new Date())
    ))
    .limit(1);

  if (!convite) {
    return { success: false, message: "Você não tem um convite válido para esta gangue!" };
  }

  const gangueInfo = await getGangueInfo(gangue.id);
  if (gangueInfo && gangueInfo.membros.length >= gangueInfo.maxMembros) {
    return { success: false, message: "A gangue atingiu o limite máximo de membros!" };
  }

  await db
    .update(gangueConvites)
    .set({ status: "aceito" })
    .where(eq(gangueConvites.id, convite.id));

  await db.insert(gangueMembros).values({
    id: uuidv4(),
    gangueId: gangue.id,
    userId: convidadoId,
    cargo: "membro_regular",
  });

  const gangueAtualizada = await getGangueInfo(gangue.id);
  return { success: true, message: `Você entrou na gangue "${gangue.nome}"!`, gangue: gangueAtualizada! };
}

export async function getConvitesPendentes(
  userId: string,
  serverId: string
): Promise<{ gangueNome: string; convidadorId: string; expiraEm: Date }[]> {
  const convites = await db
    .select({
      gangueNome: gangues.nome,
      convidadorId: gangueConvites.convidadorId,
      expiraEm: gangueConvites.expiraEm,
    })
    .from(gangueConvites)
    .innerJoin(gangues, eq(gangueConvites.gangueId, gangues.id))
    .where(and(
      eq(gangueConvites.convidadoId, userId),
      eq(gangueConvites.status, "pendente"),
      eq(gangues.serverId, serverId),
      gt(gangueConvites.expiraEm, new Date())
    ));

  return convites;
}

export async function doar(
  userId: string,
  serverId: string,
  prata: number,
  ouro: number
): Promise<{ success: boolean; message: string; xpGanho?: number }> {
  const gangue = await getGangueDoUsuario(userId, serverId);
  if (!gangue) {
    return { success: false, message: "Você não faz parte de uma gangue!" };
  }

  if (prata < 0 || ouro < 0) {
    return { success: false, message: "Valores inválidos!" };
  }

  if (prata === 0 && ouro === 0) {
    return { success: false, message: "Você precisa doar pelo menos prata ou ouro!" };
  }

  const prataUsuario = getUserSilver(userId);
  const ouroUsuario = getUserGold(userId);

  if (prataUsuario < prata) {
    return { success: false, message: `Você não tem prata suficiente! Você tem: ${prataUsuario}` };
  }

  if (ouroUsuario < ouro) {
    return { success: false, message: `Você não tem ouro suficiente! Você tem: ${ouroUsuario}` };
  }

  await removeUserSilver(userId, prata);
  await removeUserGold(userId, ouro);

  const xpGanho = prata + (ouro * 250);

  await db
    .update(gangues)
    .set({
      tesouroPrata: sql`${gangues.tesouroPrata} + ${prata}`,
      tesouroOuro: sql`${gangues.tesouroOuro} + ${ouro}`,
      xpTotal: sql`${gangues.xpTotal} + ${xpGanho}`,
      atualizadoEm: new Date(),
    })
    .where(eq(gangues.id, gangue.id));

  await db
    .update(gangueMembros)
    .set({
      doadoPrata: sql`${gangueMembros.doadoPrata} + ${prata}`,
      doadoOuro: sql`${gangueMembros.doadoOuro} + ${ouro}`,
    })
    .where(and(
      eq(gangueMembros.gangueId, gangue.id),
      eq(gangueMembros.userId, userId)
    ));

  return { 
    success: true, 
    message: `Doação realizada com sucesso! +${xpGanho} XP para a gangue.`,
    xpGanho 
  };
}

export async function promoverMembro(
  promotorId: string,
  alvoId: string,
  novoCargo: CargoGangue,
  serverId: string
): Promise<{ success: boolean; message: string }> {
  const gangue = await getGangueDoUsuario(promotorId, serverId);
  if (!gangue) {
    return { success: false, message: "Você não faz parte de uma gangue!" };
  }

  const promotor = gangue.membros.find(m => m.userId === promotorId);
  const alvo = gangue.membros.find(m => m.userId === alvoId);

  if (!promotor || !alvo) {
    return { success: false, message: "Membro não encontrado na gangue!" };
  }

  if (promotor.cargo !== "lider_1" && promotor.cargo !== "lider_2") {
    return { success: false, message: "Apenas Líderes podem promover membros!" };
  }

  if (promotor.cargo === "lider_2" && (novoCargo === "lider_1" || novoCargo === "lider_2")) {
    return { success: false, message: "Apenas o Líder 1 pode promover a cargos de liderança!" };
  }

  if (novoCargo === "lider_1") {
    return { success: false, message: "Só pode haver um Líder 1 (o fundador)!" };
  }

  if (novoCargo === "lider_2") {
    const lideres = gangue.membros.filter(m => m.cargo === "lider_1" || m.cargo === "lider_2");
    if (lideres.length >= 2) {
      return { success: false, message: "A gangue já tem o máximo de 2 Líderes!" };
    }
  }

  if (novoCargo === "veterano") {
    const veteranos = gangue.membros.filter(m => m.cargo === "veterano");
    if (veteranos.length >= 4) {
      return { success: false, message: "A gangue já tem o máximo de 4 Veteranos!" };
    }
  }

  await db
    .update(gangueMembros)
    .set({ cargo: novoCargo })
    .where(and(
      eq(gangueMembros.gangueId, gangue.id),
      eq(gangueMembros.userId, alvoId)
    ));

  const cargoNomes: { [key: string]: string } = {
    lider_1: "Líder 1",
    lider_2: "Líder 2",
    veterano: "Veterano",
    membro_regular: "Membro Regular",
  };

  return { success: true, message: `Membro promovido para ${cargoNomes[novoCargo]}!` };
}

export async function sairDaGangue(
  userId: string,
  serverId: string
): Promise<{ success: boolean; message: string }> {
  const gangue = await getGangueDoUsuario(userId, serverId);
  if (!gangue) {
    return { success: false, message: "Você não faz parte de uma gangue!" };
  }

  const membro = gangue.membros.find(m => m.userId === userId);
  if (!membro) {
    return { success: false, message: "Erro ao encontrar seus dados na gangue!" };
  }

  if (membro.cargo === "lider_1") {
    if (gangue.membros.length > 1) {
      const lider2 = gangue.membros.find(m => m.cargo === "lider_2");
      if (lider2) {
        await db
          .update(gangueMembros)
          .set({ cargo: "lider_1" })
          .where(and(
            eq(gangueMembros.gangueId, gangue.id),
            eq(gangueMembros.userId, lider2.userId)
          ));
      } else {
        const veteranos = gangue.membros
          .filter(m => m.cargo === "veterano")
          .sort((a, b) => b.totalDoado - a.totalDoado);
        
        if (veteranos.length > 0) {
          await db
            .update(gangueMembros)
            .set({ cargo: "lider_1" })
            .where(and(
              eq(gangueMembros.gangueId, gangue.id),
              eq(gangueMembros.userId, veteranos[0].userId)
            ));
        } else {
          const membrosRegulares = gangue.membros
            .filter(m => m.cargo === "membro_regular" && m.userId !== userId)
            .sort((a, b) => b.totalDoado - a.totalDoado);
          
          if (membrosRegulares.length > 0) {
            await db
              .update(gangueMembros)
              .set({ cargo: "lider_1" })
              .where(and(
                eq(gangueMembros.gangueId, gangue.id),
                eq(gangueMembros.userId, membrosRegulares[0].userId)
              ));
          }
        }
      }
    }
  }

  await db
    .delete(gangueMembros)
    .where(and(
      eq(gangueMembros.gangueId, gangue.id),
      eq(gangueMembros.userId, userId)
    ));

  const membrosRestantes = await db
    .select()
    .from(gangueMembros)
    .where(eq(gangueMembros.gangueId, gangue.id));

  if (membrosRestantes.length === 0) {
    await db.delete(gangueConvites).where(eq(gangueConvites.gangueId, gangue.id));
    await db.delete(gangues).where(eq(gangues.id, gangue.id));
    return { success: true, message: "Você saiu da gangue e ela foi dissolvida por não ter mais membros!" };
  }

  return { success: true, message: `Você saiu da gangue "${gangue.nome}"!` };
}

export async function expulsarMembro(
  expulsorId: string,
  alvoId: string,
  serverId: string
): Promise<{ success: boolean; message: string }> {
  const gangue = await getGangueDoUsuario(expulsorId, serverId);
  if (!gangue) {
    return { success: false, message: "Você não faz parte de uma gangue!" };
  }

  const expulsor = gangue.membros.find(m => m.userId === expulsorId);
  const alvo = gangue.membros.find(m => m.userId === alvoId);

  if (!expulsor || !alvo) {
    return { success: false, message: "Membro não encontrado na gangue!" };
  }

  if (expulsor.userId === alvo.userId) {
    return { success: false, message: "Você não pode expulsar a si mesmo! Use /gangue sair." };
  }

  const cargoHierarquia: { [key: string]: number } = {
    lider_1: 4,
    lider_2: 3,
    veterano: 2,
    membro_regular: 1,
  };

  if (cargoHierarquia[expulsor.cargo] <= cargoHierarquia[alvo.cargo]) {
    return { success: false, message: "Você não pode expulsar alguém de cargo igual ou superior!" };
  }

  if (expulsor.cargo === "veterano" && alvo.cargo !== "membro_regular") {
    return { success: false, message: "Veteranos só podem expulsar Membros Regulares!" };
  }

  await db
    .delete(gangueMembros)
    .where(and(
      eq(gangueMembros.gangueId, gangue.id),
      eq(gangueMembros.userId, alvoId)
    ));

  return { success: true, message: "Membro expulso da gangue!" };
}

export async function dissolverGangue(
  userId: string,
  serverId: string
): Promise<{ success: boolean; message: string }> {
  const gangue = await getGangueDoUsuario(userId, serverId);
  if (!gangue) {
    return { success: false, message: "Você não faz parte de uma gangue!" };
  }

  const membro = gangue.membros.find(m => m.userId === userId);
  if (!membro || membro.cargo !== "lider_1") {
    return { success: false, message: "Apenas o Líder 1 (fundador) pode dissolver a gangue!" };
  }

  await db.delete(gangueConvites).where(eq(gangueConvites.gangueId, gangue.id));
  await db.delete(gangueMembros).where(eq(gangueMembros.gangueId, gangue.id));
  await db.delete(gangues).where(eq(gangues.id, gangue.id));

  return { success: true, message: `A gangue "${gangue.nome}" foi dissolvida permanentemente!` };
}

export async function buscarGanguePorNome(
  nome: string,
  serverId: string
): Promise<GangueInfo | null> {
  const [gangue] = await db
    .select()
    .from(gangues)
    .where(and(
      eq(gangues.serverId, serverId),
      eq(gangues.nome, nome)
    ))
    .limit(1);

  if (!gangue) return null;
  return getGangueInfo(gangue.id);
}

export async function listarGangues(serverId: string): Promise<GangueInfo[]> {
  const ganguesList = await db
    .select()
    .from(gangues)
    .where(eq(gangues.serverId, serverId))
    .orderBy(desc(gangues.xpTotal));

  const result: GangueInfo[] = [];
  for (const g of ganguesList) {
    const info = await getGangueInfo(g.id);
    if (info) result.push(info);
  }

  return result;
}
