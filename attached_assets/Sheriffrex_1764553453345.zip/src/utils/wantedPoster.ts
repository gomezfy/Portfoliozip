import { createCanvas, loadImage, GlobalFonts, type SKRSContext2D } from "@napi-rs/canvas";
import { User } from "discord.js";
import path from "path";

GlobalFonts.registerFromPath(
  path.join(process.cwd(), "assets/fonts/Nunito-Bold.ttf"),
  "Nunito",
);
GlobalFonts.registerFromPath(
  path.join(process.cwd(), "assets/fonts/Nunito-Regular.ttf"),
  "Nunito Regular",
);
GlobalFonts.registerFromPath(
  path.join(process.cwd(), "assets/fonts/Nunito-SemiBold.ttf"),
  "Nunito SemiBold",
);
GlobalFonts.registerFromPath(
  path.join(process.cwd(), "assets/fonts/BleedingCowboys.ttf"),
  "BleedingCowboys",
);

/**
 * Normaliza texto para suportar qualquer tipo de caractere
 * Apenas remove quebras de linha e espaços múltiplos
 * Mantém o nome do usuário como está
 */
function normalizeTextForCanvas(text: string): string {
  // Remove quebras de linha e tabulações
  let normalized = text.replace(/[\n\r\t]/g, " ");
  
  // Remove espaços múltiplos
  normalized = normalized.replace(/\s+/g, " ");
  
  return normalized.trim();
}

function drawStar(ctx: SKRSContext2D, cx: number, cy: number, spikes: number, outerRadius: number, innerRadius: number) {
  let rot = (Math.PI / 2) * 3;
  let x = cx;
  let y = cy;
  const step = Math.PI / spikes;

  ctx.beginPath();
  ctx.moveTo(cx, cy - outerRadius);
  for (let i = 0; i < spikes; i++) {
    x = cx + Math.cos(rot) * outerRadius;
    y = cy - Math.sin(rot) * outerRadius;
    ctx.lineTo(x, y);
    rot += step;

    x = cx + Math.cos(rot) * innerRadius;
    y = cy - Math.sin(rot) * innerRadius;
    ctx.lineTo(x, y);
    rot += step;
  }
  ctx.lineTo(cx, cy - outerRadius);
  ctx.closePath();
  ctx.fill();
}

export async function generateWantedPoster(
  user: User,
  bountyAmount: number,
  locale: string = "pt-BR",
  reason: string = "crimes diversos",
  status: "dead" | "alive" | "dead_or_alive" = "dead_or_alive",
  titleText: string = "PROCURADO",
  crimesText: string = "Pelos crimes de",
  deliverText: string = "Entregue-o no gabinete de xerifes mais próximo",
  statusTexts: { dead: string; alive: string; dead_or_alive: string } = { dead: "MORTO", alive: "VIVO", dead_or_alive: "VIVO OU MORTO" },
  customImageURL?: string,
  customOutlawName?: string | null,
): Promise<Buffer> {
  const width = 500;
  const height = 700;

  const canvas = createCanvas(width, height);
  const ctx = canvas.getContext("2d");

  const paperColor = "#d8d4cc";
  const darkInk = "#2a2520";
  const mediumInk = "#4a4540";

  ctx.fillStyle = paperColor;
  ctx.fillRect(0, 0, width, height);

  for (let i = 0; i < 150; i++) {
    const x = Math.random() * width;
    const y = Math.random() * height;
    const size = Math.random() * 4 + 1;
    const opacity = Math.random() * 0.08;
    ctx.fillStyle = `rgba(100, 95, 90, ${opacity})`;
    ctx.fillRect(x, y, size, size);
  }

  for (let i = 0; i < 80; i++) {
    const x = Math.random() * width;
    const y = Math.random() * height;
    const size = Math.random() * 8 + 2;
    const opacity = Math.random() * 0.05;
    ctx.fillStyle = `rgba(150, 145, 140, ${opacity})`;
    ctx.beginPath();
    ctx.arc(x, y, size, 0, Math.PI * 2);
    ctx.fill();
  }

  const edgeGradientLeft = ctx.createLinearGradient(0, 0, 60, 0);
  edgeGradientLeft.addColorStop(0, "rgba(120, 115, 110, 0.2)");
  edgeGradientLeft.addColorStop(1, "rgba(120, 115, 110, 0)");
  ctx.fillStyle = edgeGradientLeft;
  ctx.fillRect(0, 0, 60, height);

  const edgeGradientRight = ctx.createLinearGradient(width - 60, 0, width, 0);
  edgeGradientRight.addColorStop(0, "rgba(120, 115, 110, 0)");
  edgeGradientRight.addColorStop(1, "rgba(120, 115, 110, 0.2)");
  ctx.fillStyle = edgeGradientRight;
  ctx.fillRect(width - 60, 0, 60, height);

  const edgeGradientTop = ctx.createLinearGradient(0, 0, 0, 50);
  edgeGradientTop.addColorStop(0, "rgba(120, 115, 110, 0.15)");
  edgeGradientTop.addColorStop(1, "rgba(120, 115, 110, 0)");
  ctx.fillStyle = edgeGradientTop;
  ctx.fillRect(0, 0, width, 50);

  const edgeGradientBottom = ctx.createLinearGradient(0, height - 50, 0, height);
  edgeGradientBottom.addColorStop(0, "rgba(120, 115, 110, 0)");
  edgeGradientBottom.addColorStop(1, "rgba(120, 115, 110, 0.15)");
  ctx.fillStyle = edgeGradientBottom;
  ctx.fillRect(0, height - 50, width, 50);

  ctx.fillStyle = darkInk;
  drawStar(ctx, width / 2, 45, 6, 12, 6);

  ctx.strokeStyle = darkInk;
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(60, 65);
  ctx.lineTo(width / 2 - 80, 65);
  ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(width / 2 + 80, 65);
  ctx.lineTo(width - 60, 65);
  ctx.stroke();

  ctx.fillStyle = darkInk;
  ctx.font = "58px BleedingCowboys";
  ctx.textAlign = "center";
  ctx.fillText(titleText, width / 2, 120);

  ctx.strokeStyle = darkInk;
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(60, 135);
  ctx.lineTo(width - 60, 135);
  ctx.stroke();

  ctx.fillStyle = mediumInk;
  ctx.font = "18px Nunito Regular";
  ctx.textAlign = "center";
  
  const crimesFullText = `${crimesText} ${reason}`;
  const maxCrimesWidth = width - 80;
  
  if (ctx.measureText(crimesFullText).width > maxCrimesWidth) {
    const words = crimesFullText.split(' ');
    let line1 = '';
    let line2 = '';
    let currentLine = '';
    
    for (const word of words) {
      const testLine = currentLine + (currentLine ? ' ' : '') + word;
      if (ctx.measureText(testLine).width > maxCrimesWidth && currentLine) {
        if (!line1) {
          line1 = currentLine;
          currentLine = word;
        } else {
          line2 = currentLine + ' ' + word;
          break;
        }
      } else {
        currentLine = testLine;
      }
    }
    if (!line2) line2 = currentLine;
    
    ctx.fillText(line1 || crimesFullText, width / 2, 165);
    if (line2 && line1) ctx.fillText(line2, width / 2, 185);
  } else {
    ctx.fillText(crimesFullText, width / 2, 165);
  }

  const avatarSize = 180;
  const avatarX = (width - avatarSize) / 2;
  const avatarY = 200;

  try {
    const imageURL = customImageURL || user.displayAvatarURL({ extension: "png", size: 256 });
    const image = await loadImage(imageURL);

    // Create a temporary canvas to crop the image proportionally
    const tempCanvas = createCanvas(avatarSize, avatarSize);
    const tempCtx = tempCanvas.getContext("2d");

    const imgWidth = image.width;
    const imgHeight = image.height;
    const scale = Math.max(avatarSize / imgWidth, avatarSize / imgHeight);
    
    const scaledWidth = imgWidth * scale;
    const scaledHeight = imgHeight * scale;
    const offsetX = (avatarSize - scaledWidth) / 2;
    const offsetY = (avatarSize - scaledHeight) / 2;

    tempCtx.drawImage(image, offsetX, offsetY, scaledWidth, scaledHeight);

    // Draw the temp canvas onto the main canvas
    ctx.drawImage(tempCanvas as any, avatarX, avatarY);
  } catch (error) {
    console.error("Error loading image:", error);
    ctx.fillStyle = "#b0a090";
    ctx.fillRect(avatarX, avatarY, avatarSize, avatarSize);
  }

  const username = customOutlawName || user.username;
  const normalizedName = normalizeTextForCanvas(username);
  const displayName = normalizedName.length > 18 ? `${normalizedName.substring(0, 15)}...` : normalizedName;
  
  ctx.font = "bold 32px Nunito";
  ctx.textAlign = "center";
  const nameWidth = ctx.measureText(displayName.toUpperCase()).width;
  
  ctx.fillStyle = darkInk;
  drawStar(ctx, width / 2 - nameWidth / 2 - 25, 420, 5, 10, 5);
  ctx.fillText(displayName.toUpperCase(), width / 2, 428);
  drawStar(ctx, width / 2 + nameWidth / 2 + 25, 420, 5, 10, 5);

  ctx.strokeStyle = darkInk;
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(100, 455);
  ctx.lineTo(width - 100, 455);
  ctx.stroke();

  ctx.fillStyle = darkInk;
  ctx.font = "bold 48px Nunito";
  ctx.textAlign = "center";
  
  const statusDisplay = statusTexts[status] || statusTexts.dead_or_alive;
  ctx.fillText(statusDisplay, width / 2, 510);

  ctx.fillStyle = mediumInk;
  ctx.font = "16px Nunito Regular";
  ctx.fillText(deliverText, width / 2, 550);

  ctx.fillStyle = darkInk;
  ctx.font = "bold 52px Nunito";
  ctx.fillText(`$${bountyAmount.toLocaleString("pt-BR")}`, width / 2, 615);

  return canvas.toBuffer("image/png");
}
