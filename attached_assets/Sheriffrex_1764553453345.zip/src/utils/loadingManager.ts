import { CommandInteraction, EmbedBuilder, MessageFlags } from "discord.js";

const LOADING_EMOJIS = ["⏳", "⌛", "⏰", "🔄"];
const LOADING_MESSAGES = [
  "Processando...",
  "Um momento, parceiro...",
  "Carregando a munição...",
  "Preparando a sela...",
];

let currentLoadingIndex = 0;

/**
 * Defer a reply to show a loading state to the user
 * Use this at the beginning of long-running commands
 */
export async function deferReply(
  interaction: CommandInteraction,
  ephemeral = false,
): Promise<void> {
  if (!interaction.deferred && !interaction.replied) {
    await interaction.deferReply({ ephemeral });
  }
}

/**
 * Get a random loading message with emoji
 */
export function getLoadingMessage(): string {
  const emoji = LOADING_EMOJIS[currentLoadingIndex % LOADING_EMOJIS.length];
  const message =
    LOADING_MESSAGES[currentLoadingIndex % LOADING_MESSAGES.length];
  currentLoadingIndex++;
  return `${emoji} ${message}`;
}

/**
 * Create a loading embed
 */
export function createLoadingEmbed(title: string): EmbedBuilder {
  return new EmbedBuilder()
    .setColor("#FF8C00")
    .setTitle(getLoadingMessage())
    .setDescription(`**${title}**`)
    .setFooter({ text: "Preparando..." })
    .setTimestamp();
}

/**
 * Send a loading message and automatically edit it later
 * Useful for commands that need to show immediate feedback
 */
export async function showLoadingState(
  interaction: CommandInteraction,
  title: string,
): Promise<void> {
  const embed = createLoadingEmbed(title);
  await interaction.editReply({
    embeds: [embed],
  });
}

/**
 * Create ephemeral loading message (only visible to the user)
 */
export function createEphemeralLoadingEmbed(title: string): EmbedBuilder {
  return new EmbedBuilder()
    .setColor("#FF8C00")
    .setTitle(getLoadingMessage())
    .setDescription(`**${title}**`)
    .setFooter({ text: "Preparando..." })
    .setTimestamp();
}
