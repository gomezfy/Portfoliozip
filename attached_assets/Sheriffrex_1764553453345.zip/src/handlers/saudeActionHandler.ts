import { StringSelectMenuInteraction, MessageFlags, AttachmentBuilder } from 'discord.js';
import { rpHealthService } from '../utils/rpHealthService';
import { db } from '../../server/db';
import { users } from '../../shared/schema';
import { eq } from 'drizzle-orm';
import { createHealthCanvas } from '../utils/healthCanvasRenderer';

export async function handleSaudeAction(
  interaction: StringSelectMenuInteraction
): Promise<void> {
  const action = interaction.values[0];
  const userId = interaction.user.id;

  try {
    await interaction.deferReply({ flags: MessageFlags.Ephemeral });

    const userResult = await db
      .select()
      .from(users)
      .where(eq(users.userId, userId))
      .limit(1);

    if (!userResult.length) {
      await interaction.editReply({
        content: 'Usuário não encontrado.',
      });
      return;
    }

    const user = userResult[0];
    let newHealth = user.health;
    let newStamina = user.stamina;
    let newHunger = user.hunger;
    let newThirst = user.thirst;
    let newBlood = user.blood;
    let actionMessage = '';

    if (action === 'comer') {
      const hungerRestore = Math.min(40, user.maxHunger - user.hunger);
      newHunger = user.hunger + hungerRestore;
      newHealth = Math.min(user.maxHealth, user.health + 10);
      actionMessage = `🍖 **Comeu com gosto!** Fome: -${hungerRestore}, Vida: +10`;
    } else if (action === 'beber') {
      const thirstRestore = Math.min(40, user.maxThirst - user.thirst);
      newThirst = user.thirst + thirstRestore;
      newStamina = Math.min(user.maxStamina, user.stamina + 15);
      actionMessage = `💧 **Bebeu com gosto!** Sede: -${thirstRestore}, Stamina: +15`;
    } else if (action === 'curar') {
      const result = await rpHealthService.healBleeding(userId);
      if (result.healed) {
        actionMessage = `🏥 **Curado!** Recuperou ${result.healthRestored} de vida. Sangramento parado!`;
      } else {
        actionMessage = `Você não está sangrando ou usuário não encontrado.`;
      }
      
      await interaction.editReply({
        content: actionMessage,
      });
      return;
    } else if (action === 'descansar') {
      const staminaRestore = Math.min(50, user.maxStamina - user.stamina);
      newStamina = user.stamina + staminaRestore;
      newHealth = Math.min(user.maxHealth, user.health + 5);
      actionMessage = `😴 **Descansou!** Stamina: +${staminaRestore}, Vida: +5`;
    } else if (action === 'transfusao') {
      const bloodRestore = Math.min(50, user.maxBlood - user.blood);
      newBlood = user.blood + bloodRestore;
      newHealth = Math.min(user.maxHealth, user.health + 20);
      actionMessage = `🩸 **Transfusão realizada!** Sangue: +${bloodRestore}, Vida: +20`;
    }

    // Atualizar no banco
    await db
      .update(users)
      .set({
        health: newHealth,
        stamina: newStamina,
        hunger: newHunger,
        thirst: newThirst,
        blood: newBlood,
        isBleeding: action === 'curar' ? false : user.isBleeding,
        bleedingAmount: action === 'curar' ? 0 : user.bleedingAmount,
        updatedAt: new Date(),
      })
      .where(eq(users.userId, userId));

    // Regenerar canvas com novos valores
    const canvasBuffer = await createHealthCanvas({
      health: newHealth,
      maxHealth: user.maxHealth,
      stamina: newStamina,
      maxStamina: user.maxStamina,
      thirst: newThirst,
      maxThirst: user.maxThirst,
      hunger: newHunger,
      maxHunger: user.maxHunger,
      blood: newBlood,
      maxBlood: user.maxBlood,
      temperature: user.temperature,
      username: interaction.user.username,
    });

    const attachment = new AttachmentBuilder(canvasBuffer, { name: 'health.png' });

    await interaction.editReply({
      content: `**Ação Realizada:** ${actionMessage}`,
      files: [attachment],
    });
  } catch (error) {
    console.error('Erro em handleSaudeAction:', error);
    await interaction.editReply({
      content: 'Erro ao executar ação.',
    });
  }
}
