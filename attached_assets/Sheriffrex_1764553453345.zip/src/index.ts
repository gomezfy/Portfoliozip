// Load environment variables (works both locally with .env and in production with system env)
import dotenv from "dotenv";
import { Client, Partials, Collection, Events, MessageFlags } from "discord.js";
import fs from "fs";
import path from "path";
import Logger from "./utils/logger";
import { modernLogger } from "./utils/modernLogger";
import {
  sanitizeErrorForLogging,
  validateEnvironment,
  getSafeEnvironmentInfo,
} from "./utils/security";
import { Command, BotClient } from "./types";
import { ErrorHandler } from "./utils/errorHandler";
import { globalCooldownManager } from "./utils/cooldownManager";
import {
  PRODUCTION_CACHE_CONFIG,
  LOW_MEMORY_CACHE_CONFIG,
  PRODUCTION_SWEEPERS,
  PRODUCTION_INTENTS,
  performanceMonitor,
  measureCommandTime,
  setupGracefulShutdown,
  setupMemoryOptimization,
  setupPerformanceMonitoring,
  healthCheck,
} from "./utils/performance";
import { startAutomaticTerritoryIncome } from "./utils/territoryIncome";
import { startMiningNotifications } from "./utils/miningTracker";
import { startDailyRewardsScheduler } from "./utils/dailyRewards";
import { startEventScheduler } from "./utils/eventScheduler";
import { startBleedingSystem } from "./utils/bleedingSystem";
import { addXp } from "./utils/xpManager";
import { initializeDatabase } from "./utils/database";
import { startReminderSystem } from "./utils/reminderManager";
import { preloadCommonAssets } from "./utils/canvasCache";
import {
  isPunished,
  getRemainingTime,
  formatTime,
} from "./utils/punishmentManager";
import { canGainXp } from "./utils/messageThrottler";

// Display startup banner
modernLogger.banner("Initializing Sheriff Rex Bot");

// Try to load .env file if it exists (for local development)
const envPath = path.join(process.cwd(), ".env");
if (fs.existsSync(envPath)) {
  modernLogger.info("Loading .env file");
  dotenv.config({ path: envPath });
} else {
  modernLogger.info("Using system environment variables (production mode)");
}

// Check environment variables
modernLogger.section("Environment Check");
modernLogger.table({
  "DISCORD_TOKEN": !!process.env.DISCORD_TOKEN,
  "DISCORD_CLIENT_ID": !!process.env.DISCORD_CLIENT_ID,
  "DATABASE_URL": !!process.env.DATABASE_URL,
  "NODE_ENV": process.env.NODE_ENV || "development",
});

// Validate environment variables before starting
modernLogger.info("Validating environment variables");
try {
  validateEnvironment();
  modernLogger.success("Environment validation passed");
  modernLogger.debug("Environment info: " + JSON.stringify(getSafeEnvironmentInfo()));
} catch (error) {
  modernLogger.error("Environment validation failed", sanitizeErrorForLogging(error as Error));
  process.exit(1);
}

// Production mode - reduce console logs
const isProduction = process.env.NODE_ENV === "production";

modernLogger.section("Database Initialization");
modernLogger.info("Initializing database system");
initializeDatabase();
modernLogger.success("Database system ready");

// Detect low memory environment
const isLowMemory =
  process.env.LOW_MEMORY === "true" ||
  (process.env.MEMORY_LIMIT && parseInt(process.env.MEMORY_LIMIT) < 100);

modernLogger.info(`Memory mode: ${isLowMemory ? "LOW MEMORY" : "PRODUCTION"}`);

// Production-optimized client configuration
const client = new Client({
  // Optimized intents - only what's needed
  intents: PRODUCTION_INTENTS,

  // Minimal partials for better performance
  partials: [Partials.User, Partials.Channel, Partials.GuildMember],

  // Advanced cache configuration - auto-detect based on memory
  makeCache: isLowMemory ? LOW_MEMORY_CACHE_CONFIG : PRODUCTION_CACHE_CONFIG,

  // Aggressive sweepers for memory management
  sweepers: PRODUCTION_SWEEPERS,

  // Connection settings for stability
  rest: {
    timeout: 15000,
    retries: 3,
  },

  // Presence configuration
  presence: {
    status: "online",
    activities: [
      {
        name: "Sheriff Rex | /help",
        type: 0, // Playing
      },
    ],
  },

  // Fail if cache is full (prevents memory leaks)
  failIfNotExists: false,

  // Allow mentions
  allowedMentions: {
    parse: ["users", "roles"],
    repliedUser: true,
  },
}) as Client & BotClient;

(client as BotClient).commands = new Collection<string, Command>();

// Helper function to load commands from a directory
function loadCommandsFromPath(basePath: string, pathLabel: string): number {
  if (!fs.existsSync(basePath)) {
    modernLogger.debug(`Path ${pathLabel} does not exist, skipping`);
    return 0;
  }

  const categories = fs.readdirSync(basePath).filter((item) => {
    const itemPath = path.join(basePath, item);
    return fs.statSync(itemPath).isDirectory();
  });

  let count = 0;
  for (const category of categories) {
    const categoryPath = path.join(basePath, category);
    const commandFiles = fs
      .readdirSync(categoryPath)
      .filter(
        (file) =>
          (file.endsWith(".js") || file.endsWith(".ts")) &&
          !file.endsWith(".d.ts"),
      );

    for (const file of commandFiles) {
      const filePath = path.join(categoryPath, file);
      try {
        const importedCommand = require(filePath);
        // Support both export default and named exports
        const command = importedCommand.default || importedCommand;
        
        if ("data" in command && "execute" in command) {
          client.commands.set(command.data.name, command);
          count++;
          modernLogger.debug(`Loaded command: /${command.data.name} (${pathLabel}/${category})`);
        }
      } catch (error: any) {
        modernLogger.error(`Failed to load command ${file}`, sanitizeErrorForLogging(error));
      }
    }
  }
  return count;
}

modernLogger.section("Loading Commands");
let commandCount = 0;

// Load from traditional commands directory
const commandsPath = path.join(__dirname, "commands");
commandCount += loadCommandsFromPath(commandsPath, "commands");

// Load from features directory
const featuresPath = path.join(__dirname, "features");
commandCount += loadCommandsFromPath(featuresPath, "features");

modernLogger.success(`Loaded ${commandCount} total commands`);

modernLogger.section("Loading Events");
const { handleSaudeAction } = require("./handlers/saudeActionHandler");

const eventsPath = path.join(__dirname, "events");
const eventFiles = fs
  .readdirSync(eventsPath)
  .filter(
    (file) =>
      (file.endsWith(".js") || file.endsWith(".ts")) && !file.endsWith(".d.ts"),
  );

let eventCount = 0;
for (const file of eventFiles) {
  const filePath = path.join(eventsPath, file);
  try {
    const event = require(filePath);
    if (event.once) {
      client.once(event.name, (...args: any[]) => event.execute(...args));
    } else {
      client.on(event.name, (...args: any[]) => event.execute(...args));
    }
    eventCount++;
    modernLogger.debug(`Loaded event: ${event.name}${event.once ? ' (once)' : ''}`);
  } catch (error: any) {
    modernLogger.error(`Failed to load event ${file}`, sanitizeErrorForLogging(error));
  }
}
modernLogger.success(`Loaded ${eventCount} events`);

/**
 * Ensures an interaction is deferred to prevent timeout errors
 * @param interaction - The interaction to defer
 * @param options - Optional defer configuration (ephemeral, etc.)
 * @returns true if deferred, false if already replied/deferred
 */
async function ensureDeferred(
  interaction: any,
  options?: { ephemeral?: boolean },
): Promise<boolean> {
  if (interaction.deferred || interaction.replied) {
    return false;
  }

  try {
    await interaction.deferReply(options);
    return true;
  } catch (error) {
    return false;
  }
}

client.on(Events.InteractionCreate, async (interaction) => {
  // Handle select menus (saude actions)
  if (interaction.isStringSelectMenu()) {
    if (interaction.customId.startsWith('saude_action_')) {
      await handleSaudeAction(interaction);
    }
    return;
  }

  if (!interaction.isChatInputCommand()) return;

  const command = client.commands.get(interaction.commandName);

  if (!command) {
    modernLogger.warn(`Command ${interaction.commandName} not found`);
    return;
  }

  // Prevent double execution
  if ((interaction as any)._handled) {
    modernLogger.debug(`Interaction already handled for ${interaction.commandName}`);
    return;
  }
  (interaction as any)._handled = true;

  // Detect and save user language automatically
  const { getLocale } = require("./utils/i18n");
  getLocale(interaction);

  // Performance monitoring - start timer
  const commandStartTime = Date.now();

  // Check cooldown using CooldownManager
  const cooldownAmount = command.cooldown ? command.cooldown * 1000 : 1000;
  const onCooldown = await globalCooldownManager.handleCooldown(
    interaction,
    interaction.commandName,
    cooldownAmount,
  );

  if (onCooldown) {
    return; // CooldownManager already replied to user
  }

  const allowedWhenPunished = [
    "help",
    "ping",
    "inventory",
    "profile",
    "avatar",
    "bounties",
  ];
  if (!allowedWhenPunished.includes(interaction.commandName)) {
    const punishment = isPunished(interaction.user.id);

    if (punishment) {
      const remaining = getRemainingTime(interaction.user.id) || 0;
      return interaction.reply({
        content: `🔒 **You're in jail!**\n\n${punishment.reason}\n\n⏰ Time remaining: **${formatTime(remaining)}**\n\nYou cannot use this command while serving your sentence!\n\n✅ Allowed: /help, /ping, /inventory, /profile, /bounties`,
        flags: MessageFlags.Ephemeral,
      });
    }
  }

  // Auto-defer for commands with autoDefer metadata
  // This prevents "Unknown interaction" errors for commands that take >3 seconds
  if (command.autoDefer) {
    const deferOptions = command.autoDefer.ephemeral
      ? { ephemeral: true }
      : undefined;
    await ensureDeferred(interaction, deferOptions);
  }

  try {
    await command.execute(interaction);

    // Performance monitoring - measure command time
    measureCommandTime(interaction.commandName, commandStartTime);

    if (interaction.guild) {
      const options = interaction.options.data
        .map(
          (opt) =>
            `${opt.name}: ${opt.value || opt.user?.id || opt.channel?.id || "N/A"}`,
        )
        .join(", ");
      Logger.log(client, interaction.guild.id, "command", {
        user: interaction.user,
        command: interaction.commandName,
        channelId: interaction.channel?.id || "DM",
        options: options || "None",
      });
    }
  } catch (error) {
    // Use centralized error handler
    await ErrorHandler.handleCommandError(
      error,
      interaction,
      interaction.commandName,
    );
  }
});

client.on(Events.MessageCreate, async (message) => {
  if (message.author.bot) return;

  // Throttled XP gain - only process once per minute per user to save memory
  if (canGainXp(message.author.id)) {
    const xpAmount = Math.floor(Math.random() * 11) + 15; // 15-25 XP
    const xpResult = addXp(message.author.id, xpAmount);

    if (xpResult.leveledUp) {
      modernLogger.debug(
        `${message.author.tag} has leveled up to level ${xpResult.newLevel}!`,
      );
    }
  }
});

process.on("unhandledRejection", (error: Error) => {
  modernLogger.error("[UNHANDLED REJECTION]", sanitizeErrorForLogging(error));
});

process.on("uncaughtException", (error: Error) => {
  modernLogger.error("[UNCAUGHT EXCEPTION]", sanitizeErrorForLogging(error));
  process.exit(1);
});

client.on("error", (error: Error) => {
  modernLogger.error("[CLIENT ERROR]", sanitizeErrorForLogging(error));
});

client.on("warn", (info: string) => {
  modernLogger.warn(`[CLIENT WARNING] ${info}`);
});

client.on("shardError", (error: Error) => {
  modernLogger.error("[SHARD ERROR]", sanitizeErrorForLogging(error));
});

const token = process.env.DISCORD_TOKEN;

if (!token) {
  modernLogger.error("Discord token not found!");
  modernLogger.error("Configure the DISCORD_TOKEN environment variable");
  process.exit(1);
}

modernLogger.info("Token found, attempting login...");

// Setup production optimizations
modernLogger.section("Production Optimizations");
setupGracefulShutdown(client);
setupMemoryOptimization();
setupPerformanceMonitoring(client);

// Health check endpoint (lazy-loaded only when needed)
if (process.env.ENABLE_HEALTH_CHECK === "true") {
  import("express")
    .then(({ default: express }) => {
      const app = express();

      app.get("/health", (req: any, res: any) => {
        const status = healthCheck.getStatus();
        const metrics = performanceMonitor.getMetrics();

        res.json({
          status: status.healthy ? "healthy" : "unhealthy",
          uptime: performanceMonitor.getUptime(),
          memory: performanceMonitor.getMemoryUsage(),
          guilds: client.guilds.cache.size,
          users: client.users.cache.size,
          metrics: metrics,
          errors: status.errors,
        });
      });

      const healthPort = process.env.HEALTH_PORT || 3001;
      app.listen(healthPort, () => {
        modernLogger.success(`Health check endpoint running on port ${healthPort}`);
      });
    })
    .catch((err) => {
      modernLogger.error("Failed to load health check server", sanitizeErrorForLogging(err as Error));
    });
}

client
  .login(token)
  .then(() => {
    modernLogger.section("Bot Systems");
    
    // Start automatic territory income system
    modernLogger.info("Starting territory income system");
    startAutomaticTerritoryIncome(client);

    // Start automatic mining notification system
    modernLogger.info("Starting mining notification system");
    startMiningNotifications(client);


    // Start daily rewards scheduler
    modernLogger.info("Starting daily rewards scheduler");
    startDailyRewardsScheduler(client);

    // Start mining event scheduler
    modernLogger.info("Starting mining event scheduler");
    startEventScheduler(client).catch((error) => {
      modernLogger.error("Failed to start event scheduler:", sanitizeErrorForLogging(error as Error));
    });

    // Start bleeding system
    modernLogger.info("Starting bleeding system");
    startBleedingSystem();

    // Start reminder notification system
    modernLogger.info("Starting reminder notification system");
    startReminderSystem(client);

    // Start automatic mute expiration checker
    modernLogger.info("Starting mute expiration checker");
    const { checkExpiredMutes } = require("./utils/muteManager");
    setInterval(() => {
      const expiredKeys = checkExpiredMutes();
      if (expiredKeys.length > 0) {
        modernLogger.debug(`${expiredKeys.length} mute(s) expired and removed`);
      }
    }, 60000); // Check every minute

    healthCheck.markHealthy();
    modernLogger.success("All systems operational!");
  })
  .catch((error: Error) => {
    const sanitizedError = sanitizeErrorForLogging(error);
    modernLogger.error("Login failed", sanitizedError);
    healthCheck.markUnhealthy(`Login failed: ${error.message}`);

    if (error.message.includes("token")) {
      modernLogger.divider();
      modernLogger.warn("TOKEN ERROR - Possible solutions:");
      modernLogger.info("1. Verify the token is correct");
      modernLogger.info("2. Generate a new token at: https://discord.com/developers/applications");
      modernLogger.info("3. Configure DISCORD_TOKEN environment variable");
    }

    if (error.message.includes("intents")) {
      modernLogger.divider();
      modernLogger.warn("INTENTS ERROR - Possible solutions:");
      modernLogger.info("1. Access: https://discord.com/developers/applications");
      modernLogger.info("2. Go to Bot > Privileged Gateway Intents");
      modernLogger.info("3. Enable all options (Presence, Server Members, Message Content)");
    }

    process.exit(1);
  });
