export * from "./ComponentRegistry";
export { componentRegistry } from "./ComponentRegistry";
