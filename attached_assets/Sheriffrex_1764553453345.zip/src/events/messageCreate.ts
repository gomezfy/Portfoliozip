import { Events, Message } from "discord.js";
import { addXp } from "../utils/xpManager";
import { checkAndGrantRewards } from "../utils/levelRewards";
import { canGainXp } from "../utils/messageThrottler";
import { handleRPMessage, isRPChannel, validateRPMessage, RPMessageType, hasAINarration } from "../utils/rpManager";
import { rpAIService } from "../utils/rpAIService";

export const name = Events.MessageCreate;
export const once = false;

export async function execute(message: Message) {
  if (message.author.bot || !message.guild || !message.member) {
    return;
  }

  if (isRPChannel(message.guild.id, message.channel.id)) {
    await handleRPMessage(message);

    if (hasAINarration(message.guild.id, message.channel.id)) {
      const validation = validateRPMessage(message.content);
      if (validation.isValid && validation.type === RPMessageType.ACTION && validation.formattedContent) {
        try {
          const narration = await rpAIService.generateNarration(validation.formattedContent);
          const embed = rpAIService.createNarrationEmbed(
            narration,
            validation.formattedContent,
            message.author.displayName
          );
          await message.reply({ embeds: [embed], allowedMentions: { repliedUser: false } }).catch(() => {});
        } catch (error) {
          console.error("Error generating narration:", error);
        }
      }
    }
  }

  if (canGainXp(message.author.id)) {
    const xpAmount = Math.floor(Math.random() * 11) + 15;
    const result = addXp(message.author.id, xpAmount);

    if (result.leveledUp) {
      try {
        const grantedRoles = await checkAndGrantRewards(
          message.member,
          result.newLevel,
        );

        let replyText = `🎉 Parabéns ${message.author}! Você subiu para o nível **${result.newLevel}**!`;

        if (grantedRoles.length > 0) {
          replyText += `\n🎁 Você ganhou ${grantedRoles.length > 1 ? "os roles" : "o role"}: **${grantedRoles.join(", ")}**!`;
        }

        if ("send" in message.channel) {
          const levelUpMessage = await message.channel.send(replyText);
          setTimeout(() => levelUpMessage.delete().catch(() => {}), 10000);
        }
      } catch (error) {
        console.error("Error handling level up:", error);
      }
    }
  }
}
