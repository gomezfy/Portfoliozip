import {
  Events,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  ActionRowBuilder,
  EmbedBuilder,
  Interaction,
  MessageFlags,
  ButtonBuilder,
  ButtonStyle,
  StringSelectMenuBuilder,
  StringSelectMenuOptionBuilder,
  AttachmentBuilder,
  UserSelectMenuBuilder,
} from "discord.js";
import { handleInteractionError } from "../utils/errors";
import { componentRegistry } from "../interactions";
import { setUserBio, setUserPhrase } from "../utils/profileManager";
import { handleGuildButtons } from "./interaction-handlers/buttons/guildManagement";
import { handleProfileModals } from "./interaction-handlers/modals/profileModals";
import { handleSellButtons } from "./interaction-handlers/buttons/sell";
import {
  getUserBackgrounds,
  purchaseBackground,
  setUserBackground as setBgActive,
  getBackgroundById,
  getRarityEmoji,
  getAllBackgrounds,
  userOwnsBackground,
  getRarityColor,
} from "../utils/backgroundManager";
import {
  getAllFrames,
  getAllFramesTranslated,
  getFrameById,
  userOwnsFrame,
  purchaseFrame,
  setActiveFrame,
  getUserFrames,
  getRarityColor as getFrameRarityColor,
  getRarityEmoji as getFrameRarityEmoji,
} from "../utils/frameManager";
import { getUserGold } from "../utils/dataManager";
import {
  createGuild,
  getUserGuild,
  getPublicGuilds,
  joinGuild,
  leaveGuild,
  approveJoinRequest,
  rejectJoinRequest,
  getRequestById,
  kickMember,
  promoteMember,
  demoteMember,
} from "../utils/guildManager";
import { tUser } from "../utils/i18n";
import path from "path";
import fs from "fs";
import { getSaloonTokenEmoji } from "../utils/customEmojis";
import { getInventory, saveInventory } from "../utils/inventoryManager";

/**
 * ComponentRegistry Integration:
 * 
 * The registry is now integrated and will be checked BEFORE legacy handlers.
 * All shop, carousel, and profile handlers have been migrated to the ComponentRegistry.
 * 
 * ✅ FULLY MIGRATED:
 * - Profile handlers (edit_bio, edit_phrase, change_background, profile_show_public)
 * - Shop entry handlers (shop_backgrounds, shop_frames, change_frame)
 * - Carousel navigation (carousel_*, frame_carousel_*)
 * - Purchase handlers (buy_bg_*, buy_frame_*)
 * 
 * See src/events/interaction-handlers/ for handler implementations.
 */

export = {
  name: Events.InteractionCreate,
  async execute(interaction: Interaction): Promise<void> {
    try {
    if (interaction.isButton()) {
      // Ignore duel, mining, expedition and farm buttons - they are handled by their command collectors
      if (
        interaction.customId.startsWith("duel_") ||
        interaction.customId.startsWith("mine_") ||
        interaction.customId.startsWith("join_mining") ||
        interaction.customId.startsWith("claim_mining") ||
        interaction.customId.startsWith("expedition_") ||
        interaction.customId.startsWith("farm_")
      ) {
        return;
      }

      // Try ComponentRegistry first (migrated handlers)
      const handled = await componentRegistry.handleButton(interaction);
      if (handled) {
        return; // Handler found and executed successfully
      }

      // Try guild management handlers
      const guildHandled = await handleGuildButtons(interaction);
      if (guildHandled) {
        return;
      }

      // Try sell handlers
      if (interaction.customId.startsWith("sell_accept_") || interaction.customId.startsWith("sell_reject_")) {
        await handleSellButtons(interaction);
        return;
      }

      // Fall through to legacy handlers below...
      // ✅ MIGRATED to ComponentRegistry: edit_bio, edit_phrase, change_background, profile_show_public,
      //    shop_backgrounds, shop_frames, change_frame, carousel navigation, purchase handlers
      // ✅ MIGRATED to guildManagement: guild_approve, guild_reject, guild_info, guild_members,
      //    guild_leave, kick_member, promote_member, demote_member


      // Fishing bait selection
      if (interaction.customId.startsWith("fish_bait_")) {
        const { handleFishBaitBasic, handleFishBaitPremium } = await import(
          "./interaction-handlers/buttons/fishingHandlers"
        );
        if (interaction.customId.includes("basic")) {
          await handleFishBaitBasic(interaction);
        } else if (interaction.customId.includes("premium")) {
          await handleFishBaitPremium(interaction);
        }
        return;
      }


      // REMOVED: Guild handlers migrated to guildManagement.ts
      // Guild approve/reject/info/members/leave/kick/promote/demote are now handled by handleGuildButtons()
    }

    // Select Menu Handler
    if (interaction.isStringSelectMenu()) {
      // Ignore farm select menus - they are handled by their command collectors
      if (interaction.customId.startsWith("farm_")) {
        return;
      }

      // Try ComponentRegistry first (migrated handlers)
      const handled = await componentRegistry.handleSelectMenu(interaction);
      if (handled) {
        return; // Handler found and executed successfully
      }

      // Fall through to legacy handlers below...


      // Help Category Select Menu
      if (interaction.customId === "help_category_select") {
        const helpCommandModule = await import("../commands/utility/help");
        const helpCommand = helpCommandModule.default || helpCommandModule;
        if (helpCommand.handleSelectMenu) {
          await helpCommand.handleSelectMenu(interaction);
        }
        return;
      }

      if (interaction.customId === "select_frame") {
        const selectedFrameId = interaction.values[0];

        if (selectedFrameId === "no_frame") {
          // Remove frame
          setActiveFrame(interaction.user.id, null);

          await interaction.update({
            embeds: [
              new EmbedBuilder()
                .setColor("#57F287")
                .setTitle("✅ Moldura Removida")
                .setDescription("Sua moldura foi removida com sucesso! Use `/profile` para ver.")
                .setTimestamp(),
            ],
            components: [],
          });
          return;
        }

        const frame = getFrameById(selectedFrameId);

        if (!frame) {
          await interaction.reply({
            content: "❌ Moldura não encontrada!",
            flags: MessageFlags.Ephemeral,
          });
          return;
        }

        if (!userOwnsFrame(interaction.user.id, selectedFrameId)) {
          await interaction.reply({
            content: "❌ Você não possui esta moldura!",
            flags: MessageFlags.Ephemeral,
          });
          return;
        }

        setActiveFrame(interaction.user.id, selectedFrameId);

        await interaction.update({
          embeds: [
            new EmbedBuilder()
              .setColor("#57F287")
              .setTitle("✅ Moldura Equipada")
              .setDescription(`Você equipou a moldura **${frame.name}**! Use \`/profile\` para ver.`)
              .setTimestamp(),
          ],
          components: [],
        });
      }

      if (interaction.customId === "select_background") {
        const selectedBgId = interaction.values[0];
        const background = getBackgroundById(selectedBgId);

        if (!background) {
          await interaction.reply({
            content: "❌ Background not found!",
            flags: MessageFlags.Ephemeral,
          });
          return;
        }

        const result = setBgActive(interaction.user.id, selectedBgId);

        if (result.success) {
          const embed = new EmbedBuilder()
            .setColor("#57F287")
            .setTitle("✅ Background Changed!")
            .setDescription(result.message)
            .addFields({
              name: "🎨 Active Background",
              value: `${getRarityEmoji(background.rarity)} ${background.name}`,
              inline: false,
            })
            .setFooter({ text: "Use /profile to see your updated card" })
            .setTimestamp();

          await interaction.update({ embeds: [embed], components: [] });
        } else {
          await interaction.reply({
            content: `❌ ${result.message}`,
            flags: MessageFlags.Ephemeral,
          });
        }
      }

      // Guild Member Management Select Menu
      if (interaction.customId === "guild_member_select") {
        const targetId = interaction.values[0];
        const userGuild = getUserGuild(interaction.user.id);

        if (!userGuild) {
          await interaction.reply({
            content: "❌ Você não está mais em uma guilda!",
            flags: MessageFlags.Ephemeral,
          });
          return;
        }

        const userMember = userGuild.members.find(
          (m) => m.userId === interaction.user.id,
        );
        const targetMember = userGuild.members.find(
          (m) => m.userId === targetId,
        );

        if (!userMember || !targetMember) {
          await interaction.reply({
            content: "❌ Membro não encontrado!",
            flags: MessageFlags.Ephemeral,
          });
          return;
        }

        const isLeader = userMember.role === "leader";
        const isCoLeader = userMember.role === "co-leader";

        const roleEmoji =
          targetMember.role === "leader"
            ? "👑"
            : targetMember.role === "co-leader"
              ? "⭐"
              : "🔷";
        const roleName =
          targetMember.role === "leader"
            ? "Líder"
            : targetMember.role === "co-leader"
              ? "Co-líder"
              : "Membro";

        const manageEmbed = new EmbedBuilder()
          .setColor("#5865F2")
          .setTitle(`${roleEmoji} Gerenciar Membro`)
          .setDescription(`**Membro:** <@${targetId}>\n**Cargo:** ${roleName}`)
          .setFooter({ text: "Selecione uma ação abaixo" })
          .setTimestamp();

        const actionButtons = new ActionRowBuilder<ButtonBuilder>();

        // Botão de expulsar (líder e co-líder podem, mas co-líder não pode expulsar outro co-líder)
        if ((isLeader || isCoLeader) && targetMember.role !== "leader") {
          const canKick =
            isLeader || (isCoLeader && targetMember.role !== "co-leader");
          if (canKick) {
            actionButtons.addComponents(
              new ButtonBuilder()
                .setCustomId(`kick_member_${targetId}`)
                .setLabel("🚫 Expulsar")
                .setStyle(ButtonStyle.Danger),
            );
          }
        }

        // Botões de promover/rebaixar (apenas líder)
        if (isLeader) {
          if (targetMember.role === "member") {
            actionButtons.addComponents(
              new ButtonBuilder()
                .setCustomId(`promote_member_${targetId}`)
                .setLabel("⭐ Promover a Co-líder")
                .setStyle(ButtonStyle.Success),
            );
          } else if (targetMember.role === "co-leader") {
            actionButtons.addComponents(
              new ButtonBuilder()
                .setCustomId(`demote_member_${targetId}`)
                .setLabel("🔻 Rebaixar a Membro")
                .setStyle(ButtonStyle.Secondary),
            );
          }
        }

        if (actionButtons.components.length > 0) {
          await interaction.reply({
            embeds: [manageEmbed],
            components: [actionButtons],
            flags: MessageFlags.Ephemeral,
          });
        } else {
          await interaction.reply({
            content: "❌ Você não tem permissão para gerenciar este membro.",
            flags: MessageFlags.Ephemeral,
          });
        }
      }
    }

    // User Select Menu Handler
    if (interaction.isUserSelectMenu()) {
      // Hunt DUO partner selection
      if (interaction.customId.startsWith("hunt_duo_partner_select_")) {
        const userId = interaction.customId.replace("hunt_duo_partner_select_", "");
        
        if (userId !== interaction.user.id) {
          await interaction.reply({
            content: "❌ Este menu não é para você!",
            flags: MessageFlags.Ephemeral,
          });
          return;
        }

        const partner = interaction.users.first();
        if (!partner) {
          await interaction.reply({
            content: "❌ Nenhum parceiro selecionado!",
            flags: MessageFlags.Ephemeral,
          });
          return;
        }

        if (partner.id === userId) {
          await interaction.reply({
            content: "❌ Você não pode caçar consigo mesmo, parceiro!",
            flags: MessageFlags.Ephemeral,
          });
          return;
        }

        if (partner.bot) {
          await interaction.reply({
            content: "❌ Bots não podem caçar, parceiro!",
            flags: MessageFlags.Ephemeral,
          });
          return;
        }

        // Import necessary modules
        const { getItem } = await import("../utils/inventoryManager");
        const { duoHuntSessionManager } = await import("../utils/duoHuntSessionManager");
        const { getEmoji } = await import("../utils/customEmojis");

        // Check if partner has a rifle
        const partnerRifleCount = getItem(partner.id, "rifle_de_caca");
        if (partnerRifleCount === 0) {
          await interaction.update({
            content: `🚫 **Parceiro sem Rifle**\n\n**${partner.username}** não possui um Rifle de Caça!\n\nAmbos os caçadores precisam de rifles para caçar em DUO.`,
            embeds: [],
            components: [],
          });
          return;
        }

        // Check if partner is already in a session
        if (duoHuntSessionManager.getSessionByUser(partner.id)) {
          await interaction.update({
            content: `❌ **Parceiro Ocupado**\n\n**${partner.username}** já está em uma caçada DUO!`,
            embeds: [],
            components: [],
          });
          return;
        }

        // Create duo invite
        const duoSession = duoHuntSessionManager.createInvite(
          userId,
          interaction.user.username,
          partner.id,
          partner.username,
        );

        const inviteEmbed = new EmbedBuilder()
          .setColor("#3b82f6")
          .setTitle(`${getEmoji("cowboy")} Convite de Caçada DUO`)
          .setDescription(
            `**${interaction.user.username}** convidou **${partner.username}** para uma caçada DUO!\n\n` +
            `${getEmoji("timer")} **Duração:** 10 minutos\n` +
            `${getEmoji("rifle_de_caca")} **Requisito:** Ambos precisam de Rifle de Caça\n` +
            `${getEmoji("gift")} **Recompensas:** Compartilhadas entre os caçadores\n\n` +
            `**${partner.username}**, clique no botão abaixo para aceitar!`
          )
          .setFooter({ text: "Convite expira em 2 minutos" })
          .setTimestamp();

        const acceptButton = new ButtonBuilder()
          .setCustomId(`duo_hunt_accept_${duoSession.sessionId}`)
          .setLabel("Aceitar Convite")
          .setStyle(ButtonStyle.Success)
          .setEmoji("✅");

        const cancelButton = new ButtonBuilder()
          .setCustomId(`duo_hunt_cancel_${duoSession.sessionId}`)
          .setLabel("Recusar")
          .setStyle(ButtonStyle.Danger)
          .setEmoji("❌");

        const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
          acceptButton,
          cancelButton,
        );

        await interaction.update({
          content: `<@${partner.id}>`,
          embeds: [inviteEmbed],
          components: [row],
        });
        return;
      }
    }

    if (interaction.isModalSubmit()) {
      // Handle farm plant quantity modal
      if (interaction.customId.startsWith("farm_plant_qty_")) {
        const { handleFarmPlantModal } = await import("./interaction-handlers/modals/farmModals");
        await handleFarmPlantModal(interaction);
        return;
      }

      // Try ComponentRegistry first (migrated handlers)
      const handled = await componentRegistry.handleModal(interaction);
      if (handled) {
        return; // Handler found and executed successfully
      }

      // Try profile modals handler
      const modalHandled = await handleProfileModals(interaction);
      if (modalHandled) {
        return;
      }

      // REMOVED: Modal handlers migrated to profileModals.ts
      // bio_modal, phrase_modal, and guild_create_modal_new are now handled by handleProfileModals()
    }
    } catch (error) {
      if (interaction.isRepliable()) {
        await handleInteractionError(interaction as any, error);
      } else {
        console.error('Error in interaction handler:', error);
      }
    }
  },
};
