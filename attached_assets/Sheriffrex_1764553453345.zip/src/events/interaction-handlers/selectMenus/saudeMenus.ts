import { StringSelectMenuInteraction, MessageFlags, AttachmentBuilder } from 'discord.js';
import { db } from '../../../../server/db';
import { users } from '../../../../shared/schema';
import { eq } from 'drizzle-orm';
import { createHealthCanvas } from '../../../utils/healthCanvasRenderer';

const ACTION_DURATIONS: Record<string, { duration: number; label: string }> = {
  comer: { duration: 10, label: 'Comendo' },
  beber: { duration: 5, label: 'Bebendo' },
  curar: { duration: 15, label: 'Curando' },
  descansar: { duration: 300, label: 'Descansando' },
};

function createProgressBar(current: number, total: number, length: number = 20): string {
  const progress = Math.floor((current / total) * length);
  const empty = length - progress;
  const filled = '█'.repeat(progress);
  const unfilled = '░'.repeat(empty);
  return `[${filled}${unfilled}]`;
}

function formatTime(seconds: number): string {
  if (seconds >= 60) {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return secs > 0 ? `${mins}m ${secs}s` : `${mins}m`;
  }
  return `${seconds}s`;
}

async function runProgressBar(
  interaction: StringSelectMenuInteraction,
  action: string,
  userId: string,
  onComplete: () => Promise<string>
): Promise<void> {
  const config = ACTION_DURATIONS[action];
  if (!config) return;

  const { duration, label } = config;
  const updateInterval = duration <= 15 ? 1 : 5;
  let elapsed = 0;

  const progressBar = createProgressBar(elapsed, duration);
  const timeLeft = formatTime(duration - elapsed);
  
  await interaction.reply({
    content: `**${label}...**\n${progressBar} ${timeLeft}`,
    flags: MessageFlags.Ephemeral,
  });

  const interval = setInterval(async () => {
    elapsed += updateInterval;
    
    if (elapsed >= duration) {
      clearInterval(interval);
      
      try {
        const resultMessage = await onComplete();
        const finalBar = createProgressBar(duration, duration);
        await interaction.editReply({
          content: `**${label}... Concluido**\n${finalBar}\n\n${resultMessage}`,
        });

        const updatedUser = await db
          .select()
          .from(users)
          .where(eq(users.userId, userId))
          .limit(1);

        if (updatedUser && updatedUser.length > 0) {
          const user = updatedUser[0];
          const canvasBuffer = await createHealthCanvas({
            health: user.health,
            maxHealth: user.maxHealth,
            stamina: user.stamina,
            maxStamina: user.maxStamina,
            thirst: user.thirst,
            maxThirst: user.maxThirst,
            hunger: user.hunger,
            maxHunger: user.maxHunger,
            blood: user.blood,
            maxBlood: user.maxBlood,
            temperature: user.temperature,
            username: interaction.user.username,
          });

          const attachment = new AttachmentBuilder(canvasBuffer, { name: 'health.png' });

          try {
            await interaction.message.edit({
              files: [attachment],
            });
          } catch (editError) {
            console.error('Could not update original message:', editError);
          }
        }
      } catch (error) {
        console.error('Error completing action:', error);
        await interaction.editReply({
          content: `Erro ao completar acao.`,
        });
      }
    } else {
      const progressBar = createProgressBar(elapsed, duration);
      const timeLeft = formatTime(duration - elapsed);
      
      try {
        await interaction.editReply({
          content: `**${label}...**\n${progressBar} ${timeLeft}`,
        });
      } catch (error) {
        clearInterval(interval);
      }
    }
  }, updateInterval * 1000);
}

export async function handleSaudeSelectMenu(interaction: StringSelectMenuInteraction): Promise<void> {
  const customId = interaction.customId;
  
  if (!customId.startsWith('saude_action_')) return;

  const targetUserId = customId.split('_')[2];
  
  if (interaction.user.id !== targetUserId) {
    await interaction.reply({
      content: 'Voce nao pode usar este menu.',
      flags: MessageFlags.Ephemeral,
    });
    return;
  }

  const action = interaction.values[0];

  try {
    const userStats = await db
      .select()
      .from(users)
      .where(eq(users.userId, interaction.user.id))
      .limit(1);

    if (!userStats || userStats.length === 0) {
      await interaction.reply({
        content: 'Usuario nao encontrado.',
        flags: MessageFlags.Ephemeral,
      });
      return;
    }

    const user = userStats[0];

    switch (action) {
      case 'comer': {
        if (user.hunger >= user.maxHunger) {
          await interaction.reply({
            content: 'Voce ja esta satisfeito, nao precisa comer agora.',
            flags: MessageFlags.Ephemeral,
          });
          return;
        }
        
        await runProgressBar(interaction, 'comer', interaction.user.id, async () => {
          const hungerRestore = Math.min(25, user.maxHunger - user.hunger);
          await db
            .update(users)
            .set({ hunger: user.hunger + hungerRestore })
            .where(eq(users.userId, interaction.user.id));
          return `Voce comeu e recuperou ${hungerRestore} de fome.`;
        });
        break;
      }

      case 'beber': {
        if (user.thirst >= user.maxThirst) {
          await interaction.reply({
            content: 'Voce ja esta hidratado, nao precisa beber agora.',
            flags: MessageFlags.Ephemeral,
          });
          return;
        }

        await runProgressBar(interaction, 'beber', interaction.user.id, async () => {
          const thirstRestore = Math.min(25, user.maxThirst - user.thirst);
          await db
            .update(users)
            .set({ thirst: user.thirst + thirstRestore })
            .where(eq(users.userId, interaction.user.id));
          return `Voce bebeu agua e recuperou ${thirstRestore} de sede.`;
        });
        break;
      }

      case 'curar': {
        if (user.health >= user.maxHealth) {
          await interaction.reply({
            content: 'Voce ja esta com a saude cheia.',
            flags: MessageFlags.Ephemeral,
          });
          return;
        }

        await runProgressBar(interaction, 'curar', interaction.user.id, async () => {
          const healthRestore = Math.min(30, user.maxHealth - user.health);
          await db
            .update(users)
            .set({ health: user.health + healthRestore })
            .where(eq(users.userId, interaction.user.id));
          return `Voce se curou e recuperou ${healthRestore} de vida.`;
        });
        break;
      }

      case 'descansar': {
        if (user.stamina >= user.maxStamina) {
          await interaction.reply({
            content: 'Voce ja esta descansado.',
            flags: MessageFlags.Ephemeral,
          });
          return;
        }

        await runProgressBar(interaction, 'descansar', interaction.user.id, async () => {
          const staminaRestore = Math.min(50, user.maxStamina - user.stamina);
          await db
            .update(users)
            .set({ stamina: user.stamina + staminaRestore })
            .where(eq(users.userId, interaction.user.id));
          return `Voce descansou e recuperou ${staminaRestore} de stamina.`;
        });
        break;
      }

      default:
        await interaction.reply({
          content: 'Acao desconhecida.',
          flags: MessageFlags.Ephemeral,
        });
    }
  } catch (error) {
    console.error('Error handling saude menu:', error);
    if (!interaction.replied && !interaction.deferred) {
      await interaction.reply({
        content: 'Erro ao processar acao. Tente novamente.',
        flags: MessageFlags.Ephemeral,
      });
    }
  }
}
