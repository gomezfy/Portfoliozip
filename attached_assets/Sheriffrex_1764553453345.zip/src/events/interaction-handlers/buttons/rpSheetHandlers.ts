import {
  ButtonInteraction,
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  MessageFlags,
} from "discord.js";
import { db } from "../../../../server/db";
import { characterSheets } from "../../../../shared/schema";
import { eq, and } from "drizzle-orm";

const Colors = {
  SUCCESS: 0x10b981,
  ERROR: 0xef4444,
  WARNING: 0xf59e0b,
  INFO: 0x3b82f6,
  CHARACTER: 0x8b4513,
} as const;

export async function handleRpEditSheet(interaction: ButtonInteraction) {
  const sheetId = interaction.customId.replace("rp_edit_sheet_", "");

  try {
    const sheets = await db
      .select()
      .from(characterSheets)
      .where(
        and(
          eq(characterSheets.id, sheetId),
          eq(characterSheets.userId, interaction.user.id)
        )
      );

    if (sheets.length === 0) {
      await interaction.reply({
        content: "❌ Ficha não encontrada ou você não tem permissão para editá-la.",
        flags: MessageFlags.Ephemeral,
      });
      return;
    }

    const sheet = sheets[0];

    const modal = new ModalBuilder()
      .setCustomId(`rp_edit_modal_${sheetId}`)
      .setTitle(`Editar: ${sheet.name.substring(0, 30)}`);

    const nameInput = new TextInputBuilder()
      .setCustomId("name")
      .setLabel("Nome do Personagem")
      .setStyle(TextInputStyle.Short)
      .setValue(sheet.name)
      .setMaxLength(50)
      .setRequired(true);

    const descriptionInput = new TextInputBuilder()
      .setCustomId("description")
      .setLabel("Descrição")
      .setStyle(TextInputStyle.Paragraph)
      .setValue(sheet.description || "")
      .setMaxLength(200)
      .setRequired(true);

    const appearanceInput = new TextInputBuilder()
      .setCustomId("appearance")
      .setLabel("Aparência")
      .setStyle(TextInputStyle.Paragraph)
      .setValue(sheet.appearance || "")
      .setMaxLength(300)
      .setRequired(false);

    const personalityInput = new TextInputBuilder()
      .setCustomId("personality")
      .setLabel("Personalidade")
      .setStyle(TextInputStyle.Paragraph)
      .setValue(sheet.personality || "")
      .setMaxLength(300)
      .setRequired(false);

    const backstoryInput = new TextInputBuilder()
      .setCustomId("backstory")
      .setLabel("História")
      .setStyle(TextInputStyle.Paragraph)
      .setValue(sheet.backstory || "")
      .setMaxLength(500)
      .setRequired(false);

    modal.addComponents(
      new ActionRowBuilder<TextInputBuilder>().addComponents(nameInput),
      new ActionRowBuilder<TextInputBuilder>().addComponents(descriptionInput),
      new ActionRowBuilder<TextInputBuilder>().addComponents(appearanceInput),
      new ActionRowBuilder<TextInputBuilder>().addComponents(personalityInput),
      new ActionRowBuilder<TextInputBuilder>().addComponents(backstoryInput)
    );

    await interaction.showModal(modal);
  } catch (error) {
    console.error("Error showing edit modal:", error);
    await interaction.reply({
      content: "❌ Erro ao abrir o editor de ficha.",
      flags: MessageFlags.Ephemeral,
    });
  }
}

export async function handleRpDeleteSheet(interaction: ButtonInteraction) {
  const sheetId = interaction.customId.replace("rp_delete_sheet_", "");

  try {
    const sheets = await db
      .select()
      .from(characterSheets)
      .where(
        and(
          eq(characterSheets.id, sheetId),
          eq(characterSheets.userId, interaction.user.id)
        )
      );

    if (sheets.length === 0) {
      await interaction.reply({
        content: "❌ Ficha não encontrada ou você não tem permissão para deletá-la.",
        flags: MessageFlags.Ephemeral,
      });
      return;
    }

    const sheet = sheets[0];

    const embed = new EmbedBuilder()
      .setColor(Colors.WARNING)
      .setTitle("⚠️ Confirmar Exclusão")
      .setDescription(`Você tem certeza que deseja excluir a ficha **${sheet.name}**?\n\nEsta ação não pode ser desfeita!`)
      .setTimestamp();

    const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
      new ButtonBuilder()
        .setCustomId(`rp_confirm_delete_${sheetId}`)
        .setLabel("🗑️ Sim, Excluir")
        .setStyle(ButtonStyle.Danger),
      new ButtonBuilder()
        .setCustomId(`rp_cancel_delete_${sheetId}`)
        .setLabel("❌ Cancelar")
        .setStyle(ButtonStyle.Secondary)
    );

    await interaction.reply({
      embeds: [embed],
      components: [row],
      flags: MessageFlags.Ephemeral,
    });
  } catch (error) {
    console.error("Error showing delete confirmation:", error);
    await interaction.reply({
      content: "❌ Erro ao processar exclusão.",
      flags: MessageFlags.Ephemeral,
    });
  }
}

export async function handleRpConfirmDelete(interaction: ButtonInteraction) {
  const sheetId = interaction.customId.replace("rp_confirm_delete_", "");

  try {
    const result = await db
      .delete(characterSheets)
      .where(
        and(
          eq(characterSheets.id, sheetId),
          eq(characterSheets.userId, interaction.user.id)
        )
      )
      .returning();

    if (result.length === 0) {
      await interaction.update({
        content: "❌ Ficha não encontrada ou já foi excluída.",
        embeds: [],
        components: [],
      });
      return;
    }

    const embed = new EmbedBuilder()
      .setColor(Colors.SUCCESS)
      .setTitle("✅ Ficha Excluída")
      .setDescription(`A ficha **${result[0].name}** foi excluída com sucesso.`)
      .setTimestamp();

    await interaction.update({
      embeds: [embed],
      components: [],
    });
  } catch (error) {
    console.error("Error deleting sheet:", error);
    await interaction.update({
      content: "❌ Erro ao excluir ficha.",
      embeds: [],
      components: [],
    });
  }
}

export async function handleRpCancelDelete(interaction: ButtonInteraction) {
  await interaction.update({
    content: "❌ Exclusão cancelada.",
    embeds: [],
    components: [],
  });
}
