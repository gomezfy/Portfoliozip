import { ButtonInteraction, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, MessageFlags } from "discord.js";
import { rpAIService } from "../../../utils/rpAIService";

const rpaiContextStore = new Map<string, { action: string; context?: string; situation?: string; character?: string }>();

export function setRpaiContext(
  interactionId: string,
  data: { action?: string; context?: string; situation?: string; character?: string }
) {
  rpaiContextStore.set(interactionId, data as any);
  setTimeout(() => rpaiContextStore.delete(interactionId), 300000);
}

export async function handleRpaiRenarrate(interaction: ButtonInteraction) {
  const userId = interaction.customId.split("_").pop();
  if (interaction.user.id !== userId) {
    await interaction.reply({
      content: "❌ Apenas quem usou o comando pode usar este botão.",
      flags: MessageFlags.Ephemeral,
    });
    return;
  }

  await interaction.deferUpdate();

  try {
    const contextData = rpaiContextStore.get(interaction.message.interaction?.id || "");
    const action = contextData?.action || "ação desconhecida";
    const context = contextData?.context;

    const newNarration = await rpAIService.generateNarration(action, context);
    const newEmbed = rpAIService.createNarrationEmbed(
      newNarration,
      action,
      interaction.user.displayName
    );

    const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
      new ButtonBuilder()
        .setCustomId(`rpai_renarrate_${interaction.user.id}`)
        .setLabel("🔄 Gerar Nova Narração")
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId(`rpai_use_${interaction.user.id}`)
        .setLabel("✅ Usar Esta Narração")
        .setStyle(ButtonStyle.Success)
    );

    await interaction.editReply({ embeds: [newEmbed], components: [row] });
  } catch (error) {
    await interaction.editReply({
      content: "❌ Erro ao gerar nova narração. Tente novamente.",
      embeds: [],
      components: [],
    });
  }
}

export async function handleRpaiUse(interaction: ButtonInteraction) {
  const userId = interaction.customId.split("_").pop();
  if (interaction.user.id !== userId) {
    await interaction.reply({
      content: "❌ Apenas quem usou o comando pode usar este botão.",
      flags: MessageFlags.Ephemeral,
    });
    return;
  }

  await interaction.update({
    components: [],
  });
}

export async function handleRpaiNewSuggest(interaction: ButtonInteraction) {
  const userId = interaction.customId.split("_").pop();
  if (interaction.user.id !== userId) {
    await interaction.reply({
      content: "❌ Apenas quem usou o comando pode usar este botão.",
      flags: MessageFlags.Ephemeral,
    });
    return;
  }

  await interaction.deferUpdate();

  try {
    const contextData = rpaiContextStore.get(interaction.message.interaction?.id || "");
    const situation = contextData?.situation || "situação desconhecida";
    const character = contextData?.character;

    const newSuggestions = await rpAIService.generateSuggestions(situation, character);
    const newEmbed = rpAIService.createSuggestionEmbed(newSuggestions, situation);

    const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
      new ButtonBuilder()
        .setCustomId(`rpai_newsuggest_${interaction.user.id}`)
        .setLabel("🔄 Novas Sugestões")
        .setStyle(ButtonStyle.Secondary)
    );

    await interaction.editReply({ embeds: [newEmbed], components: [row] });
  } catch (error) {
    await interaction.editReply({
      content: "❌ Erro ao gerar novas sugestões.",
      embeds: [],
      components: [],
    });
  }
}

export async function handleRpaiContinue(interaction: ButtonInteraction) {
  const parts = interaction.customId.split("_");
  const userId = parts.pop();
  
  if (interaction.user.id !== userId) {
    await interaction.reply({
      content: "❌ Apenas quem usou o comando pode usar este botão.",
      flags: MessageFlags.Ephemeral,
    });
    return;
  }

  await interaction.reply({
    content: "💬 Para continuar a conversa, use `/rpai npc` novamente com sua próxima mensagem!",
    flags: MessageFlags.Ephemeral,
  });
}

export async function handleRpaiEndNpc(interaction: ButtonInteraction) {
  const parts = interaction.customId.split("_");
  const userId = parts.pop();
  const npcType = parts[2];
  
  if (interaction.user.id !== userId) {
    await interaction.reply({
      content: "❌ Apenas quem usou o comando pode usar este botão.",
      flags: MessageFlags.Ephemeral,
    });
    return;
  }

  rpAIService.clearConversation(interaction.channelId, npcType);
  
  await interaction.update({
    components: [],
  });
  
  await interaction.followUp({
    content: "👋 Conversa encerrada! O histórico foi limpo.",
    flags: MessageFlags.Ephemeral,
  });
}
