import { ButtonInteraction, EmbedBuilder, MessageFlags } from "discord.js";
import fs from "fs";
import path from "path";
import { successEmbed, errorEmbed } from "../../../utils/embeds";
import { getItem, addItem, removeItem } from "../../../utils/inventoryManager";
import { getUserSilver, addUserSilver, removeUserSilver } from "../../../utils/dataManager";
import { trackSellAction, trackEarning } from "../../../utils/missionTracker";
import {
  getSilverCoinEmoji,
  getSaloonTokenEmoji,
  getGoldBarEmoji,
  getDiamondEmoji,
  getPickaxeEmoji,
  getCheckEmoji,
  getCancelEmoji,
} from "../../../utils/customEmojis";

const getDataPath = (file: string) => path.join(process.cwd(), "replit-data", file);

function ensureDataDir() {
  const dir = path.join(process.cwd(), "replit-data");
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
}

function getPendingOffers() {
  ensureDataDir();
  const filePath = getDataPath("pending_offers.json");
  if (!fs.existsSync(filePath)) {
    fs.writeFileSync(filePath, JSON.stringify({}, null, 2));
    return {};
  }
  try {
    return JSON.parse(fs.readFileSync(filePath, "utf-8"));
  } catch {
    return {};
  }
}

function savePendingOffers(data: any) {
  ensureDataDir();
  const filePath = getDataPath("pending_offers.json");
  fs.writeFileSync(filePath, JSON.stringify(data, null, 2));
}

function getItemEmoji(itemId: string): string {
  if (itemId === "saloon_token") return getSaloonTokenEmoji();
  if (itemId === "silver") return getSilverCoinEmoji();
  if (itemId === "gold") return getGoldBarEmoji();
  if (itemId === "diamond") return getDiamondEmoji();
  if (itemId === "pickaxe") return getPickaxeEmoji();
  return "📦";
}

export async function handleSellButtons(interaction: ButtonInteraction) {
  const customId = interaction.customId;

  if (customId.startsWith("sell_accept_")) {
    const offerId = customId.replace("sell_accept_", "");
    const offers = getPendingOffers();
    const offer = offers[offerId];

    if (!offer) {
      await interaction.reply({
        embeds: [errorEmbed("❌ Oferta Expirada", "Esta oferta não existe mais.")],
        flags: MessageFlags.Ephemeral,
      });
      return;
    }

    // Verificar se é o comprador correto
    if (interaction.user.id !== offer.buyer) {
      await interaction.reply({
        embeds: [errorEmbed("❌ Erro", "Apenas o comprador pode aceitar esta oferta.")],
        flags: MessageFlags.Ephemeral,
      });
      return;
    }

    await interaction.deferReply({ ephemeral: true });

    // Verificar saldo do comprador
    const buyerBalance = getUserSilver(offer.buyer);
    if (buyerBalance < offer.price) {
      await interaction.editReply({
        embeds: [
          errorEmbed(
            "❌ Saldo Insuficiente",
            `Você precisa de ${getSilverCoinEmoji()} ${offer.price.toLocaleString()}, mas tem apenas ${getSilverCoinEmoji()} ${buyerBalance.toLocaleString()}`
          ),
        ],
      });
      return;
    }

    // Verificar se vendedor ainda tem o item
    let sellerStillHasItem = false;
    if (offer.item === "silver") {
      sellerStillHasItem = getUserSilver(offer.seller) >= offer.amount;
    } else {
      sellerStillHasItem = getItem(offer.seller, offer.item) >= offer.amount;
    }

    if (!sellerStillHasItem) {
      await interaction.editReply({
        embeds: [errorEmbed("❌ Vendedor sem Item", "O vendedor não tem mais este item.")],
      });
      delete offers[offerId];
      savePendingOffers(offers);
      return;
    }

    // Executar transação
    try {
      // Remover item do vendedor
      if (offer.item === "silver") {
        await removeUserSilver(offer.seller, offer.amount);
      } else {
        await removeItem(offer.seller, offer.item, offer.amount);
      }

      // Adicionar item ao comprador
      if (offer.item === "silver") {
        await addUserSilver(offer.buyer, offer.amount);
      } else {
        await addItem(offer.buyer, offer.item, offer.amount);
      }

      // Remover prata do comprador
      await removeUserSilver(offer.buyer, offer.price);

      // Adicionar prata ao vendedor
      await addUserSilver(offer.seller, offer.price);

      // Remover oferta
      delete offers[offerId];
      savePendingOffers(offers);
      
      // Track sell mission for seller
      const sellerUser = await interaction.client.users.fetch(offer.seller).catch(() => null);
      trackSellAction(offer.seller, sellerUser?.username || "Unknown");
      trackEarning(offer.seller, sellerUser?.username || "Unknown", offer.price);

      // Emojis
      const itemEmoji = getItemEmoji(offer.item);

      // Resposta ao comprador
      const successMsg = new EmbedBuilder()
        .setColor(0x00ff00)
        .setTitle(`${getCheckEmoji()} Compra Realizada!`)
        .setDescription(`Você comprou **${offer.amount}x ${itemEmoji}** por **${offer.price}** ${getSilverCoinEmoji()}`)
        .addFields(
          { name: "Item", value: `${itemEmoji} ${offer.amount}x`, inline: true },
          { name: "Preço Pago", value: `${getSilverCoinEmoji()} ${offer.price.toLocaleString()}`, inline: true }
        )
        .setFooter({ text: "Transação completa!" });

      await interaction.editReply({ embeds: [successMsg] });

      // Notificar vendedor (se possível)
      try {
        const seller = await interaction.client.users.fetch(offer.seller);
        const sellerMsg = new EmbedBuilder()
          .setColor(0x00ff00)
          .setTitle(`${getCheckEmoji()} Venda Realizada!`)
          .setDescription(`<@${offer.buyer}> comprou **${offer.amount}x ${itemEmoji}** por **${offer.price}** ${getSilverCoinEmoji()}`)
          .addFields(
            { name: "Item Vendido", value: `${itemEmoji} ${offer.amount}x`, inline: true },
            { name: "Preço Recebido", value: `${getSilverCoinEmoji()} ${offer.price.toLocaleString()}`, inline: true }
          )
          .setFooter({ text: "Transação completa!" });

        await seller.send({ embeds: [sellerMsg] });
      } catch {
        // Vendedor tem DMs desativadas
      }
    } catch (error: any) {
      await interaction.editReply({
        embeds: [errorEmbed("❌ Erro na Transação", error?.message || "Erro ao processar a venda.")],
      });
    }

    return;
  }

  if (customId.startsWith("sell_reject_")) {
    const offerId = customId.replace("sell_reject_", "");
    const offers = getPendingOffers();
    const offer = offers[offerId];

    if (!offer) {
      await interaction.reply({
        embeds: [errorEmbed("❌ Oferta Expirada", "Esta oferta não existe mais.")],
        flags: MessageFlags.Ephemeral,
      });
      return;
    }

    // Verificar se é o comprador correto
    if (interaction.user.id !== offer.buyer) {
      await interaction.reply({
        embeds: [errorEmbed("❌ Erro", "Apenas o comprador pode rejeitar esta oferta.")],
        flags: MessageFlags.Ephemeral,
      });
      return;
    }

    // Remover oferta
    delete offers[offerId];
    savePendingOffers(offers);

    const rejectMsg = new EmbedBuilder()
      .setColor(0xff0000)
      .setTitle(`${getCancelEmoji()} Oferta Rejeitada`)
      .setDescription("Você rejeitou esta oferta de venda.")
      .setFooter({ text: "Oferta cancelada" });

    await interaction.reply({ embeds: [rejectMsg], flags: MessageFlags.Ephemeral });

    // Notificar vendedor
    try {
      const seller = await interaction.client.users.fetch(offer.seller);
      const itemEmoji = getItemEmoji(offer.item);
      const sellerMsg = new EmbedBuilder()
        .setColor(0xff0000)
        .setTitle(`${getCancelEmoji()} Oferta Rejeitada`)
        .setDescription(`<@${offer.buyer}> rejeitou sua oferta de venda de **${offer.amount}x ${itemEmoji}**`)
        .setFooter({ text: "Oferta cancelada" });

      await seller.send({ embeds: [sellerMsg] });
    } catch {
      // Vendedor tem DMs desativadas
    }
  }
}
