import { ModalSubmitInteraction, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, MessageFlags } from "discord.js";
import { db } from "../../../../server/db";
import { characterSheets } from "../../../../shared/schema";
import { eq, and } from "drizzle-orm";

const Colors = {
  SUCCESS: 0x10b981,
  ERROR: 0xef4444,
  CHARACTER: 0x8b4513,
} as const;

export async function handleRpEditModal(interaction: ModalSubmitInteraction) {
  const sheetId = interaction.customId.replace("rp_edit_modal_", "");

  await interaction.deferReply({ ephemeral: true });

  try {
    const name = interaction.fields.getTextInputValue("name");
    const description = interaction.fields.getTextInputValue("description");
    const appearance = interaction.fields.getTextInputValue("appearance") || null;
    const personality = interaction.fields.getTextInputValue("personality") || null;
    const backstory = interaction.fields.getTextInputValue("backstory") || null;

    const result = await db
      .update(characterSheets)
      .set({
        name,
        description,
        appearance,
        personality,
        backstory,
        updatedAt: new Date(),
      })
      .where(
        and(
          eq(characterSheets.id, sheetId),
          eq(characterSheets.userId, interaction.user.id)
        )
      )
      .returning();

    if (result.length === 0) {
      await interaction.editReply({
        content: "❌ Ficha não encontrada ou você não tem permissão para editá-la.",
      });
      return;
    }

    const updatedSheet = result[0];
    const skills = (updatedSheet.skills as string[]) || [];
    const traits = (updatedSheet.traits as string[]) || [];

    const embed = new EmbedBuilder()
      .setColor(Colors.CHARACTER)
      .setTitle(`📋 ${updatedSheet.name}`)
      .setDescription(updatedSheet.description || "Sem descrição")
      .setThumbnail(interaction.user.displayAvatarURL())
      .setTimestamp();

    if (updatedSheet.appearance) {
      embed.addFields({ name: "👤 Aparência", value: updatedSheet.appearance, inline: false });
    }

    if (updatedSheet.personality) {
      embed.addFields({ name: "🎭 Personalidade", value: updatedSheet.personality, inline: false });
    }

    if (updatedSheet.backstory) {
      embed.addFields({ name: "📖 História", value: updatedSheet.backstory.substring(0, 1000), inline: false });
    }

    if (skills.length > 0) {
      embed.addFields({ name: "⚔️ Habilidades", value: skills.join(", "), inline: true });
    }

    if (traits.length > 0) {
      embed.addFields({ name: "✨ Traços", value: traits.join(", "), inline: true });
    }

    embed.setFooter({ text: `✅ Ficha atualizada! | ID: ${updatedSheet.id.substring(0, 8)}` });

    const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
      new ButtonBuilder()
        .setCustomId(`rp_edit_sheet_${updatedSheet.id}`)
        .setLabel("✏️ Editar")
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId(`rp_delete_sheet_${updatedSheet.id}`)
        .setLabel("🗑️ Deletar")
        .setStyle(ButtonStyle.Danger)
    );

    await interaction.editReply({ embeds: [embed], components: [row] });
  } catch (error) {
    console.error("Error updating sheet:", error);
    await interaction.editReply({
      content: "❌ Erro ao atualizar ficha de personagem.",
    });
  }
}
