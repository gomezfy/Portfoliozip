import { ModalSubmitInteraction, EmbedBuilder, MessageFlags } from "discord.js";
import { getItem, removeItem, addItem } from "../../../utils/inventoryManager";
import {
  CROP_TYPES,
  plantCrop,
  formatDuration,
} from "../../../utils/farmManager";

export async function handleFarmPlantModal(interaction: ModalSubmitInteraction): Promise<void> {
  try {
    const userId = interaction.user.id;
    const cropType = interaction.customId.replace("farm_plant_qty_", "");
    const quantityStr = interaction.fields.getTextInputValue("plant_quantity");
    const quantity = parseInt(quantityStr);
    const cropInfo = CROP_TYPES[cropType as keyof typeof CROP_TYPES];

    if (!cropInfo) {
      await interaction.reply({ 
        content: "❌ Plantação inválida.", 
        flags: MessageFlags.Ephemeral 
      });
      return;
    }

    if (isNaN(quantity) || quantity < 1) {
      await interaction.reply({ 
        content: "❌ Quantidade inválida. Digite um número válido.", 
        flags: MessageFlags.Ephemeral 
      });
      return;
    }

    const MAX_PLANT_PER_ACTION = 100;
    if (quantity > MAX_PLANT_PER_ACTION) {
      await interaction.reply({ 
        content: `❌ Você pode plantar no máximo **${MAX_PLANT_PER_ACTION}** plantas por vez.`, 
        flags: MessageFlags.Ephemeral 
      });
      return;
    }

    const totalCost = cropInfo.buyCost * quantity;
    const userSilver = getItem(userId, "silver");

    if (userSilver < totalCost) {
      await interaction.reply({
        embeds: [new EmbedBuilder()
          .setTitle("❌ Prata Insuficiente")
          .setColor(0xFF0000)
          .setDescription(`Você precisa de **${totalCost}** prata para plantar ${quantity}x ${cropInfo.name}.\nVocê tem: **${userSilver}** prata`)],
        flags: MessageFlags.Ephemeral
      });
      return;
    }

    removeItem(userId, "silver", totalCost);

    const result = plantCrop(userId, cropType as keyof typeof CROP_TYPES, quantity);
    
    if (!result.success) {
      addItem(userId, "silver", totalCost);
      await interaction.reply({
        embeds: [new EmbedBuilder()
          .setTitle("❌ Erro ao Plantar")
          .setColor(0xFF0000)
          .setDescription(result.error || "Não foi possível plantar")],
        flags: MessageFlags.Ephemeral
      });
      return;
    }

    const actualCost = totalCost;
    const embed = new EmbedBuilder()
      .setTitle(`🌱 Plantações Criadas!`)
      .setColor(0x228B22)
      .setDescription(`Você plantou **${quantity}x ${cropInfo.name}**!\n\nCusto total: **${actualCost}** prata`)
      .addFields(
        { name: "⏰ Tempo de Crescimento", value: formatDuration(cropInfo.growTime), inline: true },
        { name: "🌾 Rendimento por Plantação", value: `${cropInfo.yield} unidades`, inline: true }
      )
      .setFooter({ text: "Volte depois para colher!" });

    await interaction.reply({
      embeds: [embed],
      flags: MessageFlags.Ephemeral
    });
  } catch (error) {
    console.error("Farm plant modal error:", error);
    try {
      if (!interaction.replied && !interaction.deferred) {
        await interaction.reply({
          content: "❌ Ocorreu um erro ao plantar. Tente novamente.",
          flags: MessageFlags.Ephemeral
        });
      }
    } catch {}
  }
}
