import { Events, Client, ActivityType } from "discord.js";
import { backupManager } from "../utils/backupManager";
import logger from "../utils/consoleLogger";
import { registerAllHandlers } from "./interaction-handlers/registerHandlers";
import { preloadCommonAssets } from "../utils/canvasCache";
import { startTimePassageSystem } from "../utils/rpHealthService";
import { BotClient } from "../types";

export = {
  name: Events.ClientReady,
  once: true,
  async execute(client: Client): Promise<void> {
    // Display beautiful ready message
    logger.ready(
      client.user?.tag || "Unknown",
      client.guilds.cache.size,
      client.users.cache.size
    );

    // Sync slash commands with Discord (skip if Entry Point is configured)
    logger.info("Syncing slash commands with Discord...");
    try {
      const botClient = client as unknown as BotClient;
      const commandsData = Array.from(botClient.commands.values()).map(cmd => cmd.data.toJSON());
      
      if (!client.application) {
        throw new Error("Application not available");
      }
      
      // Fetch existing commands to preserve Entry Point
      const existingCommands = await client.application.commands.fetch();
      const entryPointCommand = existingCommands.find(cmd => cmd.type === 4); // Type 4 = Primary Entry Point
      
      if (entryPointCommand) {
        // If Entry Point exists, add it to our commands to preserve it
        logger.info("Entry Point detected, preserving it during sync...");
        commandsData.push(entryPointCommand.toJSON() as any);
      }
      
      await client.application.commands.set(commandsData);
      logger.success(`✅ Synced ${commandsData.length} slash commands with Discord`);
    } catch (error: any) {
      // If it's the Entry Point error, log a warning instead of error
      if (error.code === 50240) {
        logger.warn("⚠️ Skipping auto-sync due to Entry Point configuration. Use 'npm run deploy' to update commands manually.");
      } else {
        logger.error("Failed to sync slash commands", error);
      }
    }

    // Register component handlers
    logger.info("Registering component handlers");
    registerAllHandlers();
    
    // Start automatic backups
    logger.info("Starting automatic backup system");
    backupManager.startAutomaticBackups();
    logger.success("Backup system initialized");

    // Pre-load common Canvas assets para performance
    logger.info("Pre-loading Canvas assets cache (iOS-like optimization)");
    preloadCommonAssets().catch(error => {
      logger.warn("Failed to preload some Canvas assets:", error);
    });

    // Start time passage system for RP health effects
    logger.info("Starting RP time passage system");
    startTimePassageSystem(client);
    logger.success("RP time passage system initialized (hourly updates)");

    let currentIndex = 0;

    const updateStatus = () => {
      const totalUsers = client.guilds.cache.reduce((acc, guild) => acc + guild.memberCount, 0);
      
      const totalServers = client.guilds.cache.size;
      
      const statusActivities = [
        { name: `${totalServers} Cidades Com Sheriff No Comando`, type: ActivityType.Custom, state: `${totalServers} Cidades Com Sheriff No Comando 🤠` },
        { name: "Use /missoes", type: ActivityType.Custom, state: "Use /missoes 📜" },
        { name: "Use /help", type: ActivityType.Custom, state: "Use /help 🆘" },
        { name: "Sheriff Rex do Velho Oeste", type: ActivityType.Custom, state: "Sheriff Rex do Velho Oeste 🌵" },
      ];

      const activity = statusActivities[currentIndex];
      client.user?.setPresence({
        activities: [{
          name: activity.name,
          type: activity.type,
          state: activity.state,
        }],
        status: "online",
      });
      currentIndex = (currentIndex + 1) % statusActivities.length;
    };

    updateStatus();
    setInterval(updateStatus, 30000);

    logger.info("Status rotation active (changes every 60 seconds)");
    logger.divider();
  },
};
