import "dotenv/config";
import { REST, Routes } from "discord.js";

const token = process.env.DISCORD_TOKEN;
const clientId = process.env.DISCORD_CLIENT_ID;

if (!token || !clientId) {
  console.error("Missing DISCORD_TOKEN or DISCORD_CLIENT_ID");
  process.exit(1);
}

const rest = new REST().setToken(token);

(async () => {
  try {
    console.log("Removendo comandos globais...");
    await rest.put(Routes.applicationCommands(clientId), { body: [] });
    console.log("✅ Comandos globais removidos!");
  } catch (error) {
    console.error("Erro:", error);
  }
})();
