/**
 * Bot API Endpoints for Dashboard Integration
 * Add this code to your linked-roles-server.ts file
 */

import { loadGuildConfig, saveGuildConfig } from './utils/configManager';
import type { Express, Request, Response } from 'express';
import type { Client, Guild, Channel, Role } from 'discord.js';

export function setupBotApiEndpoints(app: Express, discordClient: Client) {
  // GET /api/guilds/:guildId/config
  app.get('/api/guilds/:guildId/config', (req: Request, res: Response) => {
    try {
      const { guildId } = req.params;
      const config = loadGuildConfig(guildId);
      res.json({ guildId, ...config });
    } catch (error: any) {
      console.error('Error fetching guild config:', error);
      res.status(500).json({ error: 'Failed to fetch config' });
    }
  });

  // POST /api/guilds/:guildId/config
  app.post('/api/guilds/:guildId/config', (req: Request, res: Response) => {
    try {
      const { guildId } = req.params;
      const config = req.body;
      saveGuildConfig(guildId, config);
      res.json({ success: true, guildId, config });
    } catch (error: any) {
      console.error('Error saving guild config:', error);
      res.status(500).json({ error: 'Failed to save config' });
    }
  });

  // GET /api/guilds/:guildId/channels
  app.get('/api/guilds/:guildId/channels', async (req: Request, res: Response) => {
    try {
      const { guildId } = req.params;
      const guild: Guild | undefined = await discordClient.guilds.fetch(guildId);

      if (!guild) {
        return res.status(404).json({ error: 'Guild not found' });
      }

      const channels = await guild.channels.fetch();
      const channelList = channels
        .filter((channel: any) => channel && channel.isTextBased?.())
        .map((channel: any) => ({
          id: channel?.id,
          name: channel?.name,
          type: channel?.type,
        }))
        .sort((a: any, b: any) => (a.name || '').localeCompare(b.name || ''));

      res.json(channelList);
    } catch (error: any) {
      console.error('Error fetching channels:', error);
      res.status(500).json({ error: 'Failed to fetch channels' });
    }
  });

  // GET /api/guilds/:guildId/roles
  app.get('/api/guilds/:guildId/roles', async (req: Request, res: Response) => {
    try {
      const { guildId } = req.params;
      const guild: Guild | undefined = await discordClient.guilds.fetch(guildId);

      if (!guild) {
        return res.status(404).json({ error: 'Guild not found' });
      }

      const roles = guild.roles.cache
        .filter((role: any) => !role.managed && role.id !== guild.id)
        .map((role: any) => ({
          id: role.id,
          name: role.name,
          color: role.hexColor,
          position: role.position,
        }))
        .sort((a: any, b: any) => b.position - a.position);

      res.json(roles);
    } catch (error: any) {
      console.error('Error fetching roles:', error);
      res.status(500).json({ error: 'Failed to fetch roles' });
    }
  });

  // GET /api/guilds/:guildId/info
  app.get('/api/guilds/:guildId/info', async (req: Request, res: Response) => {
    try {
      const { guildId } = req.params;
      const guild: Guild | undefined = await discordClient.guilds.fetch(guildId);

      if (!guild) {
        return res.status(404).json({ error: 'Guild not found' });
      }

      res.json({
        id: guild.id,
        name: guild.name,
        icon: guild.iconURL(),
        memberCount: guild.memberCount,
        ownerId: guild.ownerId,
      });
    } catch (error: any) {
      console.error('Error fetching guild info:', error);
      res.status(500).json({ error: 'Failed to fetch guild info' });
    }
  });
}
