import {
  SlashCommandBuilder,
  PermissionFlagsBits,
  ChannelType,
} from "discord.js";
import {
  handleLogs,
  handleWanted,
  handleAutoMod,
  handleAutoModAll,
  handleGenerateCode,
  handleIdioma,
  handleServidor,
  handleUploadEmojis,
  handleAnnouncementSend,
  handleAnnouncementTemplate,
  handleAnnouncementHistory,
} from "./handlers";

export default {
  data: new SlashCommandBuilder()
    .setName("admin")
    .setDescription("Admin commands for server management")
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addSubcommandGroup((group) =>
      group
        .setName("announcement")
        .setDescription("Announcement management")
        .addSubcommand((sub) =>
          sub
            .setName("send")
            .setDescription("Send an announcement to a channel")
            .addChannelOption((option) =>
              option
                .setName("channel")
                .setDescription("The channel to send the announcement to")
                .setRequired(true)
                .addChannelTypes(ChannelType.GuildText)
            )
            .addStringOption((option) =>
              option
                .setName("message")
                .setDescription("The announcement message")
                .setRequired(true)
            )
            .addStringOption((option) =>
              option
                .setName("title")
                .setDescription("Optional title for the embed")
                .setRequired(false)
            )
            .addStringOption((option) =>
              option
                .setName("color")
                .setDescription("Embed color (hex code like #FF0000)")
                .setRequired(false)
            )
        )
        .addSubcommand((sub) =>
          sub
            .setName("template")
            .setDescription("Use a pre-made announcement template")
            .addChannelOption((option) =>
              option
                .setName("channel")
                .setDescription("The channel to send the announcement to")
                .setRequired(true)
                .addChannelTypes(ChannelType.GuildText)
            )
            .addStringOption((option) =>
              option
                .setName("template")
                .setDescription("Choose a template")
                .setRequired(true)
                .addChoices(
                  { name: "Welcome", value: "welcome" },
                  { name: "Rules", value: "rules" },
                  { name: "Event", value: "event" },
                  { name: "Maintenance", value: "maintenance" },
                  { name: "Update", value: "update" }
                )
            )
        )
        .addSubcommand((sub) =>
          sub
            .setName("history")
            .setDescription("View announcement history for this server")
        )
    )
    .addSubcommandGroup((group) =>
      group
        .setName("logs")
        .setDescription("Configure server logs")
        .addSubcommand((sub) =>
          sub
            .setName("set")
            .setDescription("Set the log channel")
            .addChannelOption((option) =>
              option
                .setName("channel")
                .setDescription("The channel to send logs to")
                .setRequired(true)
                .addChannelTypes(ChannelType.GuildText)
            )
        )
        .addSubcommand((sub) =>
          sub.setName("view").setDescription("View current log settings")
        )
        .addSubcommand((sub) =>
          sub.setName("disable").setDescription("Disable logging")
        )
    )
    .addSubcommandGroup((group) =>
      group
        .setName("wanted")
        .setDescription("Manage wanted posters")
        .addSubcommand((sub) =>
          sub
            .setName("create")
            .setDescription("Create a wanted poster for a user")
            .addUserOption((option) =>
              option
                .setName("user")
                .setDescription("The user to create a poster for")
                .setRequired(true)
            )
            .addStringOption((option) =>
              option
                .setName("reason")
                .setDescription("The reason for the wanted poster")
                .setRequired(false)
            )
            .addIntegerOption((option) =>
              option
                .setName("reward")
                .setDescription("The reward amount")
                .setRequired(false)
                .setMinValue(100)
                .setMaxValue(100000)
            )
        )
        .addSubcommand((sub) =>
          sub.setName("list").setDescription("List all wanted posters")
        )
        .addSubcommand((sub) =>
          sub
            .setName("remove")
            .setDescription("Remove a wanted poster")
            .addUserOption((option) =>
              option
                .setName("user")
                .setDescription("The user to remove the poster for")
                .setRequired(true)
            )
        )
    )
    .addSubcommandGroup((group) =>
      group
        .setName("automod")
        .setDescription("AutoMod management")
        .addSubcommand((sub) =>
          sub
            .setName("setup")
            .setDescription("Setup default AutoMod rules")
            .addChannelOption((option) =>
              option
                .setName("log-channel")
                .setDescription("Channel for AutoMod logs")
                .setRequired(false)
                .addChannelTypes(ChannelType.GuildText)
            )
        )
        .addSubcommand((sub) =>
          sub.setName("status").setDescription("View AutoMod badge progress")
        )
        .addSubcommand((sub) =>
          sub
            .setName("clear")
            .setDescription("Clear all AutoMod rules from this server")
        )
    )
    .addSubcommand((sub) =>
      sub
        .setName("generatecode")
        .setDescription("[OWNER ONLY] Generate a redemption code")
        .addStringOption((option) =>
          option
            .setName("type")
            .setDescription("Type of reward")
            .setRequired(true)
            .addChoices(
              { name: "Gold", value: "gold" },
              { name: "Silver", value: "silver" },
              { name: "Tokens", value: "tokens" },
              { name: "RexBucks", value: "rexbucks" }
            )
        )
        .addIntegerOption((option) =>
          option
            .setName("amount")
            .setDescription("Amount of reward")
            .setRequired(true)
            .setMinValue(1)
        )
        .addIntegerOption((option) =>
          option
            .setName("uses")
            .setDescription("Number of uses (default: 1)")
            .setRequired(false)
            .setMinValue(1)
            .setMaxValue(1000)
        )
        .addIntegerOption((option) =>
          option
            .setName("expires")
            .setDescription("Expiration in hours (default: 24)")
            .setRequired(false)
            .setMinValue(1)
            .setMaxValue(720)
        )
    )
    .addSubcommand((sub) =>
      sub.setName("idioma").setDescription("Check your detected language")
    )
    .addSubcommand((sub) =>
      sub.setName("servidor").setDescription("View server information")
    )
    .addSubcommand((sub) =>
      sub
        .setName("uploademojis")
        .setDescription("[OWNER ONLY] Upload custom emojis to servers")
    )
    .addSubcommand((sub) =>
      sub
        .setName("automodall")
        .setDescription("[OWNER ONLY] Setup AutoMod on all servers")
    ),

  async execute(interaction: any) {
    const subcommandGroup = interaction.options.getSubcommandGroup(false);
    const subcommand = interaction.options.getSubcommand();

    if (subcommandGroup === "announcement") {
      if (subcommand === "send") {
        await handleAnnouncementSend(interaction);
      } else if (subcommand === "template") {
        await handleAnnouncementTemplate(interaction);
      } else if (subcommand === "history") {
        await handleAnnouncementHistory(interaction);
      }
    } else if (subcommandGroup === "logs") {
      await handleLogs(interaction, subcommand);
    } else if (subcommandGroup === "wanted") {
      await handleWanted(interaction, subcommand);
    } else if (subcommandGroup === "automod") {
      await handleAutoMod(interaction, subcommand);
    } else if (subcommand === "generatecode") {
      await handleGenerateCode(interaction);
    } else if (subcommand === "idioma") {
      await handleIdioma(interaction);
    } else if (subcommand === "servidor") {
      await handleServidor(interaction);
    } else if (subcommand === "uploademojis") {
      await handleUploadEmojis(interaction);
    } else if (subcommand === "automodall") {
      await handleAutoModAll(interaction, "setup");
    }
  },
};
