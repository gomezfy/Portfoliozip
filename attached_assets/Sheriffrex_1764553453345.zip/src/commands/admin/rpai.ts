import {
  SlashCommandBuilder,
  ChatInputCommandInteraction,
  EmbedBuilder,
  ActionRowBuilder,
  StringSelectMenuBuilder,
  StringSelectMenuOptionBuilder,
  ButtonBuilder,
  ButtonStyle,
  ComponentType,
  MessageFlags,
} from "discord.js";
import { rpAIService } from "../../utils/rpAIService";
import { rpHealthService } from "../../utils/rpHealthService";
import { geminiService } from "../../utils/geminiService";
import { rpEventsService } from "../../utils/rpEventsService";
import { removeUserGold, removeUserSilver, getUserGold, getUserSilver, ensureUser } from "../../utils/postgresEconomyManager";
import { requireAdmin } from "../../utils/permissionManager";

const Colors = {
  SUCCESS: 0x10b981,
  ERROR: 0xef4444,
  WARNING: 0xf59e0b,
  NARRATOR: 0x8b4513,
  ASSISTANT: 0xd4a03a,
  NPC: 0x4a5568,
} as const;

export const data = new SlashCommandBuilder()
  .setName("rpai")
  .setDescription("🤖 Sistema de RP com Inteligência Artificial")
  .addSubcommand((subcommand) =>
    subcommand
      .setName("narrar")
      .setDescription("📖 Gere uma narração cinematográfica para uma ação")
      .addStringOption((option) =>
        option
          .setName("acao")
          .setDescription("A ação que seu personagem está fazendo")
          .setRequired(true)
          .setMaxLength(300)
      )
      .addStringOption((option) =>
        option
          .setName("contexto")
          .setDescription("Contexto adicional da cena (opcional)")
          .setRequired(false)
          .setMaxLength(200)
      )
  )
  .addSubcommand((subcommand) =>
    subcommand
      .setName("sugerir")
      .setDescription("💡 Receba sugestões de ações, falas e pensamentos")
      .addStringOption((option) =>
        option
          .setName("situacao")
          .setDescription("Descreva a situação atual do seu personagem")
          .setRequired(true)
          .setMaxLength(300)
      )
      .addStringOption((option) =>
        option
          .setName("personagem")
          .setDescription("Descrição do seu personagem (opcional)")
          .setRequired(false)
          .setMaxLength(200)
      )
  )
  .addSubcommand((subcommand) =>
    subcommand
      .setName("npc")
      .setDescription("🎭 Interaja com um NPC controlado por IA")
      .addStringOption((option) =>
        option
          .setName("tipo")
          .setDescription("Tipo de NPC")
          .setRequired(true)
          .addChoices(
            { name: "🍺 Bartender do Saloon (1-8 prata)", value: "bartender" },
            { name: "⭐ Xerife da Cidade", value: "sheriff" },
            { name: "🔫 Fora-da-lei", value: "outlaw" },
            { name: "🏪 Comerciante (10 prata)", value: "merchant" },
            { name: "💊 Médica (38 prata)", value: "doctor" },
            { name: "🃏 Jogador/Apostador", value: "gambler" },
            { name: "🤠 Vaqueira/Caçadora", value: "cowgirl" }
          )
      )
      .addStringOption((option) =>
        option
          .setName("mensagem")
          .setDescription("O que você diz ou faz com o NPC")
          .setRequired(true)
          .setMaxLength(300)
      )
      .addStringOption((option) =>
        option
          .setName("contexto")
          .setDescription("Contexto da cena (opcional)")
          .setRequired(false)
          .setMaxLength(200)
      )
  )
  .addSubcommand((subcommand) =>
    subcommand
      .setName("npcs")
      .setDescription("📋 Listar todos os NPCs disponíveis")
  )
  .addSubcommand((subcommand) =>
    subcommand
      .setName("limpar")
      .setDescription("🗑️ Limpar histórico de conversa com um NPC")
      .addStringOption((option) =>
        option
          .setName("tipo")
          .setDescription("Tipo de NPC para limpar histórico")
          .setRequired(true)
          .addChoices(
            { name: "🍺 Bartender", value: "bartender" },
            { name: "⭐ Xerife", value: "sheriff" },
            { name: "🔫 Fora-da-lei", value: "outlaw" },
            { name: "🏪 Comerciante", value: "merchant" },
            { name: "💊 Médica", value: "doctor" },
            { name: "🃏 Jogador", value: "gambler" },
            { name: "🤠 Vaqueira", value: "cowgirl" }
          )
      )
  );

export async function execute(interaction: ChatInputCommandInteraction) {
  if (!(await requireAdmin(interaction))) return;
  if (!geminiService.isConfigured()) {
    await interaction.reply({
      content: "❌ A IA não está configurada. Por favor, configure a `GOOGLE_API_KEY`.",
      flags: MessageFlags.Ephemeral,
    });
    return;
  }

  const subcommand = interaction.options.getSubcommand();

  switch (subcommand) {
    case "narrar":
      await handleNarration(interaction);
      break;
    case "sugerir":
      await handleSuggestions(interaction);
      break;
    case "npc":
      await handleNPCInteraction(interaction);
      break;
    case "npcs":
      await handleListNPCs(interaction);
      break;
    case "limpar":
      await handleClearHistory(interaction);
      break;
  }
}

async function handleNarration(interaction: ChatInputCommandInteraction) {
  const action = interaction.options.getString("acao", true);
  const context = interaction.options.getString("contexto");

  await interaction.deferReply();

  try {
    const narration = await rpAIService.generateNarration(action, context || undefined);
    const analysis = await rpHealthService.analyzeAction(action, context || undefined);
    
    const hasEffects = analysis.effects && (
      analysis.effects.health !== 0 || analysis.effects.stamina !== 0 || 
      analysis.effects.thirst !== 0 || analysis.effects.hunger !== 0 || 
      analysis.effects.blood !== 0 || analysis.effects.temperature !== 0
    );

    let healthResult: { before: Record<string, number>; after: Record<string, number>; warnings: string[] } | null = null;
    let targetDamageResult: any = null;
    
    if (hasEffects) {
      try {
        healthResult = await rpHealthService.applyEffects(interaction.user.id, analysis.effects);
        await rpHealthService.logAction(
          interaction.user.id,
          null,
          'narration',
          action,
          narration,
          analysis.effects
        );
      } catch (error) {
        console.error("Error applying health effects:", error);
      }
    }

    // Detectar menção a outro usuário e aplicar dano se for ação de combate
    const targetUserId = rpHealthService.extractTargetUserId(action);
    
    if (targetUserId && targetUserId !== interaction.user.id) {
      const targetDamage = rpHealthService.calculateTargetDamage(action);
      
      if (targetDamage) {
        try {
          targetDamageResult = await rpHealthService.applyTargetDamage(targetUserId, targetDamage);
          if (targetDamageResult.targetFound) {
            console.log(`⚔️ Dano aplicado ao alvo: ${targetUserId}, Dano: ${targetDamage.health} de vida`);
          }
        } catch (error) {
          console.error("Error applying target damage:", error);
        }
      }
    }
    
    const embed = rpAIService.createNarrationEmbed(
      narration,
      action,
      interaction.user.displayName
    );

    if (hasEffects && healthResult) {
      const effectsText = rpHealthService.formatEffectsEmbed(analysis.effects, healthResult.before, healthResult.after);
      embed.addFields({
        name: "💥 Efeitos na Saúde (Você)",
        value: effectsText,
        inline: false
      });

      if (healthResult.warnings.length > 0) {
        embed.addFields({
          name: "⚠️ Avisos",
          value: healthResult.warnings.join('\n'),
          inline: false
        });
      }
    }

    // Mostrar dano ao alvo
    if (targetDamageResult && targetDamageResult.targetFound) {
      const targetEffectsText = rpHealthService.formatEffectsEmbed(
        rpHealthService.calculateTargetDamage(action)!,
        targetDamageResult.before,
        targetDamageResult.after
      );
      embed.addFields({
        name: "⚔️ Efeitos no Alvo",
        value: targetEffectsText,
        inline: false
      });

      if (targetDamageResult.warnings && targetDamageResult.warnings.length > 0) {
        embed.addFields({
          name: "🩸 Status do Alvo",
          value: targetDamageResult.warnings.join('\n'),
          inline: false
        });
      }
    }

    const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
      new ButtonBuilder()
        .setCustomId(`rpai_renarrate_${interaction.user.id}`)
        .setLabel("🔄 Gerar Nova Narração")
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId(`rpai_saude_${interaction.user.id}`)
        .setLabel("❤️ Ver Saúde")
        .setStyle(ButtonStyle.Primary)
    );

    const response = await interaction.editReply({
      embeds: [embed],
      components: [row],
    });

    const collector = response.createMessageComponentCollector({
      componentType: ComponentType.Button,
      time: 60000,
      filter: (i) => i.user.id === interaction.user.id,
    });

    collector.on("collect", async (i) => {
      if (i.customId.startsWith("rpai_renarrate_")) {
        await i.deferUpdate();
        try {
          const newNarration = await rpAIService.generateNarration(action, context || undefined);
          const newAnalysis = await rpHealthService.analyzeAction(action, context || undefined);
          
          const newHasEffects = newAnalysis.effects && (
            newAnalysis.effects.health !== 0 || newAnalysis.effects.stamina !== 0 ||
            newAnalysis.effects.thirst !== 0 || newAnalysis.effects.hunger !== 0
          );

          let newHealthResult: { before: Record<string, number>; after: Record<string, number>; warnings: string[] } | null = null;
          
          if (newHasEffects) {
            try {
              newHealthResult = await rpHealthService.applyEffects(interaction.user.id, newAnalysis.effects);
            } catch (error) {
              console.error("Error applying new health effects:", error);
            }
          }

          const newEmbed = rpAIService.createNarrationEmbed(
            newNarration,
            action,
            interaction.user.displayName
          );
          
          if (newHasEffects && newHealthResult) {
            const effectsText = rpHealthService.formatEffectsEmbed(newAnalysis.effects, newHealthResult.before, newHealthResult.after);
            newEmbed.addFields({
              name: "💥 Efeitos na Saúde (Aplicados)",
              value: effectsText,
              inline: false
            });

            if (newHealthResult.warnings.length > 0) {
              newEmbed.addFields({
                name: "⚠️ Avisos",
                value: newHealthResult.warnings.join('\n'),
                inline: false
              });
            }
          }
          await i.editReply({ embeds: [newEmbed], components: [row] });
        } catch (error) {
          await i.editReply({
            content: "❌ Erro ao gerar nova narração. Tente novamente.",
            embeds: [],
            components: [],
          });
        }
      } else if (i.customId.startsWith("rpai_saude_")) {
        await i.reply({
          content: "💡 Use o comando `/saude` para ver seu status completo de saúde!",
          flags: MessageFlags.Ephemeral,
        });
      }
    });

    collector.on("end", async () => {
      try {
        await interaction.editReply({ components: [] });
      } catch {}
    });
  } catch (error: any) {
    console.error("Error in narration:", error);
    await interaction.editReply({
      content: `❌ **Erro ao gerar narração:**\n${error.message || "Erro desconhecido"}`,
    });
  }
}

async function handleSuggestions(interaction: ChatInputCommandInteraction) {
  const situation = interaction.options.getString("situacao", true);
  const character = interaction.options.getString("personagem");

  await interaction.deferReply();

  try {
    const suggestions = await rpAIService.generateSuggestions(
      situation,
      character || undefined
    );

    const embed = rpAIService.createSuggestionEmbed(suggestions, situation);

    const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
      new ButtonBuilder()
        .setCustomId(`rpai_newsuggest_${interaction.user.id}`)
        .setLabel("🔄 Novas Sugestões")
        .setStyle(ButtonStyle.Secondary)
    );

    const response = await interaction.editReply({
      embeds: [embed],
      components: [row],
    });

    const collector = response.createMessageComponentCollector({
      componentType: ComponentType.Button,
      time: 120000,
      filter: (i) => i.user.id === interaction.user.id,
    });

    collector.on("collect", async (i) => {
      await i.deferUpdate();
      try {
        const newSuggestions = await rpAIService.generateSuggestions(
          situation,
          character || undefined
        );
        const newEmbed = rpAIService.createSuggestionEmbed(newSuggestions, situation);
        await i.editReply({ embeds: [newEmbed], components: [row] });
      } catch (error) {
        await i.editReply({
          content: "❌ Erro ao gerar novas sugestões.",
          embeds: [],
          components: [],
        });
      }
    });

    collector.on("end", async () => {
      try {
        await interaction.editReply({ components: [] });
      } catch {}
    });
  } catch (error: any) {
    console.error("Error in suggestions:", error);
    await interaction.editReply({
      content: `❌ **Erro ao gerar sugestões:**\n${error.message || "Erro desconhecido"}`,
    });
  }
}

const NPC_HEALTH_EFFECTS: Record<string, { effects: Partial<import("../../utils/rpHealthService").HealthEffects>; description: string }> = {
  bartender: { 
    effects: { thirst: 20, stamina: 5 }, 
    description: "O bartender serve uma bebida refrescante" 
  },
  doctor: { 
    effects: { health: 25, blood: 15, stamina: 10 }, 
    description: "A médica trata seus ferimentos" 
  },
  merchant: { 
    effects: { hunger: 10 }, 
    description: "O comerciante oferece um petisco" 
  },
  sheriff: { 
    effects: { stamina: -5 }, 
    description: "A tensão com a lei gasta sua energia" 
  },
  outlaw: { 
    effects: { stamina: -10, health: -5 }, 
    description: "Lidar com foras-da-lei é arriscado" 
  },
  gambler: { 
    effects: { stamina: -5, thirst: -5 }, 
    description: "Jogos de azar são estressantes e dão sede" 
  },
  cowgirl: { 
    effects: { stamina: -5 }, 
    description: "Conversar com caçadores de recompensa é intenso" 
  },
};

// Fixed prices per NPC (silver coins) - only paid NPCs
const NPC_PRICES: Record<string, { min: number; max: number; description: string }> = {
  bartender: { min: 1, max: 8, description: "Bebida" },
  merchant: { min: 10, max: 10, description: "Serviço" },
  doctor: { min: 120, max: 120, description: "Consulta médica" },
};

// Get random price for bartender (1-8) or fixed price for others
function getNPCPrice(npcType: string): number {
  const priceInfo = NPC_PRICES[npcType];
  if (!priceInfo) return 0;
  if (priceInfo.min === priceInfo.max) return priceInfo.min;
  return Math.floor(Math.random() * (priceInfo.max - priceInfo.min + 1)) + priceInfo.min;
}

async function handleNPCInteraction(interaction: ChatInputCommandInteraction) {
  const npcType = interaction.options.getString("tipo", true);
  const message = interaction.options.getString("mensagem", true);
  const context = interaction.options.getString("contexto");

  await interaction.deferReply();

  // Ensure user exists in database before any operation
  try {
    await ensureUser(interaction.user.id, interaction.user.username || "Unknown");
  } catch (error) {
    console.error("Error ensuring user exists:", error);
  }

  // Check if this NPC charges silver coins (validate before interaction)
  const price = getNPCPrice(npcType);
  let chargedAmount = 0;

  if (price > 0) {
    const userSilver = await getUserSilver(interaction.user.id);
    
    if (userSilver < price) {
      const priceInfo = NPC_PRICES[npcType];
      const npcNames: Record<string, string> = {
        bartender: "Bartender",
        merchant: "Comerciante", 
        doctor: "Médica"
      };
      
      await interaction.editReply({
        embeds: [
          new EmbedBuilder()
            .setColor(0xef4444)
            .setTitle("❌ Prata Insuficiente")
            .setDescription(
              `O **${npcNames[npcType]}** cobra **${price} prata** pelo serviço.\n\n` +
              `Você tem apenas **${userSilver} prata**.\n\n` +
              `💡 Ganhe mais prata minerando, caçando ou completando atividades!`
            )
            .setFooter({ text: `Preço: ${priceInfo.min === priceInfo.max ? priceInfo.min : `${priceInfo.min}-${priceInfo.max}`} prata` })
        ]
      });
      return;
    }
    // Note: Charging happens AFTER successful NPC response to avoid coin loss on errors
  }

  try {
    const { response, npcName } = await rpAIService.npcRespond(
      npcType,
      message,
      interaction.channelId,
      context || undefined,
      interaction.user.id
    );

    // Charge silver coins AFTER successful NPC response (to avoid loss on errors)
    if (price > 0) {
      const success = await removeUserSilver(interaction.user.id, price);
      if (success) {
        chargedAmount = price;
        console.log(`✅ Charged ${price} silver to ${interaction.user.username} for ${npcType} NPC interaction`);
      } else {
        console.error(`❌ Failed to charge ${price} silver to ${interaction.user.id} - insufficient balance after check`);
      }
    }

    // Verificar se há evento aleatório
    let eventEmbed: EmbedBuilder | null = null;
    let eventMessage = '';
    
    try {
      if (rpEventsService.shouldTriggerEvent(npcType)) {
        const randomEvent = rpEventsService.getRandomEvent(npcType);
        if (randomEvent) {
          const eventInfo = rpEventsService.formatEventEmbed(randomEvent);
          eventEmbed = new EmbedBuilder()
            .setColor(eventInfo.color)
            .setTitle(eventInfo.title)
            .setDescription(eventInfo.description)
            .setFooter({ text: '🎬 Evento aleatório ativado!' })
            .setTimestamp();
          
          eventMessage = '\n\n🎬 **Um evento aconteceu durante sua interação!**';
          
          try {
            await rpEventsService.logEvent(
              randomEvent,
              interaction.user.id,
              interaction.channelId,
              interaction.guildId || ''
            );
          } catch (logError) {
            console.warn('⚠️ Evento não foi registrado (tabela não criada)');
          }
        }
      }
    } catch (eventError) {
      console.warn('⚠️ Sistema de eventos não disponível');
    }

    const npcEffects = NPC_HEALTH_EFFECTS[npcType];
    let healthResult: { before: Record<string, number>; after: Record<string, number>; warnings: string[] } | null = null;

    if (npcEffects && npcEffects.effects) {
      try {
        const fullEffects = {
          health: npcEffects.effects.health || 0,
          stamina: npcEffects.effects.stamina || 0,
          thirst: npcEffects.effects.thirst || 0,
          hunger: npcEffects.effects.hunger || 0,
          blood: npcEffects.effects.blood || 0,
          temperature: npcEffects.effects.temperature || 0,
          description: npcEffects.description,
          severity: 'minor' as const,
        };
        healthResult = await rpHealthService.applyEffects(interaction.user.id, fullEffects);
        
        await rpHealthService.updateReputation(interaction.user.id, npcType, 1);
        
        await rpHealthService.logAction(
          interaction.user.id,
          null,
          'npc_interaction',
          `Interação com ${npcName}: ${message}`,
          response,
          fullEffects
        );
      } catch (error) {
        console.error("Error applying NPC health effects:", error);
      }
    }

    const embed = rpAIService.createNPCEmbed(npcName, response + eventMessage, npcType);

    embed.addFields({
      name: "💬 Você disse/fez",
      value: message.length > 100 ? message.substring(0, 100) + "..." : message,
      inline: false,
    });

    // Show payment info if charged
    if (chargedAmount > 0) {
      const priceInfo = NPC_PRICES[npcType];
      embed.addFields({
        name: "🪙 Pagamento",
        value: `**-${chargedAmount} prata** (${priceInfo.description})`,
        inline: true,
      });
    }

    if (healthResult && npcEffects) {
      const effectLines: string[] = [];
      const emoji = { health: '❤️', stamina: '⚡', thirst: '💧', hunger: '🍖', blood: '🩸' };
      
      for (const [key, value] of Object.entries(npcEffects.effects)) {
        const numValue = typeof value === 'number' ? value : 0;
        if (numValue !== 0) {
          const sign = numValue > 0 ? '+' : '';
          const emojiKey = key as keyof typeof emoji;
          effectLines.push(`${emoji[emojiKey] || '📊'} ${sign}${numValue} ${key}`);
        }
      }
      
      if (effectLines.length > 0) {
        embed.addFields({
          name: `🎭 Efeito da Interação`,
          value: `${npcEffects.description}\n${effectLines.join(' | ')}`,
          inline: false,
        });
      }

      if (healthResult.warnings.length > 0) {
        embed.addFields({
          name: "⚠️ Avisos",
          value: healthResult.warnings.join('\n'),
          inline: false,
        });
      }
    }

    const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
      new ButtonBuilder()
        .setCustomId(`rpai_continue_${npcType}_${interaction.user.id}`)
        .setLabel("💬 Continuar Conversa")
        .setStyle(ButtonStyle.Primary),
      new ButtonBuilder()
        .setCustomId(`rpai_endnpc_${npcType}_${interaction.user.id}`)
        .setLabel("👋 Encerrar")
        .setStyle(ButtonStyle.Secondary)
    );

    const embeds = eventEmbed ? [embed, eventEmbed] : [embed];
    const replyMessage = await interaction.editReply({
      embeds,
      components: [row],
    });

    const collector = replyMessage.createMessageComponentCollector({
      componentType: ComponentType.Button,
      time: 300000,
      filter: (buttonInteraction) => buttonInteraction.user.id === interaction.user.id,
    });

    collector.on("collect", async (buttonInteraction) => {
      if (buttonInteraction.customId.startsWith("rpai_continue_")) {
        await buttonInteraction.reply({
          content: "💬 Para continuar a conversa, use `/rpai npc` novamente com sua próxima mensagem!",
          flags: MessageFlags.Ephemeral,
        });
      } else if (buttonInteraction.customId.startsWith("rpai_endnpc_")) {
        rpAIService.clearConversation(interaction.channelId, npcType);
        await buttonInteraction.update({
          components: [],
        });
        await buttonInteraction.followUp({
          content: "👋 Conversa encerrada! O histórico foi limpo.",
          flags: MessageFlags.Ephemeral,
        });
        collector.stop();
      }
    });

    collector.on("end", async () => {
      try {
        await interaction.editReply({ components: [] });
      } catch {}
    });
  } catch (error: any) {
    console.error("Error in NPC interaction:", error);
    await interaction.editReply({
      content: `❌ **Erro ao interagir com NPC:**\n${error.message || "Erro desconhecido"}`,
    });
  }
}

async function handleListNPCs(interaction: ChatInputCommandInteraction) {
  const npcs = rpAIService.getAvailableNPCs();

  const npcIcons: Record<string, string> = {
    bartender: "🍺",
    sheriff: "⭐",
    outlaw: "🔫",
    merchant: "🏪",
    doctor: "💊",
    gambler: "🃏",
    cowgirl: "🤠",
  };

  const embed = new EmbedBuilder()
    .setColor(Colors.NPC)
    .setTitle("🎭 NPCs Disponíveis")
    .setDescription("Estes são os personagens controlados por IA que você pode interagir no RP:")
    .setTimestamp();

  npcs.forEach((npc) => {
    const icon = npcIcons[npc.id] || "👤";
    embed.addFields({
      name: `${icon} ${npc.name}`,
      value: `**Papel:** ${npc.role}\n**Comando:** \`/rpai npc tipo:${npc.id}\``,
      inline: true,
    });
  });

  embed.setFooter({
    text: "Use /rpai npc para interagir com um NPC",
  });

  await interaction.reply({ embeds: [embed] });
}

async function handleClearHistory(interaction: ChatInputCommandInteraction) {
  const npcType = interaction.options.getString("tipo", true);

  rpAIService.clearConversation(interaction.channelId, npcType);

  const npcNames: Record<string, string> = {
    bartender: "Bartender",
    sheriff: "Xerife",
    outlaw: "Fora-da-lei",
    merchant: "Comerciante",
    doctor: "Médica",
    gambler: "Jogador",
    cowgirl: "Vaqueira",
  };

  const embed = new EmbedBuilder()
    .setColor(Colors.SUCCESS)
    .setTitle("🗑️ Histórico Limpo")
    .setDescription(
      `O histórico de conversa com **${npcNames[npcType] || npcType}** foi limpo.\nA próxima interação começará uma nova conversa.`
    )
    .setTimestamp();

  await interaction.reply({ embeds: [embed], flags: MessageFlags.Ephemeral });
}
