import {
  SlashCommandBuilder,
  ChatInputCommandInteraction,
  PermissionFlagsBits,
  ChannelType,
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  StringSelectMenuBuilder,
  StringSelectMenuOptionBuilder,
  MessageFlags,
} from "discord.js";
import {
  addRPChannel,
  removeRPChannel,
  listRPChannels,
  loadRPGuildConfig,
  saveRPGuildConfig,
  createRPRulesEmbed,
  RPChannelConfig,
} from "../../utils/rpManager";
import { db } from "../../../server/db";
import { characterSheets, rpSessions, rpLocations, users } from "../../../shared/schema";
import { eq, and } from "drizzle-orm";
import { v4 as uuidv4 } from "uuid";
import { requireAdmin } from "../../utils/permissionManager";

const Colors = {
  SUCCESS: 0x10b981,
  ERROR: 0xef4444,
  WARNING: 0xf59e0b,
  INFO: 0x3b82f6,
  WESTERN_GOLD: 0xd4a03a,
  PARCHMENT: 0xf5e5c7,
  CHARACTER: 0x8b4513,
  SESSION: 0x4a5568,
} as const;

const WEATHER_OPTIONS = [
  { name: "☀️ Céu Limpo", value: "clear", temp: 30, description: "Sol escaldante do deserto" },
  { name: "🌤️ Parcialmente Nublado", value: "partly_cloudy", temp: 25, description: "Algumas nuvens no horizonte" },
  { name: "☁️ Nublado", value: "cloudy", temp: 20, description: "Céu coberto de nuvens" },
  { name: "🌧️ Chuva", value: "rain", temp: 18, description: "Chuva caindo sobre a cidade" },
  { name: "⛈️ Tempestade", value: "storm", temp: 15, description: "Tempestade violenta com trovões" },
  { name: "🌪️ Tempestade de Areia", value: "sandstorm", temp: 35, description: "Ventos fortes levantando areia" },
  { name: "❄️ Frio Intenso", value: "cold", temp: 5, description: "Noite gélida do deserto" },
  { name: "🌙 Noite Clara", value: "night_clear", temp: 15, description: "Noite estrelada e fria" },
];

const TIME_OPTIONS = [
  { name: "🌅 Amanhecer", value: "dawn", description: "O sol começa a surgir no horizonte" },
  { name: "☀️ Manhã", value: "morning", description: "Sol da manhã iluminando a cidade" },
  { name: "🌞 Meio-dia", value: "noon", description: "Sol a pino, calor intenso" },
  { name: "🌇 Tarde", value: "afternoon", description: "Sombras começam a se alongar" },
  { name: "🌆 Entardecer", value: "dusk", description: "O céu se pinta de laranja e vermelho" },
  { name: "🌙 Noite", value: "night", description: "A escuridão toma conta" },
  { name: "🌑 Madrugada", value: "midnight", description: "As horas mais escuras da noite" },
];

export const data = new SlashCommandBuilder()
  .setName("rp")
  .setDescription("🎭 Sistema de Roleplay - Configuração, fichas e sessões")
  .addSubcommand((subcommand) =>
    subcommand
      .setName("canal")
      .setDescription("Adicionar ou remover um canal de RP")
      .addChannelOption((option) =>
        option
          .setName("canal")
          .setDescription("O canal para configurar como RP")
          .addChannelTypes(ChannelType.GuildText)
          .setRequired(true)
      )
      .addStringOption((option) =>
        option
          .setName("acao")
          .setDescription("Adicionar ou remover o canal")
          .setRequired(true)
          .addChoices(
            { name: "Adicionar", value: "add" },
            { name: "Remover", value: "remove" }
          )
      )
      .addStringOption((option) =>
        option
          .setName("modo_aviso")
          .setDescription("Como avisar sobre erros de formato")
          .setRequired(false)
          .addChoices(
            { name: "Responder no canal", value: "reply" },
            { name: "Enviar DM", value: "dm" },
            { name: "Deletar mensagem", value: "delete" },
            { name: "Não avisar", value: "none" }
          )
      )
      .addBooleanOption((option) =>
        option
          .setName("modo_estrito")
          .setDescription("Modo estrito - exige formatação correta")
          .setRequired(false)
      )
      .addBooleanOption((option) =>
        option
          .setName("narracao_ia")
          .setDescription("Gerar narração automática com IA para ações")
          .setRequired(false)
      )
  )
  .addSubcommand((subcommand) =>
    subcommand
      .setName("regras")
      .setDescription("Mostrar as regras de RP")
      .addBooleanOption((option) =>
        option
          .setName("publico")
          .setDescription("Mostrar para todos no canal")
          .setRequired(false)
      )
  )
  .addSubcommand((subcommand) =>
    subcommand
      .setName("listar")
      .setDescription("Listar todos os canais de RP configurados")
  )
  .addSubcommand((subcommand) =>
    subcommand
      .setName("config")
      .setDescription("Configurar o sistema de RP")
      .addIntegerOption((option) =>
        option
          .setName("cooldown")
          .setDescription("Tempo em segundos entre avisos para o mesmo usuário")
          .setMinValue(5)
          .setMaxValue(300)
          .setRequired(false)
      )
      .addBooleanOption((option) =>
        option
          .setName("ativar")
          .setDescription("Ativar ou desativar o sistema de RP")
          .setRequired(false)
      )
  )
  .addSubcommand((subcommand) =>
    subcommand
      .setName("ficha")
      .setDescription("📋 Ver ou criar sua ficha de personagem")
  )
  .addSubcommand((subcommand) =>
    subcommand
      .setName("criarficha")
      .setDescription("📝 Criar uma nova ficha de personagem")
      .addStringOption((option) =>
        option
          .setName("nome")
          .setDescription("Nome do seu personagem")
          .setRequired(true)
          .setMaxLength(50)
      )
      .addStringOption((option) =>
        option
          .setName("descricao")
          .setDescription("Descrição breve do personagem")
          .setRequired(true)
          .setMaxLength(200)
      )
      .addStringOption((option) =>
        option
          .setName("aparencia")
          .setDescription("Aparência física do personagem")
          .setRequired(false)
          .setMaxLength(300)
      )
      .addStringOption((option) =>
        option
          .setName("personalidade")
          .setDescription("Traços de personalidade")
          .setRequired(false)
          .setMaxLength(300)
      )
      .addStringOption((option) =>
        option
          .setName("historia")
          .setDescription("História/Backstory do personagem")
          .setRequired(false)
          .setMaxLength(500)
      )
  )
  .addSubcommand((subcommand) =>
    subcommand
      .setName("sessao")
      .setDescription("🎬 Gerenciar sessões de RP")
      .addStringOption((option) =>
        option
          .setName("acao")
          .setDescription("O que fazer com a sessão")
          .setRequired(true)
          .addChoices(
            { name: "Iniciar Nova Sessão", value: "start" },
            { name: "Ver Sessão Atual", value: "view" },
            { name: "Encerrar Sessão", value: "end" }
          )
      )
      .addStringOption((option) =>
        option
          .setName("nome")
          .setDescription("Nome da sessão (para iniciar)")
          .setRequired(false)
          .setMaxLength(100)
      )
  )
  .addSubcommand((subcommand) =>
    subcommand
      .setName("cena")
      .setDescription("🎭 Definir o cenário da cena atual")
      .addStringOption((option) =>
        option
          .setName("clima")
          .setDescription("Clima da cena")
          .setRequired(false)
          .addChoices(...WEATHER_OPTIONS.map(w => ({ name: w.name, value: w.value })))
      )
      .addStringOption((option) =>
        option
          .setName("horario")
          .setDescription("Horário do dia")
          .setRequired(false)
          .addChoices(...TIME_OPTIONS.map(t => ({ name: t.name, value: t.value })))
      )
      .addIntegerOption((option) =>
        option
          .setName("temperatura")
          .setDescription("Temperatura ambiente (°C)")
          .setRequired(false)
          .setMinValue(-10)
          .setMaxValue(50)
      )
      .addStringOption((option) =>
        option
          .setName("local")
          .setDescription("Local da cena")
          .setRequired(false)
          .setMaxLength(100)
      )
      .addStringOption((option) =>
        option
          .setName("descricao")
          .setDescription("Descrição narrativa da cena")
          .setRequired(false)
          .setMaxLength(500)
      )
  )
  .addSubcommand((subcommand) =>
    subcommand
      .setName("dado")
      .setDescription("🎲 Rolar dados para ações de RP")
      .addStringOption((option) =>
        option
          .setName("tipo")
          .setDescription("Tipo de dado para rolar")
          .setRequired(true)
          .addChoices(
            { name: "🎯 D20 (Ação geral)", value: "d20" },
            { name: "⚔️ D12 (Combate)", value: "d12" },
            { name: "🛡️ D10 (Defesa)", value: "d10" },
            { name: "💪 D8 (Força)", value: "d8" },
            { name: "🏃 D6 (Agilidade)", value: "d6" },
            { name: "🍀 D4 (Sorte)", value: "d4" },
            { name: "💯 D100 (Percentual)", value: "d100" }
          )
      )
      .addStringOption((option) =>
        option
          .setName("acao")
          .setDescription("Descrição da ação que está tentando")
          .setRequired(false)
          .setMaxLength(200)
      )
      .addIntegerOption((option) =>
        option
          .setName("modificador")
          .setDescription("Modificador para adicionar ao resultado")
          .setRequired(false)
          .setMinValue(-20)
          .setMaxValue(20)
      )
  )
  .addSubcommand((subcommand) =>
    subcommand
      .setName("local")
      .setDescription("📍 Criar ou listar locais de RP")
      .addStringOption((option) =>
        option
          .setName("acao")
          .setDescription("O que fazer")
          .setRequired(true)
          .addChoices(
            { name: "Listar Locais", value: "list" },
            { name: "Criar Local", value: "create" }
          )
      )
      .addStringOption((option) =>
        option
          .setName("nome")
          .setDescription("Nome do local (para criar)")
          .setRequired(false)
          .setMaxLength(50)
      )
      .addStringOption((option) =>
        option
          .setName("descricao")
          .setDescription("Descrição do local (para criar)")
          .setRequired(false)
          .setMaxLength(300)
      )
      .addStringOption((option) =>
        option
          .setName("tipo")
          .setDescription("Tipo do local")
          .setRequired(false)
          .addChoices(
            { name: "🏠 Saloon", value: "saloon" },
            { name: "🏛️ Delegacia", value: "sheriff_office" },
            { name: "🏪 Loja", value: "store" },
            { name: "⛏️ Mina", value: "mine" },
            { name: "🌵 Deserto", value: "desert" },
            { name: "🏔️ Montanha", value: "mountain" },
            { name: "🌲 Floresta", value: "forest" },
            { name: "🏚️ Fazenda", value: "ranch" },
            { name: "⛪ Igreja", value: "church" },
            { name: "🏥 Consultório", value: "doctor" }
          )
      )
  );

export async function execute(interaction: ChatInputCommandInteraction) {
  if (!(await requireAdmin(interaction))) return;
  if (!interaction.guild) {
    await interaction.reply({
      content: "Este comando só pode ser usado em servidores.",
      ephemeral: true,
    });
    return;
  }

  const subcommand = interaction.options.getSubcommand();

  switch (subcommand) {
    case "canal":
      await handleChannelCommand(interaction);
      break;
    case "regras":
      await handleRulesCommand(interaction);
      break;
    case "listar":
      await handleListCommand(interaction);
      break;
    case "config":
      await handleConfigCommand(interaction);
      break;
    case "ficha":
      await handleViewSheet(interaction);
      break;
    case "criarficha":
      await handleCreateSheet(interaction);
      break;
    case "sessao":
      await handleSession(interaction);
      break;
    case "cena":
      await handleScene(interaction);
      break;
    case "dado":
      await handleDiceRoll(interaction);
      break;
    case "local":
      await handleLocation(interaction);
      break;
  }
}

async function handleChannelCommand(interaction: ChatInputCommandInteraction) {
  const channel = interaction.options.getChannel("canal", true);
  const action = interaction.options.getString("acao", true);
  const warningMode = (interaction.options.getString("modo_aviso") || "reply") as
    | "reply"
    | "dm"
    | "delete"
    | "none";
  const strictMode = interaction.options.getBoolean("modo_estrito") ?? false;
  const aiNarration = interaction.options.getBoolean("narracao_ia") ?? false;

  if (action === "add") {
    addRPChannel(interaction.guild!.id, channel.id, strictMode, warningMode, aiNarration);

    const modeText = {
      reply: "Responder no canal",
      dm: "Enviar DM",
      delete: "Deletar mensagem",
      none: "Não avisar",
    };

    const embed = new EmbedBuilder()
      .setColor(Colors.SUCCESS)
      .setTitle("✅ Canal de RP Configurado")
      .setDescription(`O canal ${channel} agora é um canal de RP!`)
      .addFields(
        { name: "📢 Modo de Aviso", value: modeText[warningMode], inline: true },
        { name: "⚠️ Modo Estrito", value: strictMode ? "Ativado" : "Desativado", inline: true },
        { name: "🤖 Narração IA", value: aiNarration ? "Ativada" : "Desativada", inline: true }
      )
      .setFooter({ text: "🤠 Xerife Rex - Sistema de RP" })
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
  } else {
    const removed = removeRPChannel(interaction.guild!.id, channel.id);

    if (removed) {
      const embed = new EmbedBuilder()
        .setColor(Colors.WARNING)
        .setTitle("🚫 Canal de RP Removido")
        .setDescription(`O canal ${channel} não é mais um canal de RP.`)
        .setFooter({ text: "🤠 Xerife Rex - Sistema de RP" })
        .setTimestamp();

      await interaction.reply({ embeds: [embed] });
    } else {
      const embed = new EmbedBuilder()
        .setColor(Colors.ERROR)
        .setTitle("❌ Erro")
        .setDescription(`O canal ${channel} não estava configurado como canal de RP.`)
        .setTimestamp();

      await interaction.reply({ embeds: [embed], ephemeral: true });
    }
  }
}

async function handleRulesCommand(interaction: ChatInputCommandInteraction) {
  const isPublic = interaction.options.getBoolean("publico") ?? false;
  const rulesEmbed = createRPRulesEmbed();

  await interaction.reply({
    embeds: [rulesEmbed],
    ephemeral: !isPublic,
  });
}

async function handleListCommand(interaction: ChatInputCommandInteraction) {
  const channels = listRPChannels(interaction.guild!.id);

  if (channels.length === 0) {
    const embed = new EmbedBuilder()
      .setColor(Colors.INFO)
      .setTitle("📋 Canais de RP")
      .setDescription("Nenhum canal de RP configurado neste servidor.")
      .addFields({
        name: "💡 Como configurar",
        value: "Use `/rp canal` para adicionar canais de RP.",
      })
      .setTimestamp();

    await interaction.reply({ embeds: [embed], ephemeral: true });
    return;
  }

  const modeText = {
    reply: "📢 Responder",
    dm: "✉️ DM",
    delete: "🗑️ Deletar",
    none: "🔇 Silencioso",
  };

  const channelList = channels
    .map((c: RPChannelConfig) => {
      const channelMention = `<#${c.channelId}>`;
      const mode = modeText[c.warningMode] || "📢 Responder";
      const strict = c.strictMode ? "⚠️ Estrito" : "✅ Normal";
      return `${channelMention}\n└ ${mode} | ${strict}`;
    })
    .join("\n\n");

  const embed = new EmbedBuilder()
    .setColor(Colors.WESTERN_GOLD)
    .setTitle("📋 Canais de RP Configurados")
    .setDescription(channelList)
    .setFooter({ text: `Total: ${channels.length} canal(is)` })
    .setTimestamp();

  await interaction.reply({ embeds: [embed], ephemeral: true });
}

async function handleConfigCommand(interaction: ChatInputCommandInteraction) {
  const cooldown = interaction.options.getInteger("cooldown");
  const enabled = interaction.options.getBoolean("ativar");

  const config = loadRPGuildConfig(interaction.guild!.id);

  if (cooldown !== null) {
    config.warningCooldown = cooldown * 1000;
  }

  if (enabled !== null) {
    config.enabled = enabled;
  }

  saveRPGuildConfig(interaction.guild!.id, config);

  const embed = new EmbedBuilder()
    .setColor(Colors.SUCCESS)
    .setTitle("⚙️ Configuração de RP Atualizada")
    .addFields(
      {
        name: "📊 Status",
        value: config.enabled ? "✅ Ativado" : "❌ Desativado",
        inline: true,
      },
      {
        name: "⏱️ Cooldown de Avisos",
        value: `${config.warningCooldown / 1000} segundos`,
        inline: true,
      },
      {
        name: "📋 Canais Configurados",
        value: `${config.channels.filter((c) => c.enabled).length} canal(is)`,
        inline: true,
      }
    )
    .setFooter({ text: "🤠 Xerife Rex - Sistema de RP" })
    .setTimestamp();

  await interaction.reply({ embeds: [embed], ephemeral: true });
}

async function handleViewSheet(interaction: ChatInputCommandInteraction) {
  await interaction.deferReply({ ephemeral: true });

  try {
    const sheets = await db
      .select()
      .from(characterSheets)
      .where(eq(characterSheets.userId, interaction.user.id));

    if (sheets.length === 0) {
      const embed = new EmbedBuilder()
        .setColor(Colors.INFO)
        .setTitle("📋 Ficha de Personagem")
        .setDescription("Você ainda não tem uma ficha de personagem!")
        .addFields({
          name: "💡 Como criar",
          value: "Use `/rp criarficha` para criar sua ficha de personagem.",
        })
        .setTimestamp();

      await interaction.editReply({ embeds: [embed] });
      return;
    }

    const activeSheet = sheets.find(s => s.isActive) || sheets[0];
    const skills = (activeSheet.skills as string[]) || [];
    const traits = (activeSheet.traits as string[]) || [];

    const embed = new EmbedBuilder()
      .setColor(Colors.CHARACTER)
      .setTitle(`📋 ${activeSheet.name}`)
      .setDescription(activeSheet.description || "Sem descrição")
      .setThumbnail(interaction.user.displayAvatarURL())
      .setTimestamp();

    if (activeSheet.appearance) {
      embed.addFields({ name: "👤 Aparência", value: activeSheet.appearance, inline: false });
    }

    if (activeSheet.personality) {
      embed.addFields({ name: "🎭 Personalidade", value: activeSheet.personality, inline: false });
    }

    if (activeSheet.backstory) {
      embed.addFields({ name: "📖 História", value: activeSheet.backstory.substring(0, 1000), inline: false });
    }

    if (skills.length > 0) {
      embed.addFields({ name: "⚔️ Habilidades", value: skills.join(", "), inline: true });
    }

    if (traits.length > 0) {
      embed.addFields({ name: "✨ Traços", value: traits.join(", "), inline: true });
    }

    embed.setFooter({ text: `ID: ${activeSheet.id.substring(0, 8)}` });

    const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
      new ButtonBuilder()
        .setCustomId(`rp_edit_sheet_${activeSheet.id}`)
        .setLabel("✏️ Editar")
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId(`rp_delete_sheet_${activeSheet.id}`)
        .setLabel("🗑️ Deletar")
        .setStyle(ButtonStyle.Danger)
    );

    await interaction.editReply({ embeds: [embed], components: [row] });
  } catch (error) {
    console.error("Error viewing sheet:", error);
    await interaction.editReply({
      content: "❌ Erro ao carregar ficha de personagem.",
    });
  }
}

async function handleCreateSheet(interaction: ChatInputCommandInteraction) {
  await interaction.deferReply({ ephemeral: true });

  const name = interaction.options.getString("nome", true);
  const description = interaction.options.getString("descricao", true);
  const appearance = interaction.options.getString("aparencia");
  const personality = interaction.options.getString("personalidade");
  const backstory = interaction.options.getString("historia");

  try {
    const existing = await db
      .select()
      .from(characterSheets)
      .where(eq(characterSheets.userId, interaction.user.id));

    if (existing.length > 0) {
      await db
        .update(characterSheets)
        .set({ isActive: false })
        .where(eq(characterSheets.userId, interaction.user.id));
    }

    const newSheet = await db.insert(characterSheets).values({
      id: uuidv4(),
      userId: interaction.user.id,
      name,
      description,
      appearance,
      personality,
      backstory,
      isActive: true,
    }).returning();

    const embed = new EmbedBuilder()
      .setColor(Colors.SUCCESS)
      .setTitle("✅ Ficha Criada!")
      .setDescription(`Seu personagem **${name}** foi criado com sucesso!`)
      .addFields(
        { name: "📝 Descrição", value: description, inline: false }
      )
      .setThumbnail(interaction.user.displayAvatarURL())
      .setFooter({ text: "Use /rp ficha para ver sua ficha completa" })
      .setTimestamp();

    if (appearance) {
      embed.addFields({ name: "👤 Aparência", value: appearance, inline: false });
    }

    if (personality) {
      embed.addFields({ name: "🎭 Personalidade", value: personality, inline: false });
    }

    await interaction.editReply({ embeds: [embed] });
  } catch (error) {
    console.error("Error creating sheet:", error);
    await interaction.editReply({
      content: "❌ Erro ao criar ficha de personagem.",
    });
  }
}

async function handleSession(interaction: ChatInputCommandInteraction) {
  await interaction.deferReply();

  const action = interaction.options.getString("acao", true);
  const name = interaction.options.getString("nome");

  try {
    switch (action) {
      case "start": {
        const existingSession = await db
          .select()
          .from(rpSessions)
          .where(and(
            eq(rpSessions.channelId, interaction.channelId),
            eq(rpSessions.status, "active")
          ))
          .limit(1);

        if (existingSession.length > 0) {
          await interaction.editReply({
            content: "❌ Já existe uma sessão ativa neste canal!",
          });
          return;
        }

        const sessionName = name || `Sessão de ${new Date().toLocaleDateString("pt-BR")}`;

        const newSession = await db.insert(rpSessions).values({
          id: uuidv4(),
          guildId: interaction.guildId!,
          channelId: interaction.channelId,
          name: sessionName,
          narratorId: interaction.user.id,
          status: "active",
          participants: [interaction.user.id],
        }).returning();

        const embed = new EmbedBuilder()
          .setColor(Colors.SESSION)
          .setTitle("🎬 Sessão de RP Iniciada!")
          .setDescription(`**${sessionName}**\n\nA sessão de roleplay começou! Todas as ações agora serão registradas.`)
          .addFields(
            { name: "🎭 Narrador", value: `<@${interaction.user.id}>`, inline: true },
            { name: "📍 Canal", value: `<#${interaction.channelId}>`, inline: true },
            { name: "🌤️ Clima", value: "Céu Limpo", inline: true },
            { name: "🕐 Horário", value: "Dia", inline: true }
          )
          .setFooter({ text: "Use /rp cena para definir o cenário" })
          .setTimestamp();

        await interaction.editReply({ embeds: [embed] });
        break;
      }

      case "view": {
        const session = await db
          .select()
          .from(rpSessions)
          .where(and(
            eq(rpSessions.channelId, interaction.channelId),
            eq(rpSessions.status, "active")
          ))
          .limit(1);

        if (session.length === 0) {
          await interaction.editReply({
            content: "❌ Não há sessão ativa neste canal. Use `/rp sessao acao:Iniciar Nova Sessão` para começar.",
          });
          return;
        }

        const s = session[0];
        const weather = WEATHER_OPTIONS.find(w => w.value === s.weather) || WEATHER_OPTIONS[0];
        const time = TIME_OPTIONS.find(t => t.value === s.timeOfDay) || TIME_OPTIONS[1];
        const participants = (s.participants as string[]) || [];

        const embed = new EmbedBuilder()
          .setColor(Colors.SESSION)
          .setTitle(`🎬 ${s.name}`)
          .setDescription(s.currentScene || "Nenhuma cena definida")
          .addFields(
            { name: "🎭 Narrador", value: s.narratorId ? `<@${s.narratorId}>` : "Nenhum", inline: true },
            { name: weather.name.split(" ")[0] + " Clima", value: weather.name, inline: true },
            { name: time.name.split(" ")[0] + " Horário", value: time.name, inline: true },
            { name: "🌡️ Temperatura", value: `${s.temperature}°C`, inline: true },
            { name: "📍 Local", value: s.location || "Não definido", inline: true },
            { name: "👥 Participantes", value: `${participants.length} jogador(es)`, inline: true }
          )
          .setFooter({ text: `Iniciada em ${new Date(s.startedAt).toLocaleString("pt-BR")}` })
          .setTimestamp();

        await interaction.editReply({ embeds: [embed] });
        break;
      }

      case "end": {
        const session = await db
          .select()
          .from(rpSessions)
          .where(and(
            eq(rpSessions.channelId, interaction.channelId),
            eq(rpSessions.status, "active")
          ))
          .limit(1);

        if (session.length === 0) {
          await interaction.editReply({
            content: "❌ Não há sessão ativa para encerrar.",
          });
          return;
        }

        await db
          .update(rpSessions)
          .set({
            status: "ended",
            endedAt: new Date(),
          })
          .where(eq(rpSessions.id, session[0].id));

        const duration = Date.now() - new Date(session[0].startedAt).getTime();
        const hours = Math.floor(duration / 3600000);
        const minutes = Math.floor((duration % 3600000) / 60000);

        const embed = new EmbedBuilder()
          .setColor(Colors.WARNING)
          .setTitle("🎬 Sessão Encerrada")
          .setDescription(`A sessão **${session[0].name}** foi encerrada.`)
          .addFields(
            { name: "⏱️ Duração", value: `${hours}h ${minutes}min`, inline: true },
            { name: "👥 Participantes", value: `${((session[0].participants as string[]) || []).length}`, inline: true }
          )
          .setTimestamp();

        await interaction.editReply({ embeds: [embed] });
        break;
      }
    }
  } catch (error) {
    console.error("Error handling session:", error);
    await interaction.editReply({
      content: "❌ Erro ao gerenciar sessão.",
    });
  }
}

async function handleScene(interaction: ChatInputCommandInteraction) {
  await interaction.deferReply();

  const weather = interaction.options.getString("clima");
  const timeOfDay = interaction.options.getString("horario");
  const temperature = interaction.options.getInteger("temperatura");
  const location = interaction.options.getString("local");
  const description = interaction.options.getString("descricao");

  try {
    const session = await db
      .select()
      .from(rpSessions)
      .where(and(
        eq(rpSessions.channelId, interaction.channelId),
        eq(rpSessions.status, "active")
      ))
      .limit(1);

    if (session.length === 0) {
      await interaction.editReply({
        content: "❌ Não há sessão ativa neste canal. Use `/rp sessao acao:Iniciar Nova Sessão` primeiro.",
      });
      return;
    }

    const updates: any = {};
    if (weather) updates.weather = weather;
    if (timeOfDay) updates.timeOfDay = timeOfDay;
    if (temperature !== null) updates.temperature = temperature;
    if (location) updates.location = location;
    if (description) updates.currentScene = description;

    if (Object.keys(updates).length > 0) {
      await db
        .update(rpSessions)
        .set(updates)
        .where(eq(rpSessions.id, session[0].id));
    }

    const weatherInfo = WEATHER_OPTIONS.find(w => w.value === (weather || session[0].weather)) || WEATHER_OPTIONS[0];
    const timeInfo = TIME_OPTIONS.find(t => t.value === (timeOfDay || session[0].timeOfDay)) || TIME_OPTIONS[1];
    const finalTemp = temperature ?? session[0].temperature;
    const finalLocation = location || session[0].location || "Local não definido";
    const finalScene = description || session[0].currentScene;

    const embed = new EmbedBuilder()
      .setColor(Colors.WESTERN_GOLD)
      .setTitle("🎭 Cena Atualizada")
      .setDescription(finalScene ? `*${finalScene}*` : "*Nenhuma descrição de cena*")
      .addFields(
        { name: weatherInfo.name.split(" ")[0] + " Clima", value: `${weatherInfo.name}\n${weatherInfo.description}`, inline: true },
        { name: timeInfo.name.split(" ")[0] + " Horário", value: `${timeInfo.name}\n${timeInfo.description}`, inline: true },
        { name: "🌡️ Temperatura", value: `${finalTemp}°C`, inline: true },
        { name: "📍 Local", value: finalLocation, inline: true }
      )
      .setFooter({ text: "As condições da cena afetam os personagens!" })
      .setTimestamp();

    await interaction.editReply({ embeds: [embed] });
  } catch (error) {
    console.error("Error handling scene:", error);
    await interaction.editReply({
      content: "❌ Erro ao atualizar cena.",
    });
  }
}

async function handleDiceRoll(interaction: ChatInputCommandInteraction) {
  const diceType = interaction.options.getString("tipo", true);
  const action = interaction.options.getString("acao");
  const modifier = interaction.options.getInteger("modificador") || 0;

  const diceMax: Record<string, number> = {
    d4: 4,
    d6: 6,
    d8: 8,
    d10: 10,
    d12: 12,
    d20: 20,
    d100: 100,
  };

  const diceEmoji: Record<string, string> = {
    d4: "🍀",
    d6: "🏃",
    d8: "💪",
    d10: "🛡️",
    d12: "⚔️",
    d20: "🎯",
    d100: "💯",
  };

  const max = diceMax[diceType];
  const roll = Math.floor(Math.random() * max) + 1;
  const total = roll + modifier;

  let resultText = "";
  let resultColor: number = Colors.INFO;

  if (diceType === "d20") {
    if (roll === 20) {
      resultText = "🌟 **SUCESSO CRÍTICO!** 🌟";
      resultColor = Colors.SUCCESS as number;
    } else if (roll === 1) {
      resultText = "💀 **FALHA CRÍTICA!** 💀";
      resultColor = Colors.ERROR as number;
    } else if (total >= 15) {
      resultText = "✅ Sucesso!";
      resultColor = Colors.SUCCESS as number;
    } else if (total >= 10) {
      resultText = "⚠️ Sucesso Parcial";
      resultColor = Colors.WARNING as number;
    } else {
      resultText = "❌ Falha";
      resultColor = Colors.ERROR as number;
    }
  } else if (diceType === "d100") {
    if (roll <= 5) {
      resultText = "🌟 **SUCESSO EXTRAORDINÁRIO!** 🌟";
      resultColor = Colors.SUCCESS as number;
    } else if (roll <= 30) {
      resultText = "✅ Sucesso!";
      resultColor = Colors.SUCCESS as number;
    } else if (roll <= 50) {
      resultText = "⚠️ Sucesso Parcial";
      resultColor = Colors.WARNING as number;
    } else if (roll >= 96) {
      resultText = "💀 **FALHA CATASTRÓFICA!** 💀";
      resultColor = Colors.ERROR as number;
    } else {
      resultText = "❌ Falha";
      resultColor = Colors.ERROR as number;
    }
  }

  const embed = new EmbedBuilder()
    .setColor(resultColor)
    .setTitle(`${diceEmoji[diceType]} Rolagem de ${diceType.toUpperCase()}`)
    .setDescription(action ? `**Ação:** ${action}` : null)
    .addFields(
      { name: "🎲 Resultado", value: `\`${roll}\``, inline: true },
      { name: "➕ Modificador", value: `\`${modifier >= 0 ? "+" : ""}${modifier}\``, inline: true },
      { name: "📊 Total", value: `\`${total}\``, inline: true }
    )
    .setFooter({ text: `Rolado por ${interaction.user.displayName}` })
    .setTimestamp();

  if (resultText) {
    embed.addFields({ name: "📋 Resultado", value: resultText, inline: false });
  }

  await interaction.reply({ embeds: [embed] });
}

async function handleLocation(interaction: ChatInputCommandInteraction) {
  await interaction.deferReply({ ephemeral: true });

  const action = interaction.options.getString("acao", true);

  try {
    if (action === "list") {
      const locations = await db
        .select()
        .from(rpLocations)
        .where(eq(rpLocations.guildId, interaction.guildId!));

      if (locations.length === 0) {
        await interaction.editReply({
          content: "📍 Nenhum local criado ainda. Use `/rp local acao:Criar Local` para criar um.",
        });
        return;
      }

      const locationList = locations.map(l => {
        const typeEmoji: Record<string, string> = {
          saloon: "🏠",
          sheriff_office: "🏛️",
          store: "🏪",
          mine: "⛏️",
          desert: "🌵",
          mountain: "🏔️",
          forest: "🌲",
          ranch: "🏚️",
          church: "⛪",
          doctor: "🏥",
        };
        return `${typeEmoji[l.type] || "📍"} **${l.name}**\n└ ${l.description.substring(0, 80)}...`;
      }).join("\n\n");

      const embed = new EmbedBuilder()
        .setColor(Colors.WESTERN_GOLD)
        .setTitle("📍 Locais de RP")
        .setDescription(locationList)
        .setFooter({ text: `Total: ${locations.length} local(is)` })
        .setTimestamp();

      await interaction.editReply({ embeds: [embed] });
    } else if (action === "create") {
      const name = interaction.options.getString("nome");
      const description = interaction.options.getString("descricao");
      const type = interaction.options.getString("tipo");

      if (!name || !description || !type) {
        await interaction.editReply({
          content: "❌ Para criar um local, você precisa fornecer nome, descrição e tipo.",
        });
        return;
      }

      await db.insert(rpLocations).values({
        id: uuidv4(),
        guildId: interaction.guildId!,
        name,
        description,
        type,
        createdBy: interaction.user.id,
      });

      const embed = new EmbedBuilder()
        .setColor(Colors.SUCCESS)
        .setTitle("✅ Local Criado!")
        .setDescription(`O local **${name}** foi criado com sucesso.`)
        .addFields(
          { name: "📝 Descrição", value: description, inline: false },
          { name: "🏷️ Tipo", value: type, inline: true }
        )
        .setTimestamp();

      await interaction.editReply({ embeds: [embed] });
    }
  } catch (error) {
    console.error("Error handling location:", error);
    await interaction.editReply({
      content: "❌ Erro ao gerenciar locais.",
    });
  }
}
