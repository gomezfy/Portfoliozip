import {
  SlashCommandBuilder,
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ChatInputCommandInteraction,
  MessageFlags,
  StringSelectMenuBuilder,
  ComponentType,
} from "discord.js";
import { getUserSilver, addUserSilver } from "../../utils/dataManager";
import { addItem, getItem } from "../../utils/inventoryManager";
import { applyLocalizations } from "../../utils/commandLocalizations";
const {
  isPunished,
  formatTime,
  getRemainingTime,
} = require("../../utils/punishmentManager");
import { createAutoWanted } from "../../utils/autoWanted";
import { getGangBoosts } from "../../utils/gangueManager";
import {
  getMuteEmoji,
  getSilverCoinEmoji,
  getGoldBarEmoji,
  getClockEmoji,
  getCancelEmoji,
  getWarningEmoji,
  getElSombraEmoji,
  getSkullOutlawEmoji,
  getDiamondEmoji,
} from "../../utils/customEmojis";
import { t, getLocale } from "../../utils/i18n";
import { trackCrimeAction, trackEarning } from "../../utils/missionTracker";

const NPC_NAME = "El Sombra";
const NPC_IMAGE = "https://i.postimg.cc/HxqJQqGz/western-outlaw-bandit-npc.png";

const cooldowns = new Map<string, Map<string, number>>();

interface CrimeType {
  id: string;
  name: string;
  nameEn: string;
  description: string;
  emoji: string;
  successRate: number;
  silverMin: number;
  silverMax: number;
  goldChance: number;
  goldAmount: number;
  diamondChance: number;
  jailTime: number;
  cooldown: number;
  requiredLevel?: number;
}

const CRIMES: CrimeType[] = [
  {
    id: "pickpocket",
    name: "Bater Carteira",
    nameEn: "Pickpocket",
    description: "Roube moedas dos bolsos de cidadãos desatentos na cidade.",
    emoji: "👛",
    successRate: 80,
    silverMin: 50,
    silverMax: 200,
    goldChance: 5,
    goldAmount: 1,
    diamondChance: 0,
    jailTime: 5,
    cooldown: 60000,
  },
  {
    id: "store_robbery",
    name: "Roubo de Loja",
    nameEn: "Store Robbery",
    description: "Assalte a loja geral da cidade. Cuidado com o dono armado!",
    emoji: "🏪",
    successRate: 65,
    silverMin: 150,
    silverMax: 400,
    goldChance: 15,
    goldAmount: 1,
    diamondChance: 2,
    jailTime: 10,
    cooldown: 180000,
  },
  {
    id: "smuggling",
    name: "Contrabando",
    nameEn: "Smuggling",
    description: "Transporte mercadorias ilegais pela fronteira.",
    emoji: "📦",
    successRate: 55,
    silverMin: 300,
    silverMax: 700,
    goldChance: 25,
    goldAmount: 2,
    diamondChance: 5,
    jailTime: 15,
    cooldown: 300000,
  },
  {
    id: "stagecoach",
    name: "Assalto a Carruagem",
    nameEn: "Stagecoach Robbery",
    description: "Embosque uma carruagem de transporte de valores.",
    emoji: "🐴",
    successRate: 45,
    silverMin: 500,
    silverMax: 1200,
    goldChance: 40,
    goldAmount: 3,
    diamondChance: 10,
    jailTime: 20,
    cooldown: 600000,
  },
  {
    id: "train_heist",
    name: "Roubo de Trem",
    nameEn: "Train Heist",
    description: "O crime mais ousado! Assalte o trem de carga do governo.",
    emoji: "🚂",
    successRate: 30,
    silverMin: 1000,
    silverMax: 2500,
    goldChance: 60,
    goldAmount: 5,
    diamondChance: 20,
    jailTime: 30,
    cooldown: 1200000,
  },
];

function getCrimeCooldown(userId: string, crimeId: string): number {
  const userCooldowns = cooldowns.get(userId);
  if (!userCooldowns) return 0;
  return userCooldowns.get(crimeId) || 0;
}

function setCrimeCooldown(userId: string, crimeId: string, time: number): void {
  if (!cooldowns.has(userId)) {
    cooldowns.set(userId, new Map());
  }
  cooldowns.get(userId)!.set(crimeId, time);
}

function formatCooldownTime(ms: number): string {
  const seconds = Math.ceil(ms / 1000);
  if (seconds < 60) return `${seconds}s`;
  const minutes = Math.floor(seconds / 60);
  const remainingSeconds = seconds % 60;
  return `${minutes}m ${remainingSeconds}s`;
}

export default {
  data: applyLocalizations(
    new SlashCommandBuilder()
      .setName("crime")
      .setDescription("Visit El Sombra and commit crimes for rewards!")
      .setDescriptionLocalizations({
        "pt-BR": "Visite El Sombra e cometa crimes por recompensas!",
      }),
    "crime"
  ),
  cooldown: 3,
  
  async execute(interaction: ChatInputCommandInteraction): Promise<void> {
    const userId = interaction.user.id;
    const locale = getLocale(interaction);
    const isPtBr = locale === "pt-BR";

    const punishment = isPunished(userId);
    if (punishment) {
      const remaining = getRemainingTime(userId);
      const lockEmoji = getMuteEmoji();
      const timerEmoji = getClockEmoji();
      await interaction.reply({
        content: `${lockEmoji} **${isPtBr ? "Você está na cadeia!" : "You're in jail!"}**\n\n${punishment.reason}\n\n${timerEmoji} ${isPtBr ? "Tempo restante" : "Time remaining"}: **${formatTime(remaining)}**`,
        flags: MessageFlags.Ephemeral,
      });
      return;
    }

    const silverEmoji = getSilverCoinEmoji();
    const goldEmoji = getGoldBarEmoji();
    const clockEmoji = getClockEmoji();
    const warningEmoji = getWarningEmoji();
    const elSombraEmoji = getElSombraEmoji();
    const skullEmoji = getSkullOutlawEmoji();

    const crimeOptions = CRIMES.map((crime) => {
      const cooldownEnd = getCrimeCooldown(userId, crime.id);
      const now = Date.now();
      const isOnCooldown = cooldownEnd > now;
      const cooldownText = isOnCooldown
        ? ` [${clockEmoji} ${formatCooldownTime(cooldownEnd - now)}]`
        : "";

      return {
        label: `${isPtBr ? crime.name : crime.nameEn}${cooldownText}`,
        description: `${crime.successRate}% sucesso | ${crime.silverMin}-${crime.silverMax} ${isPtBr ? "prata" : "silver"}`,
        value: crime.id,
        emoji: crime.emoji,
      };
    });

    const selectMenu = new StringSelectMenuBuilder()
      .setCustomId(`crime_select_${userId}`)
      .setPlaceholder(isPtBr ? "Escolha um crime..." : "Choose a crime...")
      .addOptions(crimeOptions);

    const row = new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(selectMenu);

    const mainEmbed = new EmbedBuilder()
      .setColor("#2C2C2C")
      .setTitle(`${skullEmoji} ${NPC_NAME} - ${isPtBr ? "Mercado Negro" : "Black Market"}`)
      .setDescription(
        isPtBr
          ? `*Um homem misterioso com máscara preta te chama para um beco escuro...*\n\n"${elSombraEmoji} **Psst... parceiro!** Procurando uma maneira de ganhar dinheiro fácil? Eu tenho alguns... *trabalhos* que podem te interessar.\n\nMas cuidado - se for pego, você vai parar na cadeia!"\n\n**Escolha seu crime abaixo:**`
          : `*A mysterious masked man beckons you into a dark alley...*\n\n"${elSombraEmoji} **Psst... partner!** Looking for a way to make easy money? I got some... *jobs* that might interest you.\n\nBut be careful - if you get caught, you'll end up in jail!"\n\n**Choose your crime below:**`
      )
      .setThumbnail(NPC_IMAGE)
      .addFields(
        {
          name: `${warningEmoji} ${isPtBr ? "Aviso" : "Warning"}`,
          value: isPtBr
            ? "Crimes mais lucrativos têm maior chance de falha e tempo de prisão!"
            : "More lucrative crimes have higher failure chance and jail time!",
          inline: false,
        }
      )
      .setImage("https://i.postimg.cc/T1fNQRjL/crime-banner.png")
      .setFooter({
        text: isPtBr
          ? `${NPC_NAME} sussurra: "O crime compensa... às vezes."`
          : `${NPC_NAME} whispers: "Crime pays... sometimes."`,
      })
      .setTimestamp();

    const response = await interaction.reply({
      embeds: [mainEmbed],
      components: [row],
      fetchReply: true,
    });

    const collector = response.createMessageComponentCollector({
      componentType: ComponentType.StringSelect,
      filter: (i) => i.user.id === userId && i.customId === `crime_select_${userId}`,
      time: 60000,
    });

    collector.on("collect", async (selectInteraction) => {
      const selectedCrimeId = selectInteraction.values[0];
      const crime = CRIMES.find((c) => c.id === selectedCrimeId);

      if (!crime) {
        await selectInteraction.reply({
          content: `${getCancelEmoji()} ${isPtBr ? "Crime não encontrado!" : "Crime not found!"}`,
          flags: MessageFlags.Ephemeral,
        });
        return;
      }

      const cooldownEnd = getCrimeCooldown(userId, crime.id);
      const now = Date.now();

      if (cooldownEnd > now) {
        await selectInteraction.reply({
          content: `${clockEmoji} ${isPtBr ? `Aguarde **${formatCooldownTime(cooldownEnd - now)}** para fazer outro **${crime.name}**!` : `Wait **${formatCooldownTime(cooldownEnd - now)}** to do another **${crime.nameEn}**!`}`,
          flags: MessageFlags.Ephemeral,
        });
        return;
      }

      await selectInteraction.deferUpdate();

      const progressEmbed = new EmbedBuilder()
        .setColor("#FFD700")
        .setTitle(`${crime.emoji} ${isPtBr ? "Executando crime..." : "Committing crime..."}`)
        .setDescription(
          isPtBr
            ? `**${crime.name}**\n\n*${NPC_NAME} observa de longe enquanto você executa o plano...*\n\n⏳ Aguarde...`
            : `**${crime.nameEn}**\n\n*${NPC_NAME} watches from afar as you execute the plan...*\n\n⏳ Please wait...`
        )
        .setThumbnail(NPC_IMAGE);

      await interaction.editReply({
        embeds: [progressEmbed],
        components: [],
      });

      await new Promise((resolve) => setTimeout(resolve, 2000 + Math.random() * 2000));

      const gangBoosts = await getGangBoosts(userId, interaction.guildId || "");
      const boostedSuccessRate = Math.min(crime.successRate + gangBoosts.crimeBoost, 95);
      
      const roll = Math.random() * 100;
      const success = roll < boostedSuccessRate;

      const cooldownReduction = 1 - (gangBoosts.cooldownReduction / 100);
      const reducedCooldown = Math.floor(crime.cooldown * cooldownReduction);
      setCrimeCooldown(userId, crime.id, Date.now() + reducedCooldown);

      if (success) {
        trackCrimeAction(userId, interaction.user.username);
        
        const silverReward = Math.floor(
          Math.random() * (crime.silverMax - crime.silverMin + 1) + crime.silverMin
        );
        
        let rewards: string[] = [];
        let goldEarned = 0;
        let diamondEarned = 0;

        const silverResult = await addUserSilver(userId, silverReward);
        if (silverResult.success) {
          trackEarning(userId, interaction.user.username, silverReward);
          rewards.push(`${silverReward} ${silverEmoji}`);
        }

        if (Math.random() * 100 < crime.goldChance) {
          const goldResult = await addItem(userId, "gold", crime.goldAmount);
          if (goldResult.success) {
            goldEarned = crime.goldAmount;
            rewards.push(`${crime.goldAmount} ${goldEmoji}`);
          }
        }

        if (Math.random() * 100 < crime.diamondChance) {
          const diamondResult = await addItem(userId, "diamond", 1);
          if (diamondResult.success) {
            diamondEarned = 1;
            rewards.push(`1 💎`);
          }
        }

        const bountyChance = 100 - crime.successRate;
        let wantedResult: { success: boolean; amount?: number } = { success: false, amount: 0 };
        if (Math.random() * 100 < bountyChance / 2) {
          const result = await createAutoWanted(
            interaction.client,
            interaction.guildId || "",
            interaction.user,
            Math.floor(silverReward * 0.5)
          );
          wantedResult = { success: result.success, amount: result.amount || 0 };
        }

        const successEmbed = new EmbedBuilder()
          .setColor("#00FF00")
          .setTitle(`${crime.emoji} ${isPtBr ? "Crime Bem Sucedido!" : "Crime Successful!"}`)
          .setDescription(
            isPtBr
              ? `*${NPC_NAME} sorri por baixo da máscara...*\n\n"${elSombraEmoji} **Belo trabalho, parceiro!** Você executou o **${crime.name}** perfeitamente!\n\nAqui está sua parte do butim..."`
              : `*${NPC_NAME} grins beneath his mask...*\n\n"${elSombraEmoji} **Nice work, partner!** You pulled off the **${crime.nameEn}** perfectly!\n\nHere's your cut of the loot..."`
          )
          .setThumbnail(NPC_IMAGE)
          .addFields(
            {
              name: `💰 ${isPtBr ? "Recompensas" : "Rewards"}`,
              value: rewards.length > 0 ? rewards.join(" + ") : isPtBr ? "Nenhuma" : "None",
              inline: true,
            },
            {
              name: `${clockEmoji} ${isPtBr ? "Cooldown" : "Cooldown"}`,
              value: formatCooldownTime(crime.cooldown),
              inline: true,
            }
          )
          .setFooter({
            text: wantedResult.success
              ? isPtBr
                ? `⚠️ Alguém te viu! Recompensa de ${wantedResult.amount} prata pela sua cabeça!`
                : `⚠️ Someone saw you! ${wantedResult.amount} silver bounty on your head!`
              : isPtBr
              ? `${NPC_NAME}: "Volte quando precisar de mais trabalho!"`
              : `${NPC_NAME}: "Come back when you need more work!"`,
          })
          .setTimestamp();

        await interaction.editReply({
          embeds: [successEmbed],
          components: [],
        });
      } else {
        const failEmbed = new EmbedBuilder()
          .setColor("#FF0000")
          .setTitle(`🚨 ${isPtBr ? "Falhou!" : "Failed!"}`)
          .setDescription(
            isPtBr
              ? `*Algo deu errado no plano...*\n\n"${elSombraEmoji} **Droga!** Você falhou no **${crime.name}**!\n\nMelhor sorte da próxima vez, parceiro."\n\n*${NPC_NAME} balança a cabeça desapontado...*`
              : `*Something went wrong with the plan...*\n\n"${elSombraEmoji} **Damn!** You failed the **${crime.nameEn}**!\n\nBetter luck next time, partner."\n\n*${NPC_NAME} shakes his head in disappointment...*`
          )
          .setThumbnail(NPC_IMAGE)
          .addFields(
            {
              name: `💸 ${isPtBr ? "Resultado" : "Result"}`,
              value: isPtBr ? "Você não conseguiu nada" : "You got nothing",
              inline: true,
            },
            {
              name: `${clockEmoji} ${isPtBr ? "Cooldown" : "Cooldown"}`,
              value: formatCooldownTime(crime.cooldown),
              inline: true,
            }
          )
          .setFooter({
            text: isPtBr
              ? `${NPC_NAME}: "Tente novamente mais tarde..."`
              : `${NPC_NAME}: "Try again later..."`,
          })
          .setTimestamp();

        await interaction.editReply({
          embeds: [failEmbed],
          components: [],
        });
      }

      collector.stop();
    });

    collector.on("end", async (collected, reason) => {
      if (reason === "time" && collected.size === 0) {
        const timeoutEmbed = new EmbedBuilder()
          .setColor("#808080")
          .setTitle(`${skullEmoji} ${NPC_NAME}`)
          .setDescription(
            isPtBr
              ? `*${NPC_NAME} se afasta nas sombras...*\n\n"Hmph... parece que você não tem coragem para isso. Volte quando estiver pronto, parceiro."`
              : `*${NPC_NAME} fades into the shadows...*\n\n"Hmph... seems like you don't have the guts for this. Come back when you're ready, partner."`
          )
          .setThumbnail(NPC_IMAGE)
          .setFooter({ text: isPtBr ? "Use /crime novamente para tentar" : "Use /crime again to try" });

        try {
          await interaction.editReply({
            embeds: [timeoutEmbed],
            components: [],
          });
        } catch (error) {
          // Ignore error
        }
      }
    });
  },
};
