import {
  SlashCommandBuilder,
  ChatInputCommandInteraction,
  EmbedBuilder,
  MessageFlags,
  User,
  Client,
} from "discord.js";
import { getLocale } from "../../utils/i18n";
import {
  getGangueDoUsuario,
  criarGangue,
  convidarMembro,
  aceitarConvite,
  doar,
  promoverMembro,
  sairDaGangue,
  expulsarMembro,
  dissolverGangue,
  buscarGanguePorNome,
  getConvitesPendentes,
  GangueInfo,
  CargoGangue,
} from "../../utils/gangueManager";
import { 
  getEmoji,
  getTrophyEmoji,
  getStarEmoji,
  getSilverMedalEmoji,
  getCowboyEmoji,
  getStatsEmoji,
  getMoneybagEmoji,
  getCowboysEmoji,
  getGiftEmoji,
  getElSombraEmoji,
  getSwordsEmoji,
  getBankEmoji,
  getTimerEmoji,
  getCheckEmoji,
  getCrossEmoji,
  getPartyEmoji,
  getSkullOutlawEmoji,
  getClockEmoji,
  getScrollEmoji,
  getInfoEmoji,
  getShowdsRexEmoji,
} from "../../utils/customEmojis";

const getCargoEmojis = (): { [key: string]: string } => ({
  lider_1: getTrophyEmoji(),
  lider_2: getStarEmoji(),
  veterano: getSilverMedalEmoji(),
  membro_regular: getCowboyEmoji(),
});

const CARGO_NOMES_PT: { [key: string]: string } = {
  lider_1: "Líder Supremo",
  lider_2: "Líder",
  veterano: "Veterano",
  membro_regular: "Membro",
};

const CARGO_NOMES_EN: { [key: string]: string } = {
  lider_1: "Supreme Leader",
  lider_2: "Leader",
  veterano: "Veteran",
  membro_regular: "Member",
};

function createProgressBar(current: number, max: number, length: number = 10): string {
  const percentage = Math.min(current / max, 1);
  const filledBars = Math.floor(percentage * length);
  const emptyBars = length - filledBars;
  return `${"█".repeat(filledBars)}${"░".repeat(emptyBars)} ${Math.floor(percentage * 100)}%`;
}

function formatNumber(num: number): string {
  if (num >= 1000000) {
    return (num / 1000000).toFixed(1) + "M";
  }
  if (num >= 1000) {
    return (num / 1000).toFixed(1) + "K";
  }
  return num.toString();
}

async function getDisplayName(client: Client, userId: string): Promise<string> {
  try {
    const user = await client.users.fetch(userId);
    return user.globalName || user.displayName || user.username;
  } catch {
    return userId;
  }
}

async function createGangueEmbed(gangue: GangueInfo, client: Client, isPtBr: boolean = true): Promise<EmbedBuilder> {
  const membrosOrdenados = [...gangue.membros].sort((a, b) => {
    const ordem: { [key: string]: number } = { lider_1: 0, lider_2: 1, veterano: 2, membro_regular: 3 };
    return ordem[a.cargo] - ordem[b.cargo];
  });

  const lideres = membrosOrdenados.filter(m => m.cargo === "lider_1" || m.cargo === "lider_2");
  const veteranos = membrosOrdenados.filter(m => m.cargo === "veterano");
  const membros = membrosOrdenados.filter(m => m.cargo === "membro_regular");
  const CARGO_NOMES = isPtBr ? CARGO_NOMES_PT : CARGO_NOMES_EN;

  let hierarquiaText = "";
  const cargoEmojis = getCargoEmojis();
  
  if (lideres.length > 0) {
    hierarquiaText += isPtBr ? "**Liderança:**\n" : "**Leadership:**\n";
    for (const m of lideres) {
      const displayName = await getDisplayName(client, m.userId);
      hierarquiaText += `${cargoEmojis[m.cargo]} ${displayName} (${CARGO_NOMES[m.cargo]})\n`;
    }
  }

  if (veteranos.length > 0) {
    hierarquiaText += isPtBr ? "\n**Veteranos:**\n" : "\n**Veterans:**\n";
    for (const m of veteranos) {
      const displayName = await getDisplayName(client, m.userId);
      hierarquiaText += `${cargoEmojis[m.cargo]} ${displayName}\n`;
    }
  }

  if (membros.length > 0) {
    hierarquiaText += isPtBr ? "\n**Membros:**\n" : "\n**Members:**\n";
    const membrosLimitados = membros.slice(0, 10);
    for (const m of membrosLimitados) {
      const displayName = await getDisplayName(client, m.userId);
      hierarquiaText += `${cargoEmojis[m.cargo]} ${displayName}\n`;
    }
    if (membros.length > 10) {
      hierarquiaText += isPtBr ? `... e mais ${membros.length - 10} membros\n` : `... and ${membros.length - 10} more members\n`;
    }
  }

  const silverEmoji = getEmoji("silver_coin") || "🪙";
  const goldEmoji = getEmoji("gold_bar") || "🪙";

  const embed = new EmbedBuilder()
    .setTitle(`${getSkullOutlawEmoji()} ${gangue.nome}`)
    .setColor(0x8B4513)
    .setDescription(isPtBr ? `*Uma gangue temida do Velho Oeste*` : `*A feared gang of the Wild West*`)
    .addFields(
      {
        name: `${getStatsEmoji()} ${isPtBr ? "Nível" : "Level"}`,
        value: `**${gangue.level}/15**\n${createProgressBar(gangue.xpTotal, gangue.xpProximoNivel)}`,
        inline: true,
      },
      {
        name: `${getMoneybagEmoji()} ${isPtBr ? "Tesouro" : "Treasury"}`,
        value: `${silverEmoji} ${formatNumber(gangue.tesouroPrata)} ${isPtBr ? "Prata" : "Silver"}\n${goldEmoji} ${formatNumber(gangue.tesouroOuro)} ${isPtBr ? "Ouro" : "Gold"}`,
        inline: true,
      },
      {
        name: `${getCowboysEmoji()} ${isPtBr ? "Membros" : "Members"}`,
        value: `${gangue.membros.length}/${gangue.maxMembros}`,
        inline: true,
      },
      {
        name: `${getStatsEmoji()} XP`,
        value: `${formatNumber(gangue.xpTotal)} / ${formatNumber(gangue.xpProximoNivel)}`,
        inline: true,
      },
      {
        name: `${getGiftEmoji()} ${isPtBr ? "Benefícios Ativos" : "Active Benefits"}`,
        value: [
          `${getElSombraEmoji()} ${isPtBr ? "Crime" : "Crime"}: **+${gangue.boosts.crimeBoost}%** ${isPtBr ? "sucesso" : "success"}`,
          `${getShowdsRexEmoji()} ${isPtBr ? "Duelo" : "Duel"}: **+${gangue.boosts.duelDamageBoost}** ${isPtBr ? "dano" : "damage"}`,
          `${getBankEmoji()} ${isPtBr ? "Assalto" : "Heist"}: **+${gangue.boosts.bankrobBoost}%** ${isPtBr ? "saque" : "loot"}`,
          `${getTimerEmoji()} Cooldown: **-${gangue.boosts.cooldownReduction}%**`,
        ].join("\n"),
        inline: true,
      },
      {
        name: "\u200B",
        value: "\u200B",
        inline: true,
      },
      {
        name: `${getScrollEmoji()} ${isPtBr ? "Hierarquia" : "Hierarchy"}`,
        value: hierarquiaText || (isPtBr ? "Nenhum membro" : "No members"),
        inline: false,
      }
    )
    .setFooter({ text: isPtBr ? "Use /gangue para gerenciar sua gangue" : "Use /gangue to manage your gang" })
    .setTimestamp();

  return embed;
}

export default {
  data: new SlashCommandBuilder()
    .setName("gangue")
    .setDescription("Wild West gang system")
    .setDescriptionLocalizations({
      "pt-BR": "Sistema de gangues do Velho Oeste",
      "en-US": "Wild West gang system",
    })
    .addSubcommand(subcommand =>
      subcommand
        .setName("criar")
        .setDescription("Create your own gang")
        .setDescriptionLocalizations({ 
          "pt-BR": "Crie sua própria gangue",
          "en-US": "Create your own gang"
        })
        .addStringOption(option =>
          option
            .setName("nome")
            .setDescription("Your gang name (3-32 characters)")
            .setDescriptionLocalizations({ 
              "pt-BR": "Nome da sua gangue (3-32 caracteres)",
              "en-US": "Your gang name (3-32 characters)"
            })
            .setRequired(true)
            .setMinLength(3)
            .setMaxLength(32)
        )
    )
    .addSubcommand(subcommand =>
      subcommand
        .setName("info")
        .setDescription("View gang information")
        .setDescriptionLocalizations({ 
          "pt-BR": "Veja informações de uma gangue",
          "en-US": "View gang information"
        })
        .addStringOption(option =>
          option
            .setName("gangue")
            .setDescription("Gang name (leave empty to see yours)")
            .setDescriptionLocalizations({ 
              "pt-BR": "Nome da gangue (deixe vazio para ver a sua)",
              "en-US": "Gang name (leave empty to see yours)"
            })
            .setRequired(false)
        )
        .addUserOption(option =>
          option
            .setName("membro")
            .setDescription("View a specific user's gang")
            .setDescriptionLocalizations({ 
              "pt-BR": "Ver a gangue de um usuário específico",
              "en-US": "View a specific user's gang"
            })
            .setRequired(false)
        )
    )
    .addSubcommand(subcommand =>
      subcommand
        .setName("convidar")
        .setDescription("Invite a member to your gang")
        .setDescriptionLocalizations({ 
          "pt-BR": "Convide um membro para sua gangue",
          "en-US": "Invite a member to your gang"
        })
        .addUserOption(option =>
          option
            .setName("membro")
            .setDescription("User to invite")
            .setDescriptionLocalizations({ 
              "pt-BR": "Usuário para convidar",
              "en-US": "User to invite"
            })
            .setRequired(true)
        )
    )
    .addSubcommand(subcommand =>
      subcommand
        .setName("aceitar")
        .setDescription("Accept a gang invitation")
        .setDescriptionLocalizations({ 
          "pt-BR": "Aceite um convite para uma gangue",
          "en-US": "Accept a gang invitation"
        })
        .addStringOption(option =>
          option
            .setName("gangue")
            .setDescription("Name of the gang that invited you")
            .setDescriptionLocalizations({ 
              "pt-BR": "Nome da gangue que te convidou",
              "en-US": "Name of the gang that invited you"
            })
            .setRequired(true)
        )
    )
    .addSubcommand(subcommand =>
      subcommand
        .setName("convites")
        .setDescription("View your pending invitations")
        .setDescriptionLocalizations({ 
          "pt-BR": "Veja seus convites pendentes",
          "en-US": "View your pending invitations"
        })
    )
    .addSubcommand(subcommand =>
      subcommand
        .setName("doar")
        .setDescription("Donate resources to the gang treasury")
        .setDescriptionLocalizations({ 
          "pt-BR": "Doe recursos para o tesouro da gangue",
          "en-US": "Donate resources to the gang treasury"
        })
        .addIntegerOption(option =>
          option
            .setName("prata")
            .setDescription("Amount of silver to donate")
            .setDescriptionLocalizations({ 
              "pt-BR": "Quantidade de prata para doar",
              "en-US": "Amount of silver to donate"
            })
            .setRequired(false)
            .setMinValue(0)
        )
        .addIntegerOption(option =>
          option
            .setName("ouro")
            .setDescription("Amount of gold to donate")
            .setDescriptionLocalizations({ 
              "pt-BR": "Quantidade de ouro para doar",
              "en-US": "Amount of gold to donate"
            })
            .setRequired(false)
            .setMinValue(0)
        )
    )
    .addSubcommand(subcommand =>
      subcommand
        .setName("promover")
        .setDescription("Promote or demote a member")
        .setDescriptionLocalizations({ 
          "pt-BR": "Promova ou rebaixe um membro",
          "en-US": "Promote or demote a member"
        })
        .addUserOption(option =>
          option
            .setName("membro")
            .setDescription("Member to promote/demote")
            .setDescriptionLocalizations({ 
              "pt-BR": "Membro para promover/rebaixar",
              "en-US": "Member to promote/demote"
            })
            .setRequired(true)
        )
        .addStringOption(option =>
          option
            .setName("cargo")
            .setDescription("New member role")
            .setDescriptionLocalizations({ 
              "pt-BR": "Novo cargo do membro",
              "en-US": "New member role"
            })
            .setRequired(true)
            .addChoices(
              { name: "Leader 2", value: "lider_2", name_localizations: { "pt-BR": "Líder 2" } },
              { name: "Veteran", value: "veterano", name_localizations: { "pt-BR": "Veterano" } },
              { name: "Regular Member", value: "membro_regular", name_localizations: { "pt-BR": "Membro Regular" } }
            )
        )
    )
    .addSubcommand(subcommand =>
      subcommand
        .setName("sair")
        .setDescription("Leave your current gang")
        .setDescriptionLocalizations({ 
          "pt-BR": "Saia da sua gangue atual",
          "en-US": "Leave your current gang"
        })
    )
    .addSubcommand(subcommand =>
      subcommand
        .setName("expulsar")
        .setDescription("Expel a member from the gang")
        .setDescriptionLocalizations({ 
          "pt-BR": "Expulse um membro da gangue",
          "en-US": "Expel a member from the gang"
        })
        .addUserOption(option =>
          option
            .setName("membro")
            .setDescription("Member to expel")
            .setDescriptionLocalizations({ 
              "pt-BR": "Membro para expulsar",
              "en-US": "Member to expel"
            })
            .setRequired(true)
        )
    )
    .addSubcommand(subcommand =>
      subcommand
        .setName("dissolver")
        .setDescription("Permanently dissolve the gang (Leader 1 only)")
        .setDescriptionLocalizations({ 
          "pt-BR": "Dissolva permanentemente a gangue (apenas Líder 1)",
          "en-US": "Permanently dissolve the gang (Leader 1 only)"
        })
    ),

  async execute(interaction: ChatInputCommandInteraction) {
    const subcommand = interaction.options.getSubcommand();
    const serverId = interaction.guildId;
    
    const isPtBr = getLocale(interaction).startsWith("pt");

    if (!serverId) {
      await interaction.reply({
        content: `${getCrossEmoji()} ${isPtBr ? "Este comando só pode ser usado em servidores!" : "This command can only be used in servers!"}`,
        flags: MessageFlags.Ephemeral,
      });
      return;
    }

    await interaction.deferReply();

    try {
      switch (subcommand) {
        case "criar": {
          const nome = interaction.options.getString("nome", true);
          const result = await criarGangue(serverId, nome, interaction.user.id);
          
          if (!result.success) {
            const translatedMsg = isPtBr ? result.message : translateGangueMessage(result.message, false);
            await interaction.editReply({ content: `${getCrossEmoji()} ${translatedMsg}` });
            return;
          }

          const embed = await createGangueEmbed(result.gangue!, interaction.client, isPtBr);
          const successMsg = isPtBr ? result.message : translateGangueMessage(result.message, false);
          await interaction.editReply({
            content: `${getPartyEmoji()} ${successMsg}`,
            embeds: [embed],
          });
          break;
        }

        case "info": {
          const nomeGangue = interaction.options.getString("gangue");
          const membroAlvo = interaction.options.getUser("membro");

          let gangue: GangueInfo | null = null;

          if (nomeGangue) {
            gangue = await buscarGanguePorNome(nomeGangue, serverId);
          } else if (membroAlvo) {
            gangue = await getGangueDoUsuario(membroAlvo.id, serverId);
          } else {
            gangue = await getGangueDoUsuario(interaction.user.id, serverId);
          }

          if (!gangue) {
            let msg: string;
            if (nomeGangue) {
              msg = isPtBr 
                ? `Gangue "${nomeGangue}" não encontrada!`
                : `Gang "${nomeGangue}" not found!`;
            } else if (membroAlvo) {
              msg = isPtBr
                ? `${membroAlvo.username} não está em nenhuma gangue!`
                : `${membroAlvo.username} is not in any gang!`;
            } else {
              msg = isPtBr
                ? "Você não está em nenhuma gangue! Use `/gangue criar` para criar uma."
                : "You are not in any gang! Use `/gangue criar` to create one.";
            }
            await interaction.editReply({ content: `${getCrossEmoji()} ${msg}` });
            return;
          }

          const embed = await createGangueEmbed(gangue, interaction.client, isPtBr);
          await interaction.editReply({ embeds: [embed] });
          break;
        }

        case "convidar": {
          const membro = interaction.options.getUser("membro", true);
          
          if (membro.bot) {
            await interaction.editReply({ 
              content: `${getCrossEmoji()} ${isPtBr ? "Você não pode convidar bots!" : "You cannot invite bots!"}` 
            });
            return;
          }

          if (membro.id === interaction.user.id) {
            await interaction.editReply({ 
              content: `${getCrossEmoji()} ${isPtBr ? "Você não pode convidar a si mesmo!" : "You cannot invite yourself!"}` 
            });
            return;
          }

          const gangue = await getGangueDoUsuario(interaction.user.id, serverId);
          if (!gangue) {
            await interaction.editReply({ 
              content: `${getCrossEmoji()} ${isPtBr ? "Você não está em uma gangue!" : "You are not in a gang!"}` 
            });
            return;
          }

          const result = await convidarMembro(gangue.id, interaction.user.id, membro.id, serverId);
          
          const emojiConvite = result.success ? getCheckEmoji() : getCrossEmoji();
          const translatedMsg = isPtBr ? result.message : translateGangueMessage(result.message, false);
          await interaction.editReply({ content: `${emojiConvite} ${translatedMsg}` });
          
          if (result.success) {
            try {
              const dmContent = isPtBr
                ? `${getSkullOutlawEmoji()} **Convite de Gangue!**\n\nVocê foi convidado por **${interaction.user.username}** para entrar na gangue **"${gangue.nome}"**!\n\nUse \`/gangue aceitar ${gangue.nome}\` no servidor para aceitar o convite.\n\n${getClockEmoji()} O convite expira em 24 horas.`
                : `${getSkullOutlawEmoji()} **Gang Invitation!**\n\nYou were invited by **${interaction.user.username}** to join the gang **"${gangue.nome}"**!\n\nUse \`/gangue aceitar ${gangue.nome}\` in the server to accept the invitation.\n\n${getClockEmoji()} The invitation expires in 24 hours.`;
              await membro.send({ content: dmContent });
            } catch {
            }
          }
          break;
        }

        case "aceitar": {
          const nomeGangue = interaction.options.getString("gangue", true);
          const result = await aceitarConvite(interaction.user.id, nomeGangue, serverId);
          
          if (!result.success) {
            const translatedMsg = isPtBr ? result.message : translateGangueMessage(result.message, false);
            await interaction.editReply({ content: `${getCrossEmoji()} ${translatedMsg}` });
            return;
          }

          const embed = await createGangueEmbed(result.gangue!, interaction.client, isPtBr);
          const successMsg = isPtBr ? result.message : translateGangueMessage(result.message, false);
          await interaction.editReply({
            content: `${getPartyEmoji()} ${successMsg}`,
            embeds: [embed],
          });
          break;
        }

        case "convites": {
          const convites = await getConvitesPendentes(interaction.user.id, serverId);
          
          if (convites.length === 0) {
            await interaction.editReply({ 
              content: `${getInfoEmoji()} ${isPtBr ? "Você não tem convites pendentes." : "You have no pending invitations."}` 
            });
            return;
          }

          const embed = new EmbedBuilder()
            .setTitle(`${getScrollEmoji()} ${isPtBr ? "Convites Pendentes" : "Pending Invitations"}`)
            .setColor(0x8B4513)
            .setDescription(
              convites.map((c, i) => {
                const expiraEm = Math.ceil((c.expiraEm.getTime() - Date.now()) / (1000 * 60 * 60));
                return isPtBr
                  ? `${i + 1}. **${c.gangueNome}** - ${getClockEmoji()} Expira em ~${expiraEm}h`
                  : `${i + 1}. **${c.gangueNome}** - ${getClockEmoji()} Expires in ~${expiraEm}h`;
              }).join("\n")
            )
            .setFooter({ text: isPtBr ? "Use /gangue aceitar <nome> para aceitar um convite" : "Use /gangue aceitar <name> to accept an invitation" })
            .setTimestamp();

          await interaction.editReply({ embeds: [embed] });
          break;
        }

        case "doar": {
          const prata = interaction.options.getInteger("prata") || 0;
          const ouro = interaction.options.getInteger("ouro") || 0;

          const result = await doar(interaction.user.id, serverId, prata, ouro);
          
          if (!result.success) {
            const translatedMsg = isPtBr ? result.message : translateGangueMessage(result.message, false);
            await interaction.editReply({ content: `${getCrossEmoji()} ${translatedMsg}` });
            return;
          }

          const silverEmoji = getEmoji("silver_coin") || "🪙";
          const goldEmoji = getEmoji("gold_bar") || "🪙";

          const embed = new EmbedBuilder()
            .setTitle(`${getMoneybagEmoji()} ${isPtBr ? "Doação Realizada!" : "Donation Complete!"}`)
            .setColor(0x00FF00)
            .setDescription(isPtBr ? `Você doou recursos para o tesouro da gangue!` : `You donated resources to the gang treasury!`)
            .addFields(
              {
                name: `${getGiftEmoji()} ${isPtBr ? "Recursos Doados" : "Resources Donated"}`,
                value: [
                  prata > 0 ? `${silverEmoji} ${prata} ${isPtBr ? "Prata" : "Silver"}` : null,
                  ouro > 0 ? `${goldEmoji} ${ouro} ${isPtBr ? "Ouro" : "Gold"}` : null,
                ].filter(Boolean).join("\n") || (isPtBr ? "Nenhum" : "None"),
                inline: true,
              },
              {
                name: `${getStatsEmoji()} ${isPtBr ? "XP Ganho" : "XP Earned"}`,
                value: `+${result.xpGanho} XP`,
                inline: true,
              }
            )
            .setFooter({ text: isPtBr ? "Fórmula: Prata × 1 + Ouro × 250 = XP" : "Formula: Silver × 1 + Gold × 250 = XP" })
            .setTimestamp();

          await interaction.editReply({ embeds: [embed] });
          break;
        }

        case "promover": {
          const membro = interaction.options.getUser("membro", true);
          const novoCargo = interaction.options.getString("cargo", true) as CargoGangue;

          const result = await promoverMembro(interaction.user.id, membro.id, novoCargo, serverId);
          
          const emojiPromover = result.success ? getCheckEmoji() : getCrossEmoji();
          const translatedMsg = isPtBr ? result.message : translateGangueMessage(result.message, false);
          await interaction.editReply({ content: `${emojiPromover} ${translatedMsg}` });
          break;
        }

        case "sair": {
          const gangue = await getGangueDoUsuario(interaction.user.id, serverId);
          if (!gangue) {
            await interaction.editReply({ 
              content: `${getCrossEmoji()} ${isPtBr ? "Você não está em uma gangue!" : "You are not in a gang!"}` 
            });
            return;
          }

          const result = await sairDaGangue(interaction.user.id, serverId);
          
          const emojiSair = result.success ? getCowboyEmoji() : getCrossEmoji();
          const translatedMsg = isPtBr ? result.message : translateGangueMessage(result.message, false);
          await interaction.editReply({ content: `${emojiSair} ${translatedMsg}` });
          break;
        }

        case "expulsar": {
          const membro = interaction.options.getUser("membro", true);
          const result = await expulsarMembro(interaction.user.id, membro.id, serverId);
          
          const emojiExpulsar = result.success ? getCheckEmoji() : getCrossEmoji();
          const translatedMsg = isPtBr ? result.message : translateGangueMessage(result.message, false);
          await interaction.editReply({ content: `${emojiExpulsar} ${translatedMsg}` });
          break;
        }

        case "dissolver": {
          const gangue = await getGangueDoUsuario(interaction.user.id, serverId);
          if (!gangue) {
            await interaction.editReply({ 
              content: `${getCrossEmoji()} ${isPtBr ? "Você não está em uma gangue!" : "You are not in a gang!"}` 
            });
            return;
          }

          const result = await dissolverGangue(interaction.user.id, serverId);
          
          const emojiDissolver = result.success ? getSkullOutlawEmoji() : getCrossEmoji();
          const translatedMsg = isPtBr ? result.message : translateGangueMessage(result.message, false);
          await interaction.editReply({ content: `${emojiDissolver} ${translatedMsg}` });
          break;
        }

        default:
          await interaction.editReply({ 
            content: `${getCrossEmoji()} ${isPtBr ? "Subcomando desconhecido!" : "Unknown subcommand!"}` 
          });
      }
    } catch (error) {
      console.error("Erro no comando /gangue:", error);
      await interaction.editReply({ 
        content: `${getCrossEmoji()} ${isPtBr ? "Ocorreu um erro ao executar o comando. Tente novamente." : "An error occurred while executing the command. Please try again."}` 
      });
    }
  },
};

function translateGangueMessage(message: string, toPtBr: boolean): string {
  const translations: { [key: string]: string } = {
    "Gangue criada com sucesso!": "Gang created successfully!",
    "Você já está em uma gangue!": "You are already in a gang!",
    "Já existe uma gangue com esse nome neste servidor!": "A gang with this name already exists in this server!",
    "Convite enviado com sucesso!": "Invitation sent successfully!",
    "Este usuário já está em uma gangue!": "This user is already in a gang!",
    "Você não tem permissão para convidar membros!": "You don't have permission to invite members!",
    "Este usuário já foi convidado!": "This user has already been invited!",
    "A gangue está cheia!": "The gang is full!",
    "Convite aceito com sucesso! Bem-vindo à gangue!": "Invitation accepted successfully! Welcome to the gang!",
    "Convite não encontrado ou expirado!": "Invitation not found or expired!",
    "Você já está em uma gangue! Saia primeiro para aceitar outro convite.": "You are already in a gang! Leave first to accept another invitation.",
    "Você não está em uma gangue!": "You are not in a gang!",
    "Você precisa doar pelo menos 1 de prata ou ouro!": "You need to donate at least 1 silver or gold!",
    "Você não tem recursos suficientes!": "You don't have enough resources!",
    "Doação realizada com sucesso!": "Donation completed successfully!",
    "Membro promovido com sucesso!": "Member promoted successfully!",
    "Membro rebaixado com sucesso!": "Member demoted successfully!",
    "Você não tem permissão para promover/rebaixar membros!": "You don't have permission to promote/demote members!",
    "Este usuário não está na sua gangue!": "This user is not in your gang!",
    "Você não pode alterar seu próprio cargo!": "You cannot change your own role!",
    "Você saiu da gangue com sucesso!": "You left the gang successfully!",
    "O líder supremo não pode sair! Transfira a liderança ou dissolva a gangue.": "The supreme leader cannot leave! Transfer leadership or dissolve the gang.",
    "Membro expulso com sucesso!": "Member expelled successfully!",
    "Você não tem permissão para expulsar membros!": "You don't have permission to expel members!",
    "Você não pode expulsar a si mesmo!": "You cannot expel yourself!",
    "Gangue dissolvida com sucesso!": "Gang dissolved successfully!",
    "Apenas o Líder Supremo pode dissolver a gangue!": "Only the Supreme Leader can dissolve the gang!",
    "Veteranos só podem convidar uma vez a cada 24 horas!": "Veterans can only invite once every 24 hours!",
    "Você não pode promover alguém para um cargo igual ou superior ao seu!": "You cannot promote someone to a role equal or higher than yours!",
    "Você não pode rebaixar alguém com cargo igual ou superior ao seu!": "You cannot demote someone with a role equal or higher than yours!",
  };

  if (toPtBr) {
    const reverseTranslations: { [key: string]: string } = {};
    for (const [pt, en] of Object.entries(translations)) {
      reverseTranslations[en] = pt;
    }
    return reverseTranslations[message] || message;
  }
  
  return translations[message] || message;
}
