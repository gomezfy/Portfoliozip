import {
  SlashCommandBuilder,
  ChatInputCommandInteraction,
  MessageFlags,
  EmbedBuilder,
} from "discord.js";
import { geminiService } from "../../utils/geminiService";
import { t } from "../../utils/i18n";
import { getEmoji } from "../../utils/customEmojis";

const GEMINI_MODELS = [
  {
    id: "gemini-flash-latest",
    name: "Gemini Flash Latest",
    description: "Latest fast and efficient model (default)",
    context_length: 1000000,
    free: true,
  },
  {
    id: "gemini-pro-latest",
    name: "Gemini Pro Latest",
    description: "Latest pro model for complex reasoning",
    context_length: 1000000,
    free: true,
  },
  {
    id: "gemini-2.0-flash",
    name: "Gemini 2.0 Flash",
    description: "Fast model with improved capabilities",
    context_length: 1000000,
    free: true,
  },
  {
    id: "gemini-1.5-flash",
    name: "Gemini 1.5 Flash",
    description: "Balanced speed and capability",
    context_length: 1000000,
    free: true,
  },
  {
    id: "gemini-1.5-pro",
    name: "Gemini 1.5 Pro",
    description: "High capability model",
    context_length: 2000000,
    free: true,
  },
];

export = {
  data: new SlashCommandBuilder()
    .setName("models")
    .setDescription("List available AI models from Google Gemini")
    .setDescriptionLocalizations({
      "pt-BR": "Listar modelos de IA disponíveis do Google Gemini",
      "en-US": "List available AI models from Google Gemini",
      "es-ES": "Listar modelos de IA disponibles de Google Gemini",
    })
    .setContexts([0, 1, 2])
    .setIntegrationTypes([0, 1]),

  cooldown: 30,

  async execute(interaction: ChatInputCommandInteraction): Promise<void> {
    const cancelEmoji = getEmoji("cancel");

    if (!geminiService.isConfigured()) {
      await interaction.reply({
        content: `${cancelEmoji} ${t(interaction, "models_not_configured")}`,
        flags: MessageFlags.Ephemeral,
      });
      return;
    }

    await interaction.deferReply({ flags: MessageFlags.Ephemeral });

    try {
      const title = t(interaction, "models_title");

      const embed = new EmbedBuilder()
        .setColor(0x4285f4)
        .setTitle(`🤖 ${title}`)
        .setDescription(
          `${t(interaction, "models_showing", { shown: GEMINI_MODELS.length, total: GEMINI_MODELS.length })}\n\n${t(interaction, "models_use_with_ai")}`,
        )
        .setFooter({
          text: "Powered by Google Gemini AI",
        })
        .setTimestamp();

      for (const model of GEMINI_MODELS) {
        const price = `🆓 **${t(interaction, "models_free")}**`;
        const contextInfo = `\n📝 ${t(interaction, "models_context", { tokens: model.context_length.toLocaleString() })}`;

        embed.addFields({
          name: model.name,
          value: `\`${model.id}\`\n${model.description}\n${price}${contextInfo}`,
          inline: false,
        });
      }

      await interaction.editReply({
        embeds: [embed],
      });
    } catch (error: any) {
      console.error("Error in /models command:", error);

      const errorMessage = error.message || "Unknown error occurred";

      await interaction.editReply({
        content: `${cancelEmoji} **${t(interaction, "models_error")}**\n${errorMessage}`,
      });
    }
  },
};
