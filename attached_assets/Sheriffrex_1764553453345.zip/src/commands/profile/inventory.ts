import {
  SlashCommandBuilder,
  ChatInputCommandInteraction,
  MessageFlags,
} from "discord.js";
import {
  infoEmbed,
  warningEmbed,
  formatCurrency,
  progressBar,
} from "../../utils/embeds";
import {
  getBackpackEmoji,
  getMoneybagEmoji,
  getStatsEmoji,
  getCrateEmoji,
  getBalanceEmoji,
  getWarningEmoji,
  getAlarmEmoji,
} from "../../utils/customEmojis";
import { getEmoji } from "../../utils/customEmojis";
import { t, getLocale } from "../../utils/i18n";
import { applyLocalizations } from "../../utils/commandLocalizations";
const {
  getInventory,
  calculateWeight,
  ITEMS,
  getNextUpgrade,
  getItemDurability,
  saveInventory,
} = require("../../utils/inventoryManager");

export default {
  data: applyLocalizations(
    new SlashCommandBuilder()
      .setName("inventory")
      .setDescription(`${getBackpackEmoji()} View your backpack inventory`)
      .setContexts([0, 1, 2]) // Guild, BotDM, PrivateChannel
      .setIntegrationTypes([0, 1]) // Guild Install, User Install
      .addUserOption((option) =>
        option
          .setName("user")
          .setDescription("Check another user's inventory (optional)")
          .setRequired(false),
      )
      .addStringOption((option) =>
        option
          .setName("sort")
          .setDescription("How to organize items in your inventory")
          .addChoices(
            { name: "Quantidade (Maior)", value: "quantity_desc" },
            { name: "Quantidade (Menor)", value: "quantity_asc" },
            { name: "Peso (Mais pesado)", value: "weight_desc" },
            { name: "Peso (Mais leve)", value: "weight_asc" },
            { name: "Nome (A-Z)", value: "name_asc" },
            { name: "Nome (Z-A)", value: "name_desc" },
          )
          .setRequired(false),
      ),
    "inventory",
  ),
  async execute(interaction: ChatInputCommandInteraction): Promise<void> {
    const locale = getLocale(interaction);
    const isPtBr = locale === "pt-BR";
    const targetUser = interaction.options.getUser("user") || interaction.user;

    // Only allow viewing own inventory for privacy
    if (targetUser.id !== interaction.user.id) {
      const embed = warningEmbed(
        isPtBr ? "🔒 Inventário Privado" : "🔒 Private Inventory",
        isPtBr ? "Você só pode ver seu próprio inventário!" : "You can only view your own inventory!",
        isPtBr ? "Por privacidade, outros usuários não podem ver seus itens" : "For privacy, other users can't see your items",
      );

      await interaction.reply({
        embeds: [embed],
        flags: MessageFlags.Ephemeral,
      });
      return;
    }

    await interaction.deferReply({ flags: MessageFlags.Ephemeral });

    const inventory = getInventory(targetUser.id);
    
    if (!inventory.itemDurability) {
      inventory.itemDurability = {};
    }
    
    let durabilityInitialized = false;
    for (const [itemId, quantity] of Object.entries(inventory.items)) {
      const quantityNum = Number(quantity);
      const item = (ITEMS as any)[itemId];
      if (item && item.maxDurability && !inventory.itemDurability[itemId] && quantityNum > 0) {
        inventory.itemDurability[itemId] = item.maxDurability;
        durabilityInitialized = true;
      }
    }
    
    if (durabilityInitialized) {
      saveInventory(targetUser.id, inventory);
    }
    
    const currentWeight = calculateWeight(inventory);
    const maxWeight = inventory.maxWeight;

    // Currency totals
    const saloonTokens = inventory.items["saloon_token"] || 0;
    const silverCoins = inventory.items["silver"] || 0;

    // Count items (excluding currencies)
    const currencies = ["saloon_token", "silver"];
    let otherItems: [string, number][] = [];
    let totalItems = 0;

    for (const [itemId, quantity] of Object.entries(inventory.items)) {
      const quantityNum = Number(quantity);
      totalItems += quantityNum;

      if (!currencies.includes(itemId)) {
        otherItems.push([itemId, quantityNum]);
      }
    }

    // Apply sorting based on user choice
    const sortOption = interaction.options.getString("sort") || "quantity_desc";
    const sortItems = (items: [string, number][]): [string, number][] => {
      const sortedItems = [...items];
      
      switch(sortOption) {
        case "quantity_desc":
          return sortedItems.sort(([, a], [, b]) => b - a);
        case "quantity_asc":
          return sortedItems.sort(([, a], [, b]) => a - b);
        case "weight_desc":
          return sortedItems.sort(([idA], [idB]) => {
            const weightA = ((ITEMS as any)[idA]?.weight || 0) * (otherItems.find(([id]) => id === idA)?.[1] || 0);
            const weightB = ((ITEMS as any)[idB]?.weight || 0) * (otherItems.find(([id]) => id === idB)?.[1] || 0);
            return weightB - weightA;
          });
        case "weight_asc":
          return sortedItems.sort(([idA], [idB]) => {
            const weightA = ((ITEMS as any)[idA]?.weight || 0) * (otherItems.find(([id]) => id === idA)?.[1] || 0);
            const weightB = ((ITEMS as any)[idB]?.weight || 0) * (otherItems.find(([id]) => id === idB)?.[1] || 0);
            return weightA - weightB;
          });
        case "name_asc":
          return sortedItems.sort(([idA], [idB]) => {
            const nameA = ((ITEMS as any)[idA]?.name || "").toLowerCase();
            const nameB = ((ITEMS as any)[idB]?.name || "").toLowerCase();
            return nameA.localeCompare(nameB);
          });
        case "name_desc":
          return sortedItems.sort(([idA], [idB]) => {
            const nameA = ((ITEMS as any)[idA]?.name || "").toLowerCase();
            const nameB = ((ITEMS as any)[idB]?.name || "").toLowerCase();
            return nameB.localeCompare(nameA);
          });
        default:
          return sortedItems;
      }
    };
    
    otherItems = sortItems(otherItems);

    // Build items list with pagination to avoid Discord's 1024 character limit
    const MAX_FIELD_LENGTH = 1000; // Safe margin below Discord's 1024 limit
    const itemsLists: string[] = [];
    
    if (otherItems.length === 0) {
      itemsLists.push(t(interaction, "inventory_empty"));
    } else {
      let currentList = "";
      
      for (const [itemId, quantity] of otherItems) {
        const item = (ITEMS as any)[itemId as string];
        if (item) {
          const itemWeight = item.weight * quantity;
          const weightDisplay =
            itemWeight >= 0.1 ? ` • ${itemWeight.toFixed(1)}kg` : "";
          // Use custom emoji if available, otherwise fallback to text emoji
          const itemEmoji = item.customEmoji
            ? getEmoji(item.customEmoji)
            : item.emoji;
          
          let durabilityBar = "";
          if (item.maxDurability) {
            const currentDurability = getItemDurability(targetUser.id, itemId);
            if (currentDurability !== null) {
              const durabilityPercent = (currentDurability / item.maxDurability) * 100;
              const barColor = durabilityPercent > 50 ? "🟢" : durabilityPercent > 20 ? "🟡" : "🔴";
              durabilityBar = ` ${barColor} ${currentDurability}/${item.maxDurability}`;
            }
          }
          
          const itemLine = `${itemEmoji} **${item.name}** ×${quantity.toLocaleString()}${weightDisplay}${durabilityBar}\n`;
          
          // Check if adding this item would exceed the limit
          if (currentList.length + itemLine.length > MAX_FIELD_LENGTH) {
            // Save current list and start a new one
            itemsLists.push(currentList);
            currentList = itemLine;
          } else {
            currentList += itemLine;
          }
        }
      }
      
      // Add the last list if not empty
      if (currentList.length > 0) {
        itemsLists.push(currentList);
      }
    }

    // Weight status
    const weightPercentage = (currentWeight / maxWeight) * 100;
    const weightColor =
      weightPercentage >= 90
        ? "red"
        : weightPercentage >= 70
          ? "amber"
          : "green";
    const weightBar = progressBar(currentWeight, maxWeight, 20);

    // Check for upgrade
    const nextUpgrade = getNextUpgrade(targetUser.id);
    let upgradeInfo = "";

    if (nextUpgrade) {
      upgradeInfo = t(interaction, "inventory_next_upgrade", {
        capacity: nextUpgrade.capacity,
        price: nextUpgrade.price,
      });
    } else {
      upgradeInfo = t(interaction, "inventory_max_capacity");
    }

    // Create embed with base fields
    const embed = infoEmbed(
      `${getBackpackEmoji()} ${t(interaction, "inventory_title", { username: targetUser.username })}`,
      t(interaction, "inventory_subtitle"),
    )
      .addFields(
        {
          name: `${getMoneybagEmoji()} ${t(interaction, "inventory_currency")}`,
          value: `${formatCurrency(saloonTokens, "tokens")}\n${formatCurrency(silverCoins, "silver")}`,
          inline: true,
        },
        {
          name: `${getStatsEmoji()} ${t(interaction, "inventory_stats")}`,
          value: t(interaction, "inventory_stats_items", {
            items: totalItems.toLocaleString(),
            types: Object.keys(inventory.items).length,
            weight: currentWeight.toFixed(1),
            maxWeight: maxWeight,
          }),
          inline: true,
        },
      )
      .setThumbnail(targetUser.displayAvatarURL({ size: 128 }));

    // Add item fields (may be multiple if list is long)
    for (let i = 0; i < itemsLists.length; i++) {
      const pageInfo = itemsLists.length > 1 ? ` (${i + 1}/${itemsLists.length})` : "";
      embed.addFields({
        name: `${getCrateEmoji()} ${t(interaction, "inventory_items")}${pageInfo}`,
        value: itemsLists[i],
        inline: false,
      });
    }

    // Add capacity field
    embed.addFields({
      name: `${getBalanceEmoji()} ${t(interaction, "inventory_capacity")}`,
      value: `${weightBar}\n${currentWeight.toFixed(1)}kg / ${maxWeight}kg (${weightPercentage.toFixed(0)}%)${upgradeInfo}`,
      inline: false,
    });

    // Warning if nearly full
    if (weightPercentage >= 90) {
      embed.setFooter({
        text: `${getWarningEmoji()} ${t(interaction, "inventory_nearly_full_warning")}`,
      });
    } else if (weightPercentage >= 100) {
      embed.setFooter({
        text: `${getAlarmEmoji()} ${t(interaction, "inventory_full_warning")}`,
      });
    } else {
      embed.setFooter({ text: t(interaction, "inventory_transfer_hint") });
    }

    await interaction.editReply({ embeds: [embed] });
  },
};
