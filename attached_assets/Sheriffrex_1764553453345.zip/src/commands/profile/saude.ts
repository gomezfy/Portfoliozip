import {
  SlashCommandBuilder,
  AttachmentBuilder,
  ChatInputCommandInteraction,
  MessageFlags,
  ActionRowBuilder,
  StringSelectMenuBuilder,
  StringSelectMenuOptionBuilder,
} from 'discord.js';
import { db } from '../../../server/db';
import { users } from '../../../shared/schema';
import { eq } from 'drizzle-orm';
import { createHealthCanvas } from '../../utils/healthCanvasRenderer';
import { t, getLocale } from '../../utils/i18n';
import { commandRateLimiter } from '../../utils/security';
import { applyLocalizations } from '../../utils/commandLocalizations';

export default {
  data: applyLocalizations(
    new SlashCommandBuilder()
      .setName('saude')
      .setDescription('Veja seu status de saúde, stamina, sede e fome')
      .setContexts([0, 1, 2])
      .setIntegrationTypes([0, 1]),
    'saude'
  ),
  async execute(interaction: ChatInputCommandInteraction): Promise<void> {
    const locale = getLocale(interaction);
    const isPtBr = locale === "pt-BR";
    
    const cooldownMs = 3000;
    if (!commandRateLimiter.canExecute('saude', interaction.user.id, cooldownMs)) {
      const remaining = commandRateLimiter.getRemainingCooldown(
        'saude',
        interaction.user.id,
        cooldownMs
      );
      const seconds = Math.ceil(remaining / 1000);
      await interaction.reply({
        content: `${t(interaction, 'error_cooldown_wait', { seconds: seconds.toString() })}`,
        flags: MessageFlags.Ephemeral,
      });
      return;
    }

    await interaction.deferReply({ flags: MessageFlags.Ephemeral });

    try {
      const userStats = await db
        .select()
        .from(users)
        .where(eq(users.userId, interaction.user.id))
        .limit(1);

      if (!userStats || userStats.length === 0) {
        await interaction.editReply({
          content: isPtBr ? 'Usuário não encontrado no banco de dados.' : 'User not found in database.',
        });
        return;
      }

      const user = userStats[0];

      const canvasBuffer = await createHealthCanvas({
        health: user.health,
        maxHealth: user.maxHealth,
        stamina: user.stamina,
        maxStamina: user.maxStamina,
        thirst: user.thirst,
        maxThirst: user.maxThirst,
        hunger: user.hunger,
        maxHunger: user.maxHunger,
        blood: user.blood,
        maxBlood: user.maxBlood,
        temperature: user.temperature,
        username: interaction.user.username,
      });

      const attachment = new AttachmentBuilder(canvasBuffer, { name: 'health.png' });

      const selectMenu = new StringSelectMenuBuilder()
        .setCustomId(`saude_action_${interaction.user.id}`)
        .setPlaceholder(isPtBr ? 'Selecione uma ação' : 'Select an action')
        .addOptions(
          new StringSelectMenuOptionBuilder()
            .setLabel(isPtBr ? 'Comer' : 'Eat')
            .setDescription(isPtBr ? 'Consumir comida do inventário' : 'Consume food from inventory')
            .setValue('comer'),
          new StringSelectMenuOptionBuilder()
            .setLabel(isPtBr ? 'Beber' : 'Drink')
            .setDescription(isPtBr ? 'Consumir água do inventário' : 'Consume water from inventory')
            .setValue('beber'),
          new StringSelectMenuOptionBuilder()
            .setLabel(isPtBr ? 'Curar' : 'Heal')
            .setDescription(isPtBr ? 'Usar item de cura do inventário' : 'Use healing item from inventory')
            .setValue('curar'),
          new StringSelectMenuOptionBuilder()
            .setLabel(isPtBr ? 'Descansar' : 'Rest')
            .setDescription(isPtBr ? 'Recuperar stamina descansando' : 'Recover stamina by resting')
            .setValue('descansar'),
          new StringSelectMenuOptionBuilder()
            .setLabel(isPtBr ? 'Transfusão' : 'Transfusion')
            .setDescription(isPtBr ? 'Restaurar sangue perdido' : 'Restore lost blood')
            .setValue('transfusao'),
        );

      const row = new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(selectMenu);

      await interaction.editReply({
        content: `**${t(interaction, 'health_status')}**`,
        files: [attachment],
        components: [row],
      });
    } catch (error) {
      console.error('Error in /saude command:', error);
      await interaction.editReply({
        content: isPtBr ? 'Erro ao recuperar status de saúde. Tente novamente.' : 'Error retrieving health status. Please try again.',
      });
    }
  },
};
