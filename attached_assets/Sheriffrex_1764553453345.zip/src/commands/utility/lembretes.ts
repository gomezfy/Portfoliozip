import {
  SlashCommandBuilder,
  ChatInputCommandInteraction,
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ComponentType,
  MessageFlags,
} from "discord.js";
import {
  getUserReminders,
  toggleReminder,
  toggleAllReminders,
  getReminderStatusText,
  UserReminders,
} from "../../utils/reminderManager";
import { Command } from "../../types";
import {
  getEmoji,
  getAlarmEmoji,
  getPickaxeEmoji,
} from "../../utils/customEmojis";
import { t } from "../../utils/i18n";

function createRemindersEmbed(reminders: UserReminders, username: string): EmbedBuilder {
  const embed = new EmbedBuilder()
    .setColor(reminders.enabled ? 0x4CAF50 : 0xF44336)
    .setTitle(getAlarmEmoji() + " Configurações de Lembretes")
    .setDescription(
      `Configure quais notificações você quer receber por DM quando seus cooldowns terminarem.\n\n${getReminderStatusText(reminders)}`
    )
    .setFooter({ text: `${username} | Clique nos botões abaixo para alternar` })
    .setTimestamp();
  
  return embed;
}

function createReminderButtons(reminders: UserReminders): ActionRowBuilder<ButtonBuilder>[] {
  const row1 = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder()
      .setCustomId("toggle_all")
      .setLabel(reminders.enabled ? "Desativar Todos" : "Ativar Todos")
      .setStyle(reminders.enabled ? ButtonStyle.Danger : ButtonStyle.Success)
      .setEmoji(reminders.enabled ? getEmoji("mute") || "🔕" : getAlarmEmoji() || "🔔"),
    new ButtonBuilder()
      .setCustomId("toggle_mining")
      .setLabel("Mineração")
      .setStyle(reminders.mining.enabled ? ButtonStyle.Primary : ButtonStyle.Secondary)
      .setEmoji(getPickaxeEmoji() || "⛏️"),
    new ButtonBuilder()
      .setCustomId("toggle_hunting")
      .setLabel("Caçada")
      .setStyle(reminders.hunting.enabled ? ButtonStyle.Primary : ButtonStyle.Secondary)
      .setEmoji("🦌")
  );
  
  const row2 = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder()
      .setCustomId("toggle_fishing")
      .setLabel("Pesca")
      .setStyle(reminders.fishing.enabled ? ButtonStyle.Primary : ButtonStyle.Secondary)
      .setEmoji(getEmoji("fishing_rod") || "🎣"),
    new ButtonBuilder()
      .setCustomId("toggle_daily")
      .setLabel("Daily")
      .setStyle(reminders.daily.enabled ? ButtonStyle.Primary : ButtonStyle.Secondary)
      .setEmoji("📅")
  );
  
  return [row1, row2];
}

const command: Command = {
  data: new SlashCommandBuilder()
    .setName("lembretes")
    .setDescription("🔔 Configure notificações por DM quando cooldowns terminarem")
    .setContexts([0, 1, 2])
    .setIntegrationTypes([0, 1]),

  async execute(interaction: ChatInputCommandInteraction): Promise<void> {
    const userId = interaction.user.id;
    const username = interaction.user.username;
    
    let reminders = getUserReminders(userId);
    
    const embed = createRemindersEmbed(reminders, username);
    const rows = createReminderButtons(reminders);
    
    const response = await interaction.reply({
      embeds: [embed],
      components: rows,
      flags: MessageFlags.Ephemeral
    });
    
    const collector = response.createMessageComponentCollector({
      componentType: ComponentType.Button,
      time: 300000
    });
    
    collector.on("collect", async (btnInteraction) => {
      if (btnInteraction.user.id !== userId) {
        await btnInteraction.reply({
          content: `❌ ${t(btnInteraction, "reminders_not_yours")}`,
          flags: MessageFlags.Ephemeral
        });
        return;
      }
      
      const customId = btnInteraction.customId;
      
      if (customId === "toggle_all") {
        toggleAllReminders(userId);
      } else if (customId === "toggle_mining") {
        toggleReminder(userId, "mining");
      } else if (customId === "toggle_hunting") {
        toggleReminder(userId, "hunting");
      } else if (customId === "toggle_fishing") {
        toggleReminder(userId, "fishing");
      } else if (customId === "toggle_daily") {
        toggleReminder(userId, "daily");
      }
      
      reminders = getUserReminders(userId);
      
      const newEmbed = createRemindersEmbed(reminders, username);
      const newRows = createReminderButtons(reminders);
      
      await btnInteraction.update({ embeds: [newEmbed], components: newRows });
    });
    
    collector.on("end", async () => {
      try {
        const finalEmbed = createRemindersEmbed(reminders, username)
          .setFooter({ text: `${username} | Configurações salvas!` });
        await interaction.editReply({ embeds: [finalEmbed], components: [] });
      } catch (error) {
      }
    });
  }
};

export default command;
