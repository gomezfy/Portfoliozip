import {
  SlashCommandBuilder,
  ChatInputCommandInteraction,
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ComponentType,
  MessageFlags,
} from "discord.js";
import { Command } from "../../types";
import { getInventory, addItem } from "../../utils/inventoryManager";
import { addXp } from "../../utils/xpManager";
import { readData, writeData } from "../../utils/database";
import {
  getEmoji,
  getSilverCoinEmoji,
  getSaloonTokenEmoji,
  getGiftEmoji,
  getStarEmoji,
  getCowboyEmoji,
} from "../../utils/customEmojis";

interface TutorialProgress {
  completed: boolean;
  currentStep: number;
  rewardsClaimed: boolean;
  completedAt?: number;
}

function getTutorialData(): Record<string, TutorialProgress> {
  return readData("tutorial.json") || {};
}

function saveTutorialData(data: Record<string, TutorialProgress>): void {
  writeData("tutorial.json", data);
}

function getUserTutorial(userId: string): TutorialProgress {
  const data = getTutorialData();
  if (!data[userId]) {
    data[userId] = {
      completed: false,
      currentStep: 0,
      rewardsClaimed: false
    };
    saveTutorialData(data);
  }
  return data[userId];
}

function updateUserTutorial(userId: string, progress: Partial<TutorialProgress>): void {
  const data = getTutorialData();
  data[userId] = { ...getUserTutorial(userId), ...progress };
  saveTutorialData(data);
}

interface TutorialStep {
  title: string;
  emoji: string;
  description: string;
  tip: string;
  command?: string;
}

const TUTORIAL_STEPS: TutorialStep[] = [
  {
    title: "Bem-vindo ao Velho Oeste!",
    emoji: getCowboyEmoji(),
    description: 
      "Howdy, parceiro! Eu sou o **Sheriff Rex**, e vou te ensinar a sobreviver no Velho Oeste!\n\n" +
      "Neste tutorial interativo, você vai aprender:\n" +
      "• 💰 Como ganhar dinheiro\n" +
      "• " + getEmoji("pickaxe") + " Como minerar ouro\n" +
      "• 🦌 Como caçar animais\n" +
      "• 🎰 Como jogar e se divertir\n\n" +
      "**Ao final, você receberá um kit de iniciante!**",
    tip: "Clique em 'Próximo' para começar sua jornada!"
  },
  {
    title: "Recompensa Diária",
    emoji: "📅",
    description:
      "Todo dia você pode coletar uma **recompensa gratuita**!\n\n" +
      "Use `/daily` para receber:\n" +
      "• " + getSilverCoinEmoji() + " Silver Coins (moeda principal)\n" +
      "• " + getSaloonTokenEmoji() + " Saloon Tokens (moeda premium)\n" +
      "• " + getStarEmoji() + " XP para subir de nível\n\n" +
      "**Dica:** Mantenha uma sequência diária (streak) para ganhar bônus de até 100%!",
    tip: "Não esqueça de coletar todo dia!",
    command: "/daily"
  },
  {
    title: "Mineração de Ouro",
    emoji: getEmoji("pickaxe"),
    description:
      "A mineração é uma das melhores formas de ganhar ouro!\n\n" +
      "Use `/mine` para começar:\n" +
      "• " + getEmoji("timer") + " Mineração solo dura 90 minutos\n" +
      "• 👥 Mineração em dupla dura 30 minutos\n" +
      "• " + getEmoji("backpack") + " Sua mochila guarda até 100kg de ouro\n\n" +
      "Quando terminar, você será notificado para coletar!",
    tip: "Compre upgrades de mochila para carregar mais ouro!",
    command: "/mine"
  },
  {
    title: "Sistema de Caça",
    emoji: "🦌",
    description:
      "Cace animais para conseguir carne e peles valiosas!\n\n" +
      "Use `/hunt` para caçar:\n" +
      "• 🐰 Coelho (Comum) - Fácil de caçar\n" +
      "• 🦌 Cervo (Incomum) - Boas recompensas\n" +
      "• 🐺 Lobo (Raro) - Precisa de boa mira\n" +
      "• 🦬 Bisão (Épico) - Muito valioso\n" +
      "• 🐻 Urso (Lendário) - O mais perigoso!\n\n" +
      "Você precisa de uma arma para caçar!",
    tip: "Compre armas na loja com /generalstore",
    command: "/hunt"
  },
  {
    title: "Missões Diárias",
    emoji: getEmoji("backpack"),
    description:
      "Complete missões para ganhar recompensas extras!\n\n" +
      "Use `/missoes` para ver suas tarefas:\n" +
      "• " + getEmoji("backpack") + " 3 missões diárias (reset todo dia)\n" +
      "• " + getEmoji("scroll") + " 2 missões semanais (reset toda semana)\n" +
      "• " + getGiftEmoji() + " Colete recompensas ao completar\n\n" +
      "Missões incluem: minerar, caçar, pescar, duelar e mais!",
    tip: "Complete todas as missões diárias para manter seu streak!",
    command: "/missoes"
  },
  {
    title: "Notificações",
    emoji: getEmoji("alarm"),
    description:
      "Fique informado sobre seus cooldowns!\n\n" +
      "Use `/lembretes` para ativar notificações:\n" +
      "• " + getEmoji("pickaxe") + " Aviso quando mineração terminar\n" +
      "• 🦌 Aviso quando caçada terminar\n" +
      "• " + getEmoji("fishing_rod") + " Aviso quando pesca terminar\n" +
      "• 📅 Lembrete do daily\n\n" +
      "Você receberá notificações por DM!",
    tip: "Ative os lembretes para não esquecer de coletar!",
    command: "/lembretes"
  },
  {
    title: "Seu Perfil",
    emoji: "👤",
    description:
      "Veja suas estatísticas e personalize seu perfil!\n\n" +
      "Use `/profile` para ver:\n" +
      "• 📊 Suas moedas e recursos\n" +
      "• ⭐ Seu nível e XP\n" +
      "• 🎨 Personalize o fundo e a frase\n\n" +
      "Use `/inventory` para ver seus itens!",
    tip: "Suba de nível para desbloquear fundos exclusivos!",
    command: "/profile"
  },
  {
    title: "Tutorial Completo!",
    emoji: "🎉",
    description:
      "**Parabéns, parceiro!** Você completou o tutorial!\n\n" +
      "Aqui está seu **Kit de Iniciante**:\n" +
      "• " + getSilverCoinEmoji() + " 1.000 Silver Coins\n" +
      "• " + getSaloonTokenEmoji() + " 10 Saloon Tokens\n" +
      "• " + getEmoji("gem") + " 5 Selos para expedições\n" +
      "• " + getStarEmoji() + " 200 XP\n\n" +
      "Agora você está pronto para conquistar o Velho Oeste!\n\n" +
      "**Comandos úteis:**\n" +
      "`/help` - Ver todos os comandos\n" +
      "`/missoes` - Ver suas missões\n" +
      "`/daily` - Coletar recompensa diária",
    tip: "Boa sorte, vaqueiro! " + getCowboyEmoji()
  }
];

function createStepEmbed(step: number, username: string): EmbedBuilder {
  const tutorialStep = TUTORIAL_STEPS[step];
  
  const embed = new EmbedBuilder()
    .setColor(0xFFD700)
    .setTitle(`${tutorialStep.emoji} ${tutorialStep.title}`)
    .setDescription(tutorialStep.description)
    .addFields({
      name: "💡 Dica",
      value: tutorialStep.tip,
      inline: false
    })
    .setFooter({ text: `Passo ${step + 1} de ${TUTORIAL_STEPS.length} | ${username}` })
    .setTimestamp();
  
  if (tutorialStep.command) {
    embed.addFields({
      name: "📝 Comando",
      value: `\`${tutorialStep.command}\``,
      inline: true
    });
  }
  
  return embed;
}

function createNavigationButtons(step: number, isCompleted: boolean): ActionRowBuilder<ButtonBuilder> {
  const row = new ActionRowBuilder<ButtonBuilder>();
  
  if (step > 0) {
    row.addComponents(
      new ButtonBuilder()
        .setCustomId("prev_step")
        .setLabel("Anterior")
        .setStyle(ButtonStyle.Secondary)
        .setEmoji("⬅️")
    );
  }
  
  if (step < TUTORIAL_STEPS.length - 1) {
    row.addComponents(
      new ButtonBuilder()
        .setCustomId("next_step")
        .setLabel("Próximo")
        .setStyle(ButtonStyle.Primary)
        .setEmoji("➡️")
    );
  } else if (!isCompleted) {
    row.addComponents(
      new ButtonBuilder()
        .setCustomId("complete_tutorial")
        .setLabel("Completar e Receber Recompensas!")
        .setStyle(ButtonStyle.Success)
        .setEmoji("🎁")
    );
  }
  
  row.addComponents(
    new ButtonBuilder()
      .setCustomId("skip_tutorial")
      .setLabel("Pular Tutorial")
      .setStyle(ButtonStyle.Danger)
      .setEmoji("⏭️")
  );
  
  return row;
}

const command: Command = {
  data: new SlashCommandBuilder()
    .setName("tutorial")
    .setDescription("📖 Tutorial interativo para novos jogadores")
    .setContexts([0, 1, 2])
    .setIntegrationTypes([0, 1]),

  async execute(interaction: ChatInputCommandInteraction): Promise<void> {
    const userId = interaction.user.id;
    const username = interaction.user.username;
    
    let tutorial = getUserTutorial(userId);
    
    if (tutorial.completed && tutorial.rewardsClaimed) {
      const embed = new EmbedBuilder()
        .setColor(0x4CAF50)
        .setTitle("✅ Tutorial já Completado!")
        .setDescription(
          "Você já completou o tutorial e recebeu suas recompensas!\n\n" +
          "**Comandos úteis:**\n" +
          "`/help` - Ver todos os comandos\n" +
          "`/missoes` - Ver suas missões\n" +
          "`/daily` - Coletar recompensa diária\n" +
          "`/mine` - Minerar ouro\n" +
          "`/hunt` - Caçar animais"
        )
        .setFooter({ text: "Boa sorte no Velho Oeste! 🤠" });
      
      await interaction.reply({
        embeds: [embed],
        flags: MessageFlags.Ephemeral
      });
      return;
    }
    
    let currentStep = tutorial.currentStep;
    
    const embed = createStepEmbed(currentStep, username);
    const row = createNavigationButtons(currentStep, tutorial.rewardsClaimed);
    
    const response = await interaction.reply({
      embeds: [embed],
      components: [row],
      flags: MessageFlags.Ephemeral
    });
    
    const collector = response.createMessageComponentCollector({
      componentType: ComponentType.Button,
      time: 600000
    });
    
    collector.on("collect", async (btnInteraction) => {
      if (btnInteraction.user.id !== userId) {
        await btnInteraction.reply({
          content: "❌ Este tutorial não é seu!",
          flags: MessageFlags.Ephemeral
        });
        return;
      }
      
      const customId = btnInteraction.customId;
      
      if (customId === "prev_step" && currentStep > 0) {
        currentStep--;
        updateUserTutorial(userId, { currentStep });
        
      } else if (customId === "next_step" && currentStep < TUTORIAL_STEPS.length - 1) {
        currentStep++;
        updateUserTutorial(userId, { currentStep });
        
      } else if (customId === "complete_tutorial") {
        addItem(userId, "silver", 1000);
        addItem(userId, "saloon_token", 10);
        addItem(userId, "seal", 5);
        addXp(userId, 200, true);
        
        updateUserTutorial(userId, {
          completed: true,
          rewardsClaimed: true,
          completedAt: Date.now()
        });
        
        const completedEmbed = new EmbedBuilder()
          .setColor(0x4CAF50)
          .setTitle("🎉 Tutorial Completo!")
          .setDescription(
            "**Parabéns, parceiro!**\n\n" +
            "Suas recompensas foram adicionadas:\n" +
            "• " + getSilverCoinEmoji() + " +1.000 Silver Coins\n" +
            "• " + getSaloonTokenEmoji() + " +10 Saloon Tokens\n" +
            "• " + getEmoji("gem") + " +5 Selos\n" +
            "• " + getStarEmoji() + " +200 XP\n\n" +
            "Agora você está pronto para conquistar o Velho Oeste!\n\n" +
            "Use `/daily` para começar sua jornada!"
          )
          .setFooter({ text: "Boa sorte, vaqueiro! " + getCowboyEmoji() })
          .setTimestamp();
        
        await btnInteraction.update({ embeds: [completedEmbed], components: [] });
        collector.stop();
        return;
        
      } else if (customId === "skip_tutorial") {
        updateUserTutorial(userId, {
          completed: true,
          rewardsClaimed: false
        });
        
        const skipEmbed = new EmbedBuilder()
          .setColor(0xF44336)
          .setTitle("⏭️ Tutorial Pulado")
          .setDescription(
            "Você pulou o tutorial.\n\n" +
            "**Nota:** Você pode usar `/tutorial` novamente a qualquer momento para completar e receber suas recompensas!\n\n" +
            "Use `/help` para ver todos os comandos disponíveis."
          )
          .setFooter({ text: "Boa sorte! 🤠" });
        
        await btnInteraction.update({ embeds: [skipEmbed], components: [] });
        collector.stop();
        return;
      }
      
      const newEmbed = createStepEmbed(currentStep, username);
      const newRow = createNavigationButtons(currentStep, tutorial.rewardsClaimed);
      
      await btnInteraction.update({ embeds: [newEmbed], components: [newRow] });
    });
    
    collector.on("end", async (collected, reason) => {
      if (reason === "time") {
        try {
          const timeoutEmbed = new EmbedBuilder()
            .setColor(0x95A5A6)
            .setTitle("⏰ Tutorial Pausado")
            .setDescription("O tutorial expirou. Use `/tutorial` para continuar de onde parou!")
            .setFooter({ text: `Você estava no passo ${currentStep + 1}` });
          
          await interaction.editReply({ embeds: [timeoutEmbed], components: [] });
        } catch (error) {
        }
      }
    });
  }
};

export default command;
