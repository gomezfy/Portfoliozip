import {
  SlashCommandBuilder,
  ChatInputCommandInteraction,
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  StringSelectMenuBuilder,
  StringSelectMenuOptionBuilder,
  ButtonInteraction,
  StringSelectMenuInteraction,
  MessageFlags,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  ModalSubmitInteraction,
} from "discord.js";
import { getSilverCoinEmoji } from "../../utils/customEmojis";
import { getItem, removeItem, addItem } from "../../utils/inventoryManager";
import { trackFarmAction } from "../../utils/missionTracker";
import {
  getFarm,
  createFarm,
  FarmFullData,
  FarmCrop,
  FarmAnimal,
  FarmWorker,
  FarmBuilding,
  CROP_TYPES,
  ANIMAL_TYPES,
  BUILDING_TYPES,
  WORKER_ROLES,
  plantCrop,
  harvestAllReady,
  buyAnimal,
  collectAnimalProducts,
  hireWorker,
  payWorkers,
  giveWorkerBonus,
  startUpgrade,
  checkAndCompleteUpgrades,
  sellResources,
  getUpgradeCost,
  formatDuration,
  getCropEmoji,
  getAnimalEmoji,
  getTotalResources,
  FarmResources,
} from "../../utils/farmManager";

const FARM_SESSION_TIMEOUT = 600000;

function getUserSilver(userId: string): number {
  return getItem(userId, "silver");
}

function getMainMenuEmbed(farmData: FarmFullData, username: string, avatarUrl?: string): EmbedBuilder {
  const farm = farmData.farm;
  const silverEmoji = getSilverCoinEmoji();
  const totalResources = getTotalResources(farm.resources);
  
  const readyCrops = farmData.crops.filter(c => Date.now() >= c.harvestTime).length;
  const totalCrops = farmData.crops.length;
  
  const xpPercent = Math.min(100, Math.floor((farm.xp / (farm.level * 500)) * 100));
  const xpBar = "█".repeat(Math.floor(xpPercent / 10)) + "░".repeat(10 - Math.floor(xpPercent / 10));
  
  const storagePercent = Math.floor((totalResources / farm.storageCapacity) * 100);
  const storageBar = "▰".repeat(Math.floor(storagePercent / 10)) + "▱".repeat(10 - Math.floor(storagePercent / 10));
  
  let description = `╔═══════════════════════════════════╗\n`;
  description += `║   ⭐ **LV ${farm.level}** - ${farm.name}\n`;
  description += `║  XP: ${xpBar} ${farm.xp}/${farm.level * 500}\n`;
  description += `║  PRATA: **${farm.totalEarnings.toLocaleString()}** ${silverEmoji}\n`;
  description += `╚═══════════════════════════════════╝`;
  
  const embed = new EmbedBuilder()
    .setTitle(`${farm.name}`)
    .setDescription(`Bem-vindo ao seu rancho, ${username}! Aqui está o resumo das suas terras.\n\n${description}`)
    .setColor(0xD2691E)
    .addFields(
      { name: "📦 ARMAZÉM", value: `${storageBar} ${totalResources}/${farm.storageCapacity}`, inline: false },
      { name: "🏚️ CELEIRO LV", value: `${farm.barnLevel}`, inline: true },
      { name: "🏠 CASA LV", value: `${farm.houseLevel}`, inline: true },
      { name: "🌾 PLANTAÇÕES", value: totalCrops > 0 ? `**${readyCrops}** ⬆️ / ${totalCrops}` : "∅ VAZIO", inline: true },
      { name: "🐄 REBANHO", value: `${farmData.animals.reduce((s, a) => s + a.quantity, 0)}`, inline: true },
      { name: "👥 FUNCIONÁRIOS", value: `${farmData.workers.length}`, inline: true },
      { name: "💼 STATUS", value: farm.hasManager ? `👔 GERENTE +${((farm.managerBonus - 1) * 100).toFixed(0)}%` : "∅", inline: true },
    )
    .setFooter({ text: "Use o menu para gerenciar" })
    .setTimestamp();
  
  if (avatarUrl) {
    embed.setThumbnail(avatarUrl);
  }
  
  return embed;
}

function getMainMenuSelect(): ActionRowBuilder<StringSelectMenuBuilder> {
  return new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(
    new StringSelectMenuBuilder()
      .setCustomId("farm_main_select")
      .setPlaceholder("Escolha o que deseja gerenciar...")
      .addOptions(
        { label: "Armazém", value: "farm_storage", emoji: "📦" },
        { label: "Plantação", value: "farm_crops", emoji: "🌾" },
        { label: "Animais", value: "farm_animals", emoji: "🐄" },
        { label: "Funcionários", value: "farm_workers", emoji: "👥" },
        { label: "Construções", value: "farm_buildings", emoji: "🏗️" },
        { label: "Mercado", value: "farm_market", emoji: "💰" }
      )
  );
}

function getStorageEmbed(farmData: FarmFullData): EmbedBuilder {
  const farm = farmData.farm;
  const totalResources = getTotalResources(farm.resources);
  const percent = Math.floor((totalResources / farm.storageCapacity) * 100);
  const storageBar = "▰".repeat(Math.floor(percent / 10)) + "▱".repeat(10 - Math.floor(percent / 10));
  
  const resourceList = Object.entries(farm.resources)
    .filter(([_, qty]) => qty > 0)
    .map(([type, qty]) => {
      const emoji = getCropEmoji(type) || getAnimalEmoji(type) || "📦";
      const name = getResourceName(type);
      return `  ${emoji} **${name}** ··· ${qty}`;
    })
    .join("\n") || "  *∅ VAZIO*";
  
  return new EmbedBuilder()
    .setTitle("📦 ARMAZÉM LEVEL " + farm.storageLevel)
    .setColor(0x8B4513)
    .setDescription(`**ESTOQUE**\n\n${storageBar}\n**${totalResources}/${farm.storageCapacity}** (${percent}%)`)
    .addFields(
      { name: "🗃️ INVENTÁRIO", value: resourceList, inline: false },
    )
    .setFooter({ text: "Melhore o armazém para mais espaço" });
}

function getStorageButtons(farmData: FarmFullData): ActionRowBuilder<ButtonBuilder> {
  const upgradeCost = getUpgradeCost("storage", farmData.farm.storageLevel);
  const silverEmoji = getSilverCoinEmoji();
  
  return new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder()
      .setCustomId("farm_upgrade_storage")
      .setLabel(`Melhorar (${upgradeCost} ${silverEmoji})`)
      .setStyle(ButtonStyle.Success)
      .setEmoji("⬆️"),
    new ButtonBuilder()
      .setCustomId("farm_main")
      .setLabel("Voltar")
      .setStyle(ButtonStyle.Danger),
  );
}

function getCropsEmbed(farmData: FarmFullData): EmbedBuilder {
  const now = Date.now();
  
  let cropsList = "";
  if (farmData.crops.length === 0) {
    cropsList = "  ∅ **VAZIO**\n\nPlante suas sementes!";
  } else {
    const grouped: Record<string, { ready: number; growing: number; minTimeLeft: number; name: string; emoji: string }> = {};
    
    for (const crop of farmData.crops) {
      const qty = crop.quantity || 1;
      if (!grouped[crop.type]) {
        grouped[crop.type] = { 
          ready: 0, 
          growing: 0, 
          minTimeLeft: Infinity, 
          name: crop.name,
          emoji: getCropEmoji(crop.type) 
        };
      }
      const timeLeft = crop.harvestTime - now;
      if (timeLeft <= 0) {
        grouped[crop.type].ready += qty;
      } else {
        grouped[crop.type].growing += qty;
        if (timeLeft < grouped[crop.type].minTimeLeft) {
          grouped[crop.type].minTimeLeft = timeLeft;
        }
      }
    }
    
    cropsList = Object.entries(grouped).map(([_, info]) => {
      if (info.ready > 0 && info.growing > 0) {
        return `${info.emoji} **${info.name}** ··· ✅ ${info.ready} | ⏰ ${info.growing} (${formatDuration(info.minTimeLeft)})`;
      } else if (info.ready > 0) {
        return `${info.emoji} **${info.name}** ··· ✅ **${info.ready} PRONTAS**`;
      } else {
        return `${info.emoji} **${info.name}** ··· ⏰ ${info.growing} crescendo (${formatDuration(info.minTimeLeft)})`;
      }
    }).join("\n");
  }
  
  const totalCrops = farmData.crops.reduce((sum, c) => sum + (c.quantity || 1), 0);
  const readyCount = farmData.crops.filter(c => now >= c.harvestTime).reduce((sum, c) => sum + (c.quantity || 1), 0);
  
  return new EmbedBuilder()
    .setTitle("🌾 PLANTAÇÃO")
    .setColor(0x228B22)
    .setDescription(`**COLHEITA ATIVA**\n\n${cropsList}`)
    .addFields(
      { name: "📊 STATUS", value: `Total: **${totalCrops}** | Prontas: **${readyCount}** ✅`, inline: false },
    )
    .setFooter({ text: "Plante e colha para ganhar recursos" });
}

function getCropsButtons(): ActionRowBuilder<ButtonBuilder> {
  return new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder()
      .setCustomId("farm_plant")
      .setLabel("Plantar")
      .setStyle(ButtonStyle.Success)
      .setEmoji("🌱"),
    new ButtonBuilder()
      .setCustomId("farm_harvest_all")
      .setLabel("Colher Tudo")
      .setStyle(ButtonStyle.Primary)
      .setEmoji("🌾"),
    new ButtonBuilder()
      .setCustomId("farm_main")
      .setLabel("Voltar")
      .setStyle(ButtonStyle.Danger),
  );
}

function getPlantSelectMenu(): ActionRowBuilder<StringSelectMenuBuilder> {
  const options = Object.entries(CROP_TYPES).map(([type, info]) => 
    new StringSelectMenuOptionBuilder()
      .setLabel(`${info.name} - ${info.buyCost} prata`)
      .setDescription(`Tempo: ${formatDuration(info.growTime)} | Colheita: ${info.yield}`)
      .setValue(type)
      .setEmoji(info.emoji)
  );
  
  return new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(
    new StringSelectMenuBuilder()
      .setCustomId("farm_plant_select")
      .setPlaceholder("Escolha o que plantar...")
      .addOptions(options)
  );
}

function getAnimalsEmbed(farmData: FarmFullData): EmbedBuilder {
  const now = Date.now();
  const maxAnimals = farmData.farm.barnLevel * 5;
  const currentAnimals = farmData.animals.reduce((s, a) => s + a.quantity, 0);
  const capacityPercent = Math.floor((currentAnimals / maxAnimals) * 100);
  const capacityBar = "▰".repeat(Math.floor(capacityPercent / 10)) + "▱".repeat(10 - Math.floor(capacityPercent / 10));
  
  const avgHappiness = farmData.animals.length > 0 
    ? Math.round(farmData.animals.reduce((s, a) => s + a.happiness, 0) / farmData.animals.length)
    : 0;
  const happinessBar = "💛".repeat(Math.floor(avgHappiness / 20)) + "🖤".repeat(5 - Math.floor(avgHappiness / 20));
  
  let animalsList = "";
  if (farmData.animals.length === 0) {
    animalsList = "  ∅ **VAZIO**\n\nCompre animais!";
  } else {
    animalsList = farmData.animals.map(animal => {
      const emoji = getAnimalEmoji(animal.type);
      const animalInfo = ANIMAL_TYPES[animal.type as keyof typeof ANIMAL_TYPES];
      const timeSince = now - (animal.lastCollection || 0);
      const cycles = Math.floor(timeSince / animalInfo.productionTime);
      const status = cycles > 0 ? `✅ ${cycles}x` : `⏰`;
      return `  ${emoji} **${animal.name}** ··· x${animal.quantity} ${status}`;
    }).join("\n");
  }
  
  return new EmbedBuilder()
    .setTitle("🐄 REBANHO")
    .setColor(0xCD853F)
    .setDescription(`**ANIMAIS ATIVOS**\n\n${animalsList}`)
    .addFields(
      { name: "🏚️ CAPACIDADE", value: `${capacityBar} ${currentAnimals}/${maxAnimals}`, inline: false },
      { name: "❤️ FELICIDADE", value: `${happinessBar} ${avgHappiness}%`, inline: false },
    )
    .setFooter({ text: "Animais felizes produzem mais!" });
}

function getAnimalsButtons(): ActionRowBuilder<ButtonBuilder> {
  return new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder()
      .setCustomId("farm_buy_animal")
      .setLabel("Comprar")
      .setStyle(ButtonStyle.Success)
      .setEmoji("🛒"),
    new ButtonBuilder()
      .setCustomId("farm_collect_animals")
      .setLabel("Coletar Produtos")
      .setStyle(ButtonStyle.Primary)
      .setEmoji("🥛"),
    new ButtonBuilder()
      .setCustomId("farm_main")
      .setLabel("Voltar")
      .setStyle(ButtonStyle.Danger),
  );
}

function getAnimalSelectMenu(): ActionRowBuilder<StringSelectMenuBuilder> {
  const silverEmoji = getSilverCoinEmoji();
  const options = Object.entries(ANIMAL_TYPES).map(([type, info]) => 
    new StringSelectMenuOptionBuilder()
      .setLabel(`${info.name} - ${info.buyCost} ${silverEmoji}`)
      .setDescription(`Produz: ${getResourceName(info.productionType)} a cada ${formatDuration(info.productionTime)}`)
      .setValue(type)
      .setEmoji(info.emoji)
  );
  
  return new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(
    new StringSelectMenuBuilder()
      .setCustomId("farm_animal_select")
      .setPlaceholder("Escolha um animal para comprar...")
      .addOptions(options)
  );
}

function getWorkersEmbed(farmData: FarmFullData): EmbedBuilder {
  const maxWorkers = farmData.farm.houseLevel * 2;
  
  let workersList = "";
  if (farmData.workers.length === 0) {
    workersList = "*Nenhum funcionário contratado*\n\nContrate peões para aumentar a produção!";
  } else {
    workersList = farmData.workers.map(worker => {
      const roleInfo = WORKER_ROLES[worker.role as keyof typeof WORKER_ROLES];
      const emoji = roleInfo?.emoji || "👤";
      const happinessBar = worker.happiness >= 80 ? "😊" : worker.happiness >= 50 ? "😐" : "😡";
      const strikeStatus = worker.isOnStrike ? " **[EM GREVE]**" : "";
      return `${emoji} **${worker.name}** (${roleInfo?.name || worker.role})\n   ${happinessBar} Felicidade: ${worker.happiness}% | Salário: ${worker.salary}/dia${strikeStatus}`;
    }).join("\n\n");
  }
  
  const totalSalary = farmData.workers.reduce((s, w) => s + w.salary, 0);
  
  return new EmbedBuilder()
    .setTitle("👥 Funcionários")
    .setColor(0x4169E1)
    .setDescription(workersList)
    .addFields(
      { name: "🏠 Capacidade", value: `${farmData.workers.length}/${maxWorkers}`, inline: true },
      { name: "💰 Folha Salarial", value: `${totalSalary}/dia`, inline: true },
    )
    .setFooter({ text: "Funcionários felizes trabalham melhor!" });
}

function getWorkersButtons(): ActionRowBuilder<ButtonBuilder> {
  return new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder()
      .setCustomId("farm_hire_worker")
      .setLabel("Contratar")
      .setStyle(ButtonStyle.Success)
      .setEmoji("➕"),
    new ButtonBuilder()
      .setCustomId("farm_pay_workers")
      .setLabel("Pagar Salários")
      .setStyle(ButtonStyle.Primary)
      .setEmoji("💵"),
    new ButtonBuilder()
      .setCustomId("farm_worker_bonus")
      .setLabel("Dar Bebida")
      .setStyle(ButtonStyle.Secondary)
      .setEmoji("🍺"),
    new ButtonBuilder()
      .setCustomId("farm_main")
      .setLabel("Voltar")
      .setStyle(ButtonStyle.Danger),
  );
}

function getHireSelectMenu(): ActionRowBuilder<StringSelectMenuBuilder> {
  const silverEmoji = getSilverCoinEmoji();
  const options = Object.entries(WORKER_ROLES).map(([role, info]) => 
    new StringSelectMenuOptionBuilder()
      .setLabel(`${info.name} - ${info.baseSalary * 5} ${silverEmoji} (contratação)`)
      .setDescription(`Salário: ${info.baseSalary}/dia | Bônus: +${(info.skillBonus * 100).toFixed(0)}%`)
      .setValue(role)
      .setEmoji(info.emoji)
  );
  
  return new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(
    new StringSelectMenuBuilder()
      .setCustomId("farm_hire_select")
      .setPlaceholder("Escolha um cargo para contratar...")
      .addOptions(options)
  );
}

function getBuildingsEmbed(farmData: FarmFullData): EmbedBuilder {
  const now = Date.now();
  
  const buildingStatus = [
    { type: "barn", name: "Celeiro", emoji: "🏚️", level: farmData.farm.barnLevel },
    { type: "silo", name: "Silo", emoji: "🏗️", level: farmData.farm.siloLevel },
    { type: "house", name: "Casa", emoji: "🏠", level: farmData.farm.houseLevel },
    { type: "storage", name: "Armazém", emoji: "📦", level: farmData.farm.storageLevel },
  ];
  
  let buildingList = buildingStatus.map(b => {
    const activeBuilding = farmData.buildings.find(bld => bld.type === b.type && bld.isBuilding);
    if (activeBuilding && activeBuilding.buildEndTime) {
      const timeLeft = activeBuilding.buildEndTime - now;
      if (timeLeft > 0) {
        return `${b.emoji} **${b.name}** Nível ${b.level} → ${b.level + 1}\n   🔨 Construindo... <t:${Math.floor(activeBuilding.buildEndTime / 1000)}:R>`;
      }
    }
    const upgradeCost = getUpgradeCost(b.type as keyof typeof BUILDING_TYPES, b.level);
    return `${b.emoji} **${b.name}** Nível ${b.level}\n   Upgrade: ${upgradeCost} prata`;
  }).join("\n\n");
  
  return new EmbedBuilder()
    .setTitle("🏗️ Construções")
    .setColor(0x8B4513)
    .setDescription(buildingList)
    .setFooter({ text: "Melhore construções para expandir seu rancho" });
}

function getBuildingsButtons(): ActionRowBuilder<ButtonBuilder> {
  return new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder()
      .setCustomId("farm_upgrade_barn")
      .setLabel("Celeiro")
      .setStyle(ButtonStyle.Secondary)
      .setEmoji("🏚️"),
    new ButtonBuilder()
      .setCustomId("farm_upgrade_house")
      .setLabel("Casa")
      .setStyle(ButtonStyle.Secondary)
      .setEmoji("🏠"),
    new ButtonBuilder()
      .setCustomId("farm_upgrade_silo")
      .setLabel("Silo")
      .setStyle(ButtonStyle.Secondary)
      .setEmoji("🏗️"),
    new ButtonBuilder()
      .setCustomId("farm_main")
      .setLabel("Voltar")
      .setStyle(ButtonStyle.Danger),
  );
}

function getMarketEmbed(farmData: FarmFullData): EmbedBuilder {
  const silverEmoji = getSilverCoinEmoji();
  const resources = farmData.farm.resources;
  
  let sellableList = Object.entries(resources)
    .filter(([_, qty]) => qty > 0)
    .map(([type, qty]) => {
      const price = getResourceSellPrice(type);
      const emoji = getCropEmoji(type) || "📦";
      return `${emoji} **${getResourceName(type)}:** ${qty} (${price} ${silverEmoji}/un)`;
    })
    .join("\n") || "*Nenhum recurso para vender*";
  
  return new EmbedBuilder()
    .setTitle("💰 Mercado")
    .setColor(0xFFD700)
    .setDescription("Venda seus recursos por moedas de prata!")
    .addFields(
      { name: "🛒 Recursos Disponíveis", value: sellableList, inline: false },
    )
    .setFooter({ text: farmData.farm.hasManager ? `Bônus de gerente: +${((farmData.farm.managerBonus - 1) * 100).toFixed(0)}%` : "Contrate um gerente para bônus nas vendas!" });
}

function getMarketButtons(): ActionRowBuilder<ButtonBuilder> {
  return new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder()
      .setCustomId("farm_sell")
      .setLabel("Vender")
      .setStyle(ButtonStyle.Success)
      .setEmoji("💰"),
    new ButtonBuilder()
      .setCustomId("farm_sell_all")
      .setLabel("Vender Tudo")
      .setStyle(ButtonStyle.Primary)
      .setEmoji("🤑"),
    new ButtonBuilder()
      .setCustomId("farm_main")
      .setLabel("Voltar")
      .setStyle(ButtonStyle.Danger),
  );
}

function getSellSelectMenu(farmData: FarmFullData): ActionRowBuilder<StringSelectMenuBuilder> | null {
  const resources = Object.entries(farmData.farm.resources).filter(([_, qty]) => qty > 0);
  
  if (resources.length === 0) return null;
  
  const options = resources.map(([type, qty]) => {
    const price = getResourceSellPrice(type);
    return new StringSelectMenuOptionBuilder()
      .setLabel(`${getResourceName(type)} (${qty} un)`)
      .setDescription(`Preço: ${price} prata/un | Total: ${qty * price} prata`)
      .setValue(type)
      .setEmoji(getCropEmoji(type) || "📦");
  });
  
  return new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(
    new StringSelectMenuBuilder()
      .setCustomId("farm_sell_select")
      .setPlaceholder("Escolha o recurso para vender...")
      .addOptions(options)
  );
}

function getResourceName(type: string): string {
  const names: Record<string, string> = {
    wheat: "Trigo", corn: "Milho", carrot: "Cenoura", tomato: "Tomate", cotton: "Algodão",
    milk: "Leite", egg: "Ovos", wool: "Lã", meat: "Carne", leather: "Couro",
  };
  return names[type] || type;
}

function getResourceSellPrice(type: string): number {
  if (type in CROP_TYPES) {
    return CROP_TYPES[type as keyof typeof CROP_TYPES].sellPrice;
  }
  const animal = Object.values(ANIMAL_TYPES).find(a => a.productionType === type);
  return animal?.sellPrice || 5;
}

export default {
  data: new SlashCommandBuilder()
    .setName("fazenda")
    .setDescription("Gerencie seu rancho no Velho Oeste!")
    .setContexts([0, 1, 2])
    .setIntegrationTypes([0, 1]),
  
  async execute(interaction: ChatInputCommandInteraction): Promise<void> {
    const userId = interaction.user.id;
    const username = interaction.user.displayName || interaction.user.username;
    trackFarmAction(userId, username);
    
    let farmData = getFarm(userId);
    
    if (!farmData) {
      // Mostrar modal para pedir nome da fazenda
      const modal = new ModalBuilder()
        .setCustomId("farm_create_modal")
        .setTitle("🤠 Crie seu Rancho");

      const nameInput = new TextInputBuilder()
        .setCustomId("farm_name_input")
        .setLabel("Qual é o nome do seu rancho?")
        .setStyle(TextInputStyle.Short)
        .setPlaceholder(`Rancho de ${username}`)
        .setMaxLength(50)
        .setRequired(true);

      modal.addComponents(new ActionRowBuilder<TextInputBuilder>().addComponents(nameInput));
      
      await interaction.showModal(modal);
      
      // Aguardar submissão do modal
      try {
        const submitted = await interaction.awaitModalSubmit({ time: 600000 });
        const farmName = submitted.fields.getTextInputValue("farm_name_input");
        
        farmData = createFarm(userId, farmName);
        checkAndCompleteUpgrades(userId);
        farmData = getFarm(userId)!;
        
        await submitted.reply({
          embeds: [getMainMenuEmbed(farmData, username, submitted.user.displayAvatarURL())],
          components: [getMainMenuSelect()],
        });
        
        const message = await submitted.fetchReply();
        startFarmSession(message, userId, username);
      } catch (error) {
        // Timeout ou erro - cancelado
        return;
      }
    } else {
      checkAndCompleteUpgrades(userId);
      farmData = getFarm(userId)!;
      
      await interaction.reply({
        embeds: [getMainMenuEmbed(farmData, username, interaction.user.displayAvatarURL())],
        components: [getMainMenuSelect()],
      });
      
      const message = await interaction.fetchReply();
      startFarmSession(message, userId, username);
    }
  }
};

async function startFarmSession(message: any, userId: string, username: string): Promise<void> {
  let farmData = getFarm(userId)!;
    
  const collector = message.createMessageComponentCollector({
    time: FARM_SESSION_TIMEOUT,
    filter: (i: ButtonInteraction | StringSelectMenuInteraction | any) => i.user.id === userId,
  });
  
  collector.on("collect", async (i: ButtonInteraction | StringSelectMenuInteraction | any) => {
      try {
        farmData = getFarm(userId)!;
        checkAndCompleteUpgrades(userId);
        farmData = getFarm(userId)!;
        
        if (i.isButton()) {
          switch (i.customId) {
            
            case "farm_main":
              await i.update({
                embeds: [getMainMenuEmbed(farmData, username, i.user.displayAvatarURL())],
                components: [getMainMenuSelect()],
              });
              break;
              
            case "farm_storage":
              await i.update({
                embeds: [getStorageEmbed(farmData)],
                components: [getStorageButtons(farmData)],
              });
              break;
              
            case "farm_crops":
              await i.update({
                embeds: [getCropsEmbed(farmData)],
                components: [getCropsButtons()],
              });
              break;
              
            case "farm_plant":
              await i.update({
                embeds: [getCropsEmbed(farmData)],
                components: [getPlantSelectMenu(), getCropsButtons()],
              });
              break;
              
            case "farm_harvest_all": {
              const result = harvestAllReady(userId);
              if (result.success && result.results.length > 0) {
                farmData = getFarm(userId)!;
                const harvestedList = result.results.map(r => `${r.name}: +${r.amount}`).join("\n");
                const embed = new EmbedBuilder()
                  .setTitle("🌾 Colheita Realizada!")
                  .setColor(0x228B22)
                  .setDescription(`Você colheu:\n${harvestedList}`)
                  .setFooter({ text: "Os recursos foram adicionados ao armazém" });
                await i.update({ embeds: [embed], components: [getCropsButtons()] });
              } else {
                await i.update({
                  embeds: [new EmbedBuilder()
                    .setTitle("❌ Sem Colheita")
                    .setColor(0xFF0000)
                    .setDescription(result.error || "Nenhuma plantação pronta")],
                  components: [getCropsButtons()],
                });
              }
              break;
            }
              
            case "farm_animals":
              await i.update({
                embeds: [getAnimalsEmbed(farmData)],
                components: [getAnimalsButtons()],
              });
              break;
              
            case "farm_buy_animal":
              await i.update({
                embeds: [getAnimalsEmbed(farmData)],
                components: [getAnimalSelectMenu(), getAnimalsButtons()],
              });
              break;
              
            case "farm_collect_animals": {
              const result = collectAnimalProducts(userId);
              if (result.success && result.collected.length > 0) {
                const collectedList = result.collected.map(c => `${c.name}: +${c.amount} ${c.product}`).join("\n");
                const embed = new EmbedBuilder()
                  .setTitle("🥛 Produtos Coletados!")
                  .setColor(0xCD853F)
                  .setDescription(`Você coletou:\n${collectedList}`)
                  .setFooter({ text: "Os produtos foram adicionados ao armazém" });
                await i.update({ embeds: [embed], components: [getAnimalsButtons()] });
              } else {
                await i.update({
                  embeds: [new EmbedBuilder()
                    .setTitle("❌ Sem Produtos")
                    .setColor(0xFF0000)
                    .setDescription(result.error || "Nenhum produto para coletar")],
                  components: [getAnimalsButtons()],
                });
              }
              break;
            }
              
            case "farm_workers":
              await i.update({
                embeds: [getWorkersEmbed(farmData)],
                components: [getWorkersButtons()],
              });
              break;
              
            case "farm_hire_worker":
              await i.update({
                embeds: [getWorkersEmbed(farmData)],
                components: [getHireSelectMenu(), getWorkersButtons()],
              });
              break;
              
            case "farm_pay_workers": {
              const totalSalary = farmData.workers.reduce((s, w) => s + w.salary, 0);
              const userSilver = getUserSilver(userId);
              
              if (userSilver < totalSalary) {
                await i.update({
                  embeds: [new EmbedBuilder()
                    .setTitle("❌ Prata Insuficiente")
                    .setColor(0xFF0000)
                    .setDescription(`Você precisa de ${totalSalary} prata para pagar os salários.\nVocê tem: ${userSilver} prata`)],
                  components: [getWorkersButtons()],
                });
                break;
              }
              
              await removeItem(userId, "silver", totalSalary);
              const result = payWorkers(userId);
              
              if (result.success) {
                const embed = new EmbedBuilder()
                  .setTitle("💵 Salários Pagos!")
                  .setColor(0x228B22)
                  .setDescription(`Você pagou ${result.totalPaid} prata em salários.\nTodos os funcionários estão felizes!`)
                  .setFooter({ text: "Funcionários felizes = mais produção" });
                await i.update({ embeds: [embed], components: [getWorkersButtons()] });
              }
              break;
            }
              
            case "farm_worker_bonus": {
              const bonusCost = 50;
              const userSilver = getUserSilver(userId);
              
              if (userSilver < bonusCost) {
                await i.update({
                  embeds: [new EmbedBuilder()
                    .setTitle("❌ Prata Insuficiente")
                    .setColor(0xFF0000)
                    .setDescription(`Você precisa de ${bonusCost} prata para pagar bebidas.\nVocê tem: ${userSilver} prata`)],
                  components: [getWorkersButtons()],
                });
                break;
              }
              
              if (farmData.workers.length === 0) {
                await i.update({
                  embeds: [new EmbedBuilder()
                    .setTitle("❌ Sem Funcionários")
                    .setColor(0xFF0000)
                    .setDescription("Você não tem funcionários para dar bebidas!")],
                  components: [getWorkersButtons()],
                });
                break;
              }
              
              await removeItem(userId, "silver", bonusCost);
              for (const worker of farmData.workers) {
                giveWorkerBonus(userId, worker.id, "drink");
              }
              
              const embed = new EmbedBuilder()
                .setTitle("🍺 Rodada no Saloon!")
                .setColor(0xFFD700)
                .setDescription(`Você pagou ${bonusCost} prata em bebidas!\nTodos os funcionários ganharam +30 felicidade.`)
                .setFooter({ text: "Funcionários felizes não entram em greve" });
              await i.update({ embeds: [embed], components: [getWorkersButtons()] });
              break;
            }
              
            case "farm_buildings":
              await i.update({
                embeds: [getBuildingsEmbed(farmData)],
                components: [getBuildingsButtons()],
              });
              break;
              
            case "farm_upgrade_barn":
            case "farm_upgrade_house":
            case "farm_upgrade_silo":
            case "farm_upgrade_storage": {
              const buildingType = i.customId.replace("farm_upgrade_", "") as keyof typeof BUILDING_TYPES;
              const currentLevel = buildingType === "barn" ? farmData.farm.barnLevel :
                                   buildingType === "house" ? farmData.farm.houseLevel :
                                   buildingType === "silo" ? farmData.farm.siloLevel :
                                   farmData.farm.storageLevel;
              const cost = getUpgradeCost(buildingType, currentLevel);
              const userSilver = getUserSilver(userId);
              
              if (userSilver < cost) {
                await i.update({
                  embeds: [new EmbedBuilder()
                    .setTitle("❌ Prata Insuficiente")
                    .setColor(0xFF0000)
                    .setDescription(`Você precisa de ${cost} prata para esta melhoria.\nVocê tem: ${userSilver} prata`)],
                  components: [getBuildingsButtons()],
                });
                break;
              }
              
              await removeItem(userId, "silver", cost);
              const result = startUpgrade(userId, buildingType);
              
              if (result.success && result.finishTime) {
                const finishTimestamp = Math.floor(result.finishTime / 1000);
                const embed = new EmbedBuilder()
                  .setTitle("🔨 Construção Iniciada!")
                  .setColor(0xFFD700)
                  .setDescription(`Seus peões estão trabalhando no ${BUILDING_TYPES[buildingType].name}!\n\nTermina em: <t:${finishTimestamp}:R>`)
                  .setFooter({ text: "Volte depois para ver o resultado" });
                await i.update({ embeds: [embed], components: [getBuildingsButtons()] });
              } else {
                await addItem(userId, "silver", cost);
                await i.update({
                  embeds: [new EmbedBuilder()
                    .setTitle("❌ Erro")
                    .setColor(0xFF0000)
                    .setDescription(result.error || "Não foi possível iniciar a construção")],
                  components: [getBuildingsButtons()],
                });
              }
              break;
            }
              
            case "farm_market":
              await i.update({
                embeds: [getMarketEmbed(farmData)],
                components: [getMarketButtons()],
              });
              break;
              
            case "farm_sell": {
              const sellMenu = getSellSelectMenu(farmData);
              if (sellMenu) {
                await i.update({
                  embeds: [getMarketEmbed(farmData)],
                  components: [sellMenu, getMarketButtons()],
                });
              } else {
                await i.update({
                  embeds: [new EmbedBuilder()
                    .setTitle("❌ Sem Recursos")
                    .setColor(0xFF0000)
                    .setDescription("Você não tem recursos para vender!")],
                  components: [getMarketButtons()],
                });
              }
              break;
            }
              
            case "farm_sell_all": {
              const resources = farmData.farm.resources;
              let totalEarnings = 0;
              const soldItems: string[] = [];
              
              for (const [type, qty] of Object.entries(resources)) {
                if (qty > 0) {
                  const result = sellResources(userId, type as keyof FarmResources, qty);
                  if (result.success && result.earnings) {
                    totalEarnings += result.earnings;
                    soldItems.push(`${getResourceName(type)}: ${qty} (+${result.earnings} prata)`);
                  }
                }
              }
              
              if (totalEarnings > 0) {
                await addItem(userId, "silver", totalEarnings);
                const embed = new EmbedBuilder()
                  .setTitle("💰 Venda Realizada!")
                  .setColor(0xFFD700)
                  .setDescription(`Você vendeu:\n${soldItems.join("\n")}\n\n**Total: +${totalEarnings} prata**`)
                  .setFooter({ text: "As moedas foram adicionadas à sua carteira" });
                await i.update({ embeds: [embed], components: [getMarketButtons()] });
              } else {
                await i.update({
                  embeds: [new EmbedBuilder()
                    .setTitle("❌ Sem Recursos")
                    .setColor(0xFF0000)
                    .setDescription("Você não tem recursos para vender!")],
                  components: [getMarketButtons()],
                });
              }
              break;
            }
          }
        } else if (i.isStringSelectMenu()) {
          const value = i.values[0];
          
          switch (i.customId) {
            case "farm_main_select": {
              // Navigate to selected menu section
              if (value === "farm_storage") {
                await i.update({
                  embeds: [getStorageEmbed(farmData)],
                  components: [getStorageButtons(farmData)],
                });
              } else if (value === "farm_crops") {
                await i.update({
                  embeds: [getCropsEmbed(farmData)],
                  components: [getCropsButtons()],
                });
              } else if (value === "farm_animals") {
                await i.update({
                  embeds: [getAnimalsEmbed(farmData)],
                  components: [getAnimalsButtons()],
                });
              } else if (value === "farm_workers") {
                await i.update({
                  embeds: [getWorkersEmbed(farmData)],
                  components: [getWorkersButtons()],
                });
              } else if (value === "farm_buildings") {
                await i.update({
                  embeds: [getBuildingsEmbed(farmData)],
                  components: [getBuildingsButtons()],
                });
              } else if (value === "farm_market") {
                farmData = getFarm(userId)!;
                await i.update({
                  embeds: [getMarketEmbed(farmData)],
                  components: [getMarketButtons()],
                });
              }
              break;
            }
            case "farm_plant_select": {
              const cropInfo = CROP_TYPES[value as keyof typeof CROP_TYPES];
              const userSilver = getUserSilver(userId);
              const maxQuantity = Math.floor(userSilver / cropInfo.buyCost);
              
              if (maxQuantity === 0) {
                await i.update({
                  embeds: [new EmbedBuilder()
                    .setTitle("❌ Prata Insuficiente")
                    .setColor(0xFF0000)
                    .setDescription(`Você precisa de ${cropInfo.buyCost} prata para plantar ${cropInfo.name}.\nVocê tem: ${userSilver} prata`)],
                  components: [getCropsButtons()],
                });
                break;
              }
              
              // Mostrar modal para quantidade
              const quantityModal = new ModalBuilder()
                .setCustomId(`farm_plant_qty_${value}`)
                .setTitle(`🌱 Plantar ${cropInfo.name}`);
              
              const quantityInput = new TextInputBuilder()
                .setCustomId("plant_quantity")
                .setLabel(`Quantidade (máx: ${maxQuantity}) - Custo: ${cropInfo.buyCost}/un`)
                .setStyle(TextInputStyle.Short)
                .setPlaceholder("Digite a quantidade de plantas")
                .setMinLength(1)
                .setMaxLength(String(maxQuantity).length)
                .setRequired(true);
              
              quantityModal.addComponents(new ActionRowBuilder<TextInputBuilder>().addComponents(quantityInput));
              
              await i.showModal(quantityModal);
              break;
            }
              
            case "farm_animal_select": {
              const animalInfo = ANIMAL_TYPES[value as keyof typeof ANIMAL_TYPES];
              const userSilver = await getUserSilver(userId);
              
              if (userSilver < animalInfo.buyCost) {
                await i.update({
                  embeds: [new EmbedBuilder()
                    .setTitle("❌ Prata Insuficiente")
                    .setColor(0xFF0000)
                    .setDescription(`Você precisa de ${animalInfo.buyCost} prata para comprar ${animalInfo.name}.\nVocê tem: ${userSilver} prata`)],
                  components: [getAnimalsButtons()],
                });
                break;
              }
              
              await removeItem(userId, "silver", animalInfo.buyCost);
              const result = buyAnimal(userId, value as keyof typeof ANIMAL_TYPES, 1);
              
              if (result.success) {
                const embed = new EmbedBuilder()
                  .setTitle(`${animalInfo.emoji} ${animalInfo.name} Comprado!`)
                  .setColor(0xCD853F)
                  .setDescription(`Você comprou um(a) ${animalInfo.name}!\n\nProduz: ${getResourceName(animalInfo.productionType)} a cada ${formatDuration(animalInfo.productionTime)}`)
                  .setFooter({ text: "Cuide bem dos seus animais!" });
                await i.update({ embeds: [embed], components: [getAnimalsButtons()] });
              } else {
                await addItem(userId, "silver", animalInfo.buyCost);
                await i.update({
                  embeds: [new EmbedBuilder()
                    .setTitle("❌ Erro")
                    .setColor(0xFF0000)
                    .setDescription(result.error || "Não foi possível comprar")],
                  components: [getAnimalsButtons()],
                });
              }
              break;
            }
              
            case "farm_hire_select": {
              const roleInfo = WORKER_ROLES[value as keyof typeof WORKER_ROLES];
              const hireCost = roleInfo.baseSalary * 5;
              const userSilver = await getUserSilver(userId);
              
              if (userSilver < hireCost) {
                await i.update({
                  embeds: [new EmbedBuilder()
                    .setTitle("❌ Prata Insuficiente")
                    .setColor(0xFF0000)
                    .setDescription(`Você precisa de ${hireCost} prata para contratar um ${roleInfo.name}.\nVocê tem: ${userSilver} prata`)],
                  components: [getWorkersButtons()],
                });
                break;
              }
              
              await removeItem(userId, "silver", hireCost);
              const result = hireWorker(userId, value as keyof typeof WORKER_ROLES);
              
              if (result.success && result.worker) {
                const embed = new EmbedBuilder()
                  .setTitle(`${roleInfo.emoji} Funcionário Contratado!`)
                  .setColor(0x4169E1)
                  .setDescription(`Você contratou **${result.worker.name}** como ${roleInfo.name}!\n\nSalário: ${roleInfo.baseSalary}/dia\nHabilidade: ${(result.worker.skill * 100).toFixed(0)}%`)
                  .setFooter({ text: "Não esqueça de pagar os salários!" });
                await i.update({ embeds: [embed], components: [getWorkersButtons()] });
              } else {
                await addItem(userId, "silver", hireCost);
                await i.update({
                  embeds: [new EmbedBuilder()
                    .setTitle("❌ Erro")
                    .setColor(0xFF0000)
                    .setDescription(result.error || "Não foi possível contratar")],
                  components: [getWorkersButtons()],
                });
              }
              break;
            }
              
            case "farm_sell_select": {
              const resourceType = value as keyof FarmResources;
              const qty = farmData.farm.resources[resourceType];
              const result = sellResources(userId, resourceType, qty);
              
              if (result.success && result.earnings) {
                await addItem(userId, "silver", result.earnings);
                const embed = new EmbedBuilder()
                  .setTitle("💰 Venda Realizada!")
                  .setColor(0xFFD700)
                  .setDescription(`Você vendeu ${qty}x ${getResourceName(value)} por ${result.earnings} prata!`)
                  .setFooter({ text: "As moedas foram adicionadas à sua carteira" });
                await i.update({ embeds: [embed], components: [getMarketButtons()] });
              } else {
                await i.update({
                  embeds: [new EmbedBuilder()
                    .setTitle("❌ Erro")
                    .setColor(0xFF0000)
                    .setDescription(result.error || "Não foi possível vender")],
                  components: [getMarketButtons()],
                });
              }
              break;
            }
          }
        } else if (i.isModalSubmit() && i.customId.startsWith("farm_plant_qty_")) {
          // Handle plant quantity modal
          const cropType = i.customId.replace("farm_plant_qty_", "");
          const quantity = parseInt(i.fields.getTextInputValue("plant_quantity"));
          const cropInfo = CROP_TYPES[cropType as keyof typeof CROP_TYPES];
          
          if (!cropInfo) {
            await i.reply({ content: "Plantação inválida.", flags: MessageFlags.Ephemeral });
          } else if (isNaN(quantity) || quantity < 1) {
            await i.reply({ content: "Quantidade inválida.", flags: MessageFlags.Ephemeral });
          } else {
            const totalCost = cropInfo.buyCost * quantity;
            const userSilver = getUserSilver(userId);
            
            if (userSilver < totalCost) {
              await i.reply({
                embeds: [new EmbedBuilder()
                  .setTitle("❌ Prata Insuficiente")
                  .setColor(0xFF0000)
                  .setDescription(`Você precisa de ${totalCost} prata para plantar ${quantity}x ${cropInfo.name}.\nVocê tem: ${userSilver} prata`)],
                flags: MessageFlags.Ephemeral
              });
            } else {
              await removeItem(userId, "silver", totalCost);
              
              let successCount = 0;
              for (let j = 0; j < quantity; j++) {
                const result = plantCrop(userId, cropType as keyof typeof CROP_TYPES, 1);
                if (result.success) {
                  successCount++;
                } else {
                  await addItem(userId, "silver", totalCost);
                  await i.reply({
                    embeds: [new EmbedBuilder()
                      .setTitle("❌ Erro ao Plantar")
                      .setColor(0xFF0000)
                      .setDescription(result.error || "Não foi possível plantar algumas plantações")],
                    flags: MessageFlags.Ephemeral
                  });
                  break;
                }
              }
              
              if (successCount > 0) {
                const embed = new EmbedBuilder()
                  .setTitle(`🌱 Plantações Criadas!`)
                  .setColor(0x228B22)
                  .setDescription(`Você plantou ${successCount}x ${cropInfo.name}!\n\nCusto total: ${totalCost} prata`)
                  .addFields({ name: "⏰ Tempo de Crescimento", value: formatDuration(cropInfo.growTime), inline: true })
                  .addFields({ name: "🌾 Rendimento por Plantação", value: `${cropInfo.yield} unidades`, inline: true })
                  .setFooter({ text: "Volte depois para colher!" });
                
                await i.reply({
                  embeds: [embed],
                  flags: MessageFlags.Ephemeral
                });
                
                farmData = getFarm(userId)!;
              }
            }
          }
        }
      } catch (error) {
        console.error("Farm interaction error:", error);
        try {
          if (!i.replied && !i.deferred) {
            await i.reply({ content: "Ocorreu um erro. Tente novamente.", flags: MessageFlags.Ephemeral });
          }
        } catch {}
      }
    });
    
    collector.on("end", async () => {
      try {
        await message.edit({
          components: [],
        });
      } catch {}
    });
}
