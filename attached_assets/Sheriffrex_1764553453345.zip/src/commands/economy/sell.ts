import {
  SlashCommandBuilder,
  ChatInputCommandInteraction,
  MessageFlags,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  EmbedBuilder,
} from "discord.js";
import {
  successEmbed,
  errorEmbed,
  formatCurrency,
} from "../../utils/embeds";
import { t, getLocale } from "../../utils/i18n";
import { applyLocalizations } from "../../utils/commandLocalizations";
import {
  getSaloonTokenEmoji,
  getSilverCoinEmoji,
  getGoldBarEmoji,
  getDiamondEmoji,
  getPickaxeEmoji,
  getEmoji,
  getCheckEmoji,
  getCancelEmoji,
} from "../../utils/customEmojis";
import { getItem, addItem, removeItem } from "../../utils/inventoryManager";
import { isValidCurrencyAmount, MAX_CURRENCY_AMOUNT } from "../../utils/security";
import { getUserSilver, addUserSilver, removeUserSilver } from "../../utils/dataManager";
import { readData, writeData } from "../../utils/database";
import { trackSellAction } from "../../utils/missionTracker";
import fs from "fs";
import path from "path";

const getDataPath = (file: string) => path.join(process.cwd(), "replit-data", file);

function ensureDataDir() {
  const dir = path.join(process.cwd(), "replit-data");
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
}

function getPendingOffers() {
  ensureDataDir();
  const filePath = getDataPath("pending_offers.json");
  if (!fs.existsSync(filePath)) {
    fs.writeFileSync(filePath, JSON.stringify({}, null, 2));
    return {};
  }
  try {
    return JSON.parse(fs.readFileSync(filePath, "utf-8"));
  } catch {
    return {};
  }
}

function savePendingOffers(data: any) {
  ensureDataDir();
  const filePath = getDataPath("pending_offers.json");
  fs.writeFileSync(filePath, JSON.stringify(data, null, 2));
}

export default {
  data: applyLocalizations(
    new SlashCommandBuilder()
      .setName("sell")
      .setDescription("Sell an item to another user")
      .setContexts([0, 1, 2])
      .setIntegrationTypes([0, 1])
      .addUserOption((option) =>
        option
          .setName("buyer")
          .setNameLocalizations({
            "pt-BR": "comprador",
          })
          .setDescription("The user to sell to")
          .setDescriptionLocalizations({
            "pt-BR": "O usuário para vender",
          })
          .setRequired(true),
      )
      .addStringOption((option) =>
        option
          .setName("item")
          .setNameLocalizations({
            "pt-BR": "item",
          })
          .setDescription("The item to sell")
          .setDescriptionLocalizations({
            "pt-BR": "O item para vender",
          })
          .setRequired(true)
          .addChoices(
            {
              name: `${getSaloonTokenEmoji()} Saloon Tokens`,
              name_localizations: { "pt-BR": `${getSaloonTokenEmoji()} Fichas do Saloon` },
              value: "saloon_token",
            },
            {
              name: `${getSilverCoinEmoji()} Silver Coins`,
              name_localizations: { "pt-BR": `${getSilverCoinEmoji()} Moedas de Prata` },
              value: "silver",
            },
            {
              name: `${getGoldBarEmoji()} Gold Bar`,
              name_localizations: { "pt-BR": `${getGoldBarEmoji()} Barra de Ouro` },
              value: "gold",
            },
            {
              name: `${getDiamondEmoji()} Diamond`,
              name_localizations: { "pt-BR": `${getDiamondEmoji()} Diamante` },
              value: "diamond",
            },
            {
              name: `${getPickaxeEmoji()} Pickaxe`,
              name_localizations: { "pt-BR": `${getPickaxeEmoji()} Picareta` },
              value: "pickaxe",
            },
            {
              name: `🐄 Cattle`,
              name_localizations: { "pt-BR": `🐄 Gado` },
              value: "cattle",
            },
          ),
      )
      .addIntegerOption((option) =>
        option
          .setName("amount")
          .setNameLocalizations({
            "pt-BR": "quantidade",
          })
          .setDescription("Amount to sell")
          .setDescriptionLocalizations({
            "pt-BR": "Quantidade para vender",
          })
          .setRequired(true)
          .setMinValue(1)
          .setMaxValue(1000000000),
      )
      .addIntegerOption((option) =>
        option
          .setName("price")
          .setNameLocalizations({
            "pt-BR": "preco",
          })
          .setDescription("Price in Silver Coins")
          .setDescriptionLocalizations({
            "pt-BR": "Preço em Moedas de Prata",
          })
          .setRequired(true)
          .setMinValue(1)
          .setMaxValue(1000000000),
      ),
    "sell",
  ),
  async execute(interaction: ChatInputCommandInteraction): Promise<void> {
    const seller = interaction.user;
    const buyer = interaction.options.getUser("buyer", true);
    const itemId = interaction.options.getString("item", true);
    const amount = interaction.options.getInteger("amount", true);
    const price = interaction.options.getInteger("price", true);
    const locale = getLocale(interaction);
    const isPtBr = locale === "pt-BR";

    if (buyer.bot) {
      await interaction.reply({
        embeds: [errorEmbed(
          isPtBr ? "Comprador Inválido" : "Invalid Buyer", 
          isPtBr ? "Você não pode vender para bots" : "You can't sell to bots"
        )],
        flags: MessageFlags.Ephemeral,
      });
      return;
    }

    if (buyer.id === seller.id) {
      await interaction.reply({
        embeds: [errorEmbed(
          isPtBr ? "Comprador Inválido" : "Invalid Buyer", 
          isPtBr ? "Você não pode vender para si mesmo" : "You can't sell to yourself"
        )],
        flags: MessageFlags.Ephemeral,
      });
      return;
    }

    if (!isValidCurrencyAmount(price)) {
      await interaction.reply({
        embeds: [errorEmbed(
          isPtBr ? "Preço Inválido" : "Invalid Price", 
          isPtBr ? "O preço deve estar entre 1 e um valor válido" : "Price must be between 1 and a valid amount"
        )],
        flags: MessageFlags.Ephemeral,
      });
      return;
    }

    // Check if seller has the item
    let sellerHasItem = false;
    if (itemId === "silver") {
      sellerHasItem = getUserSilver(seller.id) >= amount;
    } else {
      sellerHasItem = getItem(seller.id, itemId) >= amount;
    }

    if (!sellerHasItem) {
      await interaction.reply({
        embeds: [errorEmbed(
          isPtBr ? "Itens Insuficientes" : "Insufficient Items", 
          isPtBr ? "Você não tem itens suficientes para vender" : "You don't have enough of this item to sell"
        )],
        flags: MessageFlags.Ephemeral,
      });
      return;
    }

    await interaction.deferReply();

    // Create offer
    const offerId = `${Date.now()}_${seller.id}_${buyer.id}`;
    const offers = getPendingOffers();

    offers[offerId] = {
      seller: seller.id,
      buyer: buyer.id,
      item: itemId,
      amount,
      price,
      createdAt: Date.now(),
    };

    savePendingOffers(offers);

    // Get emoji for item
    let itemEmoji = "📦";
    if (itemId === "saloon_token") itemEmoji = getSaloonTokenEmoji();
    else if (itemId === "silver") itemEmoji = getSilverCoinEmoji();
    else if (itemId === "gold") itemEmoji = getGoldBarEmoji();
    else if (itemId === "diamond") itemEmoji = getDiamondEmoji();
    else if (itemId === "pickaxe") itemEmoji = getPickaxeEmoji();

    // Create offer embed for seller
    const offerEmbed = new EmbedBuilder()
      .setColor(0x00ff00)
      .setTitle(`${getCheckEmoji()} ${isPtBr ? "Oferta Criada!" : "Offer Created!"}`)
      .setDescription(
        isPtBr
          ? `Você está vendendo **${amount}x ${itemEmoji}** para <@${buyer.id}> por **${price}** ${getSilverCoinEmoji()}`
          : `You're selling **${amount}x ${itemEmoji}** to <@${buyer.id}> for **${price}** ${getSilverCoinEmoji()}`
      )
      .addFields(
        { name: isPtBr ? "Vendedor" : "Seller", value: seller.tag, inline: true },
        { name: isPtBr ? "Comprador" : "Buyer", value: buyer.tag, inline: true },
        { name: "Item", value: `${itemEmoji} ${amount}x`, inline: true },
        { name: isPtBr ? "Preço" : "Price", value: `${getSilverCoinEmoji()} ${price.toLocaleString()}`, inline: true },
      )
      .setFooter({ text: isPtBr ? "O comprador recebeu uma notificação" : "The buyer has been notified" });

    await interaction.editReply({ embeds: [offerEmbed] });

    // Create buttons for buyer
    const acceptButton = new ButtonBuilder()
      .setCustomId(`sell_accept_${offerId}`)
      .setLabel(isPtBr ? "Aceitar" : "Accept")
      .setStyle(ButtonStyle.Success);

    const rejectButton = new ButtonBuilder()
      .setCustomId(`sell_reject_${offerId}`)
      .setLabel(isPtBr ? "Rejeitar" : "Reject")
      .setStyle(ButtonStyle.Danger);

    const buttonRow = new ActionRowBuilder<ButtonBuilder>().addComponents(acceptButton, rejectButton);

    // Send offer to buyer
    const buyerEmbed = new EmbedBuilder()
      .setColor(0xffd700)
      .setTitle(isPtBr ? "🤝 Nova Oferta de Venda!" : "🤝 New Sale Offer!")
      .setDescription(
        isPtBr
          ? `<@${seller.id}> quer vender **${amount}x ${itemEmoji}** para você por **${price}** ${getSilverCoinEmoji()}`
          : `<@${seller.id}> wants to sell **${amount}x ${itemEmoji}** to you for **${price}** ${getSilverCoinEmoji()}`
      )
      .addFields(
        { name: isPtBr ? "Vendedor" : "Seller", value: seller.tag, inline: true },
        { name: isPtBr ? "Seu Saldo" : "Your Balance", value: `${getSilverCoinEmoji()} ${getUserSilver(buyer.id).toLocaleString()}`, inline: true },
        { name: "Item", value: `${itemEmoji} ${amount}x`, inline: true },
        { name: isPtBr ? "Preço" : "Price", value: `${getSilverCoinEmoji()} ${price.toLocaleString()}`, inline: true },
      );

    try {
      const dmChannel = await buyer.createDM();
      await dmChannel.send({ embeds: [buyerEmbed], components: [buttonRow] });
    } catch {
      // Buyer has DMs disabled, try to send in interaction channel
      await interaction.followUp({
        content: isPtBr 
          ? `<@${buyer.id}> você tem uma oferta de venda!` 
          : `<@${buyer.id}> you have a sale offer!`,
        embeds: [buyerEmbed],
        components: [buttonRow],
      });
    }
  },
};
