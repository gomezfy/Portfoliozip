import {
  SlashCommandBuilder,
  ChatInputCommandInteraction,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  AttachmentBuilder,
  StringSelectMenuBuilder,
  StringSelectMenuOptionBuilder,
  ComponentType,
  EmbedBuilder,
} from 'discord.js';
import { applyLocalizations } from '../../utils/commandLocalizations';
import { getStoreItemsByCategory, getCategoryName } from '../../utils/generalStoreManager';
import { getInventory } from '../../utils/inventoryManager';
import { createStoreItemCanvas } from '../../utils/generalStoreCanvas';
import { getUserSilver, addUserSilver, removeUserSilver } from '../../utils/dataManager';
import { addItem } from '../../utils/inventoryManager';
import { getLocale } from '../../utils/i18n';
import {
  getBackpackEmoji,
  getSilverCoinEmoji,
  getSaloonTokenEmoji,
  getClockEmoji,
  getEmoji,
  EMOJI_TEXT,
} from '../../utils/customEmojis';

const commandBuilder = new SlashCommandBuilder()
  .setName('generalstore')
  .setDescription('General Store - Buy useful items for your journey')
  .setDescriptionLocalizations({
    "pt-BR": "Loja Geral - Compre itens úteis para sua jornada",
    "en-US": "General Store - Buy useful items for your journey",
  })
  .setContexts([0, 1, 2])
  .setIntegrationTypes([0, 1]);

export default {
  data: applyLocalizations(commandBuilder, 'generalstore'),
  async execute(interaction: ChatInputCommandInteraction): Promise<void> {
    await interaction.deferReply();

    const isPtBr = getLocale(interaction).startsWith("pt");
    const category = 'all';
    const allItems = getStoreItemsByCategory(category);
    let currentIndex = 0;

    const updateMessage = async () => {
      const item = allItems[currentIndex];
      
      const language = isPtBr ? 'pt-BR' : 'en-US';
      
      const inventory = getInventory(interaction.user.id);
      const userTokens = inventory.items['saloon_token'] || 0;
      const userSilver = getUserSilver(interaction.user.id);
      
      let userHasItem = false;
      if (item.category === 'backpacks') {
        userHasItem = inventory.purchasedBackpacks?.includes(item.id) || false;
      } else {
        userHasItem = inventory.items[item.id] ? inventory.items[item.id] > 0 : false;
      }

      const canvasBuffer = await createStoreItemCanvas(item, userTokens, userHasItem, userSilver, language);
      const attachment = new AttachmentBuilder(canvasBuffer, {
        name: 'store_item.png',
      });

      const silverCoinEmoji = getSilverCoinEmoji();
      const saloonTokenEmoji = getSaloonTokenEmoji();
      const selectOptions = allItems.map((itm, idx) => {
        const currencyEmoji = itm.currency === 'silver' ? silverCoinEmoji : saloonTokenEmoji;
        const coinsLabel = isPtBr ? "moedas" : "coins";
        const itemName = isPtBr ? itm.name : (itm.nameEn || itm.name);
        const option = new StringSelectMenuOptionBuilder()
          .setLabel(itemName)
          .setValue(idx.toString())
          .setDescription(`${itm.price.toLocaleString()} ${coinsLabel}`)
          .setEmoji(currencyEmoji)
          .setDefault(idx === currentIndex);
        
        return option;
      });

      const selectRow = new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(
        new StringSelectMenuBuilder()
          .setCustomId("store_select")
          .setPlaceholder(isPtBr ? "Escolha um item..." : "Choose an item...")
          .addOptions(selectOptions)
      );

      const currency = item.currency || 'tokens';
      const userBalance = currency === 'silver' ? userSilver : userTokens;

      const buttonRow = new ActionRowBuilder<ButtonBuilder>().addComponents(
        new ButtonBuilder()
          .setCustomId("store_buy")
          .setLabel(userHasItem 
            ? (isPtBr ? "Já Possui" : "Already Owned") 
            : (isPtBr ? "Comprar" : "Buy"))
          .setStyle(userHasItem ? ButtonStyle.Secondary : ButtonStyle.Success)
          .setDisabled(userHasItem || userBalance < item.price)
      );

      return { files: [attachment], components: [selectRow, buttonRow] };
    };

    const initialMessage = await updateMessage();
    const response = await interaction.editReply(initialMessage);

    const collector = response.createMessageComponentCollector({
      filter: (i) => i.isButton() || i.isStringSelectMenu(),
      time: 300000,
    });

    collector.on("collect", async (componentInteraction) => {
      const userIsPtBr = componentInteraction.locale?.startsWith("pt") || false;
      
      if (componentInteraction.user.id !== interaction.user.id) {
        await componentInteraction.reply({
          content: userIsPtBr 
            ? "❌ Esta loja não pertence a você! Use `/generalstore` para abrir sua própria loja."
            : "❌ This store doesn't belong to you! Use `/generalstore` to open your own shop.",
          ephemeral: true,
        });
        return;
      }

      if (componentInteraction.isStringSelectMenu() && componentInteraction.customId === "store_select") {
        currentIndex = parseInt(componentInteraction.values[0]);
        await componentInteraction.deferUpdate();
        await new Promise(resolve => setTimeout(resolve, 200));
        const updatedMessage = await updateMessage();
        await componentInteraction.editReply(updatedMessage);
      } else if (componentInteraction.isButton() && componentInteraction.customId === "store_buy") {
        await componentInteraction.deferUpdate();

        const item = allItems[currentIndex];
        const userId = interaction.user.id;
        const inventory = getInventory(userId);
        
        let userHasItem = false;
        if (item.category === 'backpacks') {
          userHasItem = inventory.purchasedBackpacks?.includes(item.id) || false;
        } else {
          userHasItem = inventory.items[item.id] ? inventory.items[item.id] > 0 : false;
        }

        if (userHasItem) {
          await componentInteraction.followUp({
            content: userIsPtBr 
              ? "❌ Você já possui este item!" 
              : "❌ You already own this item!",
            ephemeral: true,
          });
          return;
        }

        const currency = item.currency || 'tokens';
        const userTokens = inventory.items['saloon_token'] || 0;
        const userSilver = getUserSilver(userId);
        const userBalance = currency === 'silver' ? userSilver : userTokens;

        if (userBalance < item.price) {
          const silverCoinEmoji = getSilverCoinEmoji();
          const saloonTokenEmoji = getSaloonTokenEmoji();
          const currencyEmoji = currency === 'silver' ? silverCoinEmoji : saloonTokenEmoji;
          const currencyName = currency === 'silver' 
            ? (userIsPtBr ? "Prata" : "Silver") 
            : "Tokens";
          
          await componentInteraction.followUp({
            content: userIsPtBr
              ? `❌ Você precisa de mais ${currencyEmoji} **${(item.price - userBalance).toLocaleString()}** ${currencyName}!`
              : `❌ You need ${currencyEmoji} **${(item.price - userBalance).toLocaleString()}** more ${currencyName}!`,
            ephemeral: true,
          });
          return;
        }

        if (currency === 'silver') {
          removeUserSilver(userId, item.price);
        } else {
          inventory.items['saloon_token'] = (inventory.items['saloon_token'] || 0) - item.price;
        }

        let success = false;
        if (item.category === 'backpacks') {
          if (!inventory.purchasedBackpacks) {
            inventory.purchasedBackpacks = [];
          }
          inventory.purchasedBackpacks.push(item.id);
          
          if (item.backpackCapacity) {
            inventory.maxWeight = (inventory.maxWeight || 100) + item.backpackCapacity;
          }
          
          const { saveInventory } = require('../../utils/inventoryManager');
          saveInventory(userId, inventory);
          
          success = true;
        } else {
          const result = await addItem(userId, item.id, 1);
          success = result.success;
          if (!success) {
            if (currency === 'silver') {
              addUserSilver(userId, item.price);
            } else {
              inventory.items['saloon_token'] = (inventory.items['saloon_token'] || 0) + item.price;
            }
          }
        }

        if (success) {
          const backpackEmoji = getBackpackEmoji();
          const itemName = userIsPtBr ? item.name : (item.nameEn || item.name);
          await componentInteraction.followUp({
            content: userIsPtBr 
              ? `✅ Você comprou **${itemName}**! ${backpackEmoji}` 
              : `✅ You purchased **${itemName}**! ${backpackEmoji}`,
            ephemeral: true,
          });
          const updatedMessage = await updateMessage();
          await componentInteraction.editReply(updatedMessage);
        } else {
          await componentInteraction.followUp({
            content: userIsPtBr 
              ? "❌ Ocorreu um erro ao processar sua compra. Tente novamente."
              : "❌ An error occurred while processing your purchase. Please try again.",
            ephemeral: true,
          });
        }
      }
    });

    collector.on("end", async (collected, reason) => {
      if (reason === "time" && collected.size === 0) {
        try {
          const clockEmoji = getClockEmoji();
          const backpackEmoji = getBackpackEmoji();
          const timeoutEmbed = new EmbedBuilder()
            .setColor(0x95a5a6)
            .setTitle(`${backpackEmoji} ${isPtBr ? "Loja Geral" : "General Store"}`)
            .setDescription(`${clockEmoji} ${isPtBr ? "Tempo esgotado. Use `/generalstore` novamente para visitar a loja." : "Time expired. Use `/generalstore` again to visit the shop."}`)
            .setTimestamp();

          await interaction.editReply({
            embeds: [timeoutEmbed],
            files: [],
            components: [],
          });
        } catch (error) {
          console.error("Error updating message after timeout:", error);
        }
      }
    });
  },
};
