import {
  SlashCommandBuilder,
  EmbedBuilder,
  ChatInputCommandInteraction,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ComponentType,
  AttachmentBuilder,
  StringSelectMenuBuilder,
  StringSelectMenuOptionBuilder,
} from "discord.js";
import { ITEMS } from "../../utils/inventoryManager";
import { generateWeaponCard } from "../../utils/weaponCanvas";
import { applyLocalizations } from "../../utils/commandLocalizations";
import { addItem } from "../../utils/inventoryManager";
import { getUserSilver, removeUserSilver, addUserSilver } from "../../utils/dataManager";
import { getLocale } from "../../utils/i18n";
import {
  getCowboyEmoji,
  getStatsEmoji,
  getBalanceEmoji,
  getSilverCoinEmoji,
  getMoneybagEmoji,
  getBackpackEmoji,
  getClockEmoji,
  getRevolverEmoji,
  getEmoji,
  EMOJI_TEXT,
} from "../../utils/customEmojis";

const weapons = [
  {
    id: "escopeta",
    ...ITEMS.escopeta,
  },
  {
    id: "revolver_vaqueiro",
    ...ITEMS.revolver_vaqueiro,
  },
  {
    id: "revolver_38",
    ...ITEMS.revolver_38,
  },
  {
    id: "rifle_de_caca",
    ...ITEMS.rifle_de_caca,
  },
];

const commandBuilder = new SlashCommandBuilder()
  .setName("armaria")
  .setDescription("Visit the armory and buy powerful weapons")
  .setDescriptionLocalizations({
    "pt-BR": "Visite a armaria e compre armas poderosas",
    "en-US": "Visit the armory and buy powerful weapons",
  })
  .setContexts([0, 1, 2])
  .setIntegrationTypes([0, 1]);

export default {
  data: applyLocalizations(commandBuilder, "armaria"),
  async execute(interaction: ChatInputCommandInteraction): Promise<void> {
    await interaction.deferReply();

    const isPtBr = getLocale(interaction).startsWith("pt");
    let currentIndex = 0;

    const updateMessage = async () => {
      const weapon = weapons[currentIndex];
      
      const language = isPtBr ? 'pt-BR' : 'en-US';

      let weaponImage: Buffer;
      try {
        weaponImage = await generateWeaponCard({
          name: isPtBr ? weapon.name : ((weapon as any).nameEn || weapon.name),
          damage: weapon.damage!,
          imageUrl: weapon.imageUrl!,
          price: weapon.price!,
          currency: weapon.currency!,
          description: isPtBr ? weapon.description : ((weapon as any).descriptionEn || weapon.description),
          story: isPtBr ? (weapon as any).story : ((weapon as any).storyEn || (weapon as any).story),
          language: language,
        });
      } catch (error) {
        console.error("Error generating weapon card:", error);
        await interaction.editReply({
          content: isPtBr 
            ? "❌ Erro ao carregar a imagem da arma. Tente novamente em alguns instantes."
            : "❌ Error loading weapon image. Please try again in a moment.",
        });
        throw error;
      }

      const attachment = new AttachmentBuilder(weaponImage, {
        name: "weapon.png",
      });

      const silverCoinEmoji = getSilverCoinEmoji();
      const selectOptions = weapons.map((w, idx) => {
        const damageLabel = isPtBr ? "Dano" : "Damage";
        const priceLabel = isPtBr ? "Preço" : "Price";
        const weaponName = isPtBr ? w.name : ((w as any).nameEn || w.name);
        const option = new StringSelectMenuOptionBuilder()
          .setLabel(weaponName)
          .setValue(idx.toString())
          .setDescription(`💥 ${damageLabel}: ${w.damage} | ${priceLabel}: ${w.price}`)
          .setEmoji(silverCoinEmoji)
          .setDefault(idx === currentIndex);
        
        return option;
      });

      const selectRow = new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(
        new StringSelectMenuBuilder()
          .setCustomId("weapon_select")
          .setPlaceholder(isPtBr ? "Escolha uma arma..." : "Choose a weapon...")
          .addOptions(selectOptions)
      );

      const buttonRow = new ActionRowBuilder<ButtonBuilder>().addComponents(
        new ButtonBuilder()
          .setCustomId("buy")
          .setLabel(isPtBr ? "Comprar" : "Buy")
          .setStyle(ButtonStyle.Primary)
      );

      return { files: [attachment], components: [selectRow, buttonRow] };
    };

    const initialMessage = await updateMessage();
    const response = await interaction.editReply(initialMessage);

    const collector = response.createMessageComponentCollector({
      filter: (i) => i.isButton() || i.isStringSelectMenu(),
      time: 300000,
    });

    collector.on("collect", async (componentInteraction) => {
      const userIsPtBr = componentInteraction.locale?.startsWith("pt") || false;
      
      if (componentInteraction.user.id !== interaction.user.id) {
        await componentInteraction.reply({
          content: userIsPtBr 
            ? "❌ Esta armaria não é para você! Use `/armaria` para abrir sua própria loja."
            : "❌ This armory isn't for you! Use `/armaria` to open your own shop.",
          ephemeral: true,
        });
        return;
      }

      if (componentInteraction.isStringSelectMenu() && componentInteraction.customId === "weapon_select") {
        currentIndex = parseInt(componentInteraction.values[0]);
        await componentInteraction.deferUpdate();
        await new Promise(resolve => setTimeout(resolve, 200));
        const updatedMessage = await updateMessage();
        await componentInteraction.editReply(updatedMessage);
      } else if (componentInteraction.isButton() && componentInteraction.customId === "buy") {
        await componentInteraction.deferUpdate();

        const weapon = weapons[currentIndex];
        const userId = interaction.user.id;

        const silverBalance = getUserSilver(userId);

        if (silverBalance < weapon.price!) {
          const silverCoinEmoji = getSilverCoinEmoji();
          const weaponName = userIsPtBr ? weapon.name : ((weapon as any).nameEn || weapon.name);
          const errorEmbed = new EmbedBuilder()
            .setColor(0xe74c3c)
            .setTitle(userIsPtBr ? "❌ Saldo Insuficiente" : "❌ Insufficient Balance")
            .setDescription(
              userIsPtBr
                ? `Você não tem moedas de prata suficientes para comprar **${weaponName}**!\n\n` +
                  `**Seu saldo:** ${silverCoinEmoji} ${silverBalance.toLocaleString()}\n` +
                  `**Preço:** ${silverCoinEmoji} ${weapon.price?.toLocaleString()}\n` +
                  `**Faltam:** ${silverCoinEmoji} ${(weapon.price! - silverBalance).toLocaleString()}`
                : `You don't have enough silver coins to buy **${weaponName}**!\n\n` +
                  `**Your balance:** ${silverCoinEmoji} ${silverBalance.toLocaleString()}\n` +
                  `**Price:** ${silverCoinEmoji} ${weapon.price?.toLocaleString()}\n` +
                  `**Missing:** ${silverCoinEmoji} ${(weapon.price! - silverBalance).toLocaleString()}`
            )
            .setTimestamp();

          await componentInteraction.followUp({
            embeds: [errorEmbed],
            ephemeral: true,
          });
          return;
        }

        await removeUserSilver(userId, weapon.price!);

        const result = await addItem(userId, weapon.id, 1);

        if (result.success) {
          const silverCoinEmoji = getSilverCoinEmoji();
          const moneybagEmoji = getMoneybagEmoji();
          const backpackEmoji = getBackpackEmoji();
          const weaponName = userIsPtBr ? weapon.name : ((weapon as any).nameEn || weapon.name);
          const successEmbed = new EmbedBuilder()
            .setColor(0x2ecc71)
            .setTitle(userIsPtBr ? "✅ Compra Realizada!" : "✅ Purchase Complete!")
            .setDescription(
              userIsPtBr
                ? `Você comprou **${weaponName}** com sucesso!\n\n` +
                  `${moneybagEmoji} **Pago:** ${silverCoinEmoji} ${weapon.price?.toLocaleString()} moedas de prata\n` +
                  `💥 **Dano:** ${weapon.damage}\n` +
                  `${backpackEmoji} **Adicionado ao inventário**\n\n` +
                  `**Novo saldo:** ${silverCoinEmoji} ${(silverBalance - weapon.price!).toLocaleString()}`
                : `You successfully bought **${weaponName}**!\n\n` +
                  `${moneybagEmoji} **Paid:** ${silverCoinEmoji} ${weapon.price?.toLocaleString()} silver coins\n` +
                  `💥 **Damage:** ${weapon.damage}\n` +
                  `${backpackEmoji} **Added to inventory**\n\n` +
                  `**New balance:** ${silverCoinEmoji} ${(silverBalance - weapon.price!).toLocaleString()}`
            )
            .setTimestamp();

          await componentInteraction.followUp({
            embeds: [successEmbed],
            ephemeral: true,
          });
        } else {
          await addUserSilver(userId, weapon.price!);

          const errorEmbed = new EmbedBuilder()
            .setColor(0xe74c3c)
            .setTitle(userIsPtBr ? "❌ Erro na Compra" : "❌ Purchase Error")
            .setDescription(
              result.error || (userIsPtBr 
                ? "Não foi possível adicionar a arma ao seu inventário."
                : "Could not add the weapon to your inventory.")
            )
            .setTimestamp();

          await componentInteraction.followUp({
            embeds: [errorEmbed],
            ephemeral: true,
          });
        }
      }
    });

    collector.on("end", async (collected, reason) => {
      if (reason === "time" && collected.size === 0) {
        try {
          const revolverEmoji = getRevolverEmoji();
          const clockEmoji = getClockEmoji();
          const timeoutEmbed = new EmbedBuilder()
            .setColor(0x95a5a6)
            .setTitle(`${revolverEmoji} ${isPtBr ? "Armaria do Velho Oeste" : "Wild West Armory"}`)
            .setDescription(`${clockEmoji} ${isPtBr ? "Tempo esgotado. Use `/armaria` novamente para visitar a loja." : "Time expired. Use `/armaria` again to visit the shop."}`)
            .setTimestamp();

          await interaction.editReply({
            embeds: [timeoutEmbed],
            files: [],
            components: [],
          });
        } catch (error) {
          console.error("Error updating message after timeout:", error);
        }
      }
    });
  },
};
