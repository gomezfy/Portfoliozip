import {
  SlashCommandBuilder,
  ChatInputCommandInteraction,
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ComponentType,
  MessageFlags,
} from "discord.js";
import {
  getUserMissions,
  getMissionById,
  claimMissionReward,
  getTimeUntilDailyReset,
  getTimeUntilWeeklyReset,
  formatTimeRemaining,
  Mission,
  UserMissionProgress,
} from "../../utils/missionsManager";
import { addItem } from "../../utils/inventoryManager";
import { addXp } from "../../utils/xpManager";
import { Command } from "../../types";
import {
  getEmoji,
  getSilverCoinEmoji,
  getSaloonTokenEmoji,
  getStarEmoji,
  getScrollEmoji,
  getCheckEmoji,
  getCancelEmoji,
} from "../../utils/customEmojis";
import { t } from "../../utils/i18n";

function createProgressBar(current: number, max: number, length: number = 10): string {
  const filled = Math.floor((current / max) * length);
  const empty = length - filled;
  return "█".repeat(filled) + "░".repeat(empty);
}

function getMissionEmbed(
  userId: string,
  username: string,
  type: "daily" | "weekly",
  interaction: ChatInputCommandInteraction
): EmbedBuilder {
  const userMissions = getUserMissions(userId);
  const missions = type === "daily" ? userMissions.daily : userMissions.weekly;
  const resetTime = type === "daily" ? getTimeUntilDailyReset() : getTimeUntilWeeklyReset();
  
  const silverEmoji = getSilverCoinEmoji();
  const tokenEmoji = getSaloonTokenEmoji();
  const clockEmoji = getEmoji("clock");
  const fireEmoji = "🔥";
  
  const titleKey = type === "daily" ? "missions_daily_title" : "missions_weekly_title";
  const descKey = type === "daily" ? "missions_daily_desc" : "missions_weekly_desc";
  
  const embed = new EmbedBuilder()
    .setColor(type === "daily" ? 0xFFD700 : 0x9B59B6)
    .setTitle(`${getEmoji("backpack")} ${t(interaction, titleKey)}`)
    .setDescription(
      t(interaction, descKey, { 
        time: formatTimeRemaining(resetTime),
        streak: userMissions.currentStreak 
      })
    )
    .setFooter({ text: `${t(interaction, "missions_footer", { total: userMissions.completedTotal })} | ${username}` })
    .setTimestamp();
  
  for (const progress of missions) {
    const mission = getMissionById(progress.missionId);
    if (!mission) continue;
    
    const progressBar = createProgressBar(progress.progress, mission.objective.target);
    const statusEmoji = progress.claimed ? getCheckEmoji() : progress.completed ? getEmoji("gift") : "⏳";
    const isPtBr = interaction.locale?.startsWith("pt") || false;
    const statusText = progress.claimed 
      ? t(interaction, "missions_collected")
      : progress.completed 
        ? t(interaction, "missions_ready") 
        : `${progress.progress}/${mission.objective.target}`;
    
    let rewardText = "";
    if (mission.reward.silver) rewardText += `${silverEmoji} ${mission.reward.silver} `;
    if (mission.reward.tokens) rewardText += `${tokenEmoji} ${mission.reward.tokens} `;
    if (mission.reward.xp) rewardText += `${getStarEmoji()} ${mission.reward.xp} XP `;
    if (mission.reward.seals) rewardText += `${getEmoji("gem")} ${mission.reward.seals} `;
    
    embed.addFields({
      name: `${mission.emoji} ${mission.name} ${statusEmoji}`,
      value: `${mission.description}\n${progressBar} **${statusText}**\n${getEmoji("diamond")} ${rewardText.trim()}`,
      inline: false
    });
  }
  
  return embed;
}

function getClaimButtons(missions: UserMissionProgress[], interaction: ChatInputCommandInteraction): ActionRowBuilder<ButtonBuilder> {
  const row = new ActionRowBuilder<ButtonBuilder>();
  
  const claimableMissions = missions.filter(m => m.completed && !m.claimed);
  
  if (claimableMissions.length > 0) {
    row.addComponents(
      new ButtonBuilder()
        .setCustomId("claim_all")
        .setLabel(t(interaction, "missions_claim_all", { count: claimableMissions.length }))
        .setStyle(ButtonStyle.Success)
        .setEmoji(getEmoji("gift") || "🎁")
    );
  }
  
  row.addComponents(
    new ButtonBuilder()
      .setCustomId("switch_daily")
      .setLabel(t(interaction, "missions_btn_daily"))
      .setStyle(ButtonStyle.Primary)
      .setEmoji(getEmoji("backpack") || "📋"),
    new ButtonBuilder()
      .setCustomId("switch_weekly")
      .setLabel(t(interaction, "missions_btn_weekly"))
      .setStyle(ButtonStyle.Secondary)
      .setEmoji(getScrollEmoji() || "📜")
  );
  
  return row;
}

const command: Command = {
  data: new SlashCommandBuilder()
    .setName("missoes")
    .setDescription("📋 Ver e completar suas missões diárias e semanais")
    .setContexts([0, 1, 2])
    .setIntegrationTypes([0, 1]),

  async execute(interaction: ChatInputCommandInteraction): Promise<void> {
    const userId = interaction.user.id;
    const username = interaction.user.username;
    
    let currentType: "daily" | "weekly" = "daily";
    let userMissions = getUserMissions(userId);
    
    const embed = getMissionEmbed(userId, username, currentType, interaction);
    const row = getClaimButtons(userMissions.daily, interaction);
    
    const response = await interaction.reply({
      embeds: [embed],
      components: [row],
      flags: MessageFlags.Ephemeral
    });
    
    const collector = response.createMessageComponentCollector({
      componentType: ComponentType.Button,
      time: 300000
    });
    
    collector.on("collect", async (btnInteraction) => {
      if (btnInteraction.user.id !== userId) {
        await btnInteraction.reply({
          content: `❌ ${t(interaction, "missions_not_yours")}`,
          flags: MessageFlags.Ephemeral
        });
        return;
      }
      
      if (btnInteraction.customId === "claim_all") {
        const missions = currentType === "daily" ? userMissions.daily : userMissions.weekly;
        const claimable = missions.filter(m => m.completed && !m.claimed);
        
        let totalSilver = 0;
        let totalTokens = 0;
        let totalXp = 0;
        let totalSeals = 0;
        let claimed = 0;
        
        for (const progress of claimable) {
          const result = claimMissionReward(userId, progress.missionId);
          if (result.success && result.reward) {
            if (result.reward.silver) {
              addItem(userId, "silver", result.reward.silver);
              totalSilver += result.reward.silver;
            }
            if (result.reward.tokens) {
              addItem(userId, "saloon_token", result.reward.tokens);
              totalTokens += result.reward.tokens;
            }
            if (result.reward.xp) {
              addXp(userId, result.reward.xp, true);
              totalXp += result.reward.xp;
            }
            if (result.reward.seals) {
              addItem(userId, "seal", result.reward.seals);
              totalSeals += result.reward.seals;
            }
            claimed++;
          }
        }
        
        userMissions = getUserMissions(userId);
        
        let rewardMsg = `${getEmoji("gift")} **${claimed} missão(ões) coletada(s)!**\n`;
        if (totalSilver > 0) rewardMsg += `${getSilverCoinEmoji()} +${totalSilver} Silver\n`;
        if (totalTokens > 0) rewardMsg += `${getSaloonTokenEmoji()} +${totalTokens} Tokens\n`;
        if (totalXp > 0) rewardMsg += `${getStarEmoji()} +${totalXp} XP\n`;
        if (totalSeals > 0) rewardMsg += `${getEmoji("gem")} +${totalSeals} Selos`;
        
        await btnInteraction.reply({
          content: rewardMsg,
          flags: MessageFlags.Ephemeral
        });
        
        const newEmbed = getMissionEmbed(userId, username, currentType, interaction);
        const newRow = getClaimButtons(currentType === "daily" ? userMissions.daily : userMissions.weekly, interaction);
        await interaction.editReply({ embeds: [newEmbed], components: [newRow] });
        
      } else if (btnInteraction.customId === "switch_daily") {
        currentType = "daily";
        userMissions = getUserMissions(userId);
        const newEmbed = getMissionEmbed(userId, username, currentType, interaction);
        const newRow = getClaimButtons(userMissions.daily, interaction);
        await btnInteraction.update({ embeds: [newEmbed], components: [newRow] });
        
      } else if (btnInteraction.customId === "switch_weekly") {
        currentType = "weekly";
        userMissions = getUserMissions(userId);
        const newEmbed = getMissionEmbed(userId, username, currentType, interaction);
        const newRow = getClaimButtons(userMissions.weekly, interaction);
        await btnInteraction.update({ embeds: [newEmbed], components: [newRow] });
      }
    });
    
    collector.on("end", async () => {
      try {
        await interaction.editReply({ components: [] });
      } catch (error) {
      }
    });
  }
};

export default command;
