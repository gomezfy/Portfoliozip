import {
  SlashCommandBuilder,
  EmbedBuilder,
  ChatInputCommandInteraction,
} from "discord.js";
import {
  getRexBuckBalance,
  getUserRexBuckData,
  getUserTransactionHistory,
} from "../../utils/rexBuckManager";
import { getRexBuckEmoji, getInfoEmoji, getCheckEmoji } from "../../utils/customEmojis";
import { applyLocalizations } from "../../utils/commandLocalizations";
import { t, getLocale } from "../../utils/i18n";

const commandBuilder = new SlashCommandBuilder()
  .setName("rexbucks")
  .setDescription("💵 Check your RexBucks balance and transaction history")
  .setContexts([0, 1, 2])
  .setIntegrationTypes([0, 1])
  .addSubcommand((subcommand) =>
    subcommand
      .setName("balance")
      .setDescription("Check your RexBucks balance"),
  )
  .addSubcommand((subcommand) =>
    subcommand
      .setName("history")
      .setDescription("View your RexBucks transaction history")
      .addIntegerOption((option) =>
        option
          .setName("limit")
          .setDescription("Number of recent transactions to show (1-20)")
          .setMinValue(1)
          .setMaxValue(20)
          .setRequired(false),
      ),
  );

export default {
  data: applyLocalizations(commandBuilder, "rexbucks"),
  async execute(interaction: ChatInputCommandInteraction): Promise<void> {
    const subcommand = interaction.options.getSubcommand();
    const userId = interaction.user.id;
    const locale = getLocale(interaction);
    const isPtBr = locale === "pt-BR";

    await interaction.deferReply({ ephemeral: true });

    try {
      if (subcommand === "balance") {
        const userData = await getUserRexBuckData(userId);

        const embed = new EmbedBuilder()
          .setColor(0x2ecc71)
          .setTitle(`${getRexBuckEmoji()} ${isPtBr ? "Saldo RexBucks" : "RexBucks Balance"}`)
          .setDescription(
            isPtBr
              ? `**Saldo Atual:** ${getRexBuckEmoji()} **${userData.balance.toLocaleString()}** RexBucks`
              : `**Current Balance:** ${getRexBuckEmoji()} **${userData.balance.toLocaleString()}** RexBucks`,
          )
          .addFields(
            {
              name: isPtBr ? "📊 Estatísticas" : "📊 Statistics",
              value: [
                isPtBr
                  ? `**Total de Transações:** ${userData.totalTransactions}`
                  : `**Total Transactions:** ${userData.totalTransactions}`,
              ].join("\n"),
              inline: false,
            },
            {
              name: `${getInfoEmoji()} ${isPtBr ? "Sobre RexBucks" : "About RexBucks"}`,
              value: isPtBr
                ? [
                    "💵 **RexBucks** é uma moeda premium",
                    "🎫 Compre RexBucks com dinheiro real",
                    "🛒 Use-os na loja e funcionalidades do bot",
                    "⚠️ **Não reembolsável e não transferível**",
                  ].join("\n")
                : [
                    "💵 **RexBucks** is a premium currency",
                    "🎫 Purchase RexBucks with real money",
                    "🛒 Use them in the bot shop and features",
                    "⚠️ **Non-refundable and non-transferable**",
                  ].join("\n"),
              inline: false,
            },
          )
          .setFooter({
            text: isPtBr
              ? "Use /rexbucks history para ver o histórico de transações"
              : "Use /rexbucks history to view transaction history",
          })
          .setTimestamp();

        await interaction.editReply({ embeds: [embed] });
      } else if (subcommand === "history") {
        const limit = interaction.options.getInteger("limit") || 10;
        const transactions = await getUserTransactionHistory(userId, limit);

        if (transactions.length === 0) {
          const embed = new EmbedBuilder()
            .setColor(0xf39c12)
            .setTitle(`${getInfoEmoji()} ${isPtBr ? "Sem Histórico de Transações" : "No Transaction History"}`)
            .setDescription(isPtBr ? "Você ainda não fez nenhuma transação com RexBucks." : "You haven't made any RexBucks transactions yet.")
            .setFooter({
              text: isPtBr ? "Compre RexBucks para começar!" : "Purchase RexBucks to get started!",
            })
            .setTimestamp();

          await interaction.editReply({ embeds: [embed] });
          return;
        }

        const transactionList = transactions
          .map((tx: any, index: number) => {
            const typeEmoji = tx.amount > 0 ? "+" : "-";
            const typeLabel = isPtBr
              ? tx.type === "redeem"
                ? "Resgatado"
                : tx.type === "purchase"
                  ? "Comprado"
                  : tx.type === "admin_add"
                    ? "Adicionado por Admin"
                    : "Removido por Admin"
              : tx.type === "redeem"
                ? "Redeemed"
                : tx.type === "purchase"
                  ? "Purchased"
                  : tx.type === "admin_add"
                    ? "Added by Admin"
                    : "Removed by Admin";
            const date = new Date(tx.timestamp).toLocaleString(isPtBr ? "pt-BR" : "en-US");

            return [
              `**${index + 1}.** ${typeLabel}`,
              `   ${typeEmoji}${Math.abs(tx.amount).toLocaleString()} RexBucks`,
              `   ${isPtBr ? "Saldo" : "Balance"}: ${tx.balanceBefore.toLocaleString()} → ${tx.balanceAfter.toLocaleString()}`,
              `   ${date}`,
            ].join("\n");
          })
          .join("\n\n");

        const embed = new EmbedBuilder()
          .setColor(0x3498db)
          .setTitle(`${getRexBuckEmoji()} ${isPtBr ? "Histórico de Transações RexBucks" : "RexBucks Transaction History"}`)
          .setDescription(transactionList)
          .setFooter({
            text: isPtBr
              ? `Mostrando as últimas ${transactions.length} transação(ões)`
              : `Showing last ${transactions.length} transaction(s)`,
          })
          .setTimestamp();

        await interaction.editReply({ embeds: [embed] });
      }
    } catch (error) {
      console.error("Error in rexbucks command:", error);

      const embed = new EmbedBuilder()
        .setColor(0xe74c3c)
        .setTitle(isPtBr ? "❌ Erro" : "❌ Error")
        .setDescription(isPtBr ? "Ocorreu um erro ao buscar seus dados de RexBucks." : "An error occurred while fetching your RexBucks data.")
        .setTimestamp();

      await interaction.editReply({ embeds: [embed] });
    }
  },
};
