import {
  SlashCommandBuilder,
  ChatInputCommandInteraction,
  EmbedBuilder,
  ActionRowBuilder,
  StringSelectMenuBuilder,
  StringSelectMenuOptionBuilder,
} from "discord.js";
import { applyLocalizations } from "../../utils/commandLocalizations";
import { getItem, removeItem } from "../../utils/inventoryManager";
import { depositSilver } from "../../utils/bankManager";
import { getEmoji } from "../../utils/customEmojis";
import { errorEmbed, warningEmbed } from "../../utils/embeds";
import { getLocale } from "../../utils/i18n";

interface HuntItem {
  id: string;
  name: string;
  nameEn: string;
  emoji: string;
  price: number;
  rarity: string;
  rarityEn: string;
  rarityColor: string;
  currency?: "silver" | "saloon_tokens";
  durability?: number;
}

const MEAT_ITEMS: HuntItem[] = [
  {
    id: "rabbit_meat",
    name: "Carne de Coelho",
    nameEn: "Rabbit Meat",
    emoji: "🍖",
    price: 50,
    rarity: "COMUM",
    rarityEn: "COMMON",
    rarityColor: "#808080",
  },
  {
    id: "deer_meat",
    name: "Carne de Cervo",
    nameEn: "Deer Meat",
    emoji: "🥩",
    price: 150,
    rarity: "INCOMUM",
    rarityEn: "UNCOMMON",
    rarityColor: "#4ade80",
  },
  {
    id: "wolf_meat",
    name: "Carne de Lobo",
    nameEn: "Wolf Meat",
    emoji: "🥩",
    price: 300,
    rarity: "RARO",
    rarityEn: "RARE",
    rarityColor: "#3b82f6",
  },
  {
    id: "bison_meat",
    name: "Carne de Bisão",
    nameEn: "Bison Meat",
    emoji: "🥩",
    price: 500,
    rarity: "ÉPICO",
    rarityEn: "EPIC",
    rarityColor: "#a855f7",
  },
  {
    id: "bear_meat",
    name: "Carne de Urso",
    nameEn: "Bear Meat",
    emoji: "🥩",
    price: 800,
    rarity: "LENDÁRIO",
    rarityEn: "LEGENDARY",
    rarityColor: "#f59e0b",
  },
];

const PELT_ITEMS: HuntItem[] = [
  {
    id: "rabbit_pelt",
    name: "Pele de Coelho",
    nameEn: "Rabbit Pelt",
    emoji: getEmoji("rabbit_pelt"),
    price: 100,
    rarity: "COMUM",
    rarityEn: "COMMON",
    rarityColor: "#808080",
  },
  {
    id: "deer_pelt",
    name: "Pele de Cervo",
    nameEn: "Deer Pelt",
    emoji: getEmoji("deer_pelt"),
    price: 300,
    rarity: "INCOMUM",
    rarityEn: "UNCOMMON",
    rarityColor: "#4ade80",
  },
  {
    id: "wolf_pelt",
    name: "Pele de Lobo",
    nameEn: "Wolf Pelt",
    emoji: getEmoji("wolf_pelt"),
    price: 600,
    rarity: "RARO",
    rarityEn: "RARE",
    rarityColor: "#3b82f6",
  },
  {
    id: "bison_pelt",
    name: "Pele de Bisão",
    nameEn: "Bison Pelt",
    emoji: getEmoji("bison_pelt"),
    price: 1000,
    rarity: "ÉPICO",
    rarityEn: "EPIC",
    rarityColor: "#a855f7",
  },
  {
    id: "bear_pelt",
    name: "Pele de Urso",
    nameEn: "Bear Pelt",
    emoji: getEmoji("bear_pelt"),
    price: 1500,
    rarity: "LENDÁRIO",
    rarityEn: "LEGENDARY",
    rarityColor: "#f59e0b",
  },
];

const SPECIAL_ITEMS: HuntItem[] = [
  {
    id: "eagle_feather",
    name: "Pena de Águia",
    nameEn: "Eagle Feather",
    emoji: getEmoji("eagle_feather"),
    price: 2000,
    rarity: "MÍTICO",
    rarityEn: "MYTHIC",
    rarityColor: "#d4af37",
  },
];

const FISH_ITEMS: HuntItem[] = [
  {
    id: "catfish",
    name: "Bagre do Rio",
    nameEn: "River Catfish",
    emoji: getEmoji("catfish"),
    price: 80,
    rarity: "COMUM",
    rarityEn: "COMMON",
    rarityColor: "#808080",
  },
  {
    id: "silver_trout",
    name: "Truta Prateada",
    nameEn: "Silver Trout",
    emoji: getEmoji("silver_trout"),
    price: 180,
    rarity: "INCOMUM",
    rarityEn: "UNCOMMON",
    rarityColor: "#4ade80",
  },
  {
    id: "wild_salmon",
    name: "Salmão Selvagem",
    nameEn: "Wild Salmon",
    emoji: getEmoji("wild_salmon"),
    price: 350,
    rarity: "RARO",
    rarityEn: "RARE",
    rarityColor: "#3b82f6",
  },
  {
    id: "giant_pike",
    name: "Lúcio Gigante",
    nameEn: "Giant Pike",
    emoji: getEmoji("giant_pike"),
    price: 700,
    rarity: "ÉPICO",
    rarityEn: "EPIC",
    rarityColor: "#a855f7",
  },
  {
    id: "golden_sturgeon",
    name: "Esturjão Dourado",
    nameEn: "Golden Sturgeon",
    emoji: getEmoji("golden_sturgeon"),
    price: 1200,
    rarity: "LENDÁRIO",
    rarityEn: "LEGENDARY",
    rarityColor: "#f59e0b",
  },
  {
    id: "mythic_western_fish",
    name: "Peixe Mítico do Oeste",
    nameEn: "Mythic Western Fish",
    emoji: getEmoji("mythic_western_fish"),
    price: 2500,
    rarity: "MÍTICO",
    rarityEn: "MYTHIC",
    rarityColor: "#d4af37",
  },
];

const SUPPLY_ITEMS: HuntItem[] = [
  {
    id: "basic_bait",
    name: "Isca Básica",
    nameEn: "Basic Bait",
    emoji: getEmoji("basic_bait"),
    price: 5,
    rarity: "COMUM",
    rarityEn: "COMMON",
    rarityColor: "#808080",
  },
  {
    id: "premium_bait",
    name: "Isca Premium",
    nameEn: "Premium Bait",
    emoji: getEmoji("premium_bait"),
    price: 12,
    rarity: "INCOMUM",
    rarityEn: "UNCOMMON",
    rarityColor: "#4ade80",
  },
  {
    id: "golden_hook",
    name: "Anzol Dourado",
    nameEn: "Golden Hook",
    emoji: getEmoji("golden_hook"),
    price: 15,
    rarity: "ÉPICO",
    rarityEn: "EPIC",
    rarityColor: "#a855f7",
    currency: "saloon_tokens",
    durability: 20,
  },
];

export default {
  data: applyLocalizations(
    new SlashCommandBuilder()
      .setName("hunterstore")
      .setDescription("🏪 Venda suas carnes e peles de caça por moedas de prata")
      .setContexts([0, 1, 2])
      .setIntegrationTypes([0, 1]),
    "hunterstore",
  ),
  cooldown: 3,
  async execute(interaction: ChatInputCommandInteraction): Promise<void> {
    await interaction.deferReply({ fetchReply: false });

    const userId = interaction.user.id;
    const locale = getLocale(interaction);
    const isPtBr = locale === "pt-BR";

    const mainEmbed = new EmbedBuilder()
      .setColor("#d4af37")
      .setTitle(`${getEmoji("shop")} Hunter's Store${isPtBr ? " - Loja do Caçador" : ""}`)
      .setDescription(
        isPtBr
          ? `Bem-vindo à **Hunter's Store**, ${interaction.user.username}!\n\n` +
            `Compramos suas carnes, peles e peixes pelos melhores preços do velho oeste!\n` +
            `Também vendemos suprimentos essenciais para caça e pesca!\n\n` +
            `${getEmoji("gift")} **Vendemos (você vende para nós):**\n` +
            `${getEmoji("meat_rex")} **Carnes** - De coelho a urso\n` +
            `${getEmoji("rabbit_pelt")} **Peles** - Valiosas peles de animais\n` +
            `${getEmoji("catfish")} **Peixes** - Do bagre ao peixe mítico\n` +
            `${getEmoji("eagle_feather")} **Penas Raras** - Penas de águia dourada\n\n` +
            `${getEmoji("shop")} **Compramos (você compra de nós):**\n` +
            `${getEmoji("basic_bait")} **Isca Básica** - Pesca peixes comuns\n` +
            `${getEmoji("premium_bait")} **Isca Premium** - Aumenta chance de raros\n\n` +
            `${getEmoji("coin")} Todos os pagamentos são feitos em **moedas de prata**!\n\n` +
            `Selecione uma categoria abaixo:`
          : `Welcome to **Hunter's Store**, ${interaction.user.username}!\n\n` +
            `We buy your meats, pelts and fish at the best prices in the Wild West!\n` +
            `We also sell essential hunting and fishing supplies!\n\n` +
            `${getEmoji("gift")} **We Buy (you sell to us):**\n` +
            `${getEmoji("meat_rex")} **Meats** - From rabbit to bear\n` +
            `${getEmoji("rabbit_pelt")} **Pelts** - Valuable animal pelts\n` +
            `${getEmoji("catfish")} **Fish** - From catfish to mythic fish\n` +
            `${getEmoji("eagle_feather")} **Rare Feathers** - Golden eagle feathers\n\n` +
            `${getEmoji("shop")} **We Sell (you buy from us):**\n` +
            `${getEmoji("basic_bait")} **Basic Bait** - Catches common fish\n` +
            `${getEmoji("premium_bait")} **Premium Bait** - Increases rare fish chances\n\n` +
            `${getEmoji("coin")} All payments are made in **silver coins**!\n\n` +
            `Select a category below:`
      )
      .setImage("https://i.postimg.cc/BQ11FPd3/IMG-3478.png")
      .setFooter({ text: isPtBr ? "Escolha uma categoria" : "Choose a category" })
      .setTimestamp();

    const selectMenu = new StringSelectMenuBuilder()
      .setCustomId(`hunterstore_menu_${userId}`)
      .setPlaceholder(isPtBr ? "Selecione uma categoria" : "Select a category")
      .addOptions(
        new StringSelectMenuOptionBuilder()
          .setLabel(isPtBr ? "Vender Carnes" : "Sell Meats")
          .setDescription(isPtBr ? "Venda suas carnes de caça por moedas de prata" : "Sell your hunt meats for silver coins")
          .setValue(`hunterstore_meat_${userId}`)
          .setEmoji(getEmoji("meat_rex")),
        new StringSelectMenuOptionBuilder()
          .setLabel(isPtBr ? "Vender Peles" : "Sell Pelts")
          .setDescription(isPtBr ? "Venda peles valiosas de animais" : "Sell valuable animal pelts")
          .setValue(`hunterstore_pelt_${userId}`)
          .setEmoji(getEmoji("deer_pelt")),
        new StringSelectMenuOptionBuilder()
          .setLabel(isPtBr ? "Vender Peixes" : "Sell Fish")
          .setDescription(isPtBr ? "Venda seus peixes capturados" : "Sell your caught fish")
          .setValue(`hunterstore_fish_${userId}`)
          .setEmoji(getEmoji("catfish")),
        new StringSelectMenuOptionBuilder()
          .setLabel(isPtBr ? "Vender Penas" : "Sell Feathers")
          .setDescription(isPtBr ? "Venda penas raras de águia" : "Sell rare eagle feathers")
          .setValue(`hunterstore_special_${userId}`)
          .setEmoji(getEmoji("eagle_feather")),
        new StringSelectMenuOptionBuilder()
          .setLabel(isPtBr ? "Comprar Suprimentos" : "Buy Supplies")
          .setDescription(isPtBr ? "Compre iscas para pesca" : "Buy bait for fishing")
          .setValue(`hunterstore_supply_${userId}`)
          .setEmoji(getEmoji("basic_bait")),
      );

    const row = new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(
      selectMenu,
    );

    await interaction.editReply({
      embeds: [mainEmbed],
      components: [row],
    });
  },
};

export { MEAT_ITEMS, PELT_ITEMS, FISH_ITEMS, SPECIAL_ITEMS, SUPPLY_ITEMS };
