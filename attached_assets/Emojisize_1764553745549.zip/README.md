# 🎨 Emoji Size

Aplicação web moderna e minimalista para redimensionar imagens e criar emojis perfeitos.

## 🚀 Início Rápido

```bash
npm install
npm start
```

O servidor iniciará automaticamente em `http://localhost:5000`

## ✨ Recursos

### Redimensionamento Inteligente
- 📐 Múltiplos tamanhos: **128×128**, **256×256**, **512×512**, **1024×1024**
- 🖼️ Preview em tempo real
- 📦 Download em arquivo ZIP
- 🎨 Interface minimalista com ícones SVG

### Sistema de Autenticação
- 🔐 Login via Discord OAuth
- 🔐 Login via GitHub OAuth
- 👤 Perfil de usuário com avatar
- ⏱ Sistema de acesso temporizado (30 minutos)

### Experiência do Usuário
- 📊 Barra de progresso detalhada
- 🎯 Drag & Drop intuitivo
- 📱 Design responsivo e moderno
- ⚡ Processamento rápido e eficiente

## 📦 Funcionalidades

1. **Escolha o tamanho** desejado (128px, 256px, 512px ou 1024px)
2. **Arraste ou clique** para fazer upload das imagens
3. **Aguarde** o processamento com barra de progresso em tempo real
4. **Clique** em "Baixar Todas" para obter o ZIP com todas as imagens processadas

### Barra de Progresso
- ✅ Mostra progresso do redimensionamento de cada imagem
- ✅ Exibe status ao adicionar arquivos ao ZIP
- ✅ Indica percentual de compactação em tempo real

## 🔐 Segurança

Este projeto implementa múltiplas camadas de segurança para proteção contra ataques:

### Proteções Implementadas
- **Helmet**: Headers de segurança HTTP (CSP, HSTS, XSS Protection)
- **Rate Limiting**: Proteção contra ataques de força bruta
  - Login: Máximo 5 tentativas em 15 minutos
  - Geral: Máximo 100 requisições por minuto
- **Validação de Inputs**: Sanitização e validação rigorosa com express-validator
- **Proteção CSRF**: Proteção contra Cross-Site Request Forgery
- **Sessões Seguras**: Cookies httpOnly, sameSite strict, secret forte
- **Limites de Payload**: Máximo 10MB para uploads
- **Content Security Policy**: Restrições de scripts e recursos externos

### Configuração de Segurança

Recomenda-se configurar as seguintes variáveis de ambiente:

```bash
SESSION_SECRET=sua_chave_secreta_aqui_minimo_32_caracteres
NODE_ENV=production
```

**Importante**: Use uma chave secreta forte e única para `SESSION_SECRET` em produção.
