#!/bin/bash

echo "🚀 Preparando pacote para VertraCloud.app..."

# Limpar pacotes anteriores
rm -f orbitalbot-vertracloud*.tar.gz

# Criar diretório temporário
rm -rf /tmp/vertracloud-deploy
mkdir -p /tmp/vertracloud-deploy

# Copiar arquivos necessários
echo "📦 Copiando arquivos..."
cp -r dist /tmp/vertracloud-deploy/
cp package.json /tmp/vertracloud-deploy/
cp package-lock.json /tmp/vertracloud-deploy/
cp vertracloud.config /tmp/vertracloud-deploy/
cp vertracloud.json /tmp/vertracloud-deploy/

# Criar README para VertraCloud
cat > /tmp/vertracloud-deploy/README-VERTRACLOUD.md << 'INNEREOF'
# 🚀 OrbitalBot - Deploy no VertraCloud

## 📋 Variáveis de Ambiente Necessárias

Configure estas variáveis no painel do VertraCloud:

```bash
NODE_ENV=production
PORT=80
DISCORD_CLIENT_ID=seu_client_id_aqui
DISCORD_CLIENT_SECRET=seu_client_secret_aqui
DISCORD_BOT_TOKEN=seu_bot_token_aqui
SESSION_SECRET=gere_um_secret_seguro_aqui
```

## 🔧 Comandos

**Build Command:**
```bash
npm install --production
```

**Start Command:**
```bash
npm start
```

ou

```bash
node dist/index.js
```

## 📞 Configuração Discord OAuth

1. Acesse: https://discord.com/developers/applications
2. Selecione sua aplicação
3. OAuth2 → Redirects → Add Redirect
4. Cole: `https://SEU-DOMINIO.vertraweb.app/api/auth/callback`
5. Save Changes

## ✅ Verificação

Após deploy, acesse:
- `https://SEU-DOMINIO.vertraweb.app/` - Página principal
- `https://SEU-DOMINIO.vertraweb.app/api/auth/debug` - Debug de configuração

INNEREOF

# Criar arquivo .vertracloudignore
cat > /tmp/vertracloud-deploy/.vertracloudignore << 'INNEREOF'
node_modules/
.git/
.replit
replit.nix
*.log
.env
.env.*
src/
client/
shared/server/
*.md
!README-VERTRACLOUD.md
INNEREOF

# Criar pacote
echo "📦 Criando arquivo .tar.gz..."
cd /tmp/vertracloud-deploy
tar -czf /tmp/orbitalbot-vertracloud-production.tar.gz .

# Mover para o projeto
mv /tmp/orbitalbot-vertracloud-production.tar.gz /home/runner/workspace/

# Informações do pacote
cd /home/runner/workspace
echo ""
echo "✅ Pacote criado com sucesso!"
echo "📦 Arquivo: orbitalbot-vertracloud-production.tar.gz"
echo "📏 Tamanho: $(du -h orbitalbot-vertracloud-production.tar.gz | cut -f1)"
echo ""
echo "📋 Conteúdo:"
tar -tzf orbitalbot-vertracloud-production.tar.gz | head -20
echo ""
echo "🎯 Pronto para upload no VertraCloud!"
