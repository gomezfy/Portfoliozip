# ✅ DEPLOY NO VERTRACLOUD - SEM PRECISAR EXTRAIR (CORRIGIDO)

## 🎯 Solução Rápida

Você **NÃO precisa extrair** o arquivo `.tar.gz` localmente!

O VertraCloud faz tudo automaticamente. Siga abaixo:

---

## 🚀 Passo-a-Passo (Simples!)

### 1️⃣ Baixe o Arquivo
```
orbitalbot-vertracloud-fixed.tar.gz
```
⚠️ **Use o arquivo `-fixed`** (contém correção de cookies!)

### 2️⃣ Acesse VertraCloud
- Vá para seu painel
- Clique em **"New Application"**
- Escolha **Node.js**

### 3️⃣ Upload do Arquivo
- Clique em **"Upload"**
- Selecione: `orbitalbot-vertracloud-fixed.tar.gz`
- VertraCloud **extrai automaticamente**

### 4️⃣ Configure as Variáveis

No dashboard, vá para **Environment Variables**:

```
NODE_ENV=production
PORT=80
DISCORD_CLIENT_ID=1442240168777224443
DISCORD_CLIENT_SECRET=MIsqPCwRoWcr_sMr_yxtja__vNeOFhIV
SESSION_SECRET=8YSGOBk4xZUXV3ywCgvlXoDmNuQ6TMBrxo2YePIHSB4DfdZxH2Xq8vjCnOtfcH9
```

### 5️⃣ Configure Build Command

**Build Script:**
```bash
tar -xzf orbitalbot-vertracloud-fixed.tar.gz && npm install --production
```

**Start Command:**
```bash
npm start
```

### 6️⃣ Configure Domínio
- Vá para **Domains**
- Associe seu domínio (ex: `random-d47fd5jpe3zn2.vertraweb.app`)
- SSL: ✅ Ativado (obrigatório!)

### 7️⃣ Configurar Discord
- Acesse: https://discord.com/developers/applications
- OAuth2 → Redirects → Add Redirect
- Cole: `https://SEU-DOMINIO.vertraweb.app/api/auth/callback`
- Save Changes

### 8️⃣ Deploy!
- Clique em **"Deploy"**
- Aguarde 2-5 minutos

---

## ✅ Teste Após Deploy

```
https://SEU-DOMINIO.vertraweb.app/api/auth/debug
```

Deve retornar JSON com `"detectedProtocol": "https"` ✅

---

## 🔧 O Que Foi Corrigido

**Problema:** Cookies não persistiam após login  
**Solução:** Configuração de cookies ajustada para `sameSite: 'none'` e `secure: true`

Agora o login funciona perfeitamente! 🎉

---

## 🎉 Pronto!

Sua aplicação estará rodando em:
```
https://SEU-DOMINIO.vertraweb.app
```

---

**IMPORTANTE:** Você não precisa fazer nada no seu computador, tudo funciona diretamente no VertraCloud!
