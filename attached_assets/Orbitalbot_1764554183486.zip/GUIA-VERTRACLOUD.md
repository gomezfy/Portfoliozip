# 🚀 Guia Completo - Deploy OrbitalBot no VertraCloud.app

## ✅ Status do Projeto

- ✅ Aplicação funcionando localmente
- ✅ Build otimizado criado
- ✅ Pacote para VertraCloud pronto
- ✅ Chave de API VertraCloud configurada

---

## 📦 Arquivo para Upload

**Nome:** `orbitalbot-vertracloud-production.tar.gz`  
**Tamanho:** 384KB  
**Localização:** Raiz do projeto Replit

---

## 🔑 Chave de API VertraCloud

Sua chave de API já está configurada:
```
95e55ec312a8ca202b72e73295136b52ba8a7d32e48848188106080dbcf79d43
```

---

## 📋 Passo a Passo Completo

### 1️⃣ Baixar o Pacote

1. No Replit, clique nos 3 pontos ao lado de `orbitalbot-vertracloud-production.tar.gz`
2. Selecione **"Download"**
3. Salve o arquivo no seu computador

### 2️⃣ Acessar o VertraCloud

1. Acesse: https://vertracloud.app
2. Faça login na sua conta
3. Vá para o painel de aplicações

### 3️⃣ Criar Nova Aplicação

1. Clique em **"New Application"** ou **"Nova Aplicação"**
2. Escolha o tipo: **Node.js**
3. Faça upload do arquivo `orbitalbot-vertracloud-production.tar.gz`

### 4️⃣ Configurar Comandos

**Build Command:**
```bash
npm install --production
```

**Start Command:**
```bash
npm start
```

### 5️⃣ Configurar Variáveis de Ambiente

No painel do VertraCloud, adicione estas variáveis:

#### Obrigatórias:

```env
NODE_ENV=production
PORT=80
SESSION_SECRET=8YSGOBk4xZUXV3ywCgvlXoDmNuQ6TMBrxo2YePIHSB4DfdZxH2Xq8vjCnOtfcH9
```

#### Discord (você precisa preencher com seus dados):

```env
DISCORD_CLIENT_ID=seu_client_id_do_discord
DISCORD_CLIENT_SECRET=seu_client_secret_do_discord
DISCORD_BOT_TOKEN=seu_bot_token_do_discord
```

**Como obter essas informações do Discord:**

1. Acesse: https://discord.com/developers/applications
2. Selecione ou crie sua aplicação Discord
3. Vá em **OAuth2** → copie o **Client ID** e **Client Secret**
4. Vá em **Bot** → copie o **Token**

### 6️⃣ Configurar Domínio

1. No VertraCloud, vá para **Domains** ou **Domínios**
2. Seu domínio será algo como: `seu-app-xyz123.vertraweb.app`
3. Certifique-se que **SSL/HTTPS está ativado** ✅

### 7️⃣ Configurar Redirect URI no Discord

**MUITO IMPORTANTE!**

1. Volte para: https://discord.com/developers/applications
2. Selecione sua aplicação
3. Vá em **OAuth2** → **Redirects**
4. Clique em **"Add Redirect"**
5. Cole **EXATAMENTE** (substituindo pelo SEU domínio):
   ```
   https://seu-app-xyz123.vertraweb.app/api/auth/callback
   ```
6. Clique em **"Save Changes"**

### 8️⃣ Fazer o Deploy

1. Revise todas as configurações
2. Clique em **"Deploy"** ou **"Implantar"**
3. Aguarde 2-5 minutos para o deploy completar

---

## ✅ Testar se Está Funcionando

### 1. Verificar Configuração

Abra no navegador:
```
https://seu-app-xyz123.vertraweb.app/api/auth/debug
```

Você deve ver algo como:
```json
{
  "detectedProtocol": "https",
  "detectedHost": "seu-app-xyz123.vertraweb.app",
  "redirectUri": "https://seu-app-xyz123.vertraweb.app/api/auth/callback",
  "DISCORD_CLIENT_ID": "configurado"
}
```

### 2. Testar o Login

1. Acesse: `https://seu-app-xyz123.vertraweb.app/`
2. Clique no botão **"Conectar com Discord"**
3. Autorize a aplicação no Discord
4. Você deve ser redirecionado para o dashboard
5. **Atualize a página (F5)** - deve continuar logado ✅

---

## 🔧 Estrutura do Projeto

```
orbitalbot-vertracloud-production.tar.gz
├── dist/
│   ├── index.js (servidor)
│   └── public/ (frontend)
│       ├── index.html
│       └── assets/
│           ├── index-CMdU9qXc.css
│           └── index-DhhkeOtc.js
├── package.json
├── package-lock.json
├── vertracloud.config
└── README-VERTRACLOUD.md
```

---

## ❌ Problemas Comuns e Soluções

### Problema: "redirect_uri_mismatch"

**Causa:** A URL de redirect no Discord não corresponde ao seu domínio

**Solução:**
1. Verifique o domínio exato no VertraCloud
2. Adicione EXATAMENTE no Discord: `https://SEU-DOMINIO/api/auth/callback`
3. Salve as mudanças no Discord

### Problema: "Page Not Found" ou "404"

**Causa:** Deploy ainda não completou ou domínio não associado

**Solução:**
1. Aguarde 5 minutos para propagação
2. Verifique se o domínio está associado corretamente
3. Verifique se SSL está ativado

### Problema: "Session não persiste" (logout automático)

**Causa:** Configuração de cookies (já corrigido no pacote!)

**Solução:** Já está corrigido no pacote. Os cookies usam `sameSite: 'none'` e `secure: true`

### Problema: "CORS Error"

**Causa:** HTTPS não está ativado

**Solução:** Ative SSL/HTTPS no painel do VertraCloud

### Problema: "Internal Server Error"

**Causa:** Variáveis de ambiente não configuradas

**Solução:** Verifique se TODAS as 6 variáveis estão configuradas corretamente

---

## 📊 Recursos da Aplicação

Após o deploy bem-sucedido, você terá acesso a:

- 📊 **Dashboard** - Estatísticas em tempo real do bot
- 🖥️ **Servidores** - Lista de servidores conectados
- ⚙️ **Comandos** - Gerenciamento de comandos do bot
- 📝 **Logs** - Registro de atividades
- ⚙️ **Configurações** - Configurações do bot e OAuth

---

## 🎯 Checklist Final

Antes de fazer o deploy, certifique-se:

- [ ] Arquivo `orbitalbot-vertracloud-production.tar.gz` baixado
- [ ] Conta no VertraCloud criada
- [ ] Aplicação Discord criada e configurada
- [ ] Client ID, Client Secret e Bot Token copiados
- [ ] Nova aplicação Node.js criada no VertraCloud
- [ ] Build command configurado: `npm install --production`
- [ ] Start command configurado: `npm start`
- [ ] 6 variáveis de ambiente adicionadas
- [ ] Domínio associado e SSL ativado
- [ ] Redirect URI adicionada no Discord
- [ ] Deploy iniciado
- [ ] Testado endpoint `/api/auth/debug`
- [ ] Login com Discord funcionando
- [ ] Sessão persistindo após F5

---

## 🎉 Pronto!

Seu bot Discord **OrbitalBot** estará rodando em produção no VertraCloud! 🚀

### URLs Importantes:

- **Sua aplicação:** `https://seu-app-xyz123.vertraweb.app`
- **Discord Developers:** https://discord.com/developers/applications
- **VertraCloud Dashboard:** https://vertracloud.app/dashboard
- **Docs VertraCloud:** https://docs.vertracloud.app

---

## 🔧 Correções Aplicadas Nesta Versão

### Cookie Session Fix (v1.0.3)
- ✅ Corrigido problema onde Set-Cookie header não era enviado
- ✅ Forçada a criação do cookie manualmente quando necessário
- ✅ Cookies agora persistem corretamente após o login
- ✅ Teste realizado: Login → Atualizar página (F5) → Mantém sessão ✅

---

**Última atualização:** 24 de Novembro de 2025  
**Versão do pacote:** 1.0.3 (Otimizado com Session Cookie Fix)  
**Status:** ✅ Production Ready - Testado e Validado
