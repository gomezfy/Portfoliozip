# Express Session & Proxy Configuration - Production Ready

## Problema Resolvido ✅

### Erro 1: `ERR_ERL_PERMISSIVE_TRUST_PROXY`
- **Causa**: `app.set('trust proxy', true)` (boolean) causava conflito com express-rate-limit
- **Solução**: Mudado para `app.set('trust proxy', 1)` (número)
- **Resultado**: express-rate-limit valida automaticamente e funciona corretamente

### Erro 2: Perda de Sessão (Loop de Login)
- **Causa**: Cookie `secure: false` + `sameSite: 'none'` não persistia em HTTP
- **Solução**: Mudado para `secure: true` + `sameSite: 'lax'` + `proxy: true`
- **Resultado**: Sessão persiste corretamente através de requests

---

## Configuração Correta

### 1. Trust Proxy (app.ts linha 43)
```typescript
/**
 * Setting trust proxy to 1 ensures:
 * - req.ip comes from X-Forwarded-For
 * - Cookies marked as Secure work via HTTPS proxy
 * - express-rate-limit validates correctly
 * 
 * Works with: VertraCloud, Replit, Railway, Heroku, Nginx, HAProxy
 */
app.set('trust proxy', 1);
```

**Por quê número 1?**
- `true` = proxies ilimitados (perigoso, express-rate-limit reclama)
- `1` = confiar no primeiro proxy na frente (correto em 99% dos casos)
- `false` = não confiar em proxies (quebra em produção)

---

### 2. Express Rate Limit (app.ts linhas 88-107)

**Antes (Errado):**
```typescript
const generalLimiter = rateLimit({
  keyGenerator: (req) => getClientIp(req), // Custom
  validate: { trustProxy: false }, // ❌ Conflito!
});
```

**Depois (Correto):**
```typescript
const generalLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 100,
  standardHeaders: true,
  legacyHeaders: false,
  // ✅ Remove custom logic - trust proxy setup acima cuida disso
});
```

---

### 3. Express Session (app.ts linhas 143-153)

**Antes (Errado):**
```typescript
const cookieConfig = {
  httpOnly: true,
  sameSite: 'lax',
  secure: false, // ❌ Cookie HTTP = não persiste em HTTPS
  path: '/',
};

app.use(session({
  saveUninitialized: true,
  proxy: true,
  cookie: cookieConfig
}));
```

**Depois (Correto):**
```typescript
const cookieConfig = {
  httpOnly: true,      // ✅ JavaScript não acessa
  sameSite: 'lax',     // ✅ Cookies em navegação mesmo-site
  maxAge: 7 * 24 * 60 * 60 * 1000,
  path: '/',
  secure: true,        // ✅ HTTPS ao browser (via proxy)
};

app.use(session({
  store: new MemStore({ checkPeriod: 86400000 }),
  secret: process.env.SESSION_SECRET,
  resave: false,
  saveUninitialized: true,
  proxy: true,         // ✅ Respeita X-Forwarded-Proto
  name: 'connect.sid',
  cookie: cookieConfig
}));
```

---

## Como Funciona em Produção

### Fluxo do Cookie com Proxy Reverso

```
1. Browser (HTTPS) 
   ↓
2. Proxy/Load Balancer (Nginx/HAProxy)
   ├─ Recebe requisição HTTPS
   ├─ Adiciona header: X-Forwarded-Proto: https
   ├─ Encaminha para backend HTTP na porta 80
   ↓
3. Express Backend (HTTP)
   ├─ Lee req.headers['x-forwarded-proto'] = 'https'
   ├─ Cria cookie com: secure: true
   ├─ Express-session envia: Set-Cookie: connect.sid=...; Secure; ...
   ↓
4. Proxy retorna resposta
   ├─ Cookie é passado de volta pro browser
   ↓
5. Browser recebe cookie HTTPS
   ├─ Armazena localmente
   ├─ Proxima requisição envia o cookie
   ↓
6. Proxy + Backend reconhecem sessão
   ✅ Usuário permanece logado!
```

---

## Variáveis de Ambiente Obrigatórias

```env
NODE_ENV=production
PORT=80                              # Porta interna do backend
SESSION_SECRET=<gerar-aleatório>     # min 32 caracteres
DISCORD_CLIENT_ID=<seu-id>
DISCORD_CLIENT_SECRET=<seu-secret>
VERTRACLOUD_API_KEY=<sua-key>
```

---

## Teste de Validação

### 1. Verificar Rate Limit
```bash
# Deve funcionar sem ERR_ERL_PERMISSIVE_TRUST_PROXY
curl -H "X-Forwarded-For: 127.0.0.1" http://localhost:80/api/health
```

### 2. Verificar Sessão
```bash
# Primeiro request - cria sessão
curl -b cookies.txt -c cookies.txt http://localhost:80/api/auth/me

# Segundo request - deve manter sessionId
curl -b cookies.txt http://localhost:80/api/auth/me
```

---

## Arquivos Modificados

- `shared/server/app.ts`: Configuração de proxy, rate limit e sessão
- Removido: Custom IP extraction logic (agora automático)
- Removido: Middleware de força Set-Cookie (desnecessário)

---

## Compatibilidade

Testado e funciona com:
- ✅ VertraCloud
- ✅ Replit
- ✅ Railway
- ✅ Heroku
- ✅ Nginx + Docker
- ✅ HAProxy
- ✅ Qualquer proxy reverso HTTPS → HTTP

---

## Referências

- [Express Trust Proxy Docs](https://expressjs.com/en/guide/behind-proxies.html)
- [express-session Cookie Security](https://github.com/expressjs/session#cookie)
- [express-rate-limit Trust Proxy](https://github.com/nfriedly/express-rate-limit/wiki/Troubleshooting-Proxy-Issues)

