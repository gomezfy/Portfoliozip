# 🚀 OrbitalBot - Guia de Deploy VertraCloud

## 📦 Arquivo de Deploy
- **Nome:** `orbitalbot-vertracloud-production.tar.gz`
- **Tamanho:** 383KB
- **Contém:** Build completo pronto para produção

## 🔧 Variáveis de Ambiente Necessárias

Configure essas 6 variáveis no VertraCloud:

```env
NODE_ENV=production
PORT=80
DISCORD_CLIENT_ID=1442240168777224443
DISCORD_CLIENT_SECRET=MIsqPCwRoWcr_sMr_yxtja__vNeOFhIV
SESSION_SECRET=8YSGOBk4xZUXV3ywCgvlXoDmNuQ6TMBrxo2YePIHSB4DfdZxH2Xq8vjCnOtfcH9
VERTRACLOUD_API_KEY=259aa3cef642460e4cf18fbcb5a877612f8e7cd2ee3793b03f451e2633af145a
```

## 📝 Passos de Deployment

### 1. Upload do Arquivo
```bash
# No painel VertraCloud
- Selecione: orbitalbot-vertracloud-production.tar.gz
- Extraia para /app ou seu diretório de aplicação
```

### 2. Instalar Dependências
```bash
cd /app
npm install --production
```

### 3. Configurar Variáveis (painel VertraCloud)
- Adicione as 6 variáveis listadas acima
- Salve

### 4. Iniciar Aplicação
```bash
# Automático ou manual:
npm start
```

## ✅ O que Está Incluído

- ✅ Build otimizado (45.9KB server + 1MB frontend)
- ✅ ESM/CommonJS compatível
- ✅ Sessão persistente com cookies
- ✅ Discord OAuth integrado
- ✅ Rate limiting seguro para produção
- ✅ Helmet & CORS configurado

## 🧪 Teste Rápido

1. Acesse: `https://seu-app.vertraweb.app`
2. Clique: "Conectar com Discord"
3. Autorize no Discord
4. Deve aparecer: Dashboard do bot
5. Atualizar página (F5): Deve manter logado

## 🆘 Troubleshooting

### "Erro na autenticação Discord"
- Verifique DISCORD_CLIENT_ID e DISCORD_CLIENT_SECRET
- Confirme que a app Discord está criada em developer.discord.com

### "Cookie não está sendo salvo"
- Confira se está usando HTTPS
- SESSION_SECRET precisa estar setado

### "Erro de rate limit"
- Normal em primeira vez. Rate limit reseta a cada 15 min

## 📊 Monitoramento

Logs do servidor estarão disponíveis no painel VertraCloud. Procure por:
- "Production server listening on port 80" → OK
- Erros de conexão Discord → Verificar credenciais
- "Auth check" → Logs de autenticação

---
**Status:** Pronto para Deploy! 🎉
