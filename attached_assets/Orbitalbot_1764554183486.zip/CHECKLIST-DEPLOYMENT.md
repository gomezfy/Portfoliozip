# ✅ Checklist de Deployment - VertraCloud.app

## 📦 Arquivo Pronto para Deploy

**Nome:** `orbitalbot-vertracloud-production.tar.gz`
**Tamanho:** 383KB
**Versão:** 1.0.3
**Status:** ✅ Production Ready

---

## 🎯 Passo a Passo Rápido

### Fase 1: Preparação (5 min)

- [ ] Ter conta no VertraCloud.app
- [ ] Ter aplicação Discord criada
- [ ] Ter Discord Client ID, Client Secret e Bot Token
- [ ] Gerar SESSION_SECRET seguro (64+ caracteres)

### Fase 2: Upload (5 min)

1. [ ] Acessar VertraCloud dashboard
2. [ ] New Application → Node.js
3. [ ] Upload: `orbitalbot-vertracloud-production.tar.gz`

### Fase 3: Configuração (10 min)

1. [ ] Build Command: `npm install --production`
2. [ ] Start Command: `npm start`

### Fase 4: Variáveis de Ambiente (5 min)

Adicione estas 6 variáveis no painel:

```
NODE_ENV                 = production
PORT                     = 80
SESSION_SECRET          = [gere um valor seguro]
DISCORD_CLIENT_ID       = [seu client ID]
DISCORD_CLIENT_SECRET   = [seu client secret]
DISCORD_BOT_TOKEN       = [seu bot token]
```

### Fase 5: Discord OAuth (5 min)

1. [ ] https://discord.com/developers/applications
2. [ ] Selecione sua app
3. [ ] OAuth2 → Redirects → Add: `https://SEU-DOMINIO/api/auth/callback`
4. [ ] Save Changes

### Fase 6: Deploy (2-5 min)

1. [ ] Clique Deploy
2. [ ] Aguarde conclusão
3. [ ] Acesse: `https://SEU-DOMINIO/api/auth/debug`
4. [ ] Teste login: `https://SEU-DOMINIO/`

---

## ✨ Testes Pós-Deploy

### Test 1: Verificar Configuração
```
Acessar: https://SEU-DOMINIO/api/auth/debug

Esperado:
- detectedProtocol: "https"
- redirectUri contém seu domínio
- DISCORD_CLIENT_ID: "configurado"
```

### Test 2: Login com Discord
```
1. Clique "Conectar com Discord"
2. Autorize
3. Redireciona para dashboard ✅
4. Atualize página (F5)
5. Continua logado ✅ (NEW!)
```

### Test 3: Verificar Cookies
```
DevTools (F12) → Application → Cookies
- connect.sid deve existir
- SameSite: None
- Secure: ✓
- HttpOnly: ✓
```

---

## ⚡ Performance

- **Tamanho do pacote:** 383KB
- **Tempo de startup:** < 2 segundos
- **Memória:** ~500MB recomendado
- **CPU:** 1 core mínimo

---

## 🆘 Troubleshooting

| Problema | Solução |
|----------|---------|
| redirect_uri_mismatch | Verify URL no Discord matches seu domínio exato |
| Page not found | Aguarde 5 min, SSL deve estar ativo |
| Session não persiste | CORRIGIDO na v1.0.3! Cookie agora funciona |
| CORS error | Ative HTTPS no VertraCloud |
| Internal Server Error | Verifique se TODAS as 6 variáveis estão set |

---

## 📞 Suporte

- **VertraCloud Docs:** https://docs.vertracloud.app
- **Discord Developers:** https://discord.com/developers
- **HTTP Status Codes:** Verifique nos logs do VertraCloud

---

## ✅ Versão Atual

- **v1.0.3** - Session Cookie Fix
- **Build:** Production Optimized
- **Ready:** YES ✅

