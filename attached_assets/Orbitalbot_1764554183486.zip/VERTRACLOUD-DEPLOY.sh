#!/bin/bash
# Script completo para deploy no VertraCloud

echo "🚀 OrbitalBot Deployment Script"
echo "================================"

# 1. Extract
echo "📦 Extracting package..."
tar -xzf orbitalbot-vertracloud-production.tar.gz

# 2. Install dependencies
echo "📥 Installing dependencies..."
npm install --production

# 3. Verify build
echo "✅ Verifying build..."
if [ ! -f "dist/index.js" ]; then
  echo "❌ Build missing! Running npm run build..."
  npm run build
fi

# 4. Environment verification
echo "🔐 Checking environment variables..."
required_vars=("NODE_ENV" "PORT" "SESSION_SECRET" "DISCORD_CLIENT_ID" "DISCORD_CLIENT_SECRET" "VERTRACLOUD_API_KEY")
for var in "${required_vars[@]}"; do
  if [ -z "$(eval echo \$$var)" ]; then
    echo "❌ Missing: $var"
  else
    echo "✅ $var is set"
  fi
done

# 5. Start application
echo "🟢 Starting application..."
NODE_ENV=production PORT=80 npm start

