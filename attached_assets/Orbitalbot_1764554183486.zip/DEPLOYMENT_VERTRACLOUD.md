# 🚀 DEPLOYMENT NO VERTRACLOUD - ORBITALBOT (CORRIGIDO)

## ✅ PROBLEMA DE COOKIES RESOLVIDO

**Arquivo para upload:** `orbitalbot-vertracloud-fixed.tar.gz` (1.3 MB)

Este arquivo contém as correções necessárias para o login funcionar corretamente no VertraCloud.

---

## 📋 Pré-requisitos

- ✅ Conta no VertraCloud.com
- ✅ Domínio do VertraCloud (ex: `random-d47fd5jpe3zn2.vertraweb.app`)
- ✅ Discord Application configurada

---

## 🔑 Variáveis de Ambiente Necessárias

Configure **EXATAMENTE** estas variáveis no VertraCloud:

```bash
NODE_ENV=production
PORT=80
DISCORD_CLIENT_ID=1442240168777224443
DISCORD_CLIENT_SECRET=MIsqPCwRoWcr_sMr_yxtja__vNeOFhIV
SESSION_SECRET=8YSGOBk4xZUXV3ywCgvlXoDmNuQ6TMBrxo2YePIHSB4DfdZxH2Xq8vjCnOtfcH9
```

**Como adicionar (uma por uma):**
- Nome: `NODE_ENV` → Valor: `production`
- Nome: `PORT` → Valor: `80`
- Nome: `DISCORD_CLIENT_ID` → Valor: `1442240168777224443`
- Nome: `DISCORD_CLIENT_SECRET` → Valor: `MIsqPCwRoWcr_sMr_yxtja__vNeOFhIV`
- Nome: `SESSION_SECRET` → Valor: `8YSGOBk4xZUXV3ywCgvlXoDmNuQ6TMBrxo2YePIHSB4DfdZxH2Xq8vjCnOtfcH9`

---

## 📦 Arquivo de Deployment

O arquivo `orbitalbot-vertracloud-fixed.tar.gz` contém:
- ✅ Build otimizado com correção de cookies (dist/)
- ✅ Servidor Express (dist/index.js)
- ✅ Arquivos estáticos (dist/public/)
- ✅ package.json

---

## 🎯 Passo-a-Passo no VertraCloud

### 1️⃣ Fazer Upload do Arquivo

1. Acesse seu painel do VertraCloud
2. Vá para **Applications** → **New Application**
3. Escolha **Node.js**
4. Upload do arquivo: `orbitalbot-vertracloud-fixed.tar.gz`

### 2️⃣ Configurar Variáveis

No dashboard do VertraCloud, vá em **Environment Variables** e adicione as 5 variáveis acima.

### 3️⃣ Configurar Build Command

**Build Command:**
```bash
tar -xzf orbitalbot-vertracloud-fixed.tar.gz && npm install --production
```

### 4️⃣ Configurar Start Command

**Start Command:**
```bash
npm start
```

**Ou:**
```bash
node dist/index.js
```

### 5️⃣ Associar Domínio

1. Vá para **Domains**
2. Associe seu domínio (ex: `random-d47fd5jpe3zn2.vertraweb.app`)
3. Certifique-se que **SSL está ativado** (obrigatório!)

### 6️⃣ Configurar Discord Developer Portal

⚠️ **IMPORTANTE:** Configure a Redirect URI no Discord!

1. Acesse: https://discord.com/developers/applications
2. Selecione sua aplicação (ID: `1442240168777224443`)
3. Vá em **OAuth2** → **Redirects**
4. Clique em **"Add Redirect"**
5. Cole **EXATAMENTE** esta URL (com SEU domínio):
   ```
   https://random-d47fd5jpe3zn2.vertraweb.app/api/auth/callback
   ```
   ⚠️ Substitua `random-d47fd5jpe3zn2.vertraweb.app` pelo domínio que o VertraCloud te forneceu!

6. Clique em **"Save Changes"**

### 7️⃣ Iniciar Aplicação

Clique em **Deploy** e aguarde 2-5 minutos

---

## ✅ Verificar Se Está Rodando

### 1. Verificar Configuração

Acesse no navegador:
```
https://SEU-DOMINIO.vertraweb.app/api/auth/debug
```

Você deve ver:
```json
{
  "detectedProtocol": "https",
  "detectedHost": "SEU-DOMINIO.vertraweb.app",
  "redirectUri": "https://SEU-DOMINIO.vertraweb.app/api/auth/callback",
  "DISCORD_CLIENT_ID": "configurado"
}
```

### 2. Testar o Login

1. Acesse `https://SEU-DOMINIO.vertraweb.app/`
2. Clique em **"Conectar com Discord"**
3. Autorize no Discord
4. Você deve voltar para o dashboard
5. **Atualize a página (F5)** - deve manter logado! ✅
6. ✅ Pronto!

---

## 🔍 Verificar Cookies no Navegador

Abra DevTools (F12):
1. Vá em **Application** → **Cookies**
2. Procure por: `connect.sid`
3. Deve ter:
   - `SameSite`: None
   - `Secure`: ✓
   - `HttpOnly`: ✓

---

## ❌ Problemas Comuns

### Problema: "redirect_uri_mismatch"
- **Solução:** Verifique se adicionou a URL correta no Discord Developer Portal
- A URL deve ser EXATAMENTE: `https://SEU-DOMINIO/api/auth/callback`

### Problema: "Login retorna para login"
- **Solução:** Já corrigido! Use o arquivo `orbitalbot-vertracloud-fixed.tar.gz`
- Certifique-se que `SESSION_SECRET` está configurado

### Problema: "CORS error"
- **Solução:** Certifique-se que SSL/HTTPS está ativado no VertraCloud

### Problema: "Session não persiste"
- **Solução:** Já corrigido no novo build! Os cookies agora usam `sameSite: 'none'`

### Problema: "Page not found"
- Verifique se domínio está associado corretamente
- Verifique se SSL está ativado
- Aguarde 5 minutos para propagação

---

## 📊 O Que Foi Corrigido

**Problema anterior:** Cookies não eram enviados/mantidos após login.

**Solução aplicada:**
```javascript
// Configuração de cookies corrigida:
cookie: {
  sameSite: 'none',  // Permite cookies cross-site
  secure: true,      // Obrigatório com sameSite: 'none'
  httpOnly: true,
  path: '/'
}
```

---

## 🎉 Pronto!

Se tudo estiver configurado corretamente, sua aplicação estará rodando em:
```
https://SEU-DOMINIO.vertraweb.app
```

O login do Discord agora funciona perfeitamente! 🚀

---

**Dúvidas?** Verifique os logs do VertraCloud para detalhes específicos do erro.

**Sucesso! 🚀**
